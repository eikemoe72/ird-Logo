<?php
error_reporting(0);
header('Content-Type: application/json');
include('db_config.php'); 

$min = isset($_GET['min_case']) ? (int)$_GET['min_case'] : 0;
$max = isset($_GET['max_case']) ? (int)$_GET['max_case'] : 0;

$sql = "SELECT * FROM regular_data WHERE CAST(case_number AS UNSIGNED) BETWEEN $min AND $max";
$result = mysqli_query($conn, $sql);

if (!$result) {
    echo json_encode(["error" => mysqli_error($conn)]);
    exit;
}

$groupedData = [];
while($row = mysqli_fetch_assoc($result)) {
    $caseNo = $row['case_number'];
    
    if (!isset($groupedData[$caseNo])) {
        $groupedData[$caseNo] = [
            'case_number' => $row['case_number'],
            'officer_name' => $row['officer_name'],
            'taxYear' => $row['taxYear'],
            'state_name' => $row['state_name'] ?? ($row['state'] ?? ''),
            'township_name' => $row['township_name'] ?? ($row['township'] ?? ''),
            'it_select' => $row['it_select'],
            'it_no' => $row['it_no'],
            'ct1_select_real' => $row['ct1_select_real'],
            'ct1_no_real' => $row['ct1_no_real'],
            'ct2_select_real' => $row['ct2_select_real'],
            'ct2_no_real' => $row['ct2_no_real'],
            'taxpayer_name' => $row['taxpayer_name'],
            'address' => $row['address'],
            'businessType1' => $row['businessType1'], // JavaScript က 'business_type' နဲ့ ခေါ်နေလို့ ပြင်လိုက်ပါတယ်
            'records' => [] 
        ];
    }
    
        $groupedData[$caseNo]['records'][] = [
        'rowYear1'    => $row['rowYear1'],  
        'income1'     => $row['income1'],    
        'income_tax1' => $row['income_tax1'],
        'sale_income1'=> $row['sale_income1'],
        'ct1'         => $row['ct1'], // comma ပါရမည်

        'rowYear2'    => $row['rowYear2'],  
        'income2'     => $row['income2'],    
        'income_tax2' => $row['income_tax2'],
        'sale_income2'=> $row['sale_income2'],
        'ct2'         => $row['ct2'], // comma ပါရမည်

        'rowYear3'    => $row['rowYear3'],  
        'income3'     => $row['income3'],    
        'income_tax3' => $row['income_tax3'],
        'sale_income3'=> $row['sale_income3'],
        'ct3'         => $row['ct3'], // comma ပါရမည်

        'salesAmount1' => $row['salesAmount1'],
        'ct1tax'       => $row['ct1tax'],
        'netProfit'    => $row['netProfit'],
        'payableIncomeTax' => $row['payableIncomeTax'],
        'salesAmount2' => $row['salesAmount2'],
        'ct2tax'       => $row['ct2tax']
    ];
}
echo json_encode(array_values($groupedData));
// ဤနေရာတွင် စာသားအပိုများ မပါရပါ
?>