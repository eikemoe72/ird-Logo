<?php
session_start();
include 'db_config.php';

// Login Check
if (!isset($_SESSION['user_name'])) {
    header("Location: Login_Form.php");
    exit();
}

// ၂။ လက်ရှိ Login ဝင်ထားသူ၏ ID ကို အသုံးပြုပြီး ဘဏ်အချက်အလက် ဆွဲယူခြင်း
$u_id = $_SESSION['user_id'] ?? 0;
$bank_township = '...............';
$md_no = '...............';
$rank_='............';

$user_role     = $_SESSION['user_role'] ?? '';
$user_state    = $_SESSION['state_name'] ?? '';
$user_township = $_SESSION['township_name'] ?? '';

if ($u_id > 0) {
    $u_query = mysqli_query($conn, "SELECT * FROM user_register WHERE id = '$u_id'");
    if ($u_row = mysqli_fetch_assoc($u_query)) {
        $bank_township = $u_row['bank_township'] ?: '...............';
        $md_no = $u_row['md_no'] ?: '...............';
        $rank = !empty($u_row['rank_']) ? $u_row['rank_'] : '...............';
        $user_state    = $u_row['state_name'] ?: $user_state;
        $user_township = $u_row['township_name'] ?: $user_township;
        $user_role     = $u_row['role'] ?: $user_role;

        $_SESSION['state_name']    = $user_state;
        $_SESSION['township_name'] = $user_township;
        $_SESSION['user_role']     = $user_role;
    }
}

function formatNumber($num) {
    return is_numeric($num) ? number_format($num) : ($num ?: '0');
}

// 🌟 🌟 🌟 [JavaScript API အတွက် JSON ထုတ်ပေးရန်] 🌟 🌟 🌟
if (isset($_GET['action']) && $_GET['action'] == 'fetch_list') {
    header('Content-Type: application/json; charset=utf-8');
    
    if ($user_role === 'super_admin') {
        $api_sql = "SELECT * FROM regular_data ORDER BY id DESC";
    } elseif ($user_role === 'state_admin') {
        $api_sql = "SELECT * FROM regular_data WHERE state_name = '$user_state' OR state = '$user_state' ORDER BY id DESC";
    } else {
        $api_sql = "SELECT * FROM regular_data WHERE township_name = '$user_township' OR township = '$user_township' ORDER BY id DESC";
    }

    $api_res = $conn->query($api_sql);
    $api_data = [];
    if ($api_res) {
        while ($api_row = $api_res->fetch_assoc()) {
            $api_row['state_name']    = $api_row['state_name'] ?? $api_row['state'] ?? '';
            $api_row['township_name'] = $api_row['township_name'] ?? $api_row['township'] ?? '';
            $api_data[] = $api_row;
        }
    }
    echo json_encode($api_data, JSON_UNESCAPED_UNICODE);
    exit();
}


$total_demand = 0;
$total_paid = 0;
$total_remaining = 0;

// Card တွက်ချက်ရန် ကနဦး Variable များ သတ်မှတ်ခြင်း
$tax_cases = 0;
$paid_cases = 0;
$remain_cases = 0;

// 🎯 ပြင်ဆင်ချက် - `totalTax1` နှင့် `paidTax1` ပေါ်မူတည်၍ ငွေရော အမှုအရေအတွက်ပါ တွက်ချက်ခြင်း
if ($user_role === 'super_admin') {
    $sql = "SELECT * FROM regular_data ORDER BY id DESC";
    $total_sql = "SELECT 
                    SUM(totalTax1) as t_demand, 
                    SUM(paidTax1) as t_paid,
                    SUM(CASE WHEN totalTax1 > 0 THEN 1 ELSE 0 END) AS tax_cases,
                    SUM(CASE WHEN paidTax1 > 0 THEN 1 ELSE 0 END) AS paid_cases,
                    SUM(CASE WHEN (totalTax1 - paidTax1) > 0 THEN 1 ELSE 0 END) AS remain_cases
                  FROM regular_data";
} 
elseif ($user_role === 'state_admin') {
    $sql = "SELECT * FROM regular_data WHERE state_name = '$user_state' ORDER BY id DESC";
    $total_sql = "SELECT 
                    SUM(totalTax1) as t_demand, 
                    SUM(paidTax1) as t_paid,
                    SUM(CASE WHEN totalTax1 > 0 THEN 1 ELSE 0 END) AS tax_cases,
                    SUM(CASE WHEN paidTax1 > 0 THEN 1 ELSE 0 END) AS paid_cases,
                    SUM(CASE WHEN (totalTax1 - paidTax1) > 0 THEN 1 ELSE 0 END) AS remain_cases
                  FROM regular_data WHERE state_name = '$user_state'";
} 
else {
    $sql = "SELECT * FROM regular_data WHERE township_name = '$user_township' ORDER BY id DESC";
    $total_sql = "SELECT 
                    SUM(totalTax1) as t_demand, 
                    SUM(paidTax1) as t_paid,
                    SUM(CASE WHEN totalTax1 > 0 THEN 1 ELSE 0 END) AS tax_cases,
                    SUM(CASE WHEN paidTax1 > 0 THEN 1 ELSE 0 END) AS paid_cases,
                    SUM(CASE WHEN (totalTax1 - paidTax1) > 0 THEN 1 ELSE 0 END) AS remain_cases
                  FROM regular_data WHERE township_name = '$user_township'";
}

$result = $conn->query($sql);
$total_res = $conn->query($total_sql);

if ($total_res && $row_total = $total_res->fetch_assoc()) {
    $total_demand    = $row_total['t_demand'] ?? 0;
    $total_paid      = $row_total['t_paid'] ?? 0;
    $total_remaining = $total_demand - $total_paid;
    
    // 💡 Card မှာ လှမ်းပြသမယ့် အမှုအရေအတွက်များ သတ်မှတ်ပေးခြင်း
    $tax_cases       = $row_total['tax_cases'] ?? 0;
    $paid_cases      = $row_total['paid_cases'] ?? 0;
    $remain_cases    = $row_total['remain_cases'] ?? 0;
}

// ဇယားထဲမှာ သုံးဖို့ Array ဆွဲထုတ်ခြင်းအပိုင်း
$data = []; 
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = $row;
    }
}
?>


<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ကုန်သွယ်လုပ်ငန်းခွန် စည်းကြပ်မှုမှတ်ပုံတင်</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <link rel="stylesheet" href="css/bootstrap.min.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/custom_style.css?v=<?php echo time(); ?>">

    
<style>
    /* ၁။ General Setup (Font & Body) */
    @import url('https://fonts.googleapis.com/css2?family=Pyidaungsu&display=swap');
    
 body { 
        background-color: white; 
        font-family: 'Pyidaungsu', sans-serif; 
        padding: 10px; 
    }

    /* ၂။ Dashboard & Main Table UI (Screen View Only) */
   .main-container { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 10px 30px rgba(7, 7, 7, 0.08); }
    .header-title { color: #0d6efd; font-weight: bold; border-left: 5px solid #0d6efd; padding-left: 15px; }
    
    .table-responsive {overflow-x: auto; position: relative;}
    /*.table-responsive { max-height: 70vh; overflow: auto; border: 1px solid #dee2e6; border-radius: 8px; }*/
    .table { font-size: 13px; white-space: nowrap; }
    
    /* Action Column ကို ညာဘက်အစွန်မှာ ကပ်ထားရန် */
    .sticky-action {
        position: sticky !important;
        right: 0;
        background-color: #d7e6f5 !important; /* Row အရောင်နဲ့ ကိုက်အောင် ပေးပါ */
        z-index: 2;
        box-shadow: 0px 0 0px rgba(0,0,0,0.1); /* မျဉ်းအစား shadow သုံးရင် ပိုလှပါတယ် */

        padding: 0px 5px !important; /* အပေါ်အောက် padding ကို လုံးဝဖြုတ်ချပါ */
        vertical-align: middle !important;
    }
    .sticky-action .btn {
    padding: 2px 6px !important; /* ခလုတ်ဆိုဒ်ကို သေးသေးကျစ်ကျစ်ဖြစ်စေရန် */
    font-size: 12px !important;
    line-height: 1 !important;
    margin: 2px 0; /* ခလုတ်များ ကပ်မနေစေရန် */
}

    /* Row ကို select လုပ်ထားရင် sticky cell ပါ အရောင်ပြောင်းရန် */
    .selected-row .sticky-action {
        background-color: #d1ecf1 !important;
    }
 

    /* Row တွေကို Select လုပ်တဲ့အခါ Action column အရောင်ပါ လိုက်ပြောင်းရန် */
    tr.selected-row td.sticky-action {
        background-color: #d8e0ec !important;
    }

    .table-striped > tbody > tr.selected-row > td { 
        background-color: #629df5 !important; 
        color: #000 !important;
        border-bottom: 2px solid #0d6efd !important;
    }
/* Highlight ဖြစ်စေမယ့် class */
    .highlight-row {
        background-color: #967df0 !important; /* အပြာနုရောင် */
        transition: background-color 0.2s ease;
    }

    /* Row height ကို တစ်ပြေးညီဖြစ်အောင် ထိန်းညှိခြင်း */
    #tableBody tr td {
        height: 35px !important; /* Row တိုင်းကို အမြင့် ပုံသေ သတ်မှတ်လိုက်ပါ */
        line-height: 1.2 !important;
    }

    .stat-card { border: none; border-radius: 10px; padding: 5px; color: white; display: flex;
     justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .bg-demand { background: linear-gradient(45deg, #4e73df, #224abe); }
    .bg-paid { background: linear-gradient(45deg, #1cc88a, #13855c); }
    .bg-rem { background: linear-gradient(45deg, #e74a3b, #be2617); }

    /* လုပ်ငန်းလိပ်စာ column အတွက် style */
    .address-column {
        max-width: 200px; /* သင်အလိုရှိသော အကျယ်ကို ဒီနေရာမှာ ချိန်နိုင်ပါတယ် */
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

/* Table header ကော body ကော column width ညီနေစေရန် */
#taxTable th:nth-child(10), 
#taxTable td:nth-child(10) {
    max-width: 200px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}


    /* Borders & Dividers */
    .border-all td { border: 1px solid #000 !important; } /* Table အကွက်အပြည့် လိုအပ်လျှင်သုံးရန် */
    
    .border-right-divider { border-right: 1px solid #000 !important; }
    .border-left-divider { border-left: 1px solid #000 !important; }
    .border-top-bottom {
        border-top: 1px solid #000 !important;
        border-bottom: 1px solid #000 !important;
    }

    .justify-myanmar {
        text-align: justify;
        line-height: 1.6;
    }

    .sheet-header { text-align: center; margin-bottom: 10px; }

    /* ပုံနှိပ်ထုတ်ဝေရန်အတွက် Layout ချိန်ညှိချက်များ */
    .print-container {
        border-left: 0px solid black;
        border-right: 0px solid black;

        padding: 0 !important; /* Padding အကုန်ဖြုတ်ချလိုက်ပါ */
        margin-left: 0mm !important; /* ဘယ်ဘက်ကို ထပ်တိုးချင်ရင် negative margin သုံးနိုင်ပါတယ် */
        border: none !important;
    }
    .header-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        margin-buttom: 10px;
    }
    /* ဘယ်ဖက်အပိုမျဉ်းကို ဖျက်ရန် border-left: none လုပ်ထားပါသည် */
    .header-table td {
        border: none;
        padding: 5px 0;
        vertical-align: top;
    }
    .main-content-table2 {
        width: 100%;
        margin-left: 0 !important;
        margin-right: 0 !important;
        border-collapse: collapse;
        border-left: none;
        border-right: none;
        border-top: 0px solid black;
    }
    .main-content-table {
        width: 100%;
        margin-left: 0 !important;
        margin-right: 0 !important;
        border-collapse: collapse;
        border-left: none;
        border-right: none;
        border-top: 1px solid black;
    }


    .main-content-table th, 
    .main-content-table td {
        border-left: 1px solid black;
        border-right: 1px solid black;
        padding: 5px;
    }
    /* အလယ်ကော်လံအတွက်သာ ဘယ်ညာမျဉ်း သတ်မှတ်ချက် */
    .middle-column {
        /*border-left: 2px solid black !important;
        border-right: 2px solid black !important;*/
        border: 2px solid black !important;
        padding: 5px;
    }
    /* ဘယ်အစွန်နှင့် ညာအစွန် ဆဲလ်ကွက်များတွင် ဘေးမျဉ်းမပါစေရန် */
    .outer-column {
        border-top: 2px solid black !important;
        border-bottom: 2px solid black !important;
        border-left: none !important;
        border-right: none !important;
    }
    .left_border{
        border-right: 0px solid black !important;
    }
    .right_border{
        border-left: 0px solid black !important;
    }


   
    /* အမှုတွဲပုံစံ ခလုတ်များ Grid Layout */
    .modal-btn-grid {
        display: flex;
        flex-wrap: wrap; /* တန်းစီရန် */
        justify-content: center; /* အလယ်ဗဟိုထားရန် */
        gap: 10px; /* ခလုတ်တစ်ခုနှင့်တစ်ခု အကွာအဝေး */
        padding: 5px;
    }

    /* ခလုတ်တစ်ခုချင်းစီ၏ Style */
    .modal-btn-grid .btn {
        /* Width ကို ချဲ့ရန် (တစ်တန်းလျှင် ၂ ခုနှုန်းဖြင့် အပြည့်နီးပါးဖြစ်စေရန်) */
        flex: 0 0 48%; 
        
        /* Height ကို လျှော့ရန် */
        padding: 10px 10px !important;
        min-height: 55px;
        
        /* စာသားကို ဘယ်ဘက်ကပ်ရန် */
        text-align: left !important;
        display: flex;
        align-items: center; /* စာသားကို အပေါ်အောက် အလယ်ရောက်ရန် */
        justify-content: flex-start; /* စာသားကို ဘယ်ဘက်ကပ်ရန် */
        
        font-size: 14px;
        line-height: 1.4;
        border-radius: 8px;
        white-space: normal;
        word-wrap: break-word;
    }

    /* ခလုတ်ထဲက စာသားများ ဘယ်ဘက်ကပ်နေစေရန် ထပ်ဆင့်ထိန်းညှိခြင်း */
    .modal-btn-grid .btn span, 
    .modal-btn-grid .btn i {
        text-align: left;
    }

    .header-bar {
        background-color: #0b5ed7;
        color: white;
        padding: 10px 20px;
        font-weight: bold;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    /* ၄။ Print Optimization (တစ်ခုတည်းသော Media Print) */
    @media print {

        @page {
            size: A4 portrait;
            margin: 5mm 0 5mm 0;
        }
        .print-container {
        margin-left: 0 !important;
        padding-left: 0 !important; /* စာရွက်အနားသတ် အနည်းငယ် ချန်ရန် */
        }
        body, html {
            width: 100%;
            height: auto;
            margin: 0;
            padding: 0;
        }
        body * {
            visibility: hidden;
            background-color: transparent !important;
        }
        body, .container, .main-wrapper {
        border: none !important;
        outline: none !important;
        margin: 0;
        padding: 0;
        }
            /* Table ရဲ့ အပြင်ဘောင်လိုင်းကို ဖျောက်ပြီး အတွင်းလိုင်းတွေကိုပဲ ချန်ထားခြင်း */
        table {
            border: none !important;
        }
        thead { position: sticky; top: 0;
        z-index: 10; 
        color: black; vertical-align: middle;
        border-top: 2px solid #000 !important;
        border-botton: 2px solid #000 !important;}
        .right_border{
            border-left: 2px solid black !important;
            border-right: 0px solid white !important;
        }
        .left_border{
            border-right: 2px solid black !important;
            border-left: 0px solid white !important;
        }

    /* စာမျက်နှာအသစ်မှာ စတဲ့ table cell တိုင်းကို top border ပေးခြင်း */
        .sheet-table td {
            border-top: 2px solid #000 !important;
            padding-top:20px;
        }
        /* ဒုတိယစာမျက်နှာက table row တွေမှာ အပေါ်လိုင်း အမြဲပါစေရန် */
        .sheet-table tr {
            page-break-inside: avoid;
        }

        /* ထိပ်လိုင်းနဲ့ အောက်လိုင်း (horizontal line) အတွက် */
        .border-top-bottom {
            border-top: 2px solid #000 !important;
            border-bottom: 0px solid #000 !important;
        }
        /* Print ထုတ်မယ့် အပိုင်းတစ်ခုတည်းကိုပဲ စာရွက်အပြည့်ပြပါ */
        #printableSheet, #printableSheet * {
            visibility: visible !important;
        }
        /* Container ကို စာရွက်အပြည့် ဆွဲဆန့်ခြင်း */
        #printableSheet {
            position: absolute;
            left: 0;
            top: 0;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
        }
    
       
        .order-sheet {
            width: 100% !important;
            max-width: 100% !important; /* နယ်ကုန် ဖြစ်စေရန် */
            padding: 0 !important; /* စာရွက်အနားသတ် */
            border: none !important;
            box-shadow: none !important;
            page-break-inside: avoid; /* စာမျက်နှာအလယ်မှာ မပြတ်သွားစေရန် */
        }

        .sheet-table {
            width: 100% !important;
            table-layout: fixed !important;
            margin-top: 0 !important; /* စိတ်ကြိုက် အကွာအဝေး ချိန်ညှိပါ */
        }
        .sheet-table td {
            padding: 4px;
            vertical-align: top;
            word-wrap: break-word; /* စာသားရှည်လျှင် အောက်ဆင်းရန် */
            border: none; /* Default အနေနဲ့ အကုန်ဖျောက်ထားမည် */
        }
        /* သို့မဟုတ် ဒုတိယစာမျက်နှာရဲ့ ပထမဆုံး row ကိုပဲ padding ပေးခြင်း */
        .sheet-table tr:first-child td {
            padding-top: 30px !important;
        }

         /* Modal content ထဲက Print ထုတ်မယ့်အပိုင်းကို စာရွက်အပြည့်ဆွဲဆန့်ပါ */
        #orderSheetModal, 
        #orderSheetModal .modal-content,
        #orderSheetModal, 
       .modal-body {
        padding: 0 !important;
        margin: 0 !important;
        }

        /* Bootstrap Modal ရဲ့ နောက်ခံတွေနဲ့ Scrollbar တွေ ဖျောက်ခြင်း */
        .modal {
            position: absolute !important;
            padding: 0 !important;
            margin: 0 !important;
            overflow: visible !important;
            display: block !important;
        }
        .modal-dialog {
    
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        .modal-content {
            border: none !important;
            box-shadow: none !important;
        }

        .no-print {
            display: none;
        }
    }

    /* ကိန်းဂဏန်းများအတွက် ညာဘက်ညှိရန် */
.num-right {
    text-align: right !important;
    padding-right: 10px !important; /* စာသားနဲ့ မြဉ်းကြား အနည်းငယ် ခြားရန် */
}

/* စာသားပါတဲ့ column တွေအတွက် (ဥပမာ-အမည်၊ လိပ်စာ) ဘယ်ဘက်ကပ်ရန် */
.text-start-custom {
    text-align: left !important;
}

.text-right{text-align:right}
thead { position: sticky; top: 0;
z-index: 10; background-color: #acc8f3 !important;
color: black; vertical-align: middle;
border-top: 2px solid #02080d !important;
border-botton: 2px solid #02080d !important;}
.table thead th {
        vertical-align: middle; /* vertical alignment ကို top သို့မဟုတ် middle ညှိနိုင်သည် */
        white-space: nowrap;    /* စာပိုဒ်မခွဲရန် */
        overflow: hidden;
        vertical-align: middle;
        text-align: center;
        text-overflow: ellipsis; 
        background-color: brown;
        color:white;
        border: 1px solid #eef1f4 !important;
        padding: 5px 5px !important;
    }
/* Table Row Height ကို အထိရောက်ဆုံး လျှော့ချခြင်း */
.table td, .table th {
    padding: 3px 8px !important; /* အပေါ်အောက် padding ကို 3px ထိ လျှော့ချလိုက်ပါ */
    vertical-align: middle !important;
    line-height: 1.4 !important; /* စာသားအမြင့်ကို ကျစ်လျစ်စေရန် */

    white-space: nowrap; /* စာသားကို အောက်တန်း လုံးဝမဆင်းစေရန် */
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Action ခလုတ်များရှိသော Column အတွင်းမှ ခလုတ်ဆိုဒ်ကိုပါ လျှော့ချခြင်း */
.btn-sm, .action-btn {
    padding: 5px 5px !important;
    font-size: 14px !important;
}

.search-container {
    position: relative;
    width: 300px;
}

.search-icon {
    position: absolute;
    right: 20px;
    top: 60%;
    transform: translateY(-80%);
    color: #706f6f;
}

.search-input {
    width: 100%;
    padding: 10px 10px 10px 35px; /* ဘယ်ဖက်မှာ icon အတွက် နေရာချန်ထားတာပါ */
    border: 1px solid #ccc;
    border-radius: 5px;
    outline: none;
}

.search-input:focus {
    border-color: #007bff;
}

    .header-bar {
        background-color: rgb(194, 169, 31);
        color: white;
        padding: 10px 20px;
        font-weight: bold;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
</style>

</head>
<body>
<div class="header-bar">
    <div>| ကုန်သွယ်လုပ်ငန်းခွန် စည်းကြပ်မှုမှတ်တမ်းပုံစံ</div>
    <div>Regular</div>
    <div style="font-size: 15px;"><i class="fa-solid fa-location-dot text-danger"></i> 
    <?= htmlspecialchars($user_township ?: $user_state ?: 'All Regions') ?>အခွန်ဦးစီးဌာနမှူးရုံး</div>
</div>

<div class="container-fluid mt-3" id="mainDemandList">
    <div class="row mb-1">
        <div class="col-md-4">
            <div class="stat-card bg-demand" style="padding-bottom: 10px;">
                <span>စည်းကြပ်တောင်းခံ-</span>
                <span style="display: block; font-size: 0.85rem; font-weight: normal; color: rgba(255,255,255,0.85); margin-top: -2px;">
                    (<?= number_format($tax_cases) ?> မှု)
                </span>
                <strong><?= formatNumber($total_demand) ?></strong>
                
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="stat-card bg-paid" style="padding-bottom: 10px;">
                <span>ပေးသွင်းငွေ-</span>
                <span style="display: block; font-size: 0.85rem; font-weight: normal; color: rgba(255,255,255,0.85); margin-top: -2px;">
                    (<?= number_format($paid_cases) ?> မှု)
                </span>
                <strong><?= formatNumber($total_paid) ?></strong>
                
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="stat-card bg-rem" style="padding-bottom: 10px;">
                <span>ပေးသွင်းရန်ကျန်-</span>
                <span style="display: block; font-size: 0.85rem; font-weight: normal; color: rgba(255,255,255,0.85); margin-top: -2px;">
                    (<?= number_format($remain_cases) ?> မှု)
                </span>
                <strong><?= formatNumber($total_remaining) ?></strong>
            </div>
        </div>
    </div>
    <div class="card p-3 shadow-sm mb-0">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            
            <div class="d-flex align-items-center gap-2">
                <div class="input-group input-group-sm" style="width: 180px;">
                    <input type="number" id="minCase" class="form-control" placeholder="မှ">
                    <input type="number" id="maxCase" class="form-control" placeholder="ထိ">
                </div>
                <div class="d-flex gap-1">
                    <button type="submit" class="btn btn-sm btn-outline-secondary w-100"><i class="fa-solid fa-filter"></i> Filter</button>
                    <a href="IT_demand_list.php" class="btn btn-sm btn-outline-danger" title="Filter များအားလုံးကို ဖျက်၍ မူလအတိုင်းပြန်ပြရန်">
                        <i class="fa fa-sync"></i>
                    </a>
                </div>
                <div class="position-relative" style="width: 250px;">
                    <i class="bi bi-search position-absolute" style="left: 10px; top: 50%; transform: translateY(-50%); color: #6c757d; z-index: 5;"></i>
                    <input type="text" id="searchInput" class="form-control form-control-sm" placeholder="ရှာဖွေရန်..." style="padding-left: 35px;">
                </div>    
            </div>
            
                
            <div class="d-flex align-items-center gap-1">
                <button class="btn btn-info btn-sm text-white" data-bs-toggle="modal" data-bs-target="#formsModal">
                    <i class="bi bi-file-earmark-text"></i> အမှုတွဲ(ပုံစံ)များ
                </button>
                <button class="btn btn-info btn-sm text-white" data-bs-toggle="modal" data-bs-target="#formsModal2">
                    <i class="bi bi-file-earmark-text"></i> အမှုတွဲ(ပုံစံ)များ-၂
                </button>
                <a href="dashboard.php" class="btn btn-secondary btn-sm">
                    <i class="bi bi-house-door-fill"></i> Dashboard
                </a>
                <button class="btn btn-success btn-sm" onclick="exportCTDemandToExcel()">
                    <i class="bi bi-file-earmark-excel-fill"></i> Excel
                </button>
                <a href="Calculation_form1.php?mode=new" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-circle"></i> စည်းကြပ်မှုအသစ်
                </a>
            </div>
                
            </div>
        </div>
    </div>

    

    <div class="table-responsive shadow-sm">
        <table class="table table-bordered table-striped table-hover mb-0" id="taxTable">
            <thead class="text-center">
                <tr>
                    <th class="no-export">#</th>
                    <th>id</th>
                    <th>အမှုတွဲ<br>နံပါတ်</th>
                    <th>Demand<br>_No</th>
                    <th>Demand<br>_Date</th>
                    <th>GIR_No</th>
                    <th>စည်းကြပ်နှစ်</th>
                    <th>အခွန်ထမ်းအမည်</th>
                    <th>လုပ်ငန်း<br>အမျိုးအစား</th>
                    <th>လုပ်ငန်းလိပ်စာ</th>
                    <th>သတ်မှတ်<br>ရောင်းရငွေ</th>
                    <th>ကျသင့်<br>ကုန်သွယ်ခွန်</th>
                    <th>စည်းမျဉ် ၄၂ <br>အရ ခုနှိမ်</th>
                    <th>ခုနှိမ်ပြီးအခွန်</th>
                    <th>ကြိုတင်ခွန်</th>
                    <th>ထပ်မံ<br>ပေးဆောင်ရန်</th>
                    <th>ဒဏ်ကြေး</th>
                    <th>အခွန်<br>ဒဏ်ပေါင်း</th>
                    <th>ပေးသွင်းသည့်<br>အခွန်ဒဏ်</th>
                    <th>ချလန်<br>နံပါတ်</th>
                    <th>ချလန်<br>ရက်စွဲ</th>
                    <th>ပေးသွင်း<br>ရန်ကျန်</th>
                    <th>တာဝန်ခံအရာရှိ</th>
              
                    <th class="no-export sticky-action">Action</th>  
                </tr>
            </thead>
            <tbody id="tableBody">
                <?php if (!empty($data)): ?>
                    <?php foreach ($data as $row): 
                        $rem1 = ($row['totalTax1'] ?? 0) - ($row['paidTax1'] ?? 0);
                        $rem2 = ($row['totalTax2'] ?? 0) - ($row['paidTax2'] ?? 0);
                        
                        $hasSecondCase = !empty($row['ct2_no_real']?? '') || !empty($row['ct2DemandNo']);
                        $rowSpan = $hasSecondCase ? 'rowspan="2"' : '';
                    ?>

                    <tr class="table-row" data-row='<?php echo json_encode($row); ?>'>
                        <td class="text-center no-export" >
                            <input type="checkbox" class="form-check-input row-checkbox" onclick="event.stopPropagation();">
                        </td>
                        <td ><?= $row['id'] ?></td>
                        <td class="text-right" ><?= $row['case_number'] ?></td>
                        
                        <td class="text-right"><?= $row['ct1DemandNo'] ?></td>
                        <td class="text-center"><?= $row['ct1DemandDate'] ?></td>
                        <td class="text-end-important ">
                            <?= ($row['ct1_select_real'] ?? 'ကသ') . " / " . $row['ct1_no_real'] ?>
                        </td>
                        
                        <td  class="text-center "><?= $row['taxYear'] ?></td>
                        <td  style="text-align: left;"><?= $row['taxpayer_name'] ?></td>
                        
                        <td style="text-align: left;"><?= $row['businessType1'] ?></td>
                        
                        <td  style="text-align: left;"><?= $row['address'] ?></td>

                        <td class="text-right "><?= formatNumber($row['salesAmount1']) ?></td>
                        <td class="text-right "><?= formatNumber($row['ct1tax']) ?></td>
                        <td class="text-right fw-bold text-primary"><?= formatNumber($row['rule42_1']) ?></td>
                        <td class="text-right "><?= formatNumber($row['afterRuler1']) ?></td>
                        <td class="text-right fw-bold text-danger"><?= formatNumber($row['advanceTax1']) ?></td>
                        <td class="text-right "><?= formatNumber($row['netTax1']) ?></td>
                        <td class="text-right fw-bold text-danger"><?= formatNumber($row['penalty1']) ?></td>
                        <td class="text-right"><?= formatNumber($row['totalTax1']) ?></td>
                        <td style="text-right font-weight: bold; color: green;"><?= formatNumber($row['paidTax1']) ?></td>
                        <td class="text-center"><?= $row['ct1_chalan_no'] ?></td>
                        <td class="text-center"><?= $row['date1'] ?></td>

                        <td class="num-right fw-bold text-danger">
                            <?= ($rem1 > 0) ? formatNumber($rem1) : '0' ?>
                        </td>
                        <td  class="text-left "><?= $row['officer_name'] ?></td>


                        <td <?= $rowSpan ?> class="text-center no-export sticky-action">
                            <div class="btn-group">
                                <a href="Calculation_Form1.php?id=<?= $row['id'] ?>&amp;return=CT1_Demand_List.php" class="btn btn-outline-warning btn-sm"><i class="bi bi-pencil-fill"></i>Edit</a>
                                <button class="btn btn-outline-danger btn-sm" onclick="confirmDelete(<?= $row['id'] ?>)"><i class="bi bi-trash-fill"></i>Del</button>
                            </div>
                        </td>
                    </tr>
                    
                    <?php if ($hasSecondCase): ?>
                    <tr class="table-row" data-row='<?php echo json_encode($row); ?>'>
                        <td class="text-center no-export">
                            <input type="checkbox" class="form-check-input row-checkbox" onclick="event.stopPropagation();">
                        </td>
                        <td ><?= $row['id'] ?></td>
                        <td class="text-right" ><?= $row['case_number'] ?></td>
                        <td class="text-right"><?= $row['ct2DemandNo'] ?></td>
                        <td class="text-center"><?= $row['ct2DemandDate'] ?></td>
                        <td class="text-end-important ">
                            <?= ($row['ct2_select_real'] ?? 'ကသ') . " / " . $row['ct2_no_real'] ?>
                        </td>

                        <td  class="text-center"><?= $row['taxYear'] ?></td>
                        <td  style="text-align: left; "><?= $row['taxpayer_name'] ?></td>

                        <td style="text-align: left; "><?= $row['businessType2'] ?></td>
                        <td  style="text-align: left; "><?= $row['address'] ?></td>

                        <td class="text-right "><?= formatNumber($row['salesAmount2']) ?></td>
                        <td class="text-right "><?= formatNumber($row['ct2tax']) ?></td>
                        <td class="text-right fw-bold text-primary"><?= formatNumber($row['rule42_2']) ?></td>
                        <td class="text-right "><?= formatNumber($row['afterRuler2']) ?></td>
                        <td class="text-right fw-bold text-danger"><?= formatNumber($row['advanceTax2']) ?></td>
                        <td class="text-right "><?= formatNumber($row['netTax2']) ?></td>
                        <td class="text-right fw-bold text-danger"><?= formatNumber($row['penalty2']) ?></td>
                        <td class="text-right"><?= formatNumber($row['totalTax2']) ?></td>
                        <td style="text-right font-weight: bold; color: green;"><?= formatNumber($row['paidTax2']) ?></td>
                        <td class="text-center"><?= $row['ct2_chalan_no'] ?></td>
                        <td class="text-center"><?= $row['date2'] ?></td>

                        <td class="num-right fw-bold text-danger">
                            <?= ($rem2 > 0) ? formatNumber($rem2) : '0' ?>
                        </td>
                        <td  class="text-left "><?= $row['officer_name'] ?></td>
                    </tr>
                    <?php endif; ?>

                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="26" class="text-center">မှတ်တမ်းမရှိသေးပါ။</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- အမှုတွဲပုံစံများ -->
<div class="modal fade" id="formsModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">အမှုတွဲပုံစံများ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="modal-btn-grid">

                    <button class="btn btn-info text-white" onclick="openFormordersheetCT()">
                        ၁။ နေ့စဉ်လုပ်ငန်းမှတ်တမ်း <br>&ensp;&ensp; (Order Sheet)
                    </button>
                    <button class="btn btn-info text-white" onclick="openForm0405CT1()">
                        ၂။ ကြားနာစစ်ဆေးရန်<br>&ensp;&ensp; အကြောင်းကြားစာ<br> &ensp;&ensp; ပတခ(ကသခ)-၀၄-၀၅
                    </button>
                </div>
                <div class="modal-btn-grid">

                    <button class="btn btn-info text-white" onclick="openFormCT1_KTK2()">
                        ၃။ မှတ်ပုံတင်ခွင့်ပြုကြောင်း<br>&ensp;&ensp; လက်မှတ်<br>&ensp;&ensp; ပတခ(ကသခ)-၂
                    </button>
                    <button class="btn btn-info text-white" onclick="openFormCT1_0407()">
                        ၄။ ဒဏ်ကြေးငွေစည်းကြပ်မှု<br>&ensp;&ensp; ဆုံးဖြတ်ချက်<br> &ensp;&ensp; ပတခ(ကသခ)-၀၄-၀၇
                    </button>
                </div>
                
                <div class="modal-btn-grid">

                    <button class="btn btn-info text-white" onclick="openForm0408CT1()">
                        ၅။ ကုန်သွယ်ခွန်စည်းကြပ်မှု <br>&ensp;&ensp; အကြောင်းကြားစာ <br> &ensp;&ensp; ပတခ(ကသခ)-၀၄-၀၈
                    </button>
                    <button class="btn btn-info text-white" onclick="openFormgeneral2CT()">
                        ၆။ အကြောင်းကြားစာ ချအပ်ခြင်း<br> &ensp;&ensp; ဆိုင်ရာ လက်ခံဖြတ်ပိုင်း <br>&ensp;&ensp; ပတခ(ထွေ)-၂
                    </button>
                </div>
                <div class="modal-btn-grid">
                    <button class="btn btn-info text-white" onclick="openForm0301()">
                        ၇။ နှစ်ချုပ်ကြေညာလွှာ<<br>&ensp;&ensp;<br>&ensp;&ensp;
                    </button>
                    <button class="btn btn-info text-white" onclick="openFormCT1_culateModal()">
                        ၈။ ကုန်သွယ်လုပ်ငန်းခွန် <br> &ensp;&ensp; တွက်ချက်မှုပုံစံ
                    </button>
                </div>
                
            </div>
        </div>
    </div>
</div>

<!-- အမှုတွဲပုံစံများ-၂ -->
<div class="modal fade" id="formsModal2" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">အမှုတွဲပုံစံများ-၂</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="modal-btn-grid">

                    <button class="btn btn-info text-white" onclick="openFormordersheetCT2()">
                        ၁။ နေ့စဉ်လုပ်ငန်းမှတ်တမ်း <br>&ensp;&ensp; (Order Sheet)
                    </button>
                    <button class="btn btn-info text-white" onclick="openForm0405CT2()">
                        ၂။ ကြားနာစစ်ဆေးရန်<br>&ensp;&ensp; အကြောင်းကြားစာ<br> &ensp;&ensp; ပတခ(ကသခ)-၀၄-၀၅
                    </button>
                </div>
                <div class="modal-btn-grid">

                    <button class="btn btn-info text-white" onclick="openFormCT1_KTK2()">
                        ၃။ မှတ်ပုံတင်ခွင့်ပြုကြောင်း<br>&ensp;&ensp; လက်မှတ်<br>&ensp;&ensp; ပတခ(ကသခ)-၂
                    </button>
                    <button class="btn btn-info text-white" onclick="openFormCT2_0407()">
                        ၄။ ဒဏ်ကြေးငွေစည်းကြပ်မှု<br>&ensp;&ensp; ဆုံးဖြတ်ချက်<br> &ensp;&ensp; ပတခ(ကသခ)-၀၄-၀၇
                    </button>
                </div>
                
                <div class="modal-btn-grid">

                    <button class="btn btn-info text-white" onclick="openForm0408CT2()">
                        ၅။ ကုန်သွယ်ခွန်စည်းကြပ်မှု <br>&ensp;&ensp; အကြောင်းကြားစာ <br> &ensp;&ensp; ပတခ(ကသခ)-၀၄-၀၈
                    </button>
                    <button class="btn btn-info text-white" onclick="openFormgeneral2CT2()">
                        ၆။ အကြောင်းကြားစာ ချအပ်ခြင်း<br> &ensp;&ensp; ဆိုင်ရာ လက်ခံဖြတ်ပိုင်း <br>&ensp;&ensp; ပတခ(ထွေ)-၂
                    </button>
                </div>
                <div class="modal-btn-grid">
                    <button class="btn btn-info text-white" onclick="openForm0301CT2()">
                        ၇။ နှစ်ချုပ်ကြေညာလွှာ<br>&ensp;&ensp;<br>&ensp;&ensp;
                    </button>
                    <button class="btn btn-info text-white" onclick="openFormCT2_culateModal()">
                        ၈။ ကုန်သွယ်လုပ်ငန်းခွန် <br> &ensp;&ensp; တွက်ချက်မှုပုံစံ
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/linways/table-to-excel@v1.0.4/dist/tableToExcel.js"></script>

<script>

    // ၂။ Excel Export IT Demand List လုပ်ဆောင်ချက်
function exportCTDemandToExcel() {
    // ၁။ Screen ပေါ်မှာ အမှန်တကယ် ရှိနေတဲ့ Table Rows များကို သေချာပေါက် ဖမ်းယူခြင်း
    // အစ်ကိုကြီးတို့ Table ရဲ့ <tbody> ID က 'taxTableBody' သို့မဟုတ် '#taxTable tbody' ဖြစ်နိုင်ပါတယ်
    var tableBody = document.getElementById("taxTableBody") || document.querySelector("#taxTable tbody") || document.querySelector("table tbody");
    
    if (!tableBody) {
        alert("Error: ဒေတာဇယားကွက် (taxTableBody) ကို ရှာမတွေ့ပါ!");
        return;
    }

    var rows = tableBody.querySelectorAll("tr");
    
    // Total Row တွေပဲ ရှိပြီး တကယ့်ဒေတာ မရှိရင် ကာကွယ်ရန်
    var validRowCount = 0;
    rows.forEach(r => {
        if (!r.classList.contains("no-export") && !r.innerText.includes("စုစုပေါင်း") && r.style.display !== "none") {
            validRowCount++;
        }
    });

    if (validRowCount === 0) {
        alert("Excel ထုတ်ရန် ဇယားထဲတွင် ဒေတာ (သို့မဟုတ်) ပေါ်နေသော Row မရှိပါ!");
        return;
    }

    // ၂။ Excel အတွက် ခေါင်းစဉ်တန်း (Header) ကို Layout မြင်ကွင်းအတိုင်း ကော်လံ (၂၀) စနစ်တကျ တည်ဆောက်ခြင်း
    var excelHtml = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <meta charset="UTF-8">
            <style>
                table { border-collapse: collapse; }
                th { background-color: #97eeab !important; font-family: "Pyidaungsu", "Segoe UI"; font-size: 9pt; border: 0.3pt solid #000; padding: 5px; text-align: center; color: black; font-weight: bold; }
                td { font-family: "Pyidaungsu", "Segoe UI"; font-size: 8pt; border: 0.3pt solid #000; padding: 5px; vertical-align: middle; }
            </style>
        </head>
        <body>
            <table>
                <thead>
                    <tr>
                        <td colspan="19" class="excel-title" style="border:none; text-align:center; font-size:15px;"><b>ကုန်သွယ်လုပ်ငန်းခွန် စည်းကြပ်ခြင်း၊ တောင်းခံခြင်းနှင့် ကောက်ခံရရှိမှုမှတ်ပုံတင်</br></td>
                    </tr>
                    <tr style="height:15px;">
                        <td colspan="19" style="border:none;"></td>
                    </tr>
                    <tr>
                        <th>စဉ်</th>
                        <th>စည်းကြပ်မှု<br>အမှတ်</th>
                        <th>စည်းကြပ်<br>သည့်နေ့</th>
                        <th>အခွန်ထမ်း<br>အမှတ်</th>
                        <th>စည်းကြပ်နှစ်</th>
                        <th>အခွန်ထမ်းအမည်</th>
                        <th width="130">လုပ်ငန်းအမျိုးအစား</th>
                        <th width="200">လုပ်ငန်းလိပ်စာ</th>
                        <th width="75">သတ်မှတ်<br>ရောင်းရငွေ</th>ျ
                        <th>ကျသင့်<br>ကုန်သွယ်ခွန်</th>
                        <th>စည်းမျဉ် ၄၂ <br>အရ ခုနှိမ်</th>
                        <th>ခုနှိမ်ပြီးအခွန်</th>
                        <th width="75">ကြိုတင်ခွန်</th>
                        <th width="75">ထပ်မံ<br>တောင်းခံရန်</th>
                        <th width="70">ဒဏ်ကြေး</th>
                        <th width="75">အခွန်ဒဏ်<br>ပေါင်း</th>
                        <th width="75">ပေးသွင်းငွေ</th>
                        <th>ချလန်<br>နံပါတ်</th>
                        <th>ချလန်ရက်စွဲ</th>
                        <th width="70">ပေးသွင်း<br>ရန်ကျန်</th>
                        <th>တာဝန်ခံအရာရှိ</th>
                    </tr>
                </thead>
                <tbody>
    `;

    // ၃။ Rows များထဲမှ ကော်လံအလိုက် ဒေတာများကို ကွက်တိ ဆွဲထုတ်ခြင်း
    var count = 1;
    rows.forEach(function(row) {
        // စုစုပေါင်း Row များနှင့် ကွယ်ထားသော Row များကို စစ်ထုတ်ခြင်း
        if (row.classList.contains("no-export") || row.innerText.includes("စုစုပေါင်း") || row.style.display === "none") return;

        var tds = row.querySelectorAll("td");
        
        if (tds.length > 0) {
            // 🎯 မူရင်း PHP ဖိုင်ရဲ့ <td> တန်းစီဇယား အစစ်အမှန်အတိုင်း ကွက်တိ Index ညှိထားခြင်း ဖြစ်ပါတယ်
            var itDemandNo       = tds[3] ? tds[3].innerText.trim() : "";   // ကော်လံ ၁
            var itDemandDate     = tds[4] ? tds[4].innerText.trim() : "";   // ကော်လံ ၂
            var gir_no           = tds[5] ? tds[5].innerText.trim() : "";   // ကော်လံ ၃ (Gir No)
            var taxYear          = tds[6] ? tds[6].innerText.trim() : "";   // ကော်လံ ၄
            var taxpayer_name    = tds[7] ? tds[7].innerText.trim() : "";   // ကော်လံ ၅
            var businessType1    = tds[8] ? tds[8].innerText.trim() : "";   // ကော်လံ ၆
            var address          = tds[9] ? tds[9].innerText.trim() : ""; // ကော်လံ ၇ (လိပ်စာ)
            
            // ငွေကြေးကော်လံများ
            var salesAmount1        = tds[10] ? tds[10].innerText.trim() : "0";  // ကော်လံ ၈
            var ct1tax              = tds[11] ? tds[11].innerText.trim() : "0";  // ကော်လံ ၉
            var rule42_1            = tds[12] ? tds[12].innerText.trim() : "0";  // ကော်လံ ၁၀
            var afterRuler1         = tds[13] ? tds[13].innerText.trim() : "0";  // ကော်လံ ၁၁
            var advanceTax1         = tds[14] ? tds[14].innerText.trim() : "0"; // ကော်လံ ၁၂
            var netTax1             = tds[15] ? tds[15].innerText.trim() : "0"; // ကော်လံ ၁၃
            var penalty1            = tds[16] ? tds[16].innerText.trim() : "0"; // ကော်လံ ၁၄
            var totalTax1           = tds[17] ? tds[17].innerText.trim() : "-"; // ကော်လံ ၁၅
            var paidTax1            = tds[18] ? tds[18].innerText.trim() : "-"; // ကော်လံ ၁၆
            var ct1_chalan_no       = tds[19] ? tds[19].innerText.trim() : "0"; // ကော်လံ ၁၇ (ပေးသွင်းရန်ကျန်)
            var date1               = tds[20] ? tds[20].innerText.trim() : "-"; // ကော်လံ ၁၈
            var balance             = tds[21] ? tds[21].innerText.trim() : "-"; // ကော်လံ ၁၈
            var officer_name        = tds[23] ? tds[23].innerText.trim() : "-"; // ကော်လံ ၁၈

            excelHtml += `
                <tr>
                    <td style="text-align:center;">${count}</td>
                    <td style="text-align:center;">${itDemandNo}</td>
                    <td style="text-align:center;">${itDemandDate}</td>
                    <td>${gir_no}</td>
                    <td style="text-align:center;">${taxYear}</td>
                    <td>${taxpayer_name}</td>
                    <td>${businessType1}</td>
                    <td>${address}</td>
                    <td style="text-align:right;">${salesAmount1}</td>
                    <td style="text-align:right;">${ct1tax}</td>
                    <td style="text-align:right;">${rule42_1}</td>
                    <td style="text-align:right;">${afterRuler1}</td>
                    
                    <td style="text-align:right;">${advanceTax1}</td>
                    <td style="text-align:right;">${netTax1}</td>
                    <td style="text-align:right;">${penalty1}</td>
                    
                    <td style="text-align:center;">${totalTax1}</td>
                    <td style="text-align:center;">${paidTax1}</td>
                    <td style="text-align:right;">${ct1_chalan_no}</td>
                    <td style="text-align:center;">${date1}</td>
                    <td style="text-align:right;">${balance}</td>
                    <td>${officer_name}</td>
                </tr>
            `;
            count++;
        }
    });

    excelHtml += `
                </tbody>
            </table>
        </body>
        </html>
    `;

    // ၄။ Blob Object တည်ဆောက်ပြီး Excel ဖိုင်အဖြစ် တိုက်ရိုက်ဒေါင်းလုဒ်ဆွဲချခြင်း
    var blob = new Blob([excelHtml], { type: "application/vnd.ms-excel;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    
    var townshipName = document.getElementById("display_township") ? document.getElementById("display_township").innerText.trim() : "";
    var fileName = "CT_Demand_" + (townshipName ? townshipName : new Date().toISOString().slice(0,10)) + ".xls";

    var a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}


   // Delete အတည်ပြုချက်
    function confirmDelete(id) {
        if (confirm('ဖျက်ရန် သေချာပါသလား?')) {
            window.location.href = 'delete.php?id=' + id;
        }
    }
    
    var selectedRowData = null; // window.selectedRowData လို့လည်း သုံးနိုင်ပါတယ်

    function openFormCT1_culateModal() {
        var data = window.selectedRowData;
        if (!data || !data.id) {
            alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
            return;
        }
        window.location.href = 'formsCT/form_CT1_calculation.php?id=' + encodeURIComponent(data.id);
    }

    function openFormCT2_culateModal() {
        var data = window.selectedRowData;
        if (!data || !data.id) {
            alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
            return;
        }
        window.location.href = 'formsCT2/form_CT2_calculation.php?id=' + encodeURIComponent(data.id);
    }

    function openForm0301() {
        var data = window.selectedRowData;
        if (!data || !data.id) {
            alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
            return;
        }
        window.location.href = 'formsCT/form_CT1_declaration.php?id=' + encodeURIComponent(data.id);
    }

    function openForm0301CT2() {
        var data = window.selectedRowData;
        if (!data || !data.id) {
            alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
            return;
        }
        window.location.href = 'formsCT2/form_CT2_declaration.php?id=' + encodeURIComponent(data.id);
    }

document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('tableBody');

    // ၁။ Checkbox အပြောင်းအလဲဖြစ်ရင် Single Select လုပ်ပေးမည့် Logic
    tableBody.addEventListener('change', function(e) {
        if (e.target && e.target.type === 'checkbox') {
            const allCheckboxes = tableBody.querySelectorAll('input[type="checkbox"]');
            
            if (e.target.checked) {
                // အခြား checkbox တွေအားလုံးကို uncheck လုပ်
                allCheckboxes.forEach(cb => {
                    if (cb !== e.target) {
                        cb.checked = false;
                        cb.closest('tr').classList.remove('selected-row');
                        
                        let next = cb.closest('tr').nextElementSibling;
                        if (next && !next.querySelector('td[rowspan]')) {
                            next.classList.remove('selected-row');
                        }
                    }
                });
                updateRowHighlight(e.target.closest('tr'));
            } else {
                e.target.closest('tr').classList.remove('selected-row');
                let next = e.target.closest('tr').nextElementSibling;
                if (next && !next.querySelector('td[rowspan]')) {
                    next.classList.remove('selected-row');
                }
            }
        }
    });

    // ၂။ Row တစ်ခုလုံးကို နှိပ်ရင် Select ဖြစ်စေမည့် Logic
    tableBody.addEventListener('click', function(e) {
      
        if (e.target.closest('button') || e.target.closest('a') || e.target.type === 'checkbox') return;

        const clickedRow = e.target.closest('tr');
        if (!clickedRow) return;

        let mainRow = clickedRow;
        let targetCheckbox = clickedRow.querySelector('input[type="checkbox"]');

        if (!targetCheckbox) {
            let prevRow = clickedRow.previousElementSibling;
            if (prevRow && prevRow.querySelector('td[rowspan]')) {
                mainRow = prevRow;
                targetCheckbox = prevRow.querySelector('input[type="checkbox"]');
            }
        }

        if (targetCheckbox) {
            targetCheckbox.checked = true;
            targetCheckbox.dispatchEvent(new Event('change', { bubbles: true }));
        }
    });

    // ၃။ Highlight ပြပေးမည့် Function (ဒီနေရာမှာ ပိတ်ရမည့် } ကျန်နေခဲ့တာပါ)
    function updateRowHighlight(mainRow) {
    // ၁။ အရင်ရွေးထားတဲ့ highlight တွေကို အကုန်ဖြုတ်
    document.querySelectorAll('#tableBody tr').forEach(r => r.classList.remove('selected-row'));

    // ၂။ လက်ရှိ row ကို highlight ပြ
    mainRow.classList.add('selected-row');

    // ၃။ Rowspan ပါရင် နောက်တစ်ကြောင်းကိုပါ highlight ပြ
    if (mainRow.querySelector('td[rowspan]')) {
        let nextRow = mainRow.nextElementSibling;
        if (nextRow && !nextRow.querySelector('td[rowspan]')) {
            nextRow.classList.add('selected-row');
        }
    }

    // ၄။ အဓိက အပိုင်း - Row ထဲက Data ကို ယူပြီး Global Variable ထဲ သိမ်းခြင်း
    try {
        const rowDataRaw = mainRow.getAttribute('data-row');
        if (rowDataRaw) {
            // String အဖြစ်ရှိနေတဲ့ Data ကို JavaScript Object ပြောင်းပြီး သိမ်းလိုက်တာပါ
            window.selectedRowData = JSON.parse(rowDataRaw);
            console.log("Data Selected အောင်မြင်သည်:", window.selectedRowData);
        }
    } catch (e) {
        console.error("Data ယူရာတွင် အမှားရှိနေပါသည်:", e);
    }

    // ၅။ Checkbox ကို အမှန်ခြစ်ပေးရန်
    let cb = mainRow.querySelector('input[type="checkbox"]');
    if (cb) cb.checked = true;
}

    
    // Search နှင့် Filter အားလုံးကိုပေါင်းပြီး Function တစ်ခုတည်းနဲ့ ထိန်းချုပ်ပါ
function applyFilters() {
    let searchText = document.getElementById('searchInput').value.toUpperCase().trim();
    let min = parseInt(document.getElementById('minCase').value) || 0;
    let max = parseInt(document.getElementById('maxCase').value) || Infinity;
    
    let rows = document.querySelectorAll("#tableBody tr");

    rows.forEach(row => {
        // အမှုတွဲနံပါတ်ရှိသော column (ဥပမာ index 1 သို့မဟုတ် 2)
        let caseNoCell = row.cells[2]; 
        let caseNo = caseNoCell ? parseInt(caseNoCell.innerText) : 0;
        let rowText = row.innerText.toUpperCase();

        // 1. Search Box နှင့် ကိုက်ညီမှု ရှိမရှိ စစ်ဆေးခြင်း
        let matchesSearch = (searchText === "" || rowText.includes(searchText));
        
        // 2. အမှုတွဲအမှတ် Range အတွင်း ရှိမရှိ စစ်ဆေးခြင်း
        let matchesRange = (caseNo >= min && caseNo <= max);

        // အချက်နှစ်ချက်လုံး ကိုက်ညီမှ ပြပါ
        if (matchesSearch && matchesRange) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
}

// Event Listeners များ
document.getElementById('searchInput').addEventListener('keyup', applyFilters);
document.getElementById('minCase').addEventListener('input', applyFilters);
document.getElementById('maxCase').addEventListener('input', applyFilters);

});

document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('tableBody');
    const rows = Array.from(tableBody.querySelectorAll('tr'));
    const rowsPerPage = 14; // ၁၄ တန်းစီ ပြရန်
    let currentPage = 1;

    function displayRows(page) {
        const start = (page - 1) * rowsPerPage;
        const end = start + rowsPerPage;

        rows.forEach((row, index) => {
            row.style.display = (index >= start && index < end) ? '' : 'none';
        });
        
        updatePaginationButtons();
    }

    // Pagination ခလုတ်များ ဖန်တီးရန်
    function updatePaginationButtons() {
        let paginationContainer = document.getElementById('paginationContainer');
        if (!paginationContainer) {
            paginationContainer = document.createElement('div');
            paginationContainer.id = 'paginationContainer';
            paginationContainer.className = 'mt-3 d-flex justify-content-center gap-2';
            tableBody.closest('.table-responsive').after(paginationContainer);
        }

        const pageCount = Math.ceil(rows.length / rowsPerPage);
        paginationContainer.innerHTML = '';

        for (let i = 1; i <= pageCount; i++) {
            const btn = document.createElement('button');
            btn.innerText = i;
            btn.className = `btn btn-sm ${i === currentPage ? 'btn-primary' : 'btn-outline-primary'}`;
            btn.addEventListener('click', () => {
                currentPage = i;
                displayRows(currentPage);
            });
            paginationContainer.appendChild(btn);
        }
    }

    displayRows(currentPage);
});
</script>

<?php include 'formsCT/formCT_order_sheet.php'; ?>
<?php include 'formsCT2/formCT2_order_sheet.php'; ?>
<?php include 'formsCT/form_04_05CT1.php'; ?>
<?php include 'formsCT2/form_04_05CT2.php'; ?>
<?php include 'formsCT/form_CT1_KTK2.php'; ?>
<?php include 'formsCT/form_04_07CT1.php'; ?>
<?php include 'formsCT2/form_04_07CT2.php'; ?>
<?php include 'formsCT/form_04_08CT1.php'; ?>
<?php include 'formsCT2/form_04_08CT2.php'; ?>
<?php include 'formsCT/form_CT1_general2.php'; ?>
<?php include 'formsCT2/form_CT2_general2.php'; ?>
</body>
</html>