<?php
include 'db_config.php';

// URL မှတစ်ဆင့် ပေးပို့လိုက်သော id ကို လက်ခံခြင်း
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Database မှ ဖျက်ရန် SQL Query
    $sql = "DELETE FROM regular_data WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('အောင်မြင်စွာ ဖျက်သိမ်းပြီးပါပြီ');
                window.location.href = 'IT_Demand_List.php';
              </script>";
    } else {
        echo "ဖျက်သိမ်းရာတွင် အမှားအယွင်းရှိခဲ့ပါသည်: " . $conn->error;
    }
} else {
    echo "ID ရှာမတွေ့ပါ";
}

$conn->close();
?>