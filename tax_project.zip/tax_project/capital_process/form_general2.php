<style>
    /* မျက်နှာပြင်ပေါ်တွင် မြင်ရမည့် style */
    .print-container {
        box-sizing: border-box;
        width: 210mm; /* A4 width standard */
        min-height: 140mm;
        margin: 10px auto;
        padding: 20mm 15mm 15mm 20mm; 
        border: 2px solid black;
        background-color: white;
        position: relative;
    }

    @media print {
        /* Print ထုတ်ရင် မလိုအပ်တာတွေ ဖျောက်ပါ */
        .modal-header, .modal-footer, .no-print, .btn, .btn-close { 
            display: none !important; 
        }

        @page {
            size: A4;
            /* Browser ရဲ့ default margin ကို 0 ထားမှ ကိုယ်ပေးတဲ့ padding/margin အတိုင်း ထွက်မှာပါ */
            margin: 0; 
        }

        body {
            visibility: hidden;
            background-color: white !important;
            margin: 0;
            padding: 0;
        }

        /* Printable Area တစ်ခုလုံးကို visible လုပ်ပါ */
        #printableSheet, #printableSheet * {
            visibility: visible !important;
        }

        #printableSheet {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }

        .print-container {
            /* ဘယ်ဘက်ဘောင် သေချာပေါ်စေရန် border ကို အသေ သတ်မှတ်ပါ */
            border: 2px solid black !important; 
            
            /* စာရွက်အနားကပ်ပြီး ဘောင်ပျောက်မသွားစေရန် margin အနည်းငယ် ပေးပါ */
            margin-left: 10mm !important; 
            margin-right: 10mm !important;
            margin-top: 7mm !important;
            
            page-break-inside: avoid;
            -webkit-print-color-adjust: exact;
            
            /* စာသားတွေနဲ့ ဘောင်ကြား အကွာအဝေး (ယခင် ပေးထားတဲ့အတိုင်း) */
            padding-left: 5mm !important; 
            padding-right: 5mm !important; 
            padding-top: 5mm !important; 
            padding-bottom: 5mm !important; 
        }
    }

    .under-line2 { 
        border-bottom: 1px dotted #121212; 
        display: inline-block; 
        min-width: 300px;
        padding-left: 5px;
    }
</style>

<div class="modal fade" id="formgeneral2Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း ထုတ်ယူရန်</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="printableSheet">
                
                <div class="print-container">
                    <p style='text-align:right; font-size:15px; margin:0;'>ပတခ(ထွေ)-၂</p>
                    <div style="text-align:center; font-weight:bold; margin: 20px 0; font-size: 18px;">
                        အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                    </div>
                    <table style='width:100%; font-size:15px; border-collapse: collapse;'>
                        <tr style="height: 35px;">
                            <td style='width:30%;'>အခွန်ထမ်းအမည်</td>
                            <td>၊ <span id="general_name" class="under-line2"></span></td>
                        </tr>
                        <tr style="height: 35px;">
                            <td>လုပ်ငန်းအမျိုးအစား</td>
                            <td>၊ <span id="general_businessType1" class="under-line2"></span></td>
                        </tr>
                        <tr style="height: 35px;">
                            <td>အခွန်ထမ်းလိပ်စာ</td>
                            <td>၊ <span id="general_address" class="under-line2"></span></td>
                        </tr>
                    </table>
                    <div style="text-align:center; font-weight:bold; margin: 15px 0;">လက်ခံရရှိပါသည်။</div>
                    <table style='width:100%; font-size:15px; border-collapse: collapse;'>
                        <tr>
                            <td style='width:35%; padding-bottom: 5px;'>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                            <td style='width:5%; text-align:center;'>-</td>
                            <td style='width:60%;' class='under-line2'>ပတခ(ကသခ)-၀၄-၀၈/ပတခ(ကသခ)-၀၂-၀၁</td>
                        </tr>
                        <tr>
                            <td style='padding-bottom: 5px;'>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                            <td style='text-align:center;'>-</td>
                            <td class='under-line2'>ပတခ(ဝင)-၀၄-၀၈/ပတခ(ဝင)-၀၂-၀၁(ခ)</td>
                        </tr>
                        <tr style="height: 30px;">
                            <td>အကြောင်းကြားစာအတည်ပြုချအပ်သူ</td>
                            <td style='text-align:center;'>-</td>
                            <td class='under-line2'></td>
                        </tr>
                        <tr style='height: 30px;'>
                            <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                            <td style='text-align:center;'>-</td>
                            <td class='under-line2'></td>
                        </tr>
                    </table>
                    <table style='width:100%; margin-top:0px;'>
                        <tr style='height: 30px;'>
                            <td style='width:60%; text-align:right; padding-right: 15px;'>လက်မှတ်</td>
                            <td style='border-bottom: 1px dotted black; width: 30%;'></td>
                        </tr>
                        <tr style="height: 30px;">
                            <td style='text-align:right; padding-right: 15px;'>အမည်</td>
                            <td style='border-bottom: 1px dotted black; width: 30%;'></td>
                        </tr>
                        <tr style='height: 30px;'>
                            <td style='text-align:right; padding-right: 15px;'>ရက်စွဲ</td>
                            <td style='border-bottom: 1px dotted black; width: 30%;'></td>
                        </tr>
                    </table>

                    <div style="clear: both;"></div>
                </div>
                <br>
                <div class="print-container">
                    <p style='text-align:right; font-size:15px; margin:0;'>ပတခ(ထွေ)-၂</p>
                    <div style="text-align:center; font-weight:bold; margin: 20px 0; font-size: 18px;">
                        အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                    </div>
                    <table style='width:100%; font-size:15px; border-collapse: collapse;'>
                        <tr style="height: 35px;">
                            <td style='width:30%;'>အခွန်ထမ်းအမည်</td>
                            <td>၊ <span id="general_name1" class="under-line2"></span></td>
                        </tr>
                        <tr style="height: 35px;">
                            <td>လုပ်ငန်းအမျိုးအစား</td>
                            <td>၊ <span id="general_businessType2" class="under-line2"></span></td>
                        </tr>
                        <tr style="height: 35px;">
                            <td>အခွန်ထမ်းလိပ်စာ</td>
                            <td>၊ <span id="general_address1" class="under-line2"></span></td>
                        </tr>
                    </table>
                    <div style="text-align:center; font-weight:bold; margin: 15px 0;">လက်ခံရရှိပါသည်။</div>
                    <table style='width:100%; font-size:15px; border-collapse: collapse;'>
                        <tr>
                            <td style='width:35%; padding-bottom: 5px;'>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                            <td style='width:5%; text-align:center;'>-</td>
                            <td style='width:60%;' class='under-line2'>ပတခ(ကသခ)-၀၄-၀၈/ပတခ(ကသခ)-၀၂-၀၁</td>
                        </tr>
                        <tr>
                            <td style='padding-bottom: 5px;'>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                            <td style='text-align:center;'>-</td>
                            <td class='under-line2'>ပတခ(ဝင)-၀၄-၀၈/ပတခ(ဝင)-၀၂-၀၁(ခ)</td>
                        </tr>
                        <tr style="height: 30px;">
                            <td>အကြောင်းကြားစာအတည်ပြုချအပ်သူ</td>
                            <td style='text-align:center;'>-</td>
                            <td class='under-line2'></td>
                        </tr>
                        <tr style='height: 30px;'>
                            <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                            <td style='text-align:center;'>-</td>
                            <td class='under-line2'></td>
                        </tr>
                    </table>
                    
                    <table style='width:100%; margin-top:0px;'>
                        <tr style='height: 30px;'>
                            <td style='width:60%; text-align:right; padding-right: 15px;'>လက်မှတ်</td>
                            <td style='border-bottom: 1px dotted black; width: 30%;'></td>
                        </tr>
                        <tr style="height: 30px;">
                            <td style='text-align:right; padding-right: 15px;'>အမည်</td>
                            <td style='border-bottom: 1px dotted black; width: 30%;'></td>
                        </tr>
                        <tr style='height: 30px;'>
                            <td style='text-align:right; padding-right: 15px;'>ရက်စွဲ</td>
                            <td style='border-bottom: 1px dotted black; width: 30%;'></td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>


function openFormgeneral2() {
    console.log("Selected Row Data:", selectedRowData);
    
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("Table ထဲမှ row ကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    // ၁။ မြန်မာဂဏန်းပြောင်းလဲခြင်း
    const toMM = (num, showComma = true) => {
        if (num === null || num === undefined || num === "") return '၀';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        let s = showComma ? Number(num).toLocaleString() : num.toString(); 
        return s.replace(/\d/g, d => mDigits[d]);
    };

    // ၂။ ဂဏန်းမှ မြန်မာစာသားသို့ ပြောင်းလဲခြင်း
    const numberToMyanmarText = (number) => {
        if (number === 0 || !number) return "သုည";
        const digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
        const units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
        let numStr = Math.floor(number).toString();
        let result = "";
        let len = numStr.length;
        for (let i = 0; i < len; i++) {
            let digit = parseInt(numStr[i]);
            let unitIndex = len - i - 1;
            if (digit !== 0) {
                result += digits[digit] + units[unitIndex];
            }
        }
        return result;
    };

    const setText = (id, val, isNum = false, showComma = true) => {
        const el = document.getElementById(id);
        if (el) el.innerText = isNum ? toMM(val, showComma) : (val || '-');
    };

    // --- Data ထည့်သွင်းခြင်း ---
    
    if (selectedRowData.taxYear) {
        setText('general_taxYear', toMM(selectedRowData.taxYear, false));
    }

    // ရက်စွဲတွက်ချက်ခြင်း (Bracket သေချာပြန်ပိတ်ထားသည်)
    if (selectedRowData.itDemandDate) {
        const d = new Date(selectedRowData.itDemandDate);
        
        // PHP Variable များကို ဤနေရာတွင် တိုက်ရိုက်မသုံးဘဲ HTML element ရှိလျှင် ထည့်ပေးပါ
        if(document.getElementById('user_bank_township')) {
            document.getElementById('user_bank_township').innerText = typeof phpBankTownship !== 'undefined' ? phpBankTownship : '';
        }

        d.setDate(d.getDate() + 14); 
        const day = toMM(d.getDate(), false);
        const month = toMM(d.getMonth() + 1, false);
        const year = toMM(d.getFullYear(), false);
        setText('general_demandDate', day + "-" + month + "-" + year);
    } // <--- ဒီနားမှာ bracket ကျန်ခဲ့တာပါ

    // အမည်နှင့် လိပ်စာ
    setText('general_name', selectedRowData.taxpayer_name);
    setText('general_address', selectedRowData.address);
    setText('general_businessType1', selectedRowData.businessType1);

    setText('general_name1', selectedRowData.taxpayer_name);
    setText('general_address1', selectedRowData.address);
    setText('general_businessType2', selectedRowData.businessType1);

    // ငွေကြေးဆိုင်ရာများ
    const totalAmount = selectedRowData.taxpanaty || 0;
    setText('general_taxTextMM', numberToMyanmarText(totalAmount));
    setText('general_incomeTax', selectedRowData.payableIncomeTax, true);

    // Modal ပြသခြင်း
    var modalElem = document.getElementById('formgeneral2Modal');
    if (modalElem) {
        var myModal = new bootstrap.Modal(modalElem);
        myModal.show();
    } else {
        console.error("Modal ID 'formgeneral2Modal' not found!");
    }
}
</script>