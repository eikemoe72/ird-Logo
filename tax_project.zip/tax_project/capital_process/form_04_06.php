<style>
@media print {
        /* Modal Footer နဲ့ ခလုတ်များကို ဖျောက်ခြင်း */
        .modal-footer, .no-print, .btn, .btn-close, .modal-header { display: none !important; }
        
        /* Modal Content နဲ့ Body ရဲ့ ဘောင်များကို ဖျောက်ခြင်း */
        .modal-content, .modal-body { border: none !important; box-shadow: none !important; }

        body * { visibility: hidden; }
        #form0406Modal, #form0406Modal * { visibility: visible !important; }
        #form0406Modal { 
        position: absolute; 
        left: 0 !important; 
        top: 0; 
        width: 100%; 
        margin: 0 !important; 
        padding: 0 !important; 
    }

        /* အပြင်ဘက်ဆုံး အနီရောင်မျဉ်း (Container Border) ကို ဖျက်ခြင်း */
    .print-container { 
        padding: 20mm 10mm 10mm 20mm !important; 
        margin: 0 !important;
        width: 100% !important;
        border: none !important;
       
    }
    .modal-dialog {
        margin: 0 !important;
        max-width: 100% !important;
        width: 100% !important;
       
    }
    .modal-content, .modal-body {
        border: none !important;
        padding: 0 !important;
       
    }

        /* Table များတွင် ရှိနေသော Border အားလုံးကို ဖျက်ခြင်း */
        table, tr, td { 
            border: none !important; /* Table အကွက်မျဉ်းများ ဖျောက်ရန် */
        }
        
    

        /* Modal Header နှင့် Footer ကြားက မျဉ်းများကို ဖျောက်ခြင်း */
    .modal-header, .modal-footer {
        border: none !important;
        border-bottom: none !important;
        border-top: none !important;
        box-shadow: none !important;
    }

    /* တစ်ခါတစ်ရံ Horizontal Rule (hr) ပါနေတတ်သဖြင့် ဖျောက်ခြင်း */
    hr {
        display: none !important;
    }

    /* Modal Body ရဲ့ အောက်ခြေ Border ကို ဖျောက်ခြင်း */
    .modal-body {
        border: none !important;
    }
}

    /* ၁။ Modal Dialog အကျယ်ကို ထိန်းခြင်း */
#form0406Modal .modal-dialog {
    max-width: 800px; /* A4 size နဲ့ ကိုက်ညီမည့် အကျယ် */
    margin: 20px auto;
}

/* ၂။ Modal Content ထဲမှာ Padding ပြန်ညှိခြင်း */
#form0406Modal .modal-body {
    padding: 0px !important; /* စာရွက်အနားသတ်ပုံစံမျိုးရအောင် */
    overflow-x: hidden; /* ဘေးကို ကျွံမထွက်စေရန် */
}
.underline{border-bottom: 1px dotted solid; width:250px;}
</style>

<div class="modal fade" id="form0406Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">၀၄-၀၆ သတင်းအချက်အလက်များပေးပို့ရန်အကြောင်းကြားစာ ထုတ်ယူရန်</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container" style="padding: 10mm !important; margin: 0 !important;">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:25px">
                        <tr>
                            <td style='border: 0px solid black; padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px; padding:5px'>ပတခ(ဝင)-၀၄-၀၆</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၆၊ ပုဒ်မခွဲ(က)၊ ပုဒ်မခွဲငယ်(၁)အရ <br>
                        သတင်းအချက်အလက်များပေးပို့ရန်အကြောင်းကြားစာ 
                    </div>

                    <table style='width:100%; font-size:15px;'>
                        <tr>
                            <td style='text-align:right; width:60%'>စာအမှတ်၊ ပတခ/ <span id="m0406_other_data"></span>/ ဝငခ/ ၂၀<span id="m0406_year_short"></span>(&emsp;&emsp;&emsp;)</td>
                        </tr>
                        <tr>
                            <td style='text-align:right;'>ရက်စွဲ၊ 
                                <strong>
                                    ၂၀<span id="m0406_year_short2"></span>ခုနှစ်၊ &ensp;
                                    <span id="m0406_month"></span> &ensp;&ensp;လ &ensp;
                                    <span id="m0406_day"></span>&ensp;&ensp;ရက်
                                </strong> 
                            </td>
                        </tr>
                    </table>

                    <div style="margin-left: 0px; text-align:left; margin-top:10px;">
                        သို့<br>
                        <span style = 'padding-left:70px;'></span><span id="m0406_name" style="border-bottom:1.5px dotted; font-weight:bold;" ></span><br>
                        <span style = 'padding-left:70px;'></span><span id="m0406_address" style="border-bottom:1.5px dotted; font-weight:bold;"></span><br>
                        <span style = 'padding-left:70px;'></span><span id="m0406_biz" style="border-bottom:1.5px dotted; font-weight:bold;"></span>
                    </div>

                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၁။<span style = 'padding-left:46px;'><strong><span id="m0406_biz_detail"></span></strong>  လုပ်ငန်းအပေါ်တွင် ဝင်ငွေခွန်စည်းကြပ်သည့် 
                        ကိစ္စနှင့်ပတ်သက်၍ လူကြီးမင်းထံမှ သတင်းအချက်အလက်များကို ရရှိစစ်ဆေးရန် လိုအပ်ပါသဖြင့် ( <strong><span id="m0406_appDate"></span></strong> )
                        ရက်နေ့၊ (၁၀:၀၀) နာရီအချိန် သို့မဟုတ် ယင်းကာလမတိုင်မီတွင် အောက်တွင်ဖော်ပြထားသည်တို့ကို ဤရုံးသို့ ပေးပို့ရန် အကြောင်းကြားပါသည်။ 
                    </div>
                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၂။<span style = 'padding-left:46px;'></span>ဤအကြောင်းကြားစာအတိုင်း လိုက်နာဆောင်ရွက်ရန် ပျက်ကွက်ပါက  အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေ 
                        ပုဒ်မ ၇၀/၇၃ တို့အရ ဒဏ်ငွေတပ်ရိုက်ခြင်း၊  ပုဒ်မ ၇၈ အရ အရေးယူခြင်းတို့ကိုခံရဖွယ်ရှိကြောင်း အသိပေးအပ်ပါသည်။
                    </div>
                     <p style = 'border:0px solid; text-align:center;font-size:15px;line-height:24px'><span style = 'padding-left:44px'><strong> ပေးပို့ရန် သတင်းအချက်အလက်အထောက်အထား စာရွက်စာတမ်းများ</strong ></span></p >

                    <p style = 'border:0px solid; text-align:left;font-size:15px;line-height:24px'>
                    <span style = 'padding-left:70px;'></span> (က) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span> ( ခ ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span> ( ဂ ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span > (ဃ) <span style = 'padding-left:30px;'> ........................................</span><br/>
                    
                    <span style = 'padding-left:70px;'></span> ( င ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span > ( စ ) <span style = 'padding-left:30px;'> ........................................ </span><br/></p>  

                    <table style='width:100%; margin-top:30px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br><span id="m0406_township"></span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>


<script>
function openForm0406() {
    console.log("Selected Row Data:", selectedRowData);

    // ၁။ Row ရွေးထားခြင်း ရှိမရှိ စစ်ဆေးခြင်း
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
        return;
    }

    // ၂။ Helper Functions (ဂဏန်းပြောင်းခြင်းနှင့် စာသားထည့်ခြင်း)
    const toMyanmarDigit = (num) => {
        if (!num) return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    const mmMonths = ['ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ'];

    // ၃။ Login User ရဲ့ Other Data ကို ထည့်သွင်းခြင်း (ဒီနေရာကို Function အထဲထဲ ပြောင်းထည့်ထားပါတယ်)
    const loginUserOther = "<?php echo $user_other_info; ?>"; // PHP variable name ကို သေချာပြန်စစ်ပါ
    console.log("ရရှိလာသော Other Data:", loginUserOther);
    setText('m0406_other_data', loginUserOther || '......');

    // ၄။ အခြေခံအချက်အလက်များ
    setText('m0406_name', selectedRowData.taxpayer_name);
    setText('m0406_address', selectedRowData.address);
    setText('m0406_biz', selectedRowData.businessType1);
    setText('m0406_township', selectedRowData.township_name || selectedRowData.state_name);
    setText('m0406_year', toMyanmarDigit(selectedRowData.taxYear));

    // ၅။ ရက်စွဲပိုင်းဆိုင်ရာ Process လုပ်ခြင်း
    const processDate = (dateStr, prefix) => {
        if (dateStr && dateStr.includes('-')) {
            const parts = dateStr.split('-');
            const yyyy = parts[0]; 
            const mm = parts[1];   
            const dd = parts[2].split(' ')[0];

            setText(prefix + '_year', toMyanmarDigit(yyyy));
            setText(prefix + '_month', mmMonths[parseInt(mm) - 1]);
            setText(prefix + '_day', toMyanmarDigit(dd));
            
            if (prefix === 'm0406') {
                setText('m0406_year_short', toMyanmarDigit(yyyy.slice(-2)));
                setText('m0406_year_short2', toMyanmarDigit(yyyy.slice(-2)));
                setText('m0406_m0406', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            } else if (prefix === 'appDate') {
                setText('m0406_appDate', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            }
        } else {
            // ရက်စွဲမရှိရင် အစက်လေးတွေပဲ ပြန်ပြထားမယ်
            setText(prefix + '_year', '....');
            setText(prefix + '_month', '....');
            setText(prefix + '_day', '....');
        }
    };

    processDate(selectedRowData.orderDate, 'm0406');
    processDate(selectedRowData.appointmentDate, 'appDate');

    // ၆။ Modal ကို ဖွင့်ခြင်း
    var modalElem = document.getElementById('form0406Modal');
    if (modalElem) {
        var myModal = new bootstrap.Modal(modalElem);
        myModal.show();
    }
}
</script>