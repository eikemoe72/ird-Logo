
<style>
   @media print {
        .modal-footer, .no-print, .btn, .btn-close { display: none !important; }
        body * { visibility: hidden; }
        #form0408Modal, #form0408Modal * { visibility: visible !important; }
        #form0408Modal { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 0; }
        .print-container { padding-left: 10mm; padding-right: 5mm; padding-top: 0mm;border: none !important; }
        .print-container2 { padding-left: 10mm; padding-right: 5mm; padding-top: 0mm;border: none !important; }
    }
    .under-line { border-bottom: 1px dashed #0d0d0d; min-width:140px; display: inline-block; text-align: right; padding-right:30px;}
    .under-line2 { border-bottom: 2px dotted #121212; min-width:450px; display: inline-block; text-align: left; }
    .under-line3 { border-bottom: 1px solid #0e0d0d;  min-width:140px; display: inline-block; text-align: right; padding-right:30px;}

    /* ... အခြား style များ ... */
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed; /* ဤအချက်က ကော်လံတွေကို အချိုးကျစေပါတယ် */
    }
    .table-custom th, .table-custom td {
        border: 1px solid black;
        padding: 5px;
        word-wrap: break-word; /* စာရှည်ရင် အောက်ဆင်းဖို့ */
    }
    .under-line-dot {
        border-bottom: 1px dotted #000;
        display: inline-block;
        width: 95%;
        min-height: 15px;
    }
</style>

<div class="modal fade" id="form0408Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">၀၄-၀၅ ကြားနာစစ်ဆေးရန်အကြောင်းကြားစာ  ထုတ်ယူရန်</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container2">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:25px">
                        <tr>
                            <td style='border: 0px solid black; padding:3px;'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px; padding:3px; line-height: 16px;'>ပတခ(ဝင)-၀၄-၀၈</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၁ အရ <br>
                        ဝင်ငွေခွန်စည်းကြပ်မှု အကြောင်းကြားစာ 
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:50%'></td>
                            <td style='width:30%; text-align:right;'>အခွန်တောင်းခံလွှာအမှတ်၊</td>
                            <td style='width:20%; 'class="under-line"><span  id="m0408_it_full" ></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style='text-align:right;'>ရက် စွဲ ၊ </td>
                            <td style=';'class="under-line"><span  id="m0408_taxYear" ></span></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:10%'>သို့</td>
                            <td style='width:25%'>အခွန်ထမ်းအမည်၊</td>
                            <td style='width:65%' class="under-line2">: <span  id="m0408_name"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:25%'>အခွန်ထမ်းအမည်၊</td>
                            <td style='width:65%' class="under-line2">: <span  id="m0408_it_full"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:25%'>အခွန်ထမ်းလိပ်စာ၊</td>
                            <td style='width:65%' class="under-line2">: <span  id="m0408_address"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:25%'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                            <td style='width:65%' class="under-line2">: (၀၁-၀၄-<span id="m0408_periodStartYear"></span>) မှ (၃၁-၀၃-<span id="m0408_periodEndYear"></span>)ထိ ကာလ</td>
                        </tr>
                    </table>

                    

                    <div style="margin-top:15px; padding:3px; text-align:justify;">
                        ၁။<span style = 'padding-left:48px;'></span>( <strong><span id="m0408_year"></span></strong> )စည်းကြပ်နှစ်အတွက် 
                        ကျောဖက်ပါပုံစံတွင် အသေးစိပ်ဖော်ပြထားချက်အရ ပေးဆောင်ရန် တာဝန်ရှိသည့် အခွန်နှင့်စပ်လျဉ်း၍ အောက်ပါအတိုင်း ပေးဆောင်ရန် အကြောင်းကြားပါသည် -
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(က)</td>
                            <td style='width:55%'>ဝင်ငွေခွန်</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"> <span  id="m0408_BalanceTax"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ခ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၅ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဂ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၆ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ဃ)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၇ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( င )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၈ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"> </td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( စ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၉ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ဆ)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၀ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဇ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၁ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဈ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၂ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ည)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၃ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဋ  )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၄ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"><span  id="m0408_panaty"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'></td>
                            <td style='width:55%'><b>စုစုပေါင်းပေးဆောင်ရမည့်အခွန်ပမာဏ</b></td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"><span  id="m0408_taxpanaty"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td colspan="5" style='padding-top: 1px;'>
                               <strong> စာသားဖြင့် ( <span id="m0408_taxTextMM"></span> ) ကျပ်တိတိ၊</strong>
                            </td>     
                        </tr>
                    </table>
                    <div style="margin-top:15px; padding:3px; text-align:justify;">
                        ၂။<span style = 'padding-left:48px;'></span>အထက်ပါပေးဆောင်ရမည့် အခွန်ငွေပမာဏကို 
                            ( <span id="user_bank_township"></span> ) ရှိ မြန်မာ့စီးပွားရေးဘဏ်၊ 
                            ဘဏ်စာရင်းအမှတ် ( <span id="user_md_no"></span>) သို့ ပူးတွဲပါ ငွေသွင်းချလန်ဖြင့်
                            ( <span  id="m0408_demandDate"></span> )ရက်နေ့ နောက်ဆုံးထား၍ ပေးသွင်းပြီး လက်ခံဖြတ်ပိုင်းကို
                            ရယူစေလိုပါသည်။ (Online Paymentဖြင့် ပေးသွင်း၍ရပါက ပေးသွင်းစေလိုပါသည်။) သတ်မှတ်ရက်အတွင်း အခွန်ပေးသွင်းရန် ပျက်ကွက်ပါက 
                            အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေ ပုဒ်မ ၇၄ ၊ ပုဒ်မခွဲ(က)အရ ဒဏ်ငွေ ထပ်မံတပ်ရိုက်ခြင်း ခံရဖွယ်ရှိပါ၍ မပျက်မကွက် ပေးဆောင်စေလိုပါသည်။<br>
                    
                        ၃။<span style = 'padding-left:48px;'></span>စည်းကြပ်မှု သို့မဟုတ် ဒဏ်ကြေးငွေတပ်ရိုက်မှုအတွက်ဆုံးဖြတ်ချက်ကို ကျေနပ်မှုမရှိပါက
                         အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၄ ပါ စီမံအုပ်ချုပ်မှုနည်းလမ်းအရ ပြန်လည်သုံးသပ်ပေးရန် ညွှန်ကြားရေးမှူးချုပ်၊ ပြည်တွင်းအခွန်များဦးစီးဌာန၊ 
                         ရုံးအမျတ်(၄၆)၊ နေပြည်တော်သို့ အကြောင်းကြားစာလက်ခံရရှိသည့်နေ့မှ ရက်ပေါင်း(၃၀)အတွင်း လျှောက်ထားနိုင်ပါသည်။
                    </div>
                    <br>
                    <table style='width:100%; margin-top:30px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br><span id="m0408_township"></span>
                            </td>
                        </tr>
                    </table>
                </div>

                <br>

                <div class="print-container2">
                    

                    <p style='text-align:right; font-size:15px; padding:3px; line-height: 16px;'>ပတခ(ဝင)-၀၄-၀၈(အဆက်)</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        ဝင်ငွေအမျိုးအစားအလိုက် သတ်မှတ်မှု 
                    </div>
                    <table style="width: 100%; " >
                        
                        <tr style="border: 2px solid #0a0a0a;">
                            <th colspan="2" style="width: 76%; text-align: center; border-right: 2px solid #0b0b0b; padding:3px;">ဝင်ငွေရလမ်း</th>
                            <!--<th style="width: 38%; text-align: left; border-right: 1px solid #0b0b0b;">လစာ</th>
                            <th style="width: 35%; text-align: center;" class="under-line2">.</th>-->
                            <th style="width: 24%; text-align: center; padding:3px;">သတ်မှတ်ဝင်ငွေ (ကျပ်)</th>
                        </tr>
                       
                    </table>

                    <table style="width: 100%; " >
                        
                        <tr style="height:26px; padding:3px;">
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;">၁။</th>
                            <th style="width: 40%; text-align: left; padding:3px;">လစာ</th>
                            <th style="width: 31%; text-align: center; border-right: 2px solid #0b0b0b;padding:3px;">............................................</th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; padding:3px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;">၂။</th>
                            <th style="width: 40%; text-align: left; padding:3px;">အသက်မွေးဝမ်းကျောင်းပညာလုပ်ငန်း</th>
                            <th style="width: 31%; text-align: center;  border-right: 2px solid #0b0b0b; padding:3px;">............................................</th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; padding:3px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;">၃။</th>
                            <th style="width: 40%; text-align: left; padding:3px;">စီးပွားရေးလုပ်ငန်း</th>
                            <th style="width: 31%; text-align: center;  border-right: 2px solid #0b0b0b; padding:3px;"><span id="m0408_businessType1" ></span></th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; " ><span id="m0408_netProfit" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;">၄။</th>
                            <th style="width: 40%; text-align: left; padding:3px;">ပစ္စည်း</th>
                            <th style="width: 31%; text-align: center; border-right: 2px solid #0b0b0b; padding:3px;">............................................</th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; padding:3px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;">၅။</th>
                            <th style="width: 40%; text-align: left; padding:3px;">အခြေပစ္စည်းမှမြတ်စွန်းငွေ</th>
                            <th style="width: 31%; text-align: center;  border-right: 2px solid #0b0b0b; padding:3px;">............................................</th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; padding:3px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;">၆။</th>
                            <th style="width: 40%; text-align: left; padding:3px;">စည်းကြပ်မှုမှလွတ်ကင်းသွားသောဝင်ငွေ</th>
                            <th style="width: 31%; text-align: center;  border-right: 2px solid #0b0b0b; padding:3px;">............................................</th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; padding:3px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left;  border-left: 2px solid #0a0a0a; padding:3px;">၇။</th>
                            <th style="width: 40%; text-align: left;  padding:3px;">အခြားရလမ်းများမှဝင်ငွေ</th>
                            <th style="width: 31%; text-align: center;  border-right: 2px solid #0b0b0b; padding:3px;">............................................</th>
                            <th style="width: 24%; text-align: right;  padding-right:30px; border-right: 2px solid #0a0a0a; padding:3px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-bottom: 2px solid #121212; border-left: 2px solid #0a0a0a;"><br></th>
                            <th style="width: 40%; text-align: left; border-bottom: 2px solid #121212; "><br></th>
                            <th style="width: 31%; text-align: center;  border-bottom: 2px solid #121212; border-right: 2px solid #0b0b0b;"><br></th>
                            <th style="width: 24%; text-align: right; border-bottom: 2px solid #121212; padding-right:40px; border-right: 2px solid #0a0a0a;" ><br></th>
                        </tr>
                       
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 2px solid #0b0b0b;  padding:3px;">စုစုပေါင်း</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 2px solid #0b0b0b;" >စုစုပေါင်း</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; "><span id="m0408_netProfit2"></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 2px solid #0b0b0b;  padding:3px;">*သက်သာခွင့်များ</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 2px solid #0b0b0b;" >စုစုပေါင်း</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-bottom: 2px solid #121212; border-right: 2px solid #0a0a0a; "><span id="m0408_relief"  ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 2px solid #0b0b0b;  padding:3px;">အခွန်စည်းကြပ်ရန်အသားတင်ဝင်ငွေ</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 2px solid #0b0b0b;" >အခွန်စည်းကြပ်ရန်အသားတင်ဝင်ငွေ</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; "><span id="m0408_taxableIncome"  ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 2px solid #0b0b0b; padding:3px;">ကျသင့်ဝင်ငွေခွန်</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 2px solid #0b0b0b;" >ကျသင့်ဝင်ငွေခွန်</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 2px solid #0a0a0a; "><span id="m0408_incomeTax"  ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 2px solid #0a0a0a; padding:3px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 2px solid #0b0b0b; color: red;  padding:3px;">နုတ်-ပုဒ်မ ၁၆ အရ ပေးဆောင်ပြီးအခွန်</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 2px solid #0b0b0b; color: red;" >နုတ်-ပုဒ်မ ၁၆ အရ ပေးဆောင်ပြီးအခွန်</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; color: red; border-bottom: 2px solid #121212; border-right: 2px solid #0a0a0a; "><span id="m0408_advancePaidTax"  ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-bottom: 2px solid #121212; border-left: 2px solid #0a0a0a; padding:3px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-bottom: 2px solid #121212; right; border-right: 2px solid #0b0b0b;  padding:3px;">ပေးဆောင်ရန်ကျန် / ပြန်အမ်းရန်အခွန်<br></th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 2px solid #0b0b0b;" >ပေးဆောင်ရန်ကျန် / ပြန်အမ်းရန်အခွန်</th>-->
                            <th style="width: 24%; text-align: right; border-bottom: 2px solid #121212; padding-right:30px; border-right: 2px solid #0a0a0a; "><span id="m0408_finalBalanceTax"  ></th>
                        </tr>
 
                    </table>
                    <br><br><br>

                    <table style="width: 100%; " >
                        
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;"></th>
                            <th style="width: 36%; text-align: center; padding:3px;"><b>*သက်သာခွင့်များ</b></th>
                            <th style="width: 12%; text-align: center; padding:3px;"></th>
                            <th style="width: 22%; text-align: right; padding:3px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;">၁။</th>
                            <th style="width: 36%; text-align: left; padding:3px;">အခြေခံသက်သာခွင့်</th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 1px dashed #0d0d0d;" ><span id="m0408_basicRelief"></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;">၂။</th>
                            <th style="width: 36%; text-align: left; padding:3px;">အတူနေမိဘအတွက်သက်သာခွင့် </th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 1px dashed #0d0d0d;" ><span id="m0408_parent_relief"></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;">၃။</th>
                            <th style="width: 36%; text-align: left; padding:3px;">အိမ်ထောင်ဖက်အတွက်သက်သာခွင့် </th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 1px dashed #0d0d0d;" ><span id="m0408_spouse_relief"></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;">၄။</th>
                            <th style="width: 36%; text-align: left; padding:3px;">သားသမီးများအတွက်သက်သာခွင့်  </th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 1px dashed #0d0d0d;" ><span id="m0408_child_relief"></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;">၅။</th>
                            <th style="width: 36%; text-align: left; font-size: 12px;"padding:3px;>အခွန်ထမ်းနှင့်အိမ်ထောင်ဖက်၏အသက်အာမခံအတွက်</th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 1px dashed #0d0d0d;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;">၆။</th>
                            <th style="width: 36%; text-align: left; padding:3px;">စုဆောင်းငွေအတွက် သက်သာခွင့်   </th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 1px dashed #0d0d0d;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;">၇။</th>
                            <th style="width: 36%; text-align: left; padding:3px;">လှူဒါန်းငွေအတွက်သက်သာခွင့် </th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 2px solid #121212;" ></th>
                        </tr>
                        <br>
                         <tr>
                            <th style="width: 15%; text-align: left; padding:3px;"></th>
                            <th style="width: 5%;  text-align: left; padding:3px;"></th>
                            <th style="width: 36%; text-align: left; padding:3px;">စုစုပေါင်း </th>
                            <th style="width: 12%; text-align: center; padding:3px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:40px; border-bottom: 2px solid #121212;" ><span id="m0408_totalRelief"></th>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
    // PHP မှ bank_township value ကို JS variable ထဲ ထည့်ခြင်း
const phpBankTownship = "<?php echo $bank_township; ?>";

function openForm0408() {console.log("Selected Row Data:", selectedRowData);
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("Table ထဲမှ row ကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    const phpBankTownship = "<?php echo $bank_township; ?>";
    const phpMdNo = "<?php echo $md_no; ?>";

    // ၁။ မြန်မာဂဏန်းပြောင်းလဲခြင်း (ဂဏန်းသက်သက်)
    const toMM = (num, showComma = true) => {
        if (num === null || num === undefined || num === "") return '၀';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        let s = showComma ? num.toLocaleString() : num.toString(); 
        return s.replace(/\d/g, d => mDigits[d]);
    };

    // ၂။ ဂဏန်းမှ မြန်မာစာသားသို့ ပြောင်းလဲခြင်း (တစ်သောင်းနှစ်ထောင်...)
    const numberToMyanmarText = (number) => {
        if (number === 0 || !number) return "သုည";
        const digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
        const units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
        let numStr = Math.floor(number).toString();
        let result = "";
        let len = numStr.length;
        for (let i = 0; i < len; i++) {
            let digit = parseInt(numStr[i]);
            let unitIndex = len - i - 1;
            if (digit !== 0) {
                result += digits[digit] + units[unitIndex];
            }
        }
        return result;
    };

    const setText = (id, val, isNum = false, showComma = true) => {
        const el = document.getElementById(id);
        if (el) el.innerText = isNum ? toMM(val, showComma) : (val || '-');
    };

    // --- Data ထည့်သွင်းခြင်း အပိုင်း ---
    
    // စည်းကြပ်နှစ် နှင့် ရက်စွဲ
    if (selectedRowData.taxYear) {
        setText('m0408_taxYear', toMM(selectedRowData.taxYear, false));
        setText('m0408_year', toMM(selectedRowData.taxYear, false)); // စာပိုဒ်ထဲက စည်းကြပ်နှစ်
    }

    let years = (selectedRowData.taxYear || "").split('-');
    if (years.length === 2) {
        let startYear = parseInt(years[0]) - 1; 
        let endYear = parseInt(years[1]) - 1; 
        setText('m0408_periodStartYear', startYear, true, false);
        setText('m0408_periodEndYear', endYear, true, false);
    }

    if (selectedRowData.itDemandDate) {
    const d = new Date(selectedRowData.itDemandDate);

    document.getElementById('user_bank_township').innerText = phpBankTownship;
    document.getElementById('user_md_no').innerText = phpMdNo;
    
    // ၁၄ ရက်ပေါင်းထည့်ခြင်း
    d.setDate(d.getDate() + 14); 

    const day = toMM(d.getDate(), false);
    const month = toMM(d.getMonth() + 1, false);
    const year = toMM(d.getFullYear(), false);
    
    const formattedDate = day + "-" + month + "-" + year;
    setText('m0408_demandDate', formattedDate);
    }

    // အမည်နှင့် လိပ်စာ
    setText('m0408_name', selectedRowData.taxpayer_name);
    setText('m0408_address', selectedRowData.address);
    setText('m0408_township', selectedRowData.township_name);
    
    const itFull = (selectedRowData.it_select || '') + "/" + (selectedRowData.it_no || '');
    // ID နှစ်ခုလုံးကို ထည့်ပေးရန် (သို့မဟုတ် selector သုံးရန်)
    const itElements = document.querySelectorAll('#m0408_it_full');
    itElements.forEach(el => el.innerText = itFull);

    // ငွေကြေးဆိုင်ရာများ
    setText('m0408_incomeTax', selectedRowData.payableIncomeTax, true);
    setText('m0408_BalanceTax', selectedRowData.finalBalanceTax, true);
    setText('m0408_panaty', selectedRowData.itpanaty, true);
    setText('m0408_taxpanaty', selectedRowData.taxpanaty, true);
    setText('m0408_netProfit', selectedRowData.netProfit, true);
    setText('m0408_businessType1', selectedRowData.businessType1, true);
    setText('m0408_netProfit2', selectedRowData.netProfit, true);
    setText('m0408_basicRelief', selectedRowData.basicRelief, true);
    setText('m0408_spouse_relief', selectedRowData.spouse_relief, true);
    setText('m0408_parent_relief', selectedRowData.parent_relief, true);
    setText('m0408_child_relief', selectedRowData.child_relief, true);
    setText('m0408_relief', selectedRowData.totalRelief, true);
    setText('m0408_totalRelief', selectedRowData.totalRelief, true);
    setText('m0408_taxableIncome', selectedRowData.finalTaxableIncome, true);
    setText('m0408_advancePaidTax', selectedRowData.advancePaidTax, true);
    setText('m0408_finalBalanceTax', selectedRowData.finalBalanceTax, true);


    

    // --- မြန်မာစာသားပြောင်းလဲခြင်း အပိုင်း (ဒီအပိုင်းကို function ထဲမှာပဲ ထားရပါမယ်) ---
    const totalAmount = selectedRowData.taxpanaty || 0;
    const amountTextMM = numberToMyanmarText(totalAmount);
    const textElement = document.getElementById('m0408_taxTextMM');
    if (textElement) {
        textElement.innerText = amountTextMM;
    }

    

    // Modal ပြသခြင်း
    var modalElem = document.getElementById('form0408Modal');
    var myModal = new bootstrap.Modal(modalElem);
    myModal.show();
}
</script>