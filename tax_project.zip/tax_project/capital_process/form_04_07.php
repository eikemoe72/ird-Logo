<style>
@media print {
        /* Modal Footer နဲ့ ခလုတ်များကို ဖျောက်ခြင်း */
        .modal-footer, .no-print, .btn, .btn-close, .modal-header { display: none !important; }
        
 

        body * { visibility: hidden; }
        #form0407Modal, #form0407Modal * { visibility: visible !important; }
        #form0407Modal { 
        position: absolute; 
        left: 0 !important; 
        top: 0; 
        width: 100%; 
        margin: 0 !important; 
        padding: 0 !important; 
    }

        /* အပြင်ဘက်ဆုံး အနီရောင်မျဉ်း (Container Border) ကို ဖျက်ခြင်း */
    .print-container { 
        padding-left: 30px !important; 
        padding-right: 15px !important;
        padding-top: 40mm !important;
        padding-bottom: 30mm !important;
        margin: 0 !important;
        width: 100% !important;
        border: 2px solid black !important;
    
    }
    .modal-dialog {
        margin: 0 !important;
        max-width: 100% !important;
        width: 100% !important;
       
    }
    .modal-content, .modal-body {

        padding: 0 !important;
       
    }

       
    

 
}

    /* ၁။ Modal Dialog အကျယ်ကို ထိန်းခြင်း */
#form0407Modal .modal-dialog {
    max-width: 800px; /* A4 size နဲ့ ကိုက်ညီမည့် အကျယ် */
    margin: 20px auto;
}

/* ၂။ Modal Content ထဲမှာ Padding ပြန်ညှိခြင်း */
#form0407Modal .modal-body {
    padding: 0px !important; /* စာရွက်အနားသတ်ပုံစံမျိုးရအောင် */
    overflow-x: hidden; /* ဘေးကို ကျွံမထွက်စေရန် */
}
.dashed-line{border-bottom:1.4px dotted black !important;}
.solid-line{border-bottom:1.4px solid black !important;}
.under-line { border-bottom: 1.4px dashed #0d0d0d !important; min-width:140px; display: inline-block; text-align: left; padding-left:0px;}
</style>

<div class="modal fade" id="form0407Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">ပတခ(ဝင)-၀၄-၀၇ ဆုံးဖြတ်ချက် ထုတ်ယူရန်</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container" style="padding-left: 80px !important; padding-right: 30px !important; margin-left: 0px !important;">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:1.9; margin-bottom: 5px;">
                        <tr>
                            <td style='padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇</p>

                    <div style="text-align:center; font-weight:bold; line-height: 1.9; margin-bottom:20px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀ နှင့် ၆၄ တို့အရ ဝင်ငွေခွန်စည်းကြပ်မှုနှင့် <br>
                        ဒဏ်ကြေးငွေစည်းကြပ်မှု ဆုံးဖြတ်ချက် 
                    </div>
                    <div style="text-align:center;  line-height: 1.9; margin-bottom:20px;">
                        
                        ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                        (<span id="m0407_township_title"></span>)
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:65%'></td>
                            <td style='text-align:right;'>ရက်စွဲ၊ <span class="dashed-line" id="m0407_demandDate" style="width: 100px;"></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style='text-align:right;'>စည်းကြပ်နှစ်၊ <span class="dashed-line" id="m0407_taxYear" style="width: 100px;"></span></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:15px; line-height: 2;'>
                        <tr>
                            <td style='width:6%'>၁။</td>
                            <td style='width:170px; font-weight:bold;'>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</td>
                            <td style='width:420px; text-align: left;' class='under-line'>၊ <span  id="m0407_it_full"></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၂။</td>
                            <td style='width:150px; font-weight:bold;'>အခွန်ထမ်းအမည်နှင့်လိပ်စာ</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ <span  id="m0407_name" ></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'></td>
                            <td style='width:150px'></td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ <span  id="m0407_address" ></span></td>
                        </tr>
                       
                        <tr>
                            <td style='width:6%'>၃။</td>
                            <td style='width:150px; font-weight:bold;'>အခွန်ထမ်းအမျိုးအစား</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ ပုဂ္ဂလိက</td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၄။</td>
                            <td style='width:150px; font-weight:bold;'>လုပ်ငန်းအမျိုးအစား</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ <span id="m0407_biz"></span></td>
                        </tr>


                        <tr>
                            <td style='width:6%'>၅။</td>
                            <td style='width:150px; font-weight:bold;'>လုပ်ငန်းခွဲများ</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ <span id="m0407_biz_txt"></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၆။</td>
                            <td style='width:150px; font-weight:bold;'>(က)ပုဂ္ဂိုလ်စုဝင်များ</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ </span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'></td>
                            <td style='width:150px; font-weight:bold;'>( ခ ) အစုများ</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ </span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၇။</td>
                            <td style='width:150px; font-weight:bold;'>ကြေညာသည့်ဝင်ငွေ</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ (ဝငခ)<span id="m0407_declaration"></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၈။</td>
                            <td style='width:150px; font-weight:bold;'>တင်ပြသောစာရင်းများ</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ </span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၉။</td>
                            <td style='width:150px; font-weight:bold;'>စည်းကြပ်သည့်ပုဒ်မ</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊၂၈၊၃၀ နှင့် ၆၄ တို့အရ </td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၁၀။</td>
                            <td style='width:150px; font-weight:bold;'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                            <td style='width:420px;; text-align: left;' class='under-line'>၊ (၀၁-၀၄-<span id="m0407_periodStartYear"></span>) မှ (၃၁-၀၃-<span id="m0407_periodEndYear"></span>)ထိ ကာလ</td>
                        </tr>
                        
                    </table>

                    <p style='text-align:center; font-weight:bold; margin-top:20px; text-decoration: '>
                        ဝင်ငွေခွန်စည်းကြပ်မှုနှင့် ဒဏ်ကြေးငွေ စည်းကြပ်မှု ဆုံးဖြတ်ချက်
                    </p>

                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းသည် (<span id="m0407_taxYear_txt"></span>) ဝင်ငွေနှစ်အတွင်း (<span id="m0407_biz_para"></span>) လုပ်ငန်းမှ 
                        ကြိုတင်ခွန်(  )ကျပ် ပေးသွင်းထားပါသည်။/(မပေးသွင်းထားပါ။) ဝင်ငွေနှစ်အတွက်
                        ဝင်ငွေ (<span id="m0407_declaration_para"></span>) ကျပ် ဖော်ပြထားသည့် ကြေညာလွှာကို အချိန်မီ တင်သွင်းထားပါသည်။ /(မတင်သွင်းထားပါ)
                        သို့ရာတွင် ခိုင်လုံသော စာရင်းအင်းတင်ပြနိုင်ခြင်း မရှိသဖြင့် အောက်ပါအတိုင်း စည်းကြပ်ဆုံးဖြတ်လိုက်သည် -
                    </div>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းသည် အဆိုပါကြေညာသောဝင်ငွေအတွက် အထောက်အကူပြုသော စာရင်းအင်း တစ်စုံတစ်ရာကိုလည်းကောင်း၊ ခိုင်မာသောသက်သေခံ အထောက်အထားများကိုလည်းကောင်း
                        ခိုင်လုံစွာ တင်ပြနိုင်ခြင်း မရှိပါသောကြောင့် အခွန်ထမ်း၏ထွက်ဆိုတင်ပြချက်၊ လုပ်ငန်းပမာဏ၊ စီးပွားရေးလုပ်ငန်း အခြေအနေနှင့် စုံစမ်းလေ့လာတွေ့ရှိ
                    </div>
                    <br><br><br><br><br><br><br><br>
                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇ (အဆက်)</p>
                     <div style="text-align:justify; line-height: 1.9; text-indent: 0px;">
                        ရသောသတင်းအချက်အလက်များကို အခြေခံ၍ 
                        ဝင်ငွေခွန် ဥပဒေပုဒ်မ ၁၉ နှင့် အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇ အရ အောက်ပါအတိုင်း စည်းကြပ်လိုက်သည်-
                    </div>

                    <table style="width:100%; margin: 20px auto; border-collapse: collapse; font-size: 15px;">
                        <tr>
                            <td style="width:65%; padding: 5px; text-align: right;">စုစုပေါင်းရောင်းရငွေ</td>
                            <td style="width:5%;">=</td>
                            <td style="width:20%; text-align:right;" class="dashed-line" id="m0407_totalSales"></td>
                            <td style="width:20%;" ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">(နုတ်) ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td>=</td>
                            <td style="text-align:right; color:red;" class="solid-line" id="m0407_minusCT" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ကုန်သွယ်လုပ်ငန်းခွန်မပါ ရောင်းရငွေ</td>
                            <td>=</td>
                            <td style="text-align:right;" class="dashed-line" id="m0407_netSales" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="width:65%; padding: 5px; text-align: right; ">အခြားရငွေ</td>
                            <td style="width:5%;">=</td>
                            <td style="text-align:right;" class="solid-line" id="m0407_otherIncomeVal" ></td>
                            <td ></td>
                        </tr>
                   
                        <tr>
                            <td style="padding: 5px; text-align: right;">ဝင်ငွေခွန်တွက်ချက်ရန်ရောင်းရငွေ</td>
                            <td>=</td>
                            <td style="text-align:right;" class="dashed-line" id="m0407_income" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; font-weight: bold; text-align: right;">(နုတ်) တိုက်ရိုက်ကုန်ကျစရိတ်</td>
                            <td>=</td>
                            <td style="text-align:right;color:red;" class="solid-line" id="m0407_directCost" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">အကြမ်းအမြတ်</td>
                            <td>=</td>
                            <td style="text-align:right;" class="dashed-line" id="m0407_grossProfit"></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">(နုတ်) စီမံအုပ်ချုပ်မှုစရိတ်</td>
                            <td>=</td>
                            <td style="text-align:right;color:red;" class="solid-line" id="m0407_AdminCost" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">အသားတင်အမြတ်</td>
                            <td>=</td>
                            <td style="text-align:right;" class="dashed-line" id="m0407_netProfit"></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">(နုတ်) သက်သာခွင့်များ</td>
                            <td>=</td>
                            <td style="text-align:right; color:red;" class="solid-line" id="m0407_totalRelief" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">အခွန်စည်းကြပ်ရန်ဝင်ငွေ</td>
                            <td>=</td>
                            <td style="text-align:right;" class="solid-line" id="m0407_taxableIncome" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px;text-align: right;">ကျသင့်ဝင်ငွေခွန်</td>
                            <td>=</td>
                            <td style="text-align:right;" class="dashed-line" id="m0407_incomeTax"></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ကြိုတင်ခွန်</td>
                            <td>=</td>
                            <td style="text-align:right;" class="solid-line" id="m0407_advancePaidTax" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ထပ်မံပေးဆောင်ရန်ဝင်ငွေခွန်</td>
                            <td>=</td>
                            <td style="text-align:right;" class="dashed-line" id="m0407_finalBalanceTax" ></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ပေးဆောင်ရမည့်ဒဏ်ကြေးငွေ</td>
                            <td>=</td>
                            <td style="text-align:right; color:red;" class="solid-line" id="m0407_panaty" ></td>
                            <td ></td>
                        </tr>
                        <tr style="font-weight: bold; font-size: 1em;">
                            <td style="padding:  5px; text-align: right;">ပေးဆောင်ရန် စုစုပေါင်း (အခွန်+ဒဏ်ကြေး)</td>
                            <td>=</td>
                            <td style="text-align:right;" class="solid-line" id="m0407_taxpanaty" ></td>
                            <td ></td>
                        </tr>
                    </table>
                    <br><br><br>
                    <table style='width:100%; margin-top:40px;'>
                        <tr>
                            <td style='width:30%; text-align:center;'>ရုံးတံဆိပ်</td>
                            <td style='width:20%; text-align:center;'></td>
                            <td style='width:50%; text-align:center; line-height: 1.8;'>
                                တာဝန်ခံအရာရှိ<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                <span id="m0407_township_footer"></span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
function openForm0407() {
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("Table ထဲမှ row ကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    // ၁။ မြန်မာဂဏန်းပြောင်းလဲခြင်း (Comma မပါစေရန် logic ပါဝင်သည်)
    const toMM = (num, showComma = true) => {
        if (num === null || num === undefined || num === "") return '၀';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        
        // ဂဏန်းမဟုတ်တဲ့ (-) တို့ကို မဖျက်စေဘဲ ဂဏန်းတွေကိုပဲ replace လုပ်ဖို့ regex သုံးပါမယ်
        let s = showComma ? num.toLocaleString() : num.toString(); 
        return s.replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val, isNum = false, showComma = true) => {
        const el = document.getElementById(id);
        if (el) el.innerText = isNum ? toMM(val, showComma) : (val || '-');
    };

    // ၂။ စည်းကြပ်နှစ် (Tax Year) ကို မြန်မာလိုပြောင်းလဲခြင်း
    // အပေါ်ဘက် စည်းကြပ်နှစ် (ညာဘက်အပေါ်)
    if (selectedRowData.taxYear) {
        // toMM function သုံးပြီး အင်္ဂလိပ်ဂဏန်းကို မြန်မာပြောင်းလိုက်ပါမယ်
        const mmTaxYear = toMM(selectedRowData.taxYear, false); 
        setText('m0407_taxYear', mmTaxYear);
    }

    // ၃။ ဝင်ငွေနှစ် (Income Year) ကာလများအတွက် ခွဲထုတ်ခြင်း
    let years = (selectedRowData.taxYear || "").split('-');
    if (years.length === 2) {
        let startYear = parseInt(years[0]) - 1; 
        let endYear = parseInt(years[1]) - 1; 
        
        // ဝင်ငွေနှစ်စာသား (ဥပမာ- ၂၀၂၅-၂၀၂၆)
        const adjustedTaxYearMM = toMM(startYear + "-" + endYear, false);
        setText('m0407_taxYear_txt', adjustedTaxYearMM);

        // ၁၀။ ဝင်ငွေနှစ် (အခွန်ကာလ) ရက်စွဲများ
        setText('m0407_periodStartYear', startYear, true, false);
        setText('m0407_periodEndYear', endYear, true, false);
    }

    // ၄။ ရက်စွဲ (Demand Date) ပြင်ဆင်ခြင်း
    if (selectedRowData.itDemandDate) {
        const d = new Date(selectedRowData.itDemandDate);
        const formattedDate = toMM(d.getDate(), false) + "-" + toMM(d.getMonth() + 1, false) + "-" + toMM(d.getFullYear(), false);
        setText('m0407_demandDate', formattedDate);
    }

    // အခြား ဒေတာများ (အနီဝိုင်းပြထားသော နေရာများအတွက် ID များ စစ်ဆေးပါ)
    setText('m0407_name', selectedRowData.taxpayer_name);
    setText('m0407_address', selectedRowData.address);
    
    // လုပ်ငန်းအမျိုးအစား (၄)
    setText('m0407_biz', selectedRowData.businessType1);
    
    // အောက်က စာပိုဒ်ထဲမှာ ထပ်ပေါ်နေတဲ့ လုပ်ငန်းအမျိုးအစား ID (ရှိလျှင်)
    // ပုံထဲက မြားပြထားတဲ့ ( ) အတွင်းက နေရာအတွက် ID ကို m0407_biz_para လို့ ယာယီသတ်မှတ်ထားပါတယ်
    const bizParaEl = document.getElementById('m0407_biz_para');
    if (bizParaEl) bizParaEl.innerText = selectedRowData.businessType1;

    setText('m0407_biz_txt', selectedRowData.businessType2);
    setText('m0407_township_title', selectedRowData.township_name);
    setText('m0407_township_footer', selectedRowData.township_name);
    
    const itFull = (selectedRowData.it_no || '') + "/" + (selectedRowData.it_select || '');
    setText('m0407_it_full', itFull);

    // ငွေကြေးဆိုင်ရာများ
    setText('m0407_declaration', selectedRowData.declaredIncome1, true);
    // စာပိုဒ်ထဲက ဝင်ငွေနေရာအတွက် ( )
    const declParaEl = document.getElementById('m0407_declaration_para');
    if (declParaEl) declParaEl.innerText = toMM(selectedRowData.declaredIncome1, true);

    setText('m0407_totalSales', selectedRowData.totalSales, true);
    setText('m0407_minusCT', selectedRowData.minusCTInput, true);
    setText('m0407_netSales', selectedRowData.netSales, true);
    setText('m0407_otherIncomeVal', selectedRowData.otherIncomeVal, true);
    setText('m0407_income', selectedRowData.taxableSales, true);
    setText('m0407_directCost', selectedRowData.totalDirectCost, true);
    setText('m0407_grossProfit', selectedRowData.grossProfit, true);
    setText('m0407_AdminCost', selectedRowData.totalAdminCost, true);

    setText('m0407_netProfit', selectedRowData.netProfit, true);
    setText('m0407_totalRelief', selectedRowData.totalRelief, true);
    setText('m0407_taxableIncome', selectedRowData.finalTaxableIncome, true);
    setText('m0407_incomeTax', selectedRowData.payableIncomeTax, true);
    setText('m0407_advancePaidTax', selectedRowData.advancePaidTax, true);
    setText('m0407_finalBalanceTax', selectedRowData.finalBalanceTax, true);
    setText('m0407_panaty', selectedRowData.itpanaty, true);
    setText('m0407_taxpanaty', selectedRowData.taxpanaty, true);

    // Modal Show
    var modalElem = document.getElementById('form0407Modal');
    var myModal = new bootstrap.Modal(modalElem);
    myModal.show();
}
</script>