<style>
@media print {
    /* ၁။ မလိုအပ်တာတွေ အကုန်ဖျောက်ပါ */
    .modal-footer, .no-print, .btn, .btn-close { display: none !important; }
    body * { visibility: hidden; }
    
    /* ၂။ Modal Content ကို အဓိကထား ဖော်ပြပါ */
    #orderSheetModal, #orderSheetModal * { visibility: visible !important; }
    
    #orderSheetModal { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    /* ၃။ Modal Dialog နှင့် Content ကို စာရွက်ဆိုဒ် (A4) အတွင်း သွတ်သွင်းပါ */
    .modal-dialog { 
        margin-left: 0mm !important; 
        max-width: 100% !important; 
        width: 100% !important;
        padding-bottom:20mm !important;
        border: none !important; 
    }

    .modal-content { 
        border: none !important; 
        width: 100% !important; /* 400mm က အရမ်းကျယ်လွန်းလို့ 100% ပြောင်းပါ */
        font-size: 12pt !important; /* စာလုံးဆိုဒ်ကို သင့်တော်ရုံ 14pt ခန့်ပဲ ထားပါ */
    }
 

    /* ၄။ ဇယားဘောင် (Border) များ အားလုံး ပြန်ပေါ်စေရန် */
    table {
        width: 100% !important;
        border-collapse: collapse !important;
        border: none !important; /* အပြင်ဘောင် အပြည့်ထည့်ပါ */
        table-layout: fixed !important; /* စာသားကြောင့် ဘေးမကျွံစေရန် */
        line-height:24px;
    }
   thead {
        display: table-header-group; /* ဒါက header ကို စာမျက်နှာတိုင်းမှာ ပေါ်စေတာပါ */
        background-color:

    }

    /* header ထဲက စာသားတွေကို အပေါ်ကနေ နည်းနည်း ခွာချချင်ရင် */
    thead tr th {
        padding-top: 20px; /* သင်လိုအပ်သလောက် အတိုးအလျှော့ လုပ်ပါ */
        vertical-align: center;
    }
    th, td {
        border: 2px solid black !important; /* အကွက်တိုင်းကို ဘောင်ခတ်ပါ */
        padding: 3px !important;
        word-wrap: break-word !important;
    }

    /* ၅။ Left Border ပျောက်နေတာကို အဓိက ပြင်ဆင်ခြင်း */
    .print-container { 
        padding: 0 !important;
        margin-left: 0mm !important; /* ဘယ်ဘက်မျဉ်း ပေါ်လာစေရန် margin အနည်းငယ်ပေးပါ */
        width: calc(100% - 0mm) !important;
        
    }
    .middle-column{vertical-align:center;}

    @page {
        size: A4;
        margin: 5mm;
    }
}

    
    /* ၁။ Modal Dialog အကျယ်ကို ထိန်းခြင်း */
#orderSheetModal .modal-dialog {
    max-width: 800px; /* A4 size နဲ့ ကိုက်ညီမည့် အကျယ် */
    margin: 20px auto;
}

/* ၂။ Modal Content ထဲမှာ Padding ပြန်ညှိခြင်း */
#orderSheetModal .modal-body {
    padding: 0px !important; /* စာရွက်အနားသတ်ပုံစံမျိုးရအောင် */
    overflow-x: hidden; /* ဘေးကို ကျွံမထွက်စေရန် */
}

/* ၃။ ဇယား အကျယ်ကို Fix လုပ်ခြင်း */
.order-sheet-table {
    width: 100% !important;
    table-layout: fixed; /* ဒါက အရေးကြီးပါတယ်၊ Column တွေ ညာဘက်ကို မတွန်းထုတ်ဖို့ပါ */
    border-collapse: collapse;
}

</style>

<div class="modal fade" id="orderSheetModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">နေ့စဉ်လုပ်ငန်းမှတ်တမ်း ထုတ်ယူရန်</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container" style="padding-left: 30px !important; margin-left: 0px !important;">
                    <div style="text-align: center;">
                        
                        <h6 style="font-weight: bold; font-size: 18px;">အမိန့်စာချပ်</h6>
                        <p>(အထွေထွေအမှုတွဲဖိုင်အတွက်အသုံးပြုရန်)</p>
                    </div>

                  
                    <table style="width:100%" class="main-content-table2">
                        <tr >
                            <td style="width:18%"><b>မြို့နယ်ရုံးအမည်</b></td>
                            <td style="width:52%; border-bottom: 1px dashed #000 !important;">- <span id="os_township"></td>
                            <td style="width:13%; border: 1px dotted #000 !important; text-align:right;"><b>စည်းကြပ်နှစ်:</b></td>
                            <td style="width:17%; border: 1px dotted #000 !important; text-align:right;"> <span id="os_year"></td>
                        </tr>

                        <tr >
                            <td style="width:18%"><b>အခွန်ထမ်းအမည်</td>
                            <td style="width:52%; border-bottom: 1px dashed #000 !important;">- <span id="os_name"></td>
                            <td style="width:13%; border: 1px dotted #000 !important; text-align:right;"><b>GIR-No:</b></td>
                            <td style="width:17%; border: 1px dotted #000 !important; text-align:right;"> <span id="os_gir"></td>
                        </tr>
    
                        <tr >
                            <td style="width:18%"><b>အခွန်ထမ်းလိပ်စာ</td>
                            <td style="width:52%; border-bottom: 1px dashed #000 !important;">- <span id="os_address"></td>
                            <td style="width:13%; border: 1px dotted #000 !important; text-align:right;"><b>အခွန်မှူး:</b></td>
                            <td style="width:17%; border: 1px dotted #000 !important; text-align:right;"> <span id="os_officer"></td>
                        </tr>

                        <tr >
                            <td style="width:18%"><b>လုပ်ငန်းအမျိုးအစား</td>
                            <td style="width:52%; border-bottom:: 1px dashed #000 !important;">- <span id="os_biz"></td>
                            <td style="width:13%; border: 1px dotted #000 !important; text-align:right;"><b>ရာထူး:</b></td>
                            <td style="width:17%; border: 1px dotted #000 !important; text-align:right;"> <span id="os_rank"></td>
                        </tr>
                    </table>

         
                    <table class="main-content-table">
                        <thead>
                            <tr>
                                <th style="width: 13%; font-size:14px; text-align:center; " class="outer-column">ဆောင်ရွက်<br>သည့်နေ့စွဲ</th>
                                <th style="width: 76%; font-size:14px; text-align:center; " class="middle-column">လုပ်ငန်းအကြောင်းအရာအကျဉ်းချုပ်</th>
                                <th style="width: 13%; font-size:14px; text-align:center; " class="outer-column">လိုက်နာဆောင်<br>ရွက်သည့်နေ့</th>
                            </tr>
                        </thead>

                        <tbody>
                            <tr>
                                <td style="text-align: center; vertical-align:top; " class="left_border">................</td>
                                <td style="height: 140px; text-align: justify; line-height:24px">
                                    <p>အခွန်ထမ်းသည် ဝင်ငွေနှစ်အတွင်း ဝင်ငွေခွန်ကြိုတင်ခွန်(3,000,000)ကျပ်ပေးသွင်းထားပါသည်။ / မပေးသွင်းထားပါ။</p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;">စာရေးကြီး</div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border"></td>
                            <tr>
                                <td style="text-align: center; vertical-align:top;" class="left_border">................</td>
                                <td style="height: 140px; text-align: justify;line-height:24px">
                                    <p>အခွန်ထမ်းသည် ဝင်ငွေနှစ်အတွင်း ဝင်ငွေကြေညာလွှာကို (................)ရက်နေ့တွင် ဝင်စာမှတ်ပုံတင်အမှတ်(......)ဖြင့် 
                                        အချိန်မီတင်သွင်းထားပါသည်။ / အချိန်မီတင်သွင်းထားခြင်းမရှိပါ။</p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;">စာရေးကြီး</div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border"></td>
                            <tr>
                                <td style="text-align: center; vertical-align:top;" class="left_border">................</td>
                                <td style="height: 140px; text-align: justify;line-height:24px">
                                    <p>အခွန်ထမ်းအား ကြားနာစစ်ဆေးရန် ပတခ(ဝင)-၀၄-၀၅ဖြင့် အကြောင်းကြားစာထုတ်ဆင့်ပါ။</p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border">..............ချိန်း</td>
                            </tr>
                            <tr>
                                <td style="text-align: center; vertical-align:top;" class="left_border">................</td>
                                <td style="height: 140px; text-align: justify; line-height:24px">
                                    <p>အခွန်ထမ်း/ကိုယ်စားလှယ်လာရောက်သဖြင့် တင်ပြချက်များနှင့်ထွက်ဆိုချက်များကို မှတ်တမ်းတင်သည်။</p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border"></td>
                            </tr>
                            <tr style="height: 50px;">
                                <td style="text-align: center; vertical-align:top;" class="left_border"><span id="os_itDemandDate"></td>
                                <td style="height: 150px; text-align: justify; line-height:24px">
                                    <p>အခွန်ထမ်းတင်ပြသော ဝင်ငွေကြေညာလွှာ၊ ပတ်ဝန်းကျင်အထောက်အထားများကို ကိုးကား၍ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၂၀၊ ၆၄ တို့အရ အောက်ပါအတိုင်းစည်းကြပ်မှုအမိန့် ချမှတ်လိုက်သည်-</p>
                                                
                                    <table style="width:100%; border:none !important; line-height:24px;">
                                        <tr >
                                            <td style="border:none !important; width:55%; text-align:right;">အသားတင်အမြတ်</td>
                                            <td style="border:none !important; width:5%;">=</td>
                                            <td style="border:none !important; width:20%; border-bottom: 1px dashed #000 !important; width:150px; text-align:right;" id="os_profit"></td>
                                            <td style="border:none !important; width:20%;"></td>
                                        </tr>
                                        <tr>
                                            <td style="border:none !important; width:55%; text-align:right;">ကျသင့်ဝင်ငွေခွန်</td>
                                            <td style="border:none !important; width:5%;">=</td>
                                            <td style="border:none !important; width:20%; border-bottom: 1px dashed #000 !important; text-align:right;" id="os_income_tax"></td>
                                            <td style="border:none !important; width:20%;"></td>
                                        </tr>
                                        <tr>
                                            <td style="border:none !important; width:55%; text-align:right;">ပေးသွင်းထားသောကြိုတင်ခွန်</td>
                                            <td style="border:none !important; width:5%;">=</td>
                                            <td style="border:none !important; width:20%; border-bottom: 2px solid #000 !important; text-align:right;" id="os_advance"></td>
                                            <td style="border:none !important; width:20%;"></td>
                                        </tr>
                                        <tr>
                                            <td style="border:none !important; width:55%; text-align:right;">ထပ်မံပေးဆောင်ရမည့်ဝင်ငွေခွန်</td>
                                            <td style="border:none !important; width:5%;">=</td>
                                            <td style="border:none !important; width:20%; border-bottom: 1px dashed #000 !important; text-align:right;" id="os_balance"></td>
                                            <td style="border:none !important; width:20%;"></td>
                                        </tr>
                                        <tr>
                                            <td style="border:none !important; width:55%; text-align:right;">ပေးဆောင်ရမည့်ဒဏ်ကြေးငွေ</td>
                                            <td style="border:none !important; width:5%; ">=</td>
                                            <td style="border:none !important; width:20%; border-bottom: 2px double #000 !important; text-align:right;" id="os_penalty"></td>
                                            <td style="border:none !important; width:20%;"></td>
                                        </tr>
                                        <tr>
                                            <td style="border:none !important; width:55%; text-align:right; font-weight: bold;">ပေးဆောင်ရန် အခွန်+ဒဏ်ကြေး</td>
                                            <td style="border:none !important; width:5%; ">=</td>
                                            <td style="border:none !important; width:20%; border-bottom: 2px double #000 !important; font-weight: bold; text-align:right;" id="os_total_all"></td>
                                            <td style="border:none !important; width:20%;"></td>
                                        </tr>
                                    </table></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border">CDN-<span id="os_itDemandNo"></td>
                            </tr>
                     
                            <tr>
                                <td style="text-align: center; vertical-align:top;" class="left_border"><br><br>................</td>
                                <td style="height: 150px; text-align: justify; line-height:24px"><br><br>
                                     <p style="text-align:justify;">ကျသင့်အခွန်( <strong><span style="color:red;" id="os_balance1"></span></strong> )
                                     နှင့်ဒဏ်ငွေ( <strong><span style="color:red;" id="os_penalty1"></span></strong> )ကို 
                                     ( <span style="color:red;" id="rq_date1"></span> )နေ့မတိုင်မီ ပေးဆောင် စေရန် ချလန်ထုတ်ဆင့်ပါ။</p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border"></td>
                            </tr>
                            <tr>
                                <td style="text-align: center; vertical-align:top;" class="left_border">................</td>
                                <td style="height: 150px; text-align: justify; line-height:24px">
                                    <p>ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေကို ပြေကြေစွာပေးသွင်းပြီး ဖြစ်ပါသဖြင့် အမှုပိတ်သိမ်းသည်။</p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border"></td>
                            </tr>
                            <tr>
                                <td style="text-align: center; vertical-align:top;" class="left_border">................</td>
                                <td style="height: 150px; text-align: justify; line-height:24px">
                                    <p>ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေကို စည်းကြပ်သည့်နှစ်အတွင်း ပေးသွင်းခြင်း မရှိသည့်အတွက် အခွန်ကြွေးကျန်ငွေအား အခွန်ကြွေးမှတ်ပုံတင်စာရင်းသို့ ကူးပြောင်းမှတ်တမ်းတင်သည်။</p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;">အခွန်မှူး<br><br><br><br><br><br><br><br><br><br><br><br></div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border">................</td>
                            </tr>
                            <tr>
                                <td style="text-align: center; vertical-align:top;" class="left_border"></td>
                                <td style="height: 150px;">
                                    <p></p>
                                    <br><br>
                                     <p></p>
                                    <br><br>
                                     <p></p>
                                    <br><br>
                                     <p></p>
                                    <br><br>
                                     <p></p>
                                    <br><br>
                                    <div style="text-align: right; padding-right: 80px;"></div></td>
                                <td style="text-align: center; vertical-align:top;" class="right_border"></td>
                            </tr>
                        </tbody>  
                    </table>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
    function openFormordersheet() {
        var data = selectedRowData;
        var userRank = "<?php echo $rank; ?>"; // PHP က rank ကို ဒီမှာ တိုက်ရိုက်ယူလိုက်ခြင်း

        // 1. Row ရွေးထားခြင်း ရှိမရှိ စစ်ဆေးခြင်း
        if (typeof selectedRowData === 'undefined' || !selectedRowData) {
            alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
            return;
        }

        // selectedRowData ကို data ဆိုတဲ့ variable အတိုကောက်ပေးလိုက်ပါ (အောက်က code တွေ အလုပ်လုပ်အောင်)
        var data = selectedRowData;

        // 2. Data များကို Modal ထဲသို့ ထည့်သွင်းခြင်း (setData function မရှိလျှင် အောက်ပါအတိုင်းရေးပါ)
        const updateText = (id, value) => {
            const el = document.getElementById(id);
            if (el) el.innerText = value || '-';
        };

        updateText('os_township', data.township_name);
        updateText('os_name', data.taxpayer_name);
        updateText('os_address', data.address);
        updateText('os_biz', data.businessType1);
        updateText('os_year', data.taxYear);
        updateText('os_officer', data.officer_name);
        updateText('os_rank', userRank);
        updateText('os_gir', (data.it_no || '') + " / " + (data.it_select || 'စီးပွား'));

        // formatNumber function ရှိတယ်ဆိုတဲ့ အယူအဆနဲ့ ရေးထားပါတယ်
        updateText('os_profit', typeof formatNumber === 'function' ? formatNumber(data.netProfit || 0) : (data.netProfit || 0));
        updateText('os_income_tax', typeof formatNumber === 'function' ? formatNumber(data.payableIncomeTax || 0) : (data.payableIncomeTax || 0));
        updateText('os_advance', typeof formatNumber === 'function' ? formatNumber(data.advancePaidTax || 0) : (data.advancePaidTax || 0));
        updateText('os_balance', typeof formatNumber === 'function' ? formatNumber(data.finalBalanceTax || 0) : (data.finalBalanceTax || 0));
        updateText('os_penalty', typeof formatNumber === 'function' ? formatNumber(data.itpanaty || 0) : (data.itpanaty || 0));
        updateText('os_total_all', typeof formatNumber === 'function' ? formatNumber(data.taxpanaty || 0) : (data.taxpanaty || 0));

        updateText('os_balance1', typeof formatNumber === 'function' ? formatNumber(data.finalBalanceTax || 0) : (data.finalBalanceTax || 0));
        updateText('os_penalty1', typeof formatNumber === 'function' ? formatNumber(data.itpanaty || 0) : (data.itpanaty || 0));
        updateText('os_itDemandNo', typeof formatNumber === 'function' ? formatNumber(data.itDemandNo || 0) : (data.itDemandNo || 0));
        updateText('os_itDemandDate', typeof formatNumber === 'function' ? formatNumber(data.itDemandDate || 0) : (data.itDemandDate || 0));

        if (data.itDemandDate && data.itDemandDate !== '0000-00-00') {
        const d = new Date(data.itDemandDate);
        
        // Date က Invalid ဖြစ်နေသလား ထပ်စစ်ပါ
        if (!isNaN(d.getTime())) {
            d.setDate(d.getDate() + 14); 
            
            // ရက်စွဲ format ကို သေသပ်အောင် (01-01-2026) ပုံစံမျိုး ပြင်ရေးပါ
            const dd = String(d.getDate()).padStart(2, '0');
            const mm = String(d.getMonth() + 1).padStart(2, '0');
            const yyyy = d.getFullYear();
            
            const formattedDate = dd + "-" + mm + "-" + yyyy;
            
            // id='rq_date1' ရှိတဲ့ element ထဲကို ထည့်ခြင်း
            const targetEl = document.getElementById('rq_date1');
            if (targetEl) {
                targetEl.innerText = formattedDate;
            }
        }
}
        // 3. Modal ကို ဖော်ပြခြင်း
        var orderModalEl = document.getElementById('orderSheetModal');
        var myModal = new bootstrap.Modal(orderModalEl);
        myModal.show();

        // 4. ယခင်တက်နေသော formsModal ကို ပိတ်ခြင်း
        var formsModalEl = document.getElementById('formsModal');
        if (formsModalEl) {
            var formsModal = bootstrap.Modal.getInstance(formsModalEl);
            if (formsModal) {
                formsModal.hide();
            }
        }
    }
</script>