<?php
include 'db_config.php';

if (isset($_GET['township_name'])) {
    $t_name = $_GET['township_name'];
    
    // table ထဲက column နာမည်မှာ township_code ဖြစ်နေလို့ အဲဒီအတိုင်း သုံးရပါမယ်
    $stmt = $conn->prepare("SELECT township_code FROM locations WHERE township_name = ? LIMIT 1");
    $stmt->bind_param("s", $t_name);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo $row['township_code']; // code ကို text အနေနဲ့ ပြန်ထုတ်ပေးမယ်
    }
    exit();
}
?>