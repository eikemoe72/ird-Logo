<?php
session_start();
include 'db_config.php';

// Login Check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$u_id = $_SESSION['user_id'] ?? 0;

// Variable များကို default အနေဖြင့် သတ်မှတ်ထားခြင်း
$bank_township = '...............';
$md_no = '...............';
$rank = '............';
$user_state = '';
$user_township = '';
$user_region = '';
$user_role = '';

if ($u_id > 0) {
    // database မှ လက်ရှိ login ဝင်ထားသူ၏ data အကုန်ဆွဲထုတ်ခြင်း
    $u_query = mysqli_query($conn, "SELECT * FROM user_register WHERE id = '$u_id'");
    
    if ($u_row = mysqli_fetch_assoc($u_query)) {
        // Table ထဲက column name အမှန်များဖြင့် variable ထဲထည့်ခြင်း
        $bank_township = $u_row['bank_township'] ?: '...............';
        $md_no         = $u_row['md_no']         ?: '...............';
        $rank          = $u_row['rank_']          ?: '...............';
        $user_state    = $u_row['state_name']    ?: '';
        $user_township = $u_row['township_name'] ?: '';
        $user_region   = $u_row['region']        ?: ''; // user_register ထဲက region
        $user_role     = $u_row['role']          ?: '';
        $user_other    = $u_row['other']         ?: '';

        // Session ထဲသို့လည်း တပါတည်း သိမ်းဆည်းထားခြင်း
        $_SESSION['state_name']    = $user_state;
        $_SESSION['township_name'] = $user_township;
        $_SESSION['region']        = $user_region;
        $_SESSION['user_role']     = $user_role;
    }
}

function formatNumber($num) {
    return is_numeric($num) ? number_format($num) : ($num ?: '0');
}


// 🌟 🌟 🌟 [အရေးကြီးဆုံး ပြင်ဆင်ချက် - JavaScript API အတွက် JSON ထုတ်ပေးရန်] 🌟 🌟 🌟
if (isset($_GET['action']) && $_GET['action'] == 'fetch_list') {
    header('Content-Type: application/json; charset=utf-8');
    
    // User Role အလိုက် JavaScript ရဲ့ Table ထဲပြမယ့် Query
    if ($user_role === 'super_admin') {
        $api_sql = "SELECT * FROM regular_data ORDER BY id DESC";
    } elseif ($user_role === 'state_admin') {
        $api_sql = "SELECT * FROM regular_data WHERE state_name = '$user_state' OR state = '$user_state' ORDER BY id DESC";
    } else {
        $api_sql = "SELECT * FROM regular_data WHERE township_name = '$user_township' OR township = '$user_township' ORDER BY id DESC";
    }

    $api_res = $conn->query($api_sql);
    $api_data = [];
    if ($api_res) {
        while ($api_row = $api_res->fetch_assoc()) {
            $api_row['state_name']    = $api_row['state_name'] ?? $api_row['state'] ?? '';
            $api_row['township_name'] = $api_row['township_name'] ?? $api_row['township'] ?? '';
            $api_data[] = $api_row;
        }
    }
    echo json_encode($api_data, JSON_UNESCAPED_UNICODE);
    exit();
}


// ဇယားဒေတာများ ဆွဲထုတ်ခြင်း (ပုံမှန် PHP ရဲ့ သုံးသပ်ချက်ဇယားအတွက် အပိုင်း)
$total_demand = 0;
$total_paid = 0;
$total_remaining = 0;

// အမှုအရေအတွက် ကနဦးသတ်မှတ်ခြင်း
$tax_cases = 0;
$paid_cases = 0;
$remain_cases = 0;

// 🎯 ပြင်ဆင်ချက် - ငွေစုစုပေါင်းရော၊ အမှုအရေအတွက် (COUNT) ကိုပါ User Role အလိုက် တစ်ခါတည်း တွက်ချက်ခြင်း
if ($user_role === 'super_admin') {
    $sql = "SELECT * FROM regular_data ORDER BY id DESC";
    $total_sql = "SELECT 
                    SUM(taxpanaty) as t_demand, 
                    SUM(taxpanatyPaid) as t_paid,
                    SUM(CASE WHEN taxpanaty > 0 THEN 1 ELSE 0 END) AS tax_cases,
                    SUM(CASE WHEN taxpanatyPaid > 0 THEN 1 ELSE 0 END) AS paid_cases,
                    SUM(CASE WHEN (taxpanaty - taxpanatyPaid) > 0 THEN 1 ELSE 0 END) AS remain_cases
                  FROM regular_data";
} 
elseif ($user_role === 'state_admin') {
    $sql = "SELECT * FROM regular_data WHERE state_name = '$user_state' ORDER BY id DESC";
    $total_sql = "SELECT 
                    SUM(taxpanaty) as t_demand, 
                    SUM(taxpanatyPaid) as t_paid,
                    SUM(CASE WHEN taxpanaty > 0 THEN 1 ELSE 0 END) AS tax_cases,
                    SUM(CASE WHEN taxpanatyPaid > 0 THEN 1 ELSE 0 END) AS paid_cases,
                    SUM(CASE WHEN (taxpanaty - taxpanatyPaid) > 0 THEN 1 ELSE 0 END) AS remain_cases
                  FROM regular_data WHERE state_name = '$user_state'";
} 
else {
    $sql = "SELECT * FROM regular_data WHERE township_name = '$user_township' ORDER BY id DESC";
    $total_sql = "SELECT 
                    SUM(taxpanaty) as t_demand, 
                    SUM(taxpanatyPaid) as t_paid,
                    SUM(CASE WHEN taxpanaty > 0 THEN 1 ELSE 0 END) AS tax_cases,
                    SUM(CASE WHEN taxpanatyPaid > 0 THEN 1 ELSE 0 END) AS paid_cases,
                    SUM(CASE WHEN (taxpanaty - taxpanatyPaid) > 0 THEN 1 ELSE 0 END) AS remain_cases
                  FROM regular_data WHERE township_name = '$user_township'";
}

$result = $conn->query($sql);
$total_res = $conn->query($total_sql);

if ($total_res && $row_total = $total_res->fetch_assoc()) {
    $total_demand    = $row_total['t_demand'] ?? 0;
    $total_paid      = $row_total['t_paid'] ?? 0;
    $total_remaining = $total_demand - $total_paid;
    
    // 💡 ဇယားအောက်ခြေက Card တွေမှာ လှမ်းပြဖို့ အမှုအရေအတွက် Variables များ သတ်မှတ်ခြင်း
    $tax_cases       = $row_total['tax_cases'] ?? 0;
    $paid_cases      = $row_total['paid_cases'] ?? 0;
    $remain_cases    = $row_total['remain_cases'] ?? 0;
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ဝင်ငွေခွန်စည်းကြပ်မှုမှတ်ပုံတင်</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="css/bootstrap.min.css?v=<?php echo time(); ?>">
    <link rel="stylesheet" href="css/custom_style.css?v=<?php echo time(); ?>">

    
<style>
    /* ၁။ General Setup (Font & Body) */
    @import url('https://fonts.googleapis.com/css2?family=Pyidaungsu&display=swap');
    
 body { 
        background-color: white; 
        font-family: 'Pyidaungsu', sans-serif; 
        padding: 10px; 
    }

    /* ၂။ Dashboard & Main Table UI (Screen View Only) */
   .main-container { background: white; padding: 20px; border-radius: 12px; box-shadow: 0 10px 30px rgba(7, 7, 7, 0.08); }
    .header-title { color: #0d6efd; font-weight: bold; border-left: 5px solid #0d6efd; padding-left: 15px; }
    
    .table-responsive {overflow-x: auto; position: relative;}
    /*.table-responsive { max-height: 70vh; overflow: auto; border: 1px solid #dee2e6; border-radius: 8px; }*/
    .table { font-size: 13px; white-space: nowrap; }
    
    /* Action Column ကို ညာဘက်အစွန်မှာ ကပ်ထားရန် */
    .sticky-action {
        position: sticky !important;
        right: 0;
        background-color: #d7e6f5 !important; /* Row အရောင်နဲ့ ကိုက်အောင် ပေးပါ */
        z-index: 2;
        box-shadow: 0px 0 0px rgba(0,0,0,0.1); /* မျဉ်းအစား shadow သုံးရင် ပိုလှပါတယ် */

        padding: 0px 5px !important; /* အပေါ်အောက် padding ကို လုံးဝဖြုတ်ချပါ */
        vertical-align: middle !important;
    }
    .sticky-action .btn {
    padding: 2px 6px !important; /* ခလုတ်ဆိုဒ်ကို သေးသေးကျစ်ကျစ်ဖြစ်စေရန် */
    font-size: 12px !important;
    line-height: 1 !important;
    margin: 2px 0; /* ခလုတ်များ ကပ်မနေစေရန် */
}

    /* Row ကို select လုပ်ထားရင် sticky cell ပါ အရောင်ပြောင်းရန် */
    .selected-row .sticky-action {
        background-color:rgb(135, 135, 243) !important;
    }
 

    /* Row တွေကို Select လုပ်တဲ့အခါ Action column အရောင်ပါ လိုက်ပြောင်းရန် */
    tr.selected-row td.sticky-action {
        background-color: #d8e0ec !important;
    }

    .table-striped > tbody > tr.selected-row > td { 
        background-color: #629df5 !important; 
        color: #000 !important;
        border-bottom: 2px solid #0d6efd !important;
    }
/* Highlight ဖြစ်စေမယ့် class */
    .highlight-row {
        background-color:rgb(133, 103, 241) !important; /* အပြာနုရောင် */
        transition: background-color 0.2s ease;
    }

    /* Row height ကို တစ်ပြေးညီဖြစ်အောင် ထိန်းညှိခြင်း */
    #tableBody tr td {
        height: 35px !important; /* Row တိုင်းကို အမြင့် ပုံသေ သတ်မှတ်လိုက်ပါ */
        line-height: 1.2 !important;
    }

    .stat-card { border: none; border-radius: 10px; padding: 5px; color: white; display: flex;
     justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .bg-demand { background: linear-gradient(45deg, #4e73df, #224abe); }
    .bg-paid { background: linear-gradient(45deg, #1cc88a, #13855c); }
    .bg-rem { background: linear-gradient(45deg, #e74a3b, #be2617); }

    /* လုပ်ငန်းလိပ်စာ — အနေတော်အကျယ်၊ မဆံ့ရင် ... */
    .address-column {
        max-width: 180px;
        width: 180px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

/* custom_style.css က .table { width:100% !important } ဖြစ်လို့ ဒီဇယားကိုပဲ ပြန်လွှမ်းသည် */
#taxTable {
    width: max-content !important;
    min-width: 100% !important;
}
#taxTable th,
#taxTable td {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    box-sizing: border-box;
}
#taxTable th:nth-child(4),
#taxTable td:nth-child(4) { min-width: 60px !important; }   /* Demand_No */
#taxTable th:nth-child(5),
#taxTable td:nth-child(5) { min-width: 80px !important; }  /* Demand_Date */
#taxTable th:nth-child(6),
#taxTable td:nth-child(6) { min-width: 90px !important; }  /* GIR_No */
#taxTable th:nth-child(7),
#taxTable td:nth-child(7) { min-width: 90px !important; }  /* စည်းကြပ်နှစ် */
#taxTable th:nth-child(8),
#taxTable td:nth-child(8) { min-width: 120px !important; }  /* အခွန်ထမ်းအမည် */
#taxTable th:nth-child(9),
#taxTable td:nth-child(9) { min-width: 150px !important; }  /* လုပ်ငန်းအမျိုးအစား */
#taxTable th:nth-child(10),
#taxTable td:nth-child(10) {
    width: 180px !important;
    min-width: 160px !important;
    max-width: 180px !important;
}


    /* Borders & Dividers */
    .border-all td { border: 1px solid #000 !important; } /* Table အကွက်အပြည့် လိုအပ်လျှင်သုံးရန် */
    
    .border-right-divider { border-right: 1px solid #000 !important; }
    .border-left-divider { border-left: 1px solid #000 !important; }
    .border-top-bottom {
        border-top: 1px solid #000 !important;
        border-bottom: 1px solid #000 !important;
    }

    .justify-myanmar {
        text-align: justify;
        line-height: 1.6;
    }

    .sheet-header { text-align: center; margin-bottom: 10px; }

    /* ပုံနှိပ်ထုတ်ဝေရန်အတွက် Layout ချိန်ညှိချက်များ */
    .print-container {
        border-left: 0px solid black;
        border-right: 0px solid black;

        padding: 0 !important; /* Padding အကုန်ဖြုတ်ချလိုက်ပါ */
        margin-left: 0mm !important; /* ဘယ်ဘက်ကို ထပ်တိုးချင်ရင် negative margin သုံးနိုင်ပါတယ် */
        border: none !important;
    }
    .header-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 10px;
        margin-buttom: 10px;
    }
    /* ဘယ်ဖက်အပိုမျဉ်းကို ဖျက်ရန် border-left: none လုပ်ထားပါသည် */
    .header-table td {
        border: none;
        padding: 5px 0;
        vertical-align: top;
    }
    .main-content-table2 {
        width: 100%;
        margin-left: 0 !important;
        margin-right: 0 !important;
        border-collapse: collapse;
        border-left: none;
        border-right: none;
        border-top: 0px solid black;
    }
    .main-content-table {
        width: 100%;
        margin-left: 0 !important;
        margin-right: 0 !important;
        border-collapse: collapse;
        border-left: none;
        border-right: none;
        border-top: 1px solid black;
    }


    .main-content-table th, 
    .main-content-table td {
        border-left: 1px solid black;
        border-right: 1px solid black;
        padding: 5px;
    }
    /* အလယ်ကော်လံအတွက်သာ ဘယ်ညာမျဉ်း သတ်မှတ်ချက် */
    .middle-column {
        /*border-left: 2px solid black !important;
        border-right: 2px solid black !important;*/
        border: 2px solid black !important;
        padding: 5px;
    }
    /* ဘယ်အစွန်နှင့် ညာအစွန် ဆဲလ်ကွက်များတွင် ဘေးမျဉ်းမပါစေရန် */
    .outer-column {
        border-top: 2px solid black !important;
        border-bottom: 2px solid black !important;
        border-left: none !important;
        border-right: none !important;
    }
    .left_border{
        border-right: 0px solid black !important;
    }
    .right_border{
        border-left: 0px solid black !important;
    }


   
    /* အမှုတွဲပုံစံ ခလုတ်များ Grid Layout */
    .modal-btn-grid {
        display: flex;
        flex-wrap: wrap; /* တန်းစီရန် */
        justify-content: center; /* အလယ်ဗဟိုထားရန် */
        gap: 10px; /* ခလုတ်တစ်ခုနှင့်တစ်ခု အကွာအဝေး */
        padding: 5px;
    }

    /* ခလုတ်တစ်ခုချင်းစီ၏ Style */
    .modal-btn-grid .btn {
        /* Width ကို ချဲ့ရန် (တစ်တန်းလျှင် ၂ ခုနှုန်းဖြင့် အပြည့်နီးပါးဖြစ်စေရန်) */
        flex: 0 0 48%; 
        
        /* Height ကို လျှော့ရန် */
        padding: 10px 10px !important;
        min-height: 55px;
        
        /* စာသားကို ဘယ်ဘက်ကပ်ရန် */
        text-align: left !important;
        display: flex;
        align-items: center; /* စာသားကို အပေါ်အောက် အလယ်ရောက်ရန် */
        justify-content: flex-start; /* စာသားကို ဘယ်ဘက်ကပ်ရန် */
        
        font-size: 14px;
        line-height: 1.4;
        border-radius: 8px;
        white-space: normal;
        word-wrap: break-word;
    }

    /* ခလုတ်ထဲက စာသားများ ဘယ်ဘက်ကပ်နေစေရန် ထပ်ဆင့်ထိန်းညှိခြင်း */
    .modal-btn-grid .btn span, 
    .modal-btn-grid .btn i {
        text-align: left;
    }
/* ခလုတ်အရောင်ပြောင်းရန် */
    body:has(#formsModal.show) .modal-backdrop {
        display: none !important;
        opacity: 0 !important;
    }

    #formsModal .modal-btn-grid .btn.btn-info {
        background-color: #0a58ca !important;
        border-color: #084298 !important;
        color: #fff !important;
    }

    #formsModal .modal-btn-grid .btn.btn-info:hover,
    #formsModal .modal-btn-grid .btn.btn-info:focus {
        background-color: #084298 !important;
        border-color: #06357a !important;
        color: #fff !important;
    }

    .header-bar {
        background-color: #0b5ed7;
        color: white;
        padding: 10px 20px;
        font-weight: bold;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    /* ၄။ Print Optimization (တစ်ခုတည်းသော Media Print) */
    @media print {

        @page {
            size: A4 portrait;
            margin: 5mm 0mm 5mm 5mm; /* Top, Right, Bottom, Left */
        }
        .print-container {
        margin-left: 0 !important;
        padding-left: 0 !important; /* စာရွက်အနားသတ် အနည်းငယ် ချန်ရန် */
        }
        body, html {
            width: 100%;
            height: auto;
            margin: 0;
            padding: 0;
        }
        body * {
            visibility: hidden;
            background-color: transparent !important;
        }
        body, .container, .main-wrapper {
        border: none !important;
        outline: none !important;
        margin: 0;
        padding: 0;
        }
            /* Table ရဲ့ အပြင်ဘောင်လိုင်းကို ဖျောက်ပြီး အတွင်းလိုင်းတွေကိုပဲ ချန်ထားခြင်း */
        table {
            border: none !important;
        }
        thead { position: sticky; top: 0;
        z-index: 10; 
        color: black; vertical-align: middle;
        border-top: 2px solid #000 !important;
        border-botton: 2px solid #000 !important;}
        .right_border{
            border-left: 2px solid black !important;
            border-right: 0px solid white !important;
        }
        .left_border{
            border-right: 2px solid black !important;
            border-left: 0px solid white !important;
        }

    /* စာမျက်နှာအသစ်မှာ စတဲ့ table cell တိုင်းကို top border ပေးခြင်း */
        .sheet-table td {
            border-top: 2px solid #000 !important;
            padding-top:20px;
        }
        /* ဒုတိယစာမျက်နှာက table row တွေမှာ အပေါ်လိုင်း အမြဲပါစေရန် */
        .sheet-table tr {
            page-break-inside: avoid;
        }

        /* ထိပ်လိုင်းနဲ့ အောက်လိုင်း (horizontal line) အတွက် */
        .border-top-bottom {
            border-top: 2px solid #000 !important;
            border-bottom: 0px solid #000 !important;
        }
        /* Print ထုတ်မယ့် အပိုင်းတစ်ခုတည်းကိုပဲ စာရွက်အပြည့်ပြပါ */
        #printableSheet, #printableSheet * {
            visibility: visible !important;
        }
        /* Container ကို စာရွက်အပြည့် ဆွဲဆန့်ခြင်း */
        #printableSheet {
            position: absolute;
            left: 0;
            top: 0;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
        }
    
       
        .order-sheet {
            width: 100% !important;
            max-width: 100% !important; /* နယ်ကုန် ဖြစ်စေရန် */
            padding: 0 !important; /* စာရွက်အနားသတ် */
            border: none !important;
            box-shadow: none !important;
            page-break-inside: avoid; /* စာမျက်နှာအလယ်မှာ မပြတ်သွားစေရန် */
        }

        .sheet-table {
            width: 100% !important;
            table-layout: fixed !important;
            margin-top: 0 !important; /* စိတ်ကြိုက် အကွာအဝေး ချိန်ညှိပါ */
        }
        .sheet-table td {
            padding: 4px;
            vertical-align: top;
            word-wrap: break-word; /* စာသားရှည်လျှင် အောက်ဆင်းရန် */
            border: none; /* Default အနေနဲ့ အကုန်ဖျောက်ထားမည် */
        }
        /* သို့မဟုတ် ဒုတိယစာမျက်နှာရဲ့ ပထမဆုံး row ကိုပဲ padding ပေးခြင်း */
        .sheet-table tr:first-child td {
            padding-top: 30px !important;
        }

         /* Modal content ထဲက Print ထုတ်မယ့်အပိုင်းကို စာရွက်အပြည့်ဆွဲဆန့်ပါ */
        #orderSheetModal, 
        #orderSheetModal .modal-content,
        #orderSheetModal, 
       .modal-body {
        padding: 0 !important;
        margin: 0 !important;
        }

        /* Bootstrap Modal ရဲ့ နောက်ခံတွေနဲ့ Scrollbar တွေ ဖျောက်ခြင်း */
        .modal {
            position: absolute !important;
            padding: 0 !important;
            margin: 0 !important;
            overflow: visible !important;
            display: block !important;
        }
        .modal-dialog {
    
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
        }
        .modal-content {
            border: none !important;
            box-shadow: none !important;
        }

        .no-print {
            display: none;
        }
    }

    /* ကိန်းဂဏန်းများအတွက် ညာဘက်ညှိရန် */
.num-right {
    text-align: right !important;
    padding-right: 10px !important; /* စာသားနဲ့ မြဉ်းကြား အနည်းငယ် ခြားရန် */
}

/* စာသားပါတဲ့ column တွေအတွက် (ဥပမာ-အမည်၊ လိပ်စာ) ဘယ်ဘက်ကပ်ရန် */
.text-start-custom {
    text-align: left !important;
}

.text-right{text-align:right}
thead { position: sticky; top: 0;
z-index: 10; background-color: #acc8f3 !important;
color: black; vertical-align: middle;
border-top: 2px solid #02080d !important;
border-botton: 2px solid #02080d !important;}
.table thead th {
        vertical-align: middle; /* vertical alignment ကို top သို့မဟုတ် middle ညှိနိုင်သည် */
        white-space: nowrap;    /* စာပိုဒ်မခွဲရန် */
        overflow: hidden;
        vertical-align: middle;
        text-align: center;
        text-overflow: ellipsis; 
        background-color: brown;
        color:white;
        border: 1px solid #eef1f4 !important;
        padding: 5px 5px !important;
    }
/* Table Row Height ကို အထိရောက်ဆုံး လျှော့ချခြင်း */
#proposalTable td.merge-top,
#proposalTable td.name-cell,
#proposalTable td.address-cell {
    vertical-align: top !important;
}
#proposalTable td.name-cell {
    border-bottom: none !important;
}
#proposalTable td.address-cell {
    border-top: none !important;
}
.table td, .table th {
    padding: 3px 8px !important; /* အပေါ်အောက် padding ကို 3px ထိ လျှော့ချလိုက်ပါ */
    vertical-align: middle !important;
    line-height: 1.4 !important; /* စာသားအမြင့်ကို ကျစ်လျစ်စေရန် */

    white-space: nowrap; /* စာသားကို အောက်တန်း လုံးဝမဆင်းစေရန် */
    overflow: hidden;
    text-overflow: ellipsis;
}

/* Action ခလုတ်များရှိသော Column အတွင်းမှ ခလုတ်ဆိုဒ်ကိုပါ လျှော့ချခြင်း */
.btn-sm, .action-btn {
    padding: 5px 5px !important;
    font-size: 14px !important;
}

.search-container {
    position: relative;
    width: 300px;
}

.search-icon {
    position: absolute;
    right: 20px;
    top: 60%;
    transform: translateY(-80%);
    color: #706f6f;
}

.search-input {
    width: 100%;
    padding: 10px 10px 10px 35px; /* ဘယ်ဖက်မှာ icon အတွက် နေရာချန်ထားတာပါ */
    border: 1px solid #ccc;
    border-radius: 5px;
    outline: none;
}

.search-input:focus {
    border-color: #007bff;
}

    .header-bar {
        background-color: rgb(194, 169, 31);
        color: white;
        padding: 10px 20px;
        font-weight: bold;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
</style>

</head>
<body>

<div class="header-bar">
    <div>| ဝင်ငွေခွန် စည်းကြပ်မှုမှတ်တမ်းပုံစံ</div>
    <div>Regular</div>
    <div style="font-size: 15px;"><i class="fa-solid fa-location-dot text-danger"></i> 
    <?= htmlspecialchars($user_township ?: $user_state ?: 'All Regions') ?>အခွန်ဦးစီးဌာနမှူးရုံး</div>
</div>

<!--<div class="container-fluid mt-3">-->
<div class="container-fluid mt-3" id="mainDemandList">
    <div class="row mb-1">
        <div class="col-md-4">
            <div class="stat-card bg-demand" style="padding-bottom: 10px;">
                <span>စည်းကြပ်တောင်းခံ-</span>
                <span style="display: block; font-size: 0.85rem; font-weight: normal; color: rgba(255,255,255,0.85); margin-top: -2px;">
                    (<?= number_format($tax_cases) ?> မှု)
                </span>
                <strong><?= formatNumber($total_demand) ?></strong>
                
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="stat-card bg-paid" style="padding-bottom: 10px;">
                <span>ပေးသွင်းငွေ-</span>
                <span style="display: block; font-size: 0.85rem; font-weight: normal; color: rgba(255,255,255,0.85); margin-top: -2px;">
                    (<?= number_format($paid_cases) ?> မှု)
                </span>
                <strong><?= formatNumber($total_paid) ?></strong>
                
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="stat-card bg-rem" style="padding-bottom: 10px;">
                <span>ပေးသွင်းရန်ကျန်-</span>
                <span style="display: block; font-size: 0.85rem; font-weight: normal; color: rgba(255,255,255,0.85); margin-top: -2px;">
                    (<?= number_format($remain_cases) ?> မှု)
                </span>
                <strong><?= formatNumber($total_remaining) ?></strong>
            </div>
        </div>
    </div>

   
    <div class="card p-2 shadow-sm mb-0">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2">
            
            <div class="d-flex align-items-center gap-2">
                <div class="input-group input-group-sm" style="width: 180px;">
                    <input type="number" id="minCase" class="form-control" placeholder="မှ">
                    <input type="number" id="maxCase" class="form-control" placeholder="ထိ">
                </div>

                <div class="d-flex gap-1">
                    <button type="submit" class="btn btn-sm btn-outline-secondary"><i class="fa-solid fa-filter"></i> Filter</button>
                    <a href="IT_demand_list.php" class="btn btn-sm btn-outline-danger" title="Filter များအားလုံးကို ဖျက်၍ မူလအတိုင်းပြန်ပြရန်">
                        <i class="fa fa-sync"></i>
                    </a>
                </div>

                <button type="button" class="btn btn-outline-primary btn-sm" onclick="openProposalFromUI()">
                    <i class="bi bi-file-earmark-plus"></i> အဆိုပြုလွှာ
                </button>

                <div class="position-relative" style="width: 240px;">
                    <i class="bi bi-search position-absolute" style="left: 10px; top: 50%; transform: translateY(-50%); color: #6c757d; z-index: 5;"></i>
                    <input type="text" id="searchInput" class="form-control form-control-sm" placeholder="ရှာဖွေရန်..." style="padding-left: 32px;">
                </div>
            </div>

            <div class="d-flex align-items-center gap-1">
                <button class="btn btn-info btn-sm text-white" data-bs-toggle="modal" data-bs-target="#formsModal">
                    <i class="bi bi-file-earmark-text"></i> အမှုတွဲ(ပုံစံ)များ
                </button>
                <a href="dashboard.php" class="btn btn-secondary btn-sm">
                    <i class="bi bi-house-door-fill"></i> Dashboard
                </a>
                <button class="btn btn-success btn-sm" onclick="exportITDemandToExcel()">
                    <i class="bi bi-file-earmark-excel-fill"></i> Excel
                </button>
                <a href="Calculation_form1.php?mode=new" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-circle"></i> စည်းကြပ်မှုအသစ်
                </a>
            </div>
        </div>
    </div>

    

    <div class="table-responsive shadow-sm">
    <table class="table table-bordered table-striped table-hover mb-0" id="taxTable">
        <thead class="text-center">
                <tr>
                    <th class="no-export">#</th>
                    <th>စဉ်</th>
                    <th>အမှုတွဲ<br>နံပါတ်</th>
                    <th>Demand<br>_No</th>
                    <th>Demand<br>_Date</th>
                    <th>GIR_No</th>
                    <th>စည်းကြပ်နှစ်</th>
                    <th>အခွန်ထမ်းအမည်</th>
                    <th>လုပ်ငန်းအမျိုးအစား</th>
                    <th>လုပ်ငန်းလိပ်စာ</th>
                    <th>အသားတင်<br>အမြတ်</th>
                    <th>ကျသင့်<br>ဝင်ငွေခွန်</th>
                    <th>ကြိုတင်ခွန်</th>
                    <th>ထပ်မံ<br>ပေးဆောင်ရန်</th>
                    <th>ဒဏ်ကြေး</th>
                    <th>အခွန်<br>ဒဏ်ပေါင်း</th>
                    <th>ပေးသွင်းသည့် <br>အခွန်ဒဏ်</th>
                    <th>ချလန်<br>နံပါတ်</th>
                    <th>ချလန်<br>ရက်စွဲ</th>
                    <th >ပေးသွင်း<br>ရန်ကျန်</th>
                    <th>တာဝန်ခံအရာရှိ</th>
                    <th class="no-export sticky-action">Action</th>  
                </tr>
            </thead>
            <tbody id="tableBody">
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while($row = $result->fetch_assoc()): 
                        $remaining = ($row['taxpanaty'] ?? 0) - ($row['taxpanatyPaid'] ?? 0);
                    ?>
                    <tr onclick='toggleRow(this)' data-info='<?= json_encode($row); ?>' style="cursor: pointer;">
                        <td class="text-center no-export">
                            <input type="checkbox" class="form-check-input row-checkbox" 
                                onclick="event.stopPropagation(); toggleCheckbox(this);">
                        </td>
                        <td class="text-center"><?= $row['id'] ?></td>
                        <td style="text-center: left;"><?= $row['case_number'] ?></td>
                        <td style="text-center: left;"><?= $row['itDemandNo'] ?></td>
                        <td class="text-center"><?= $row['itDemandDate'] ?></td>
                        <td class="text-end-important "><?= $row['it_no'] . " / " . ($row['it_select'] ?? 'စီးပွား') ?></td>
                        <td class="text-center"><?= $row['taxYear'] ?></td>
                        <td style="text-align: left;"><?= $row['taxpayer_name'] ?></td>
                        <td style="text-align: left;"><?= $row['businessType1'] ?></td>
                        <td class="searchable address-column" style="text-align: left;" title="<?= htmlspecialchars($row['address']) ?>"><?= $row['address'] ?></td>
                        <td class="num-right"><?= formatNumber($row['netProfit']) ?></td>
                        <td class="num-right text-success"><?= formatNumber($row['payableIncomeTax']) ?></td>
                        <td class="num-right text-danger"><?= formatNumber($row['advancePaidTax']) ?></td>
                        <td class="num-right"><?= formatNumber($row['finalBalanceTax']) ?></td>
                        <td class="num-right text-danger"><?= formatNumber($row['itpanaty']) ?></td>
                        <td class="num-right fw-bold"><?= formatNumber($row['taxpanaty']) ?></td>
                        <td class="num-right text-primary"><?= formatNumber($row['taxpanatyPaid']) ?></td>
                        <td class="num-center" ><?= $row['itchalanNo'] ?></td>
                        <td class="text-center"><?= $row['itchalanDate'] ?></td>
                        <td class="num-right fw-bold text-danger bg-light"><?= ($remaining > 0) ? formatNumber($remaining) : '0' ?></td>

                        <td><?= $row['officer_name'] ?></td>
                        <td class="text-center no-export sticky-action">
                            <div class="btn-group">
                             
                                <a href="Calculation_Form1.php?id=<?= $row['id'] ?>" class="btn btn-outline-warning btn-sm" onclick="event.stopPropagation();"><i class="bi bi-pencil-fill"></i>Edit</a>
                                <button class="btn btn-outline-danger btn-sm" onclick="confirmDelete(<?= $row['id'] ?>); event.stopPropagation();"><i class="bi bi-trash-fill"></i>Del</button>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="23" class="text-center p-4">ပြသရန် အချက်အလက်မရှိပါ။</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="formsModal" tabindex="-1" data-bs-backdrop="false">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">အမှုတွဲပုံစံများ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="modal-btn-grid">

                    <button class="btn btn-info text-white" onclick="openFormordersheet()">
                        ၁။ နေ့စဉ်လုပ်ငန်းမှတ်တမ်း <br>&ensp;&ensp; (Order Sheet)<br>&ensp;&ensp;
                    </button>
                    <button class="btn btn-info text-white" onclick="openForm0405()">
                        ၂။ ကြားနာစစ်ဆေးရန်<br>&ensp;&ensp; အကြောင်းကြားစာ<br> &ensp;&ensp; ပတခ(ဝင)-၀၄-၀၅
                    </button>
                </div>
                <div class="modal-btn-grid">
                    <button class="btn btn-info text-white" onclick="openForm0406()">
                        ၃။ သတင်းအချက်အလက်များ<br>&ensp;&ensp; ပေးပို့ရန်အကြောင်းကြားစာ<br> &ensp;&ensp; ပတခ(ဝင)-၀၄-၀၆
                    </button>
                    <button class="btn btn-info text-white" onclick="openForm0407()">
                         ၄။ ဒဏ်ကြေးငွေစည်းကြပ်မှု<br>&ensp;&ensp; ဆုံးဖြတ်ချက်<br> &ensp;&ensp; ပတခ(ဝင)-၀၄-၀၇
                    </button>
                    
                </div>
                
                <div class="modal-btn-grid">
                    <button class="btn btn-info text-white" onclick="openForm0408()">
                        ၅။ ဝင်ငွေခွန်စည်းကြပ်မှု <br>&ensp;&ensp; အကြောင်းကြားစာ <br> &ensp;&ensp; ပတခ(ဝင)-၀၄-၀၈
                    </button>
                    <button class="btn btn-info text-white" onclick="openFormgeneral2()">
                        ၆။ အကြောင်းကြားစာ ချအပ်ခြင်း <br> &ensp;&ensp; ဆိုင်ရာ လက်ခံဖြတ်ပိုင်း <br>&ensp;&ensp; ပတခ(ထွေ)-၂

                    </button>
                </div>
                <div class="modal-btn-grid">
                    <button class="btn btn-info text-white" onclick="openForm0301()">
                        ၇။ ဝင်ငွေကြေညာလွှာ <br>&ensp;&ensp; ပတခ(ဝင)-၀၃-၀၁(ဂ)<br>&ensp;&ensp;<br>
                    </button>
                    <button class="btn btn-info text-white" onclick="openForm_regularculateModal()">
                        ၈။ အခွန်တွက်ချက်မှုပုံစံ<br> &ensp;&ensp;<br>&ensp;&ensp;

                    </button>
                </div>
            </div>
        </div>
    </div>
</div>


<!--အဆိုပြုလွှာပုံစံ-->
<div id="taxFormModal" class="modal" style="display:none; position:fixed; z-index:1000; left:0; top:0; width:100%; height:100%; overflow:auto; background-color:rgba(0,0,0,0.5);">
    <div class="modal-content" style="background-color:#fff; margin:2% auto; padding:20px; width:95%; border-radius:5px;">
        <div id="printableArea" class="form-container">

            <table id="proposalTable" class="table table-bordered" style="width:100%; border-collapse:collapse; font-size:0.8em; color:#333; padding:5px;line-height:24px; vertical-align:center;">
                <thead>
                    <tr id="excel-row-1">
                        <td colspan="17" style="text-align: center; font-weight: bold; font-size: 12pt; color: #333; border: none !important; padding: 10px ;padding:5px;">
                            ဝင်ငွေခွန်/ကုန်သွယ်လုပ်ငန်းခွန် စည်းကြပ်မှု အဆိုပြုလွှာ
                        </td>
                    </tr>
                    <tr id="excel-row-2">
                        <td colspan="4" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;padding:5px;">
                                <span>တိုင်းဒေသကြီး/ပြည်နယ်( <span id="display_state"></span> )</span>
                                
                            </div>
                        </td>
                        <td colspan="6" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;padding:5px;">
                                <span>မြို့နယ်( <span id="display_township"></span> )</span>
                               
                            </div>
                        </td>
                        <td colspan="4" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;padding:5px;">
                                <span>နယ်မြေ( <span id="display_region"></span> )</span>
                            </div>
                        </td>
                        <td colspan="3" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;padding:5px;">
                               
                                <span>အတွဲ(........)</span0>
                            </div>
                        </td>
                       

                    </tr>
                    <tr>
                        <th rowspan="2" class="col-no" style="width:40px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">အမှတ် စဉ်</th>
                        <th rowspan="2" class="col-gir" style="width:75px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">GIR အမှတ်</th>
                        <th rowspan="2" class="col-name" style="width:165px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">အခွန်ထမ်းအမည်နှင့် လိပ်စာ</th>
                        <th rowspan="2" class="col-biz" style="width:120px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">လုပ်ငန်းအမျိုးအစား</th>
                        <th colspan="5" style="text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">နောက်ဆုံးပြီးပြတ်သည့် သုံးနှစ်စည်းကြပ်မှုအခြေအနေ</th> 
                        <th colspan="2" style="text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">အခွန်ထမ်းကြေညာ သည့် ရောင်းရငွေ</th>
                        <th colspan="4" style="text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">မြို့နယ်အခွန်ဦးစီးဌာနမှူးတင်ပြသည့်</th>
                        <th rowspan="2" class="col-division" style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">တိုင်းဦးစီးမှူး သုံးသပ်ချက်</th>
                        <th rowspan="2" class="col-note" style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">မှတ်ချက်</th>
                    </tr>
                    <tr>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">စည်းကြပ်နှစ်</th>
                        <th style="width:75px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေ</th>
                        <th style="width:75px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေခွန်</th>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ရောင်းရငွေ</th>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ကုန်သွယ်ခွန်</th>
                        <th style="width:70px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ရောင်းရငွေ</th>
                        <th style="width:70px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေ</th>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ရောင်းရငွေ</th>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ကုန်သွယ်ခွန်</th>
                        <th style="width:80px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေ</th>
                        <th style="width:75px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေခွန်</th>
                    </tr>
                </thead>
                <tbody id="form_data_body">
                </tbody>
            </table>
        </div>
        <div class="text-end mt-3">
            <button onclick="exportProposalToExcel()" class="btn btn-success">Excel ထုတ်ယူမည်</button>
            <button onclick="printProposal()" class="btn btn-primary">Print ထုတ်မည်</button>
            <button onclick="closeModal()" class="btn btn-danger">ပိတ်မည်</button>
        </div>
    </div>
</div>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/gh/linways/table-to-excel@v1.0.4/dist/tableToExcel.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
    // ကိန်းဂဏန်းများတွင် ကော်မာထည့်ရန်
    function formatNumber(num) {
        if (!num) return "0";
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    let selectedRowData = null;

    // Row Highlight လုပ်ခြင်း
    function toggleRow(row) {
    const checkbox = row.querySelector('.row-checkbox');
    if (checkbox) {
        // အခြား Row တွေကို အကုန်အရောင်ဖြုတ်၊ Checkbox ဖြုတ်မယ်
        clearAllSelections();
        
        // လက်ရှိနှိပ်တဲ့ Row ကို Highlight သွင်းပြီး Checkbox အမှန်ခြစ်မယ်
        row.classList.add('selected-row');
        checkbox.checked = true;
        
        // Data သိမ်းဆည်းရန် (Attribute ကနေ JSON ယူခြင်း)
        const rowData = row.getAttribute('data-info');
        selectedRowData = rowData ? JSON.parse(rowData) : null;
    }
}

// Checkbox ကို တိုက်ရိုက်နှိပ်တဲ့အခါ အလုပ်လုပ်မည့် Function
function toggleCheckbox(checkbox) {
    const row = checkbox.closest('tr');
    
    if (checkbox.checked) {
        clearAllSelections(); // အရင်ဟာတွေ ဖြုတ်
        row.classList.add('selected-row');
        checkbox.checked = true; // အခုဟာကို ပြန်ချစ်
        const rowData = row.getAttribute('data-info');
        selectedRowData = rowData ? JSON.parse(rowData) : null;
    } else {
        row.classList.remove('selected-row');
        selectedRowData = null;
    }
}

function hideFormsModal() {
    const el = document.getElementById('formsModal');
    if (!el) return;
    if (window.bootstrap && bootstrap.Modal) {
        const modal = bootstrap.Modal.getInstance(el);
        if (modal) {
            try { modal.dispose(); } catch (e) {}
        }
    }
    el.classList.remove('show');
    el.style.display = 'none';
    el.setAttribute('aria-hidden', 'true');
    el.removeAttribute('aria-modal');
    el.removeAttribute('role');
    document.querySelectorAll('.modal-backdrop').forEach(function (backdrop) {
        backdrop.remove();
    });
    document.body.classList.remove('modal-open');
    document.body.style.removeProperty('overflow');
    document.body.style.removeProperty('padding-right');
}

function presentFormModal(modalId) {
    const modalElem = document.getElementById(modalId);
    if (!modalElem || !window.bootstrap || !bootstrap.Modal) {
        alert('ဖောင်ကို ဖွင့်လို့မရပါ။ စာမျက်နှာကို refresh လုပ်ပြီး ပြန်စမ်းပါ။');
        return;
    }
    if (modalElem.parentElement !== document.body) {
        document.body.appendChild(modalElem);
    }
    hideFormsModal();
    setTimeout(function () {
        const myModal = bootstrap.Modal.getOrCreateInstance(modalElem);
        myModal.show();
    }, 50);
}

function requireSelectedRow() {
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
        return false;
    }
    return true;
}

// အားလုံးကို ရှင်းလင်းပေးမည့် Helper Function
function clearAllSelections() {
    document.querySelectorAll('#tableBody tr').forEach(r => {
        r.classList.remove('selected-row');
        const cb = r.querySelector('.row-checkbox');
        if (cb) cb.checked = false;
    });
}

     // Modal ထဲက ခလုတ်နှိပ်ရင် လက်ရှိ Highlight ဖြစ်နေတဲ့ row data ကို သုံးခြင်း
    function openOrderSheetFromModal() {
        if (!selectedRowData) {
            alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြအောင် နှိပ်ပါ)။");
            return;
        }
        // Forms Modal ကို ပိတ်ပြီးမှ Order Sheet ပြပါ
        bootstrap.Modal.getInstance(document.getElementById('formsModal')).hide();
        showOrderSheet(selectedRowData);
    }


    // Filter လုပ်ဆောင်ချက်
    function applyFilters() {
        let searchText = document.getElementById('searchInput').value.toUpperCase().trim();
        let min = parseInt(document.getElementById('minCase').value) || 0;
        let max = parseInt(document.getElementById('maxCase').value) || Infinity;
        let rows = document.querySelectorAll("#tableBody tr");

        rows.forEach(row => {
            let caseNoCell = row.cells[2]; 
            let caseNo = caseNoCell ? parseInt(caseNoCell.innerText) : 0;
            let rowText = row.innerText.toUpperCase();

            let matchesSearch = (searchText === "" || rowText.includes(searchText));
            let matchesRange = (caseNo >= min && caseNo <= max);

            row.style.display = (matchesSearch && matchesRange) ? "" : "none";
        });
    }

    // Event Listeners များ
    document.getElementById('searchInput').addEventListener('keyup', applyFilters);
    document.getElementById('minCase').addEventListener('input', applyFilters);
    document.getElementById('maxCase').addEventListener('input', applyFilters);

// PHP မှ ဒေတာများကို JS သို့ တိုက်ရိုက် လွှဲပြောင်းပေးခြင်း
const loginUserInfo = {
    state_name: <?php echo json_encode($user_state, JSON_UNESCAPED_UNICODE); ?>,
    township_name: <?php echo json_encode($user_township, JSON_UNESCAPED_UNICODE); ?>,
    region: <?php echo json_encode($user_region, JSON_UNESCAPED_UNICODE); ?>
};
// မျက်နှာပြင်ပေါ်တွင် ဒေတာများ ချက်ချင်းပြသရန် function
function updateLayoutHeader() {
    if(document.getElementById("display_state")) {
        document.getElementById("display_state").innerText = loginUserInfo.state_name;
    }
    if(document.getElementById("display_township")) {
        document.getElementById("display_township").innerText = loginUserInfo.township_name;
    }
    if(document.getElementById("display_region")) {
        document.getElementById("display_region").innerText = loginUserInfo.region;
    }
}

// စာမျက်နှာပွင့်လာသည်နှင့် တစ်ခါတည်း run ရန်
window.onload = updateLayoutHeader;

// ၂။ Excel Export IT Demand List လုပ်ဆောင်ချက်
function exportITDemandToExcel() {
    // ၁။ Screen ပေါ်မှာ အမှန်တကယ် ရှိနေတဲ့ Table Rows များကို သေချာပေါက် ဖမ်းယူခြင်း
    // အစ်ကိုကြီးတို့ Table ရဲ့ <tbody> ID က 'taxTableBody' သို့မဟုတ် '#taxTable tbody' ဖြစ်နိုင်ပါတယ်
    var tableBody = document.getElementById("taxTableBody") || document.querySelector("#taxTable tbody") || document.querySelector("table tbody");
    
    if (!tableBody) {
        alert("Error: ဒေတာဇယားကွက် (taxTableBody) ကို ရှာမတွေ့ပါ!");
        return;
    }

    var rows = tableBody.querySelectorAll("tr");
    
    // Total Row တွေပဲ ရှိပြီး တကယ့်ဒေတာ မရှိရင် ကာကွယ်ရန်
    var validRowCount = 0;
    rows.forEach(r => {
        if (!r.classList.contains("no-export") && !r.innerText.includes("စုစုပေါင်း") && r.style.display !== "none") {
            validRowCount++;
        }
    });

    if (validRowCount === 0) {
        alert("Excel ထုတ်ရန် ဇယားထဲတွင် ဒေတာ (သို့မဟုတ်) ပေါ်နေသော Row မရှိပါ!");
        return;
    }

    // ၂။ Excel အတွက် ခေါင်းစဉ်တန်း (Header) ကို Layout မြင်ကွင်းအတိုင်း ကော်လံ (၂၀) စနစ်တကျ တည်ဆောက်ခြင်း
    var excelHtml = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <meta charset="UTF-8">
            <style>
                table { border-collapse: collapse; }
                th { background-color: #97eeab !important; font-family: "Pyidaungsu", "Segoe UI"; font-size: 9pt; border: 0.3pt solid #000; padding: 5px; text-align: center; color: black; font-weight: bold; }
                td { font-family: "Pyidaungsu", "Segoe UI"; font-size: 8pt; border: 0.3pt solid #000; padding: 5px; vertical-align: middle; }
            </style>
        </head>
        <body>
            <table>
                <thead>
                    <tr>
                        <td colspan="19" class="excel-title" style="border:none; text-align:center; font-size:15px;"><b>ဝင်ငွေခွန် စည်းကြပ်ခြင်း၊ တောင်းခံခြင်းနှင့် ကောက်ခံရရှိမှုမှတ်ပုံတင်</br></td>
                    </tr>
                    <tr style="height:15px;">
                        <td colspan="19" style="border:none;"></td>
                    </tr>
                    <tr>
                        <th>စဉ်</th>
                        <th>စည်းကြပ်မှု<br>အမှတ်</th>
                        <th>စည်းကြပ်<br>သည့်နေ့</th>
                        <th>အခွန်ထမ်း<br>အမှတ်</th>
                        <th>စည်းကြပ်နှစ်</th>
                        <th>အခွန်ထမ်းအမည်</th>
                        <th width="130">လုပ်ငန်းအမျိုးအစား</th>
                        <th width="200">လုပ်ငန်းလိပ်စာ</th>
                        <th width="75">အသားတင်<br>အမြတ်</th>ျ
                        <th width="75">ကျသင့်<br>ဝင်ငွေခွန်</th>
                        <th width="75">ကြိုတင်ခွန်</th>
                        <th width="75">ထပ်မံပေး<br>ရန်အခွန်</th>
                        <th width="70">ဒဏ်ကြေး</th>
                        <th width="75">အခွန်ဒဏ်<br>ပေါင်း</th>
                        <th width="75">ပေးသွင်းငွေ</th>
                        <th>ချလန်<br>နံပါတ်</th>
                        <th>ချလန်ရက်စွဲ</th>
                        <th width="70">ပေးသွင်း<br>ရန်ကျန်</th>
                        <th>တာဝန်ခံအရာရှိ</th>
                    </tr>
                </thead>
                <tbody>
    `;

    // ၃။ Rows များထဲမှ ကော်လံအလိုက် ဒေတာများကို ကွက်တိ ဆွဲထုတ်ခြင်း
    var count = 1;
    rows.forEach(function(row) {
        // စုစုပေါင်း Row များနှင့် ကွယ်ထားသော Row များကို စစ်ထုတ်ခြင်း
        if (row.classList.contains("no-export") || row.innerText.includes("စုစုပေါင်း") || row.style.display === "none") return;

        var tds = row.querySelectorAll("td");
        
        if (tds.length > 0) {
            // 🎯 မူရင်း PHP ဖိုင်ရဲ့ <td> တန်းစီဇယား အစစ်အမှန်အတိုင်း ကွက်တိ Index ညှိထားခြင်း ဖြစ်ပါတယ်
            var itDemandNo       = tds[3] ? tds[3].innerText.trim() : "";   // ကော်လံ ၁
            var itDemandDate     = tds[4] ? tds[4].innerText.trim() : "";   // ကော်လံ ၂
            var gir_no           = tds[5] ? tds[5].innerText.trim() : "";   // ကော်လံ ၃ (Gir No)
            var taxYear          = tds[6] ? tds[6].innerText.trim() : "";   // ကော်လံ ၄
            var taxpayer_name    = tds[7] ? tds[7].innerText.trim() : "";   // ကော်လံ ၅
            var businessType1    = tds[8] ? tds[8].innerText.trim() : "";   // ကော်လံ ၆
            var address          = tds[9] ? tds[9].innerText.trim() : ""; // ကော်လံ ၇ (လိပ်စာ)
            
            // ငွေကြေးကော်လံများ
            var netProfit        = tds[10] ? tds[10].innerText.trim() : "0";  // ကော်လံ ၈
            var payableIncomeTax = tds[11] ? tds[11].innerText.trim() : "0";  // ကော်လံ ၉
            var advancePaidTax   = tds[12] ? tds[12].innerText.trim() : "0";  // ကော်လံ ၁၀
            var finalBalanceTax  = tds[13] ? tds[13].innerText.trim() : "0";  // ကော်လံ ၁၁
            var itpanaty         = tds[14] ? tds[14].innerText.trim() : "0"; // ကော်လံ ၁၂
            var taxpanaty        = tds[15] ? tds[15].innerText.trim() : "0"; // ကော်လံ ၁၃
            var taxpanatyPaid    = tds[16] ? tds[16].innerText.trim() : "0"; // ကော်လံ ၁၄
            var itchalanNo       = tds[17] ? tds[17].innerText.trim() : "-"; // ကော်လံ ၁၅
            var itchalanDate     = tds[18] ? tds[18].innerText.trim() : "-"; // ကော်လံ ၁၆
            var balance          = tds[19] ? tds[19].innerText.trim() : "0"; // ကော်လံ ၁၇ (ပေးသွင်းရန်ကျန်)
            var officer_name     = tds[20] ? tds[20].innerText.trim() : "-"; // ကော်လံ ၁၈

            excelHtml += `
                <tr>
                    <td style="text-align:center;">${count}</td>
                    <td style="text-align:center;">${itDemandNo}</td>
                    <td style="text-align:center;">${itDemandDate}</td>
                    <td>${gir_no}</td>
                    <td style="text-align:center;">${taxYear}</td>
                    <td>${taxpayer_name}</td>
                    <td>${businessType1}</td>
                    <td>${address}</td>
                    <td style="text-align:right;">${netProfit}</td>
                    <td style="text-align:right;">${payableIncomeTax}</td>
                    <td style="text-align:right;">${advancePaidTax}</td>
                    <td style="text-align:right;">${finalBalanceTax}</td>
                    
                    <td style="text-align:right;">${itpanaty}</td>
                    <td style="text-align:right;">${taxpanaty}</td>
                    <td style="text-align:right;">${taxpanatyPaid}</td>
                    
                    <td style="text-align:center;">${itchalanNo}</td>
                    <td style="text-align:center;">${itchalanDate}</td>
                    <td style="text-align:right;">${balance}</td>
                    <td>${officer_name}</td>
                </tr>
            `;
            count++;
        }
    });

    excelHtml += `
                </tbody>
            </table>
        </body>
        </html>
    `;

    // ၄။ Blob Object တည်ဆောက်ပြီး Excel ဖိုင်အဖြစ် တိုက်ရိုက်ဒေါင်းလုဒ်ဆွဲချခြင်း
    var blob = new Blob([excelHtml], { type: "application/vnd.ms-excel;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    
    var townshipName = document.getElementById("display_township") ? document.getElementById("display_township").innerText.trim() : "";
    var fileName = "IT_Demand_" + (townshipName ? townshipName : new Date().toISOString().slice(0,10)) + ".xls";

    var a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

//..............................................................................................................
    // ၃။ Display User Info on UI (ဇယားအပေါ်မှာ မြင်နေရအောင်)
    function exportProposalToExcel() {
    // 1️⃣ တကယ့် ဒေတာဇယားရှိရာ Table ID ကို တိုက်ရိုက်ဖမ်းယူခြင်း
    var table = document.getElementById("proposalTable");
    if (!table) {
        alert("Error: proposalTable ကို ရှာမတွေ့ပါ!");
        return;
    }

    // 2️⃣ ဇယားတစ်ခုလုံးကို ပုံတူကူး (Clone) ပြီး မလိုအပ်သော အကွက်များနှင့် ခလုတ်များ ဖယ်ထုတ်ခြင်း
    var cloneTable = table.cloneNode(true);
    cloneTable.querySelectorAll(".no-export, button").forEach(el => el.remove());

    // 3️⃣ Input Box များ သို့မဟုတ် Textarea များရှိနေပါက ၎င်းတို့၏ တန်ဖိုးများကို စာသားအဖြစ် ပြောင်းလဲပေးခြင်း
    cloneTable.querySelectorAll("input, textarea, select").forEach(input => {
        var span = document.createElement("span");
        span.innerText = input.value;
        input.parentNode.replaceChild(span, input);
    });

    var htmlContent = cloneTable.outerHTML;

    // ဖောင်ပေါ်က မြို့နယ်အမည်ကို ယူ၍ ဖိုင်အမည်ပေးရန်
    var township = document.getElementById("display_township") ? document.getElementById("display_township").innerText.trim() : "Tax";

    // 4️⃣ Excel သတ်မှတ်ချက် Template (ထိပ်ဆုံး Row ၁ နှင့် ၂ ကို လိုင်းဖျောက်သည့် စနစ်ပါဝင်သည်)
    var excelTemplate = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <meta charset="UTF-8">
            <style>
                table { border-collapse: collapse; width: 100%; }
                th, td { font-family: "Pyidaungsu", "Segoe UI", Arial; padding: 6px; border: 0.5pt solid #000000; vertical-align: middle; }
                th { background-color: #caf6d4 !important; font-weight: bold; text-align: center; color: black; }
                td.merge-top, td.name-cell, td.address-cell { vertical-align: top !important; }
                td.name-cell { border-bottom: none !important; }
                td.address-cell { border-top: none !important; }
                
                /* 🎯 အပေါ်ဆုံးက ခေါင်းစဉ်နှစ်ခု (excel-row-1 နှင့် excel-row-2) ၏ လိုင်းများကို လုံးဝဖျောက်ခြင်း */
                #excel-row-1 td, #excel-row-2 td { 
                    border: none !important; 
                }
            </style>
        </head>
        <body>
            ${htmlContent}
        </body>
        </html>
    `;

    // 5️⃣ JavaScript Native Blob ဖြင့် အော့ဖ်လိုင်းပါ သေချာပေါက် ဒေါင်းလုဒ်လုပ်ခိုင်းခြင်း
    var blob = new Blob([excelTemplate], { type: "application/vnd.ms-excel;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    
    var a = document.createElement("a");
    a.href = url;
    a.download = "Proposal_" + township + ".xls"; // 🎯 မြို့နယ်အမည်ဖြင့် ကွက်တိထွက်လာပါမည်
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

    // Delete အတည်ပြုချက်
    function confirmDelete(id) {
        if (confirm('ဖျက်ရန် သေချာပါသလား?')) {
            window.location.href = 'delete.php?id=' + id;
        }
    }

    // Function ရဲ့ အောက်ဆုံးနားမှာ ထည့်ပါ
    const bankTownshipValue = "<?php echo $bank_township; ?>";
    const mdNoValue = "<?php echo $md_no; ?>";

    // ID အတိအကျဖြင့် တန်ဖိုးထည့်ခြင်း
    if(document.getElementById('user_bank_township')) {
        document.getElementById('user_bank_township').innerText = bankTownshipValue;
    }
    if(document.getElementById('user_md_no')) {
        document.getElementById('user_md_no').innerText = mdNoValue;
    }

    // Pagination စနစ်
document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('tableBody');
    if(!tableBody) return;
    
    const rows = Array.from(tableBody.querySelectorAll('tr'));
    
    // Row တွေကို နှိပ်လို့ရအောင် လုပ်ခြင်း
    rows.forEach(row => {
        row.style.cursor = "pointer";
        row.onclick = function() {
            // အကယ်၍ သင်သည် PHP ကနေ ဒေတာကို data- attribute နဲ့ ထည့်ထားခဲ့ရင် 
            // ဥပမာ- <tr data-info='...'> ဆိုရင် ဒီနေရာမှာ ယူလို့ရပါတယ်
            let rowData = this.getAttribute('data-info') ? JSON.parse(this.getAttribute('data-info')) : null;
            toggleRow(this, rowData); 
        };
    });

    const rowsPerPage = 12;
    let currentPage = 1;

    function displayRows(page) {
        const start = (page - 1) * rowsPerPage;
        const end = start + rowsPerPage;
        rows.forEach((row, index) => {
            row.style.display = (index >= start && index < end) ? '' : 'none';
        });
        updatePaginationButtons();
    }
    function updatePaginationButtons() {
            let paginationContainer = document.getElementById('paginationContainer');
            if (!paginationContainer) {
                paginationContainer = document.createElement('div');
                paginationContainer.id = 'paginationContainer';
                paginationContainer.className = 'mt-3 d-flex justify-content-center gap-2';
                tableBody.closest('.table-responsive').after(paginationContainer);
            }
            const pageCount = Math.ceil(rows.length / rowsPerPage);
            paginationContainer.innerHTML = '';
            for (let i = 1; i <= pageCount; i++) {
                const btn = document.createElement('button');
                btn.innerText = i;
                btn.className = `btn btn-sm ${i === currentPage ? 'btn-primary' : 'btn-outline-primary'}`;
                btn.onclick = () => { currentPage = i; displayRows(i); };
                paginationContainer.appendChild(btn);
            }
        }
    
    displayRows(currentPage);
});



    // အဆိုပြုလွှာ Modal ဖွင့်ခြင်း
   function openProposal() {
    // ၁။ Input တန်ဖိုးများကို ယူပါ
    const minCaseInput = document.getElementById('minCase');
    const maxCaseInput = document.getElementById('maxCase');

    // Input box တွေ တကယ်ရှိမရှိ အရင်စစ်ပါ (Error ကာကွယ်ရန်)
    if (!minCaseInput || !maxCaseInput) {
        console.error("ID 'minCase' သို့မဟုတ် 'maxCase' ကို HTML ထဲမှာ ရှာမတွေ့ပါ");
        return;
    }

    const minCase = minCaseInput.value.trim(); 
    const maxCase = maxCaseInput.value.trim();

    // ၂။ တန်ဖိုးရှိမရှိ စစ်ဆေးပါ
    if (!minCase || !maxCase) {
        alert("ကျေးဇူးပြု၍ အမှုတွဲနံပါတ် အကွာအဝေးကို ရိုက်ထည့်ပါ");
        return;
    }

    // ၃။ Modal ကို ဖွင့်ပါ
    document.getElementById('taxFormModal').style.display = "block";
    
    // ၄။ PHP ထံမှ ဒေတာကို တောင်းဆိုပါ
    fetch(`get_case_details.php?min_case=${minCase}&max_case=${maxCase}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log("Received Data:", data); // F12 Console မှာ ဒေတာဝင်မဝင် စစ်ရန်

            if (!data || data.length === 0) {
                alert("ဒေတာမရှိပါ");
                return;
            }

            // ၅။ ဇယားထဲသို့ ဒေတာထည့်ရန် Function ကို ခေါ်ပါ
            renderProposalTable(data);
        })
        .catch(error => {
            console.error("Error details:", error);
            alert("ဒေတာဆွဲယူရာတွင် အမှားအယွင်းရှိပါသည်");
        });
}

    /*function closeModal() {
        document.getElementById('taxFormModal').style.display = "none";
    }

    function openProposalFromUI() {
    // ၁။ Filter Box (minCase) ထဲတွင် ရိုက်ထားသော နံပါတ်ကို ယူပါ
    let minV = document.getElementById('minCase').value;
    let maxV = document.getElementById('maxCase').value;
    
    if(!minV || !maxV) {
        alert("အမှုတွဲနံပါတ် အကွာအဝေးကို ရိုက်ထည့်ပါ");
        return;
    }
    openProposal(); // function ထဲမှာ value တွေကို ပြန်ယူပါလိမ့်မယ်
}*/

function closeModal() {
    const modal = document.getElementById('taxFormModal');
    if (modal) modal.style.display = "none";
}

function printProposal() {
    const area = document.getElementById("printableArea");
    if (!area) return;
    const win = window.open("", "_blank");
    if (!win) {
        alert("Print window ကို ဖွင့်၍မရပါ။ Popup ကို ခွင့်ပြုပေးပါ။");
        return;
    }
    win.document.write(`<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>အဆိုပြုလွှာ</title>
<style>
@page { size: A4 landscape; margin: 8mm; }
body { font-family: "Pyidaungsu", "Myanmar Text", sans-serif; margin: 0; color: #000; }
table { width: 100%; border-collapse: collapse; }
td, th { border: 0.5pt solid #000; padding: 2px; font-size: 9pt; vertical-align: top; color: #000; }
#excel-row-1 td, #excel-row-2 td { border: none !important; }
</style></head><body>${area.innerHTML}</body></html>`);
    win.document.close();
    win.focus();
    setTimeout(function () { win.print(); }, 300);
}

function openProposalFromUI() {
    let minV = document.getElementById('minCase').value;
    let maxV = document.getElementById('maxCase').value;
    if(!minV || !maxV) return alert("အမှုတွဲနံပါတ် အကွာအဝေး ရိုက်ထည့်ပါ");

    updateLayoutHeader();
    document.getElementById('taxFormModal').style.display = "block";
    fetch(`get_case_details.php?min_case=${minV}&max_case=${maxV}`)
        .then(res => res.json())
        .then(data => renderProposalTable(data))
        .catch(err => console.error("အဆိုပြုလွှာဒေတာ ရယူမရပါ", err));
}

function showProposalLayout() {
    // loginUserInfo ထဲမှာ ဒေတာရှိပြီးသားဖြစ်ရပါမယ်
    if(document.getElementById("display_state")) document.getElementById("display_state").innerText = loginUserInfo.state_name;
    if(document.getElementById("display_township")) document.getElementById("display_township").innerText = loginUserInfo.township_name;
    if(document.getElementById("display_region")) document.getElementById("display_region").innerText = loginUserInfo.region;

    // Layout/Modal ကို ဖွင့်သည့် ကုဒ်ကို ဒီအောက်မှာ ဆက်ရေးပါ
    // $('#proposalModal').modal('show'); 
}

    // Modal ထဲသို့ ဒေတာဖြည့်သွင်းခြင်း

function renderProposalTable(dataList) {
        const tableBody = document.querySelector("#proposalTable tbody");
        if (!tableBody) return;
        tableBody.innerHTML = "";
        if (!Array.isArray(dataList)) return;

        const officeRow = dataList.find(group => group && (group.state_name || group.township_name)) || {};
        const stateName = officeRow.state_name || loginUserInfo.state_name || '';
        const townshipName = officeRow.township_name || loginUserInfo.township_name || '';
        const stateEl = document.getElementById("display_state");
        const townshipEl = document.getElementById("display_township");
        if (stateEl && stateName) stateEl.innerText = stateName;
        if (townshipEl && townshipName) townshipEl.innerText = townshipName; 

        // ပေါင်းလဒ် သိမ်းရန် Object
        let subTotals = { col6: 0, col7: 0, col8: 0, col9: 0, col12: 0, col13: 0, col14: 0, col15: 0 };
        const commonStyle = "border: 0.5pt solid black; padding: 2px; font-size: 12pt; line-height: 1.0;";

        dataList.forEach((group, index) => {
            const records = Array.isArray(group.records) ? group.records : [];
            records.forEach((record) => {
                // ဒေတာများ ပေါင်းခြင်း
                subTotals.col6 += parseFloat(record.income3 || 0);
                subTotals.col7 += parseFloat(record.income_tax3 || 0);
                subTotals.col8 += parseFloat(record.sale_income3 || 0);
                subTotals.col9 += parseFloat(record.ct3 || 0);
                subTotals.col12 += (parseFloat(record.salesAmount1 || 0) + parseFloat(record.salesAmount2 || 0));
                subTotals.col13 += (parseFloat(record.ct1tax || 0) + parseFloat(record.ct2tax || 0));
                subTotals.col14 += parseFloat(record.netProfit || 0);
                subTotals.col15 += parseFloat(record.payableIncomeTax || 0);

                // ၁ အမှုတွဲလျှင် ၅ လိုင်း ထည့်ခြင်း
                for (let i = 1; i <= 5; i++) {
                    const tr = document.createElement('tr');
                    let html = "";
                    
                    if (i === 1) {
                        let itStr = `${group.it_no || ''} / ${group.it_select || ''}</b>`;
                        
                        // CT1 အတွက်
                        let ct1Str = (group.ct1_no_real || group.ct1_select_real) 
                                    ? `<br>${group.ct1_select_real || ''} / ${group.ct1_no_real || ''}` 
                                    : '';
                        
                        // CT2 အတွက် (ဒီနေရာမှာ ဒေတာပါမလာသေးတာပါ)
                        // console ထဲမှာ ct1_no_real ရော ct2_no_real ပါ ပါသလား တစ်ချက် ထပ်စစ်ကြည့်ပါ
                        let ct2Str = (group.ct2_no_real || group.ct2_select_real) 
                                    ? `<br>${group.ct2_select_real || ''} / ${group.ct2_no_real || ''}` 
                                    : '';

                        html += `
                            <td rowspan="5" class="merge-top" style="${commonStyle} text-align: center; vertical-align: top !important;font-size: 0.8em; color: #333;">${index + 1}</td>
                            <td rowspan="5" class="merge-top" style="${commonStyle} text-align: center; vertical-align: top !important;font-size: 0.8em; color: #333;">
                                ${itStr}${ct1Str}${ct2Str}
                            </td>
                            <td class="name-cell" style="${commonStyle} width: 140px; vertical-align: top !important; border-bottom: none !important; word-break: break-word; line-height: 1.2; padding: 2px;font-size: 0.8em; color: #333;">
                                <b>${group.taxpayer_name || ''}</b>
                            </td>
                            <td rowspan="5" class="merge-top" style="${commonStyle} width: 140px; vertical-align: top !important;font-size: 0.8em; color: #333;">${group.businessType1 || ''}</td>`;
                    }

                    if (i === 1) {
                        html += `<td style="${commonStyle} text-align: center;font-size: 0.8em; color: #333;">${record.rowYear1 || ''}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.income1)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.income_tax1)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.sale_income1)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.ct1)}</td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>`;
                    } else if (i === 2) {
                        html += `<td rowspan="4" class="address-cell merge-top" style="${commonStyle} width: 140px; vertical-align: top !important; border-top: none !important; word-break: break-word; line-height: 1.2; padding: 2px;font-size: 0.8em; color: #333;">${group.address || ''}</td>
                        <td style="${commonStyle} text-align: center;font-size: 0.8em; color: #333;">${record.rowYear2 || ''}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.income2)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.income_tax2)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.sale_income2)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.ct2)}</td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>`;
                    } else if (i === 3) {
                        html += `<td style="${commonStyle} text-align: center;font-size: 0.8em; color: #333;">${record.rowYear3 || ''}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.income3)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.income_tax3)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.sale_income3)}</td>
                        <td style="${commonStyle} text-align: right; font-size: 0.8em; color: #333;">${formatNumber(record.ct3)}</td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>`;
                    } else if (i === 4) {
                        // taxYear ကို record ထဲကနေ တိုက်ရိုက်ယူပါတယ်
                        // record ထဲမှာ ရှာမတွေ့ရင် group (Object အကြီး) ထဲက taxYear ကို ယူဖို့ Logic ပြင်လိုက်ပါတယ်
                        let yearValue = record.taxYear || group.taxYear || "";
                        let yearDisplay = yearValue ? `<b>${yearValue}</b>` : '';
                        
                        html += `<td style="${commonStyle} text-align: center;font-size: 0.8em; color: #333;">${yearDisplay}</td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle} text-align: right;font-size: 0.8em; color: #333;">${formatNumber(record.salesAmount1)}</td>
                        <td style="${commonStyle} text-align: right;font-size: 0.8em; color: #333;">${formatNumber(record.ct1tax)}</td>
                        <td style="${commonStyle} text-align: right;font-size: 0.8em; color: #333;">${formatNumber(record.netProfit)}</td>
                        <td style="${commonStyle} text-align: right;font-size: 0.8em; color: #333;">${formatNumber(record.payableIncomeTax)}</td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>`;
                    } else if (i === 5) {
                        html += `<td colspan="0" style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle} text-align: right;font-size: 0.8em; color: #333;">${formatNumber(record.salesAmount2)}</td>
                        <td style="${commonStyle} text-align: right;font-size: 0.8em; color: #333;">${formatNumber(record.ct2tax)}</td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>
                        <td style="${commonStyle}"></td>`;
                    }
                    tr.innerHTML = html;
                    tableBody.appendChild(tr);
                }
            });

            // ၅ မူတစ်ဖြတ် ပေါင်းလဒ် Row (Border ပါဝင်အောင် ပြင်ထားသည်)
            if ((index + 1) % 5 === 0 || (index + 1) === dataList.length) {
                const totalTr = document.createElement('tr');
                totalTr.style.backgroundColor = "#f2f2f2";
                totalTr.style.fontWeight = "bold";
                totalTr.innerHTML = `
                    <td colspan="4" style="${commonStyle} text-align:center;font-size: 0.8em; color: #333;">စုစုပေါင်း</td>
                    <td style="${commonStyle}"></td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col6)}</td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col7)}</td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col8)}</td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col9)}</td>
                    <td style="${commonStyle}"></td>
                    <td style="${commonStyle}"></td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col12)}</td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col13)}</td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col14)}</td>
                    <td style="${commonStyle} text-align:right;font-size: 0.8em; color: #333;">${formatNumber(subTotals.col15)}</td>
                    <td style="${commonStyle}"></td>
                    <td style="${commonStyle}"></td>`;
                tableBody.appendChild(totalTr);
                subTotals = { col6: 0, col7: 0, col8: 0, col9: 0, col12: 0, col13: 0, col14: 0, col15: 0 };
            }
        });
    }


    window.onclick = function(event) {
        let modal = document.getElementById('taxFormModal');
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

function openForm_regularculateModal() {
    if (!requireSelectedRow()) return;
    hideFormsModal();
    window.location.href = `forms/form_regular_calculation.php?id=${selectedRowData.id}`;
}


// Order Sheet Modal ကို ဒေတာများထည့်သွင်း၍ တိုက်ရိုက်ဖွင့်လှစ်ပေးမည့် Function
function openFormordersheet() {
    // ၁။ ဆရာ့မူရင်းကုဒ်ထဲက variable နာမည်အမှန် selectedRowData ကို ပြန်သုံးထားပါတယ်
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ ဇယားထဲမှ အမှုတွဲတစ်ခုအား အရင်နှိပ်၍ ရွေးချယ်ပေးပါဦးဗျာ။");
        return;
    }
    
    // ၂။ ပင်မ Forms Modal ကြီးကို အရင်ပိတ်ပါမယ်
    let formsModalEl = document.getElementById('formsModal');
    if (formsModalEl) {
        let modalInstance = bootstrap.Modal.getInstance(formsModalEl);
        if (modalInstance) modalInstance.hide();
    }
    
    // ၃။ ဒေတာများကို ပုံစံစာချပ်ထဲသို့ စနစ်တကျ ထည့်သွင်းခြင်း
    const updateText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.innerText = value || '-';
    };

    updateText('os_township', selectedRowData.township_name);
    updateText('os_name', selectedRowData.taxpayer_name);
    updateText('os_address', selectedRowData.address);
    updateText('os_biz', selectedRowData.businessType1);
    updateText('os_year', selectedRowData.taxYear);
    updateText('os_officer', selectedRowData.officer_name);
    updateText('os_gir', (selectedRowData.it_no || '') + " / " + (selectedRowData.it_select || 'စီးပွား'));

    updateText('os_profit', typeof formatNumber === 'function' ? formatNumber(selectedRowData.netProfit || 0) : (selectedRowData.netProfit || 0));
    updateText('os_income_tax', typeof formatNumber === 'function' ? formatNumber(selectedRowData.payableIncomeTax || 0) : (selectedRowData.payableIncomeTax || 0));
    updateText('os_advance', typeof formatNumber === 'function' ? formatNumber(selectedRowData.advancePaidTax || 0) : (selectedRowData.advancePaidTax || 0));
    updateText('os_balance', typeof formatNumber === 'function' ? formatNumber(selectedRowData.finalBalanceTax || 0) : (selectedRowData.finalBalanceTax || 0));
    updateText('os_penalty', typeof formatNumber === 'function' ? formatNumber(selectedRowData.itpanaty || 0) : (selectedRowData.itpanaty || 0));
    updateText('os_total_all', typeof formatNumber === 'function' ? formatNumber(selectedRowData.taxpanaty || 0) : (selectedRowData.taxpanaty || 0));
    updateText('os_balance1', typeof formatNumber === 'function' ? formatNumber(selectedRowData.finalBalanceTax || 0) : (selectedRowData.finalBalanceTax || 0));
    updateText('os_penalty1', typeof formatNumber === 'function' ? formatNumber(selectedRowData.itpanaty || 0) : (selectedRowData.itpanaty || 0));
    updateText('os_itDemandNo', selectedRowData.itDemandNo);
    updateText('os_itDemandDate', selectedRowData.itDemandDate);

    // ရက်စွဲတွက်ချက်မှုအပိုင်း
    if (selectedRowData.itDemandDate && selectedRowData.itDemandDate !== '0000-00-00') {
        const d = new Date(selectedRowData.itDemandDate);
        if (!isNaN(d.getTime())) {
            d.setDate(d.getDate() + 14); 
            const dd = String(d.getDate()).padStart(2, '0');
            const mm = String(d.getMonth() + 1).padStart(2, '0');
            const yyyy = d.getFullYear();
            const targetEl = document.getElementById('rq_date1');
            if (targetEl) targetEl.innerText = dd + "-" + mm + "-" + yyyy;
        }
    }

    // ၄။ အမိန့်စာချပ် (Order Sheet) Modal ကြီးကို လှမ်း၍ Show လုပ်လိုက်ပါပြီဗျာ
    var orderModalEl = document.getElementById('orderSheetModal');
    if (orderModalEl) {
        var myModal = new bootstrap.Modal(orderModalEl);
        myModal.show();
    } else {
        alert("orderSheetModal ကို ရှာမတွေ့ပါဗျာ။ form_order_sheet.php ဖိုင်ကို လက်ရှိစာမျက်နှာထဲမှာ include လုပ်ထားဖို့ လိုအပ်ပါတယ် ဆရာ။");
    }
}

function openForm0405() {
    if (!requireSelectedRow()) return;
    hideFormsModal();
    window.location.href = `forms/form_04_05.php?id=${selectedRowData.id}`;
}

function openForm0406() {
    if (!requireSelectedRow()) return;
    hideFormsModal();
    window.location.href = `forms/form_04_06.php?id=${selectedRowData.id}`;
}

function openForm0408() {
    if (!requireSelectedRow()) return;
    hideFormsModal();
    window.location.href = `forms/form_04_08.php?id=${selectedRowData.id}`;
}
function openForm0301() {
    if (!requireSelectedRow()) return;
    hideFormsModal();
    window.location.href = `forms/form_wanga1.php?id=${selectedRowData.id}`;
}
</script>


<?php include 'forms/form_order_sheet.php'; ?>
<?php include 'forms/form_04_05.php'; ?>
<?php include 'forms/form_04_06.php'; ?>
<?php include 'forms/form_04_07.php'; ?>
<?php include 'forms/form_04_08.php'; ?>
<?php include 'forms/form_general2.php'; ?>
</body>
</html>