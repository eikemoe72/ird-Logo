
<?php
ob_start(); // အပို space တွေ မထွက်အောင် တားထားခြင်း
session_start();
include 'db_config.php';
header('Content-Type: application/json'); // Browser ကို JSON format ဖြစ်ကြောင်း ပြောခြင်း

if (isset($_SESSION['user_name'])) {
    $current_user = $_SESSION['user_name'];
    // Backticks သုံးရန် မမေ့ပါနှင့်
    $query = "SELECT `officer_name`, `rank`, `region` FROM `user_register` WHERE `user_name` = '$current_user'";
    $result = $conn->query($query);

    if ($result && $row = $result->fetch_assoc()) {
        echo json_encode($row);
    } else {
        echo json_encode([
            'officer_name' => $_SESSION['officer_name'] ?? '',
            'rank_'        => $_SESSION['rank'] ?? '',
            'region'       => $_SESSION['region'] ?? ''
        ]);
    }
} else {
    echo json_encode(['error' => 'not_logged_in']);
}
ob_end_flush();
?>