<?php
include 'db_config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start(); 
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 🔍 စမ်းသပ်ရန် Debug Code (Data ပါမလာပါက အဖြူရောင် Screen ဖြင့် ပြပေးပါလိမ့်မည်)
    if (!isset($_POST['investigation_value'])) {
        die("သတိပေးချက် - Form ထဲကနေ investigation_value ဆိုတဲ့ name နဲ့ data ပါမလာပါဗျာ။ HTML ဘက်က name ကို ပြန်စစ်ပေးပါ။");
    }

    // ၄။ HTML Form က ပို့လိုက်သော name="id" သို့မဟုတ် name="edit_id" ကို ကျိန်းသေဖမ်းယူခြင်း
    $edit_id = !empty($_POST['edit_id']) ? intval($_POST['edit_id']) : (!empty($_POST['id']) ? intval($_POST['id']) : null);

    // စာသားအချက်အလက်များ
    $case_number        = mysqli_real_escape_string($conn, $_POST['case_number'] ?? '');
    $tax_year           = mysqli_real_escape_string($conn, $_POST['tax_year'] ?? '');
    $officer_name       = mysqli_real_escape_string($conn, $_POST['officer_name'] ?? '');
    $officer_rank       = mysqli_real_escape_string($conn, $_POST['officer_rank'] ?? $_POST['rank_'] ?? '');
    $officer_rank       = mb_substr(trim($officer_rank), 0, 30, 'UTF-8');
    $region             = mysqli_real_escape_string($conn, $_POST['region'] ?? '');
    
    // 🎯 ✅ ပြည်နယ်နှင့် မြို့နယ်အမည်များကို ပိုမိုစိတ်ချရအောင် အဆင့်ဆင့်စစ်ဆေးခြင်း
    $state_name    = isset($_POST['state_name']) ? mysqli_real_escape_string($conn, trim($_POST['state_name'])) : '';
    $township_name = isset($_POST['township_name']) ? mysqli_real_escape_string($conn, trim($_POST['township_name'])) : '';

    // အကယ်၍ Form ဘက်ကနေ Blank (ဗလာ) အနေနဲ့ ရောက်လာခဲ့ပါက Session ထဲမှ လှမ်းယူခြင်း
    if (empty($state_name) && isset($_SESSION['state_name'])) {
        $state_name = mysqli_real_escape_string($conn, $_SESSION['state_name']);
    }
    if (empty($township_name) && isset($_SESSION['township_name'])) {
        $township_name = mysqli_real_escape_string($conn, $_SESSION['township_name']);
    }

    // 🛡️ Edit Mode ဖြစ်ပြီး အပေါ်ကစနစ်တွေနဲ့မှ Blank ဖြစ်နေသေးပါက မူလ DB ထဲက Data ဟောင်းကို ဆွဲယူ၍ ကာကွယ်ခြင်း
    if ($edit_id > 0 && (empty($state_name) || empty($township_name))) {
        $check_old_sql = "SELECT state_name, township_name FROM sharedata WHERE id = $edit_id LIMIT 1";
        $check_old_res = $conn->query($check_old_sql);
        if ($check_old_res && $check_old_res->num_rows > 0) {
            $old_row = $check_old_res->fetch_assoc();
            if (empty($state_name)) $state_name = mysqli_real_escape_string($conn, $old_row['state_name']);
            if (empty($township_name)) $township_name = mysqli_real_escape_string($conn, $old_row['township_name']);
        }
    }
    
    $taxpayer_name      = mysqli_real_escape_string($conn, $_POST['taxpayer_name'] ?? '');
    $nrc_no             = mysqli_real_escape_string($conn, $_POST['nrc_no'] ?? ''); 
    $gir_type           = mysqli_real_escape_string($conn, $_POST['gir_type'] ?? '');
    $gir_no             = mysqli_real_escape_string($conn, $_POST['gir_no'] ?? '');
    $address            = mysqli_real_escape_string($conn, $_POST['address'] ?? '');
    $business_type      = mysqli_real_escape_string($conn, $_POST['business_type'] ?? '');
    $company_name       = mysqli_real_escape_string($conn, $_POST['company_name'] ?? '');
    $paid               = mysqli_real_escape_string($conn, $_POST['paid'] ?? '');
    $share_value        = mysqli_real_escape_string($conn, $_POST['share_value'] ?? '');
    $chalan_no          = mysqli_real_escape_string($conn, $_POST['chalan_no'] ?? '');
    $it_demand_no       = mysqli_real_escape_string($conn, $_POST['it_demand_no'] ?? '');
    
    $investigation_value    = mysqli_real_escape_string($conn, $_POST['investigation_value'] ?? '');
    $source_of_income       = mysqli_real_escape_string($conn, $_POST['source_of_income'] ?? '');
    $investigation          = mysqli_real_escape_string($conn, $_POST['investigation'] ?? '');

    // 🎯 ရက်စွဲများအတွက် Helper Function
    function formatDateForSQL($conn, $value) {
        $trimmed = trim($value);
        if (empty($trimmed) || $trimmed === '-/-/-' || $trimmed === '0000-00-00') {
            return "NULL";
        }
        return "'" . mysqli_real_escape_string($conn, $trimmed) . "'";
    }
    
    $share_date             = formatDateForSQL($conn, $_POST['share_date'] ?? '');
    $notified_date          = formatDateForSQL($conn, $_POST['notified_date'] ?? '');
    $appointment_date       = formatDateForSQL($conn, $_POST['appointment_date'] ?? '');
    $appearance_date        = formatDateForSQL($conn, $_POST['appearance_date'] ?? '');
    $it_demand_date         = formatDateForSQL($conn, $_POST['it_demand_date'] ?? '');
    $chalan_date            = formatDateForSQL($conn, $_POST['chalan_date'] ?? '');

    // ကိန်းဂဏန်းများသန့်စင်ခြင်း
    function cleanNumber($val) {
        $clean = preg_replace('/[^\d.]/', '', $val);
        return (empty($clean)) ? 0 : floatval($clean);
    }

    $paid_share_value   = cleanNumber($_POST['paid_share_value'] ?? 0);
    $valuation_value    = cleanNumber($_POST['valuation_value'] ?? 0);
    $allowable_expenses = cleanNumber($_POST['allowable_expenses'] ?? 0);
    $taxable_income     = cleanNumber($_POST['taxable_income'] ?? 0);
    $income_tax         = cleanNumber($_POST['income_tax'] ?? 0);
    $advance_tax        = cleanNumber($_POST['advance_tax'] ?? 0);
    $tax_to_pay         = cleanNumber($_POST['tax_to_pay'] ?? 0);
    $penalty_tax        = cleanNumber($_POST['penalty_tax'] ?? 0);
    $total_tax          = cleanNumber($_POST['total_tax'] ?? 0);
    $paid_amount        = cleanNumber($_POST['paid_amount'] ?? 0);

    // ၅။ $edit_id အပေါ်မူတည်ပြီး INSERT သို့မဟုတ် UPDATE လုပ်ခြင်း
    if ($edit_id === null || $edit_id <= 0) {
        // 🎯 INSERT MODE
        $sql = "INSERT INTO sharedata (
            case_number, tax_year, officer_name, officer_rank, region, state_name, township_name, taxpayer_name, 
            nrc_no, gir_type, gir_no, address, business_type, company_name, share_date, paid, share_value, paid_share_value, 
            valuation_value, allowable_expenses, taxable_income, 
            income_tax, advance_tax, tax_to_pay, penalty_tax, total_tax, paid_amount, chalan_no, chalan_date, 
            notified_date, appointment_date, appearance_date, it_demand_no, it_demand_date, investigation_value, 
            source_of_income, investigation
        ) VALUES (
            '$case_number', '$tax_year', '$officer_name', '$officer_rank', '$region', '$state_name', '$township_name', '$taxpayer_name',
            '$nrc_no', '$gir_type', '$gir_no', '$address', '$business_type', '$company_name', $share_date, '$paid', '$share_value', '$paid_share_value',
            '$valuation_value', '$allowable_expenses', '$taxable_income', 
            '$income_tax', '$advance_tax', '$tax_to_pay', '$penalty_tax', '$total_tax', '$paid_amount', '$chalan_no', $chalan_date, 
            $notified_date, $appointment_date, $appearance_date, '$it_demand_no', $it_demand_date, '$investigation_value', 
            '$source_of_income', '$investigation'
        )";
        $msg = "အချက်အလက်အသစ်ကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ။";
    } else {
        // 🎯 UPDATE MODE
        $sql = "UPDATE sharedata SET 
                    case_number='$case_number', 
                    tax_year='$tax_year',  
                    officer_name='$officer_name',
                    officer_rank='$officer_rank', 
                    region='$region',  
                    state_name='$state_name',
                    township_name='$township_name', 
                    taxpayer_name='$taxpayer_name', 
                    nrc_no='$nrc_no',
                    gir_type='$gir_type',
                    gir_no='$gir_no', 
                    address='$address', 
                    business_type='$business_type', 
                    company_name='$company_name', 
                    share_date=$share_date, 
                    paid='$paid',
                    share_value='$share_value', 
                    paid_share_value='$paid_share_value', 
                    valuation_value='$valuation_value', 
                    allowable_expenses='$allowable_expenses',
                    taxable_income='$taxable_income',
                    income_tax='$income_tax',
                    advance_tax='$advance_tax', 
                    tax_to_pay='$tax_to_pay',
                    penalty_tax='$penalty_tax', 
                    total_tax='$total_tax', 
                    paid_amount='$paid_amount', 
                    chalan_no='$chalan_no', 
                    chalan_date=$chalan_date,
                    notified_date=$notified_date, 
                    appointment_date=$appointment_date,
                    appearance_date=$appearance_date, 
                    it_demand_no='$it_demand_no',
                    it_demand_date=$it_demand_date,
                    investigation_value='$investigation_value',
                    source_of_income='$source_of_income', 
                    investigation='$investigation'
                WHERE id = $edit_id"; 
        $msg = "အချက်အလက်များကို အောင်မြင်စွာ ပြင်ဆင်ပြီးပါပြီ။";
    }

    // Query ကို Run ခြင်း
    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('$msg');
                window.location.href = 'share_demand_list.php'; 
              </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>