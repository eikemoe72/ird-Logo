<?php
// ၁။ Session စတင်ခြင်း နှင့် Error အားလုံးကို Browser တွင် ပေါ်အောင် ဖွင့်ပေးခြင်း
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ db_config.php ချိတ်ဆက်မှုကို စစ်ဆေးခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}

if (!isset($conn)) {
    die("Database Connection Error: \$conn variable is not defined.");
}
$conn->set_charset("utf8mb4");

// ၃။ Login User ၏ အချက်အလက်များ ဆွဲထုတ်ခြင်း
$os_md_no = '............'; 
$os_bank_township = '............'; 
$session_user = $_SESSION['user_id'] ?? $_SESSION['username'] ?? '';

if (!empty($session_user)) {
    $user_stmt = $conn->prepare("SELECT md_no, bank_township FROM user_register WHERE id = ? LIMIT 1");
    if ($user_stmt) {
        $user_stmt->bind_param("s", $session_user);
        $user_stmt->execute();
        $user_res = $user_stmt->get_result();
        if ($user_res && $user_res->num_rows > 0) {
            $user_row = $user_res->fetch_assoc();
            if (!empty($user_row['md_no'])) $os_md_no = htmlspecialchars($user_row['md_no']);
            if (!empty($user_row['bank_township'])) {
                $os_bank_township = htmlspecialchars(trim(str_replace('နယ်', '', $user_row['bank_township'])));
            }
        }
        $user_stmt->close();
    }
}

// ၄။ URL ID မှ ဒေတာဆွဲထုတ်ခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    $query = "SELECT * FROM regular_data WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ဂဏန်းကို မြန်မာဂဏန်းပြောင်းရန် Function (လိုအပ်ပါက သုံးရန်)
function toMMNum($num, $showComma = true) {
    if ($num === null || $num === '' ) return '၀';
    $mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
    $s = $showComma ? number_format($num) : (string)$num;
    return preg_replace_callback('/\d/', function($matches) use ($mDigits) {
        return $mDigits[$matches[0]];
    }, $s);
}

// မြန်မာစာသားပြောင်းရန် Function 
function numToMyanmarText($number) {
    if (!$number) return "သုည";
    $digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
    $units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
    $numStr = (string)floor($number);
    $result = "";
    $len = mb_strlen($numStr);
    for ($i = 0; $i < $len; $i++) {
        $digit = intval(mb_substr($numStr, $i, 1));
        $unitIndex = $len - $i - 1;
        if ($digit !== 0) {
            $result .= $digits[$digit] . $units[$unitIndex];
        }
    }
    return $result;
}

// ဒေတာများ ထည့်သွင်းခြင်း
$tax_year     = $db_data['taxYear'] ?? '';
$taxpayer_name = $db_data['taxpayer_name'] ?? '-';
$address      = $db_data['address'] ?? '-';
$township     = $db_data['township_name'] ?? '-';
$it_full      = ($db_data['it_no'] ?? '') . "/" . ($db_data['it_select'] ?? '');
$final_balance = $db_data['finalBalanceTax'] ?? 0;
$net_profit   = $db_data['netProfit'] ?? 0;
$biz_type1    = $db_data['businessType1'] ?? '-';
$panaty       = $db_data['itpanaty'] ?? 0;
$taxpanaty    = $db_data['taxpanaty'] ?? 0;
$DemandNo    = $db_data['itDemandNo'] ?? 0;

// သက်သာခွင့်များ
$basic_relief   = $db_data['basicRelief'] ?? 0;
$spouse_relief  = $db_data['spouse_relief'] ?? 0;
$parent_relief  = $db_data['parent_relief'] ?? 0;
$child_relief   = $db_data['child_relief'] ?? 0;
$total_relief   = $db_data['totalRelief'] ?? 0;
$taxable_income = $db_data['finalTaxableIncome'] ?? 0;
$income_tax     = $db_data['payableIncomeTax'] ?? 0;
$advance_tax    = $db_data['advancePaidTax'] ?? 0;

// နှစ်အပိုင်းအခြား တွက်ချက်ခြင်း
$years = explode('-', $tax_year);
$start_p_year = count($years) === 2 ? toMMNum(intval($years[0]) - 1, false) : '-';
$end_p_year   = count($years) === 2 ? toMMNum(intval($years[1]) - 1, false) : '-';

$os_terget_date = '............';
if (!empty($db_data['itDemandDate']) && $db_data['itDemandDate'] !== '0000-00-00' && strtotime($db_data['itDemandDate'])) {
    $os_terget_date = date('d-m-Y', strtotime($db_data['itDemandDate'] . ' + 14 days'));
}
?>



<style>
#form0408Modal .modal-dialog {
    max-width: 820px !important; 
    width: 100% !important;
    margin: 10px auto !important;
    position: relative;
}


#form0408Modal .modal-content {
    background-color: #55bbee !important; 
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 20px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}

#form0408Modal .modal-body {
   
    background-color: white !important; 
    padding: 5px !important; 
    overflow-x: auto !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
    justify-content: center !important;
}

.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 34px !important;
    background-color: #dc3545 !important; 
    color: #ffffff !important; 
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 34px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; 
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 1.5px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}

.custom-close-btn:hover {
    background-color: #bd2130 !important; 
}

.print-container { 
    background: white !important;
    width: 210mm !important; 
    min-height: 297mm !important;
    height: auto !important; 
    padding: 5mm 5mm 5mm 10mm !important; 
    margin: 0 auto 20px auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}

table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}

table, tr, td { 
    box-sizing: border-box !important;
}

.custom-modal-title {
    font-size: 20px !important; 
    font-weight: bold !important; 
    color: #3c8ddf !important; 
    padding-left: 25px !important; 
    display: inline-block !important;
    line-height: 40px !important; 
}

.no-print-bottoms {
    display: flex !important;
    justify-content: center !important;
    gap: 15px !important;
    margin-top: 0px !important;    
    margin-bottom: 30px !important;
    width: 100% !important;
}

.no-print-bottoms .btn {
    font-size: 16px !important;         
    font-weight: bold !important;     
    padding: 10px 24px !important;    
    border-radius: 5px !important;    
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important; 
    transition: all 0.2s ease-in-out !important;
}

.no-print-bottoms .btn:hover {
    transform: translateY(-1.5px) !important; 
    box-shadow: 0 6px 11.5px rgba(0, 0, 0, 0.2) !important;
}

table {
    border-collapse: collapse; /* ဒါက အရေးကြီးဆုံးပါ */
    width: 100%;
}

#form0408Modal .modal-header {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    background-color: #55bbee !important; /* လိုအပ်ပါက အရောင်ဆက်ထားရန် */
}


@media print {
    .modal-footer, .no-print, .btn, .btn-close, .modal-header, .modal-title { 
        display: none !important; 
    }
    
    body * { 
        visibility: hidden !important; 
    }
    
    #form0408Modal, #form0408Modal * { 
        visibility: visible !important; 
    }
    
    #form0408Modal { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .modal-dialog, .modal-content, .modal-body { 
        margin: 0 !important;
        margin-top: -3mm !important;
        padding: 0 !important;
        max-width: 100% !important; 
        width: 100% !important;
        border: none !important; 
        box-shadow: none !important;
        background: transparent !important;
    }

    html, body {
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    /* Two sheets only. A forced full-page height was opening a blank third sheet. */
    .print-container { 
        width: 100% !important;
        max-width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        padding: 5mm 10mm 5mm 15mm !important; 
        margin: 0 !important;
        border: none !important;
        display: block !important;
        box-sizing: border-box !important; 
        page-break-after: auto !important;
        break-after: auto !important;
        overflow: visible !important;
    }

    .print-container + .print-container {
        min-height: 290mm !important;
        page-break-before: always !important;
        break-before: page !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
    }

    table, .main-content-table, .main-content-table2, .order-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important; 
    }
    
    table, tr, td { 
        border: none !important; 
        box-sizing: border-box !important;
    }
    
    .print-container table:first-child {
        border: none !important;
    }

    hr { display: none !important; }
    
    @page {
        size: A4 portrait;
        margin: 0mm !important; 
    }
    .border{
        border: 1.5px solid #0b0b0b;
    }
}


.underline{border-bottom: 1px dotted black; width:250px;}
.dashed-line{border-bottom:1.5px dotted black !important;}
.solid-line{border-bottom: 1.5px solid #0d0d0d !important; min-width:150px; display: inline-block; text-align: left; padding-left:5px;}
.under-line { border-bottom: 1.5px dashed #0d0d0d !important; min-width:100px; display: inline-block; text-align: left; padding-left:0px; padding-top:5px;}
.under-line3 { border-bottom: px dashed #0d0d0d !important; min-width:100px; display: inline-block; text-align: left; padding-left:0px; padding-top:5px;}
.under-line2 { border-bottom: 1.5px dashed #0d0d0d !important; min-width:460px; display: inline-block; text-align: left; padding-left:0px; }
</style>

<div class="modal fade" id="form0408Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
               
                <h4 class="modal-title" style="font-size: 18px; font-weight: bold; margin: 0; color: white;">
                ၀၄-၀၈ စည်းကြပ်မှုအကြောင်းကြားစာ  ထုတ်ယူရန်</h4>
                <button type="button" class="close-modal-btn no-print" onclick="window.location.href='../IT_demand_list.php';" style="background: none; border: none; color: #ff4d4d; font-size: 26px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <table style="border: 1.5px solid #000 !important; text-align:center; font-size:14px; width:100%; line-height:24px">
                        <tr>
                            <td style='border: 0px solid black; padding:3px;'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:14px; padding:1px; line-height: 11.5px;'>ပတခ(ဝင)-၀၄-၀၈</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:0px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၁ အရ <br>
                        ဝင်ငွေခွန်စည်းကြပ်မှု အကြောင်းကြားစာ 
                    </div>

                    <table style='width:100%; font-size:14px;line-height:21px; margin-bottom: 0px;'>
                        <tr>
                            <td style='width:45%'></td>
                            <td style='width:40%; text-align:right;'>အခွန်တောင်းခံလွှာအမှတ်၊</td>
                            <td style='width:5%; text-align:right; ' class="under-line">DN-<?php echo htmlspecialchars($DemandNo); ?></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style='text-align:right;'>ရက် စွဲ ၊ </td>
                            <td style='text-align:right;' class="under-line"><?php echo toMMNum($tax_year, false); ?></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:1၅px; line-height:21px; margin-bottom: 0px;'>
                        <tr>
                            <td style='width:10%;'>သို့</td>
                            <td style='width:23%;'></td>
                            <td style='width:67%;'></td>
                        </tr>
                        <tr>
                            <td style='width:10%;'></td>
                            <td style='width:23%;'>အခွန်ထမ်းအမည်</td>
                            <td style='width:67%;' class="under-line2">၊ <?php echo htmlspecialchars($taxpayer_name); ?></td>
                        </tr>
                        <tr>
                            <td style='width:10%;'></td>
                            <td style='width:23%;'>အခွန်ထမ်းTinအမှတ်</td>
                            <td style='width:67%;' class="under-line2">၊ <?php echo htmlspecialchars($it_full); ?>၊  <?php echo htmlspecialchars($biz_type1); ?></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:23%'>အခွန်ထမ်းလိပ်စာ</td>
                            <td style='width:67%' class="under-line2">၊ <?php echo htmlspecialchars($address); ?></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:23%'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                            <td style='width:67%' class="under-line2">၊ ( ၀၁-၀၄-<?php echo $start_p_year; ?>) မှ (၃၁-၀၃-<?php echo $end_p_year; ?> )ထိ ကာလ</td>
                        </tr>
                    </table>

                    

                    <div style="margin-top:5px; padding:1px; text-align:justify;">
                        ၁။<span style = 'padding-left:50px;'></span>( <strong><?php echo toMMNum($tax_year, false); ?></strong> )စည်းကြပ်နှစ်အတွက် 
                        ကျောဖက်ပါပုံစံတွင် အသေးစိပ်ဖော်ပြထားချက်အရ ပေးဆောင်ရန် တာဝန်ရှိသည့် အခွန်နှင့်စပ်လျဉ်း၍ အောက်ပါအတိုင်း ပေးဆောင်ရန် အကြောင်းကြားပါသည် -
                    </div>

                    <table style='width:100%; font-size:15px; line-height:22px;margin-bottom: 0px;'>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(က)</td>
                            <td style='width:55%'>ဝင်ငွေခွန်</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%; text-align:right; vertical-align: middle;' class="under-line3"> <?php echo toMMNum($final_balance); ?></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ခ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၅ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဂ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၆ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ဃ)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၇ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( င )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၈ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"> </td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( စ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၉ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ဆ)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၀ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဇ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၁ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဈ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၂ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ည)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၃ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဋ  )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၄ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%; text-align:right' class="under-line"><?php echo toMMNum($panaty); ?></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'></td>
                            <td style='width:55%'><b>စုစုပေါင်းပေးဆောင်ရမည့်အခွန်ပမာဏ</b></td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%; text-align:right' class="under-line"><?php echo toMMNum($taxpanaty); ?></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td colspan="5" style='padding-top: 1px;'>
                               <strong> စာသားဖြင့် ( <?php echo numToMyanmarText($taxpanaty); ?> ) ကျပ်တိတိ၊</strong>
                            </td>     
                        </tr>
                    </table>
                    <div style="margin-top:5px; padding:1px; text-align:justify;">
                        ၂။<span style = 'padding-left:48px;'></span>အထက်ပါပေးဆောင်ရမည့် အခွန်ငွေပမာဏကို 
                            ( <?php echo htmlspecialchars($os_bank_township); ?> ) ရှိ မြန်မာ့စီးပွားရေးဘဏ်၊ 
                            ဘဏ်စာရင်းအမှတ် ( <?php echo htmlspecialchars($os_md_no); ?> ) သို့ ပူးတွဲပါ ငွေသွင်းချလန်ဖြင့်
                            ( <?php echo htmlspecialchars($os_terget_date); ?> )ရက်နေ့ နောက်ဆုံးထား၍ ပေးသွင်းပြီး လက်ခံဖြတ်ပိုင်းကို
                            ရယူစေလိုပါသည်။ (Online Paymentဖြင့် ပေးသွင်း၍ရပါက ပေးသွင်းစေလိုပါသည်။) သတ်မှတ်ရက်အတွင်း အခွန်ပေးသွင်းရန် ပျက်ကွက်ပါက 
                            အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေ ပုဒ်မ ၇၄ ၊ ပုဒ်မခွဲ(က)အရ ဒဏ်ငွေ ထပ်မံတပ်ရိုက်ခြင်း ခံရဖွယ်ရှိပါ၍ မပျက်မကွက် ပေးဆောင်စေလိုပါသည်။<br>
                    
                        ၃။<span style = 'padding-left:48px;'></span>စည်းကြပ်မှု သို့မဟုတ် ဒဏ်ကြေးငွေတပ်ရိုက်မှုအတွက်ဆုံးဖြတ်ချက်ကို ကျေနပ်မှုမရှိပါက
                         အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၄ ပါ စီမံအုပ်ချုပ်မှုနည်းလမ်းအရ ပြန်လည်သုံးသပ်ပေးရန် ညွှန်ကြားရေးမှူးချုပ်၊ ပြည်တွင်းအခွန်များဦးစီးဌာန၊ 
                         ရုံးအမျတ်(၄၆)၊ နေပြည်တော်သို့ အကြောင်းကြားစာလက်ခံရရှိသည့်နေ့မှ ရက်ပေါင်း(၃၀)အတွင်း လျှောက်ထားနိုင်ပါသည်။
                    </div>
                    <br>
                    <table style='width:100%; margin-top:10px;line-height:22px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br><?php echo htmlspecialchars($township); ?>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="print-container">
                    <p style='text-align:right; font-size:14px; padding:1px; line-height: 16px;'>ပတခ(ဝင)-၀၄-၀၈(အဆက်)</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        ဝင်ငွေအမျိုးအစားအလိုက် သတ်မှတ်မှု 
                    </div>
                    <table style="width: 100%; border: 1.5px solid #0a0a0a;" >
                        
                        <tr style="border: 1.5px solid #0a0a0a;">
                            <th colspan="2" style="width: 76%; text-align: center;   padding:3px;" class="border">ဝင်ငွေရလမ်း</th>
                            <!--<th style="width: 38%; text-align: left; border-right: 1px solid #0b0b0b;">လစာ</th>
                            <th style="width: 35%; text-align: center;" class="under-line2">.</th>-->
                            <th style="width: 24%; text-align: center;  padding:1px;" class="border">သတ်မှတ်ဝင်ငွေ (ကျပ်)</th>
                        </tr>
                       
                    </table>

                    <table style="width: 100%; " >
                        
                        <tr style="height:26px; padding:1px;">
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;">၁။</th>
                            <th style="width: 40%; text-align: left; padding:1px; ">လစာ</th>
                            <th style="width: 31%; text-align: center; border-right: 1px solid #0b0b0b;padding:1px; border-bottom: 1.5px dotted black;"></th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:1px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;">၂။</th>
                            <th style="width: 40%; text-align: left; padding:1px;">အသက်မွေးဝမ်းကျောင်းပညာလုပ်ငန်း</th>
                            <th style="width: 31%; text-align: center;  border-right: 1px solid #0b0b0b; padding:1px; border-bottom: 1.5px dotted black;"></th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:1px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;">၃။</th>
                            <th style="width: 40%; text-align: left; padding:1px;">စီးပွားရေးလုပ်ငန်း</th>
                            <th style="width: 31%; text-align: center;  border-right: 1.5px solid #0b0b0b; padding:1px; border-bottom: 1.5px dotted black;"><?php echo htmlspecialchars($biz_type1); ?></th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; " ><?php echo htmlspecialchars($net_profit); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;">၄။</th>
                            <th style="width: 40%; text-align: left; padding:1px;">ပစ္စည်း</th>
                            <th style="width: 31%; text-align: center; border-right: 1.5px solid #0b0b0b; padding:1px; border-bottom: 2px dotted black;"></th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:1px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;">၅။</th>
                            <th style="width: 40%; text-align: left; padding:1px;">အခြေပစ္စည်းမှမြတ်စွန်းငွေ</th>
                            <th style="width: 31%; text-align: center;  border-right: 1.5px solid #0b0b0b; padding:1px;border-bottom: 1.5px dotted black;"></th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:1px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;">၆။</th>
                            <th style="width: 40%; text-align: left; padding:1px;">စည်းကြပ်မှုမှလွတ်ကင်းသွားသောဝင်ငွေ</th>
                            <th style="width: 31%; text-align: center;  border-right: 1.5px solid #0b0b0b; padding:1px;border-bottom: 1.5px dotted black;"></th>
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:1px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left;  border-left: 1.5px solid #0a0a0a; padding:1px;">၇။</th>
                            <th style="width: 40%; text-align: left;  padding:1px;">အခြားရလမ်းများမှဝင်ငွေ</th>
                            <th style="width: 31%; text-align: center;  border-right: 1.5px solid #0b0b0b; padding:1px; border-bottom: 1.5px dotted black;"></th>
                            <th style="width: 24%; text-align: right;  padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:1px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-bottom: 1.5px solid #121212; border-left: 1.5px solid #0a0a0a;"><br></th>
                            <th style="width: 40%; text-align: left; border-bottom: 1.5px solid #121212; "><br></th>
                            <th style="width: 31%; text-align: center;  border-bottom: 1.5px solid #121212; border-right: 1.5px solid #0b0b0b;"><br></th>
                            <th style="width: 24%; text-align: right; border-bottom: 1.5px solid #121212; padding-right:35px; border-right: 1.5px solid #0a0a0a;" ><br></th>
                        </tr>
                       
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 1.5px solid #0b0b0b;  padding-right:15px;">စုစုပေါင်း</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 1.5px solid #0b0b0b;" >စုစုပေါင်း</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; "><?php echo htmlspecialchars($net_profit); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 1.5px solid #0b0b0b;  padding-right:15px;">*သက်သာခွင့်များ</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 1.5px solid #0b0b0b;" >စုစုပေါင်း</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-bottom: 1.5px solid #121212; border-right: 1.5px solid #0a0a0a; "><?php echo htmlspecialchars($total_relief); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 1.5px solid #0b0b0b;  padding-right:15px;">အခွန်စည်းကြပ်ရန်အသားတင်ဝင်ငွေ</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 1.5px solid #0b0b0b;" >အခွန်စည်းကြပ်ရန်အသားတင်ဝင်ငွေ</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; "><?php echo htmlspecialchars($taxable_income); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 1.5px solid #0b0b0b; padding-right:15px;">ကျသင့်ဝင်ငွေခွန်</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 1.5px solid #0b0b0b;" >ကျသင့်ဝင်ငွေခွန်</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; "><?php echo htmlspecialchars($income_tax); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-left: 1.5px solid #0a0a0a; padding:1px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-right: 1.5px solid #0b0b0b; color: red;  padding-right:15px;">နုတ်-ပုဒ်မ ၁၆ အရ ပေးဆောင်ပြီးအခွန်</th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 1.5px solid #0b0b0b; color: red;" >နုတ်-ပုဒ်မ ၁၆ အရ ပေးဆောင်ပြီးအခွန်</th>-->
                            <th style="width: 24%; text-align: right; padding-right:30px; color: red; border-bottom: 1.5px solid #121212; border-right: 1.5px solid #0a0a0a; "><?php echo htmlspecialchars($advance_tax); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 5%; text-align: left; border-bottom: 1.5px solid #121212; border-left: 1.5px solid #0a0a0a; padding:1px;"></th>
                            <th colspan="2" style="width: 40%; text-align: right; border-bottom: 1.5px solid #121212; right; border-right: 1.5px solid #0b0b0b;  padding-right:15px;">ပေးဆောင်ရန်ကျန် / ပြန်အမ်းရန်အခွန်<br></th>
                            <!--<th style="width: 31%; text-align: right;  border-right: 1.5px solid #0b0b0b;" >ပေးဆောင်ရန်ကျန် / ပြန်အမ်းရန်အခွန်</th>-->
                            <th style="width: 24%; text-align: right; border-bottom: 1.5px solid #121212; padding-right:30px; border-right: 1.5px solid #0a0a0a; "><?php echo htmlspecialchars($final_balance); ?></th>
                        </tr>
 
                    </table>
                    <br><br>

                    <table style="width: 100%; " >
                        
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;"></th>
                            <th style="width: 36%; text-align: center; padding:1px;"><b>*သက်သာခွင့်များ</b></th>
                            <th style="width: 12%; text-align: center; padding:1px;"></th>
                            <th style="width: 22%; text-align: right; padding:1px;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;">၁။</th>
                            <th style="width: 36%; text-align: left; padding:1px;">အခြေခံသက်သာခွင့်</th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1px dashed #0d0d0d;" ><?php echo htmlspecialchars($basic_relief); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;">၂။</th>
                            <th style="width: 36%; text-align: left; padding:1px;">အတူနေမိဘအတွက်သက်သာခွင့် </th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1px dashed #0d0d0d;" ><?php echo htmlspecialchars($parent_relief); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;">၃။</th>
                            <th style="width: 36%; text-align: left; padding:1px;">အိမ်ထောင်ဖက်အတွက်သက်သာခွင့် </th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1px dashed #0d0d0d;" ><?php echo htmlspecialchars($spouse_relief); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;">၄။</th>
                            <th style="width: 36%; text-align: left; padding:1px;">သားသမီးများအတွက်သက်သာခွင့်  </th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1px dashed #0d0d0d;" ><?php echo htmlspecialchars($child_relief); ?></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;">၅။</th>
                            <th style="width: 36%; text-align: left; font-size: 12px;"padding:1px;>အခွန်ထမ်းနှင့်အိမ်ထောင်ဖက်၏အသက်အာမခံအတွက်</th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1px dashed #0d0d0d;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;">၆။</th>
                            <th style="width: 36%; text-align: left; padding:1px;">စုဆောင်းငွေအတွက် သက်သာခွင့်   </th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1px dashed #0d0d0d;" ></th>
                        </tr>
                        <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;">၇။</th>
                            <th style="width: 36%; text-align: left; padding:1px;">လှူဒါန်းငွေအတွက်သက်သာခွင့် </th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1.5px solid #121212;" ></th>
                        </tr>
                        <br>
                         <tr>
                            <th style="width: 15%; text-align: left; padding:1px;"></th>
                            <th style="width: 5%;  text-align: left; padding:1px;"></th>
                            <th style="width: 36%; text-align: left; padding:1px;">စုစုပေါင်း </th>
                            <th style="width: 12%; text-align: center; padding-right:15px;">........&ensp;ကျပ်</th>
                            <th style="width: 22%; text-align: right; padding-right:35px; border-bottom: 1.5px solid #121212;" ><?php echo htmlspecialchars($total_relief); ?></th>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn px-4" onclick="window.print()" 
                        style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                    <i class="fa fa-print"></i> Print ထုတ်မည်
                </button>
                <button type="button" class="btn px-4" 
                        onclick="window.location.href='../IT_demand_list.php?openModal=formsModal2';" 
                        style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                    ပိတ်မည်
                </button>
            </div>
        </div>
    </div>
</div>

<script>

// PHP မှ bank_township value ကို JS variable ထဲ ထည့်ခြင်း
const phpBankTownship = "<?php echo $bank_township; ?>";

// စာမျက်နှာ Load ဖြစ်ချိန်တွင် လိုအပ်သည်များ ဆောင်ရွက်ရန်
document.addEventListener("DOMContentLoaded", function() {
    console.log("Form loaded successfully.");
});

// ပိတ်မည် ခလုတ်အတွက် သေချာပေါက် အလုပ်လုပ်မည့် Function
function closeAndReturnToDemandList() {
    // စာမျက်နှာဟောင်း (သို့) Demand List စာမျက်နှာသို့ တိုက်ရိုက်ပြန်သွားရန်
    window.location.href = '../IT_demand_list.php';
}
</script>