<?php
// ၁။ Session စတင်ခြင်း နှင့် Error အားလုံးကို Browser တွင် ပေါ်အောင် ဖွင့်ပေးခြင်း
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ db_config.php ချိတ်ဆက်မှုကို စစ်ဆေးခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}

if (!isset($conn)) {
    die("Database Connection Error: \$conn variable is not defined.");
}
$conn->set_charset("utf8mb4");

// ၃။ Login User ၏ အချက်အလက်များ ဆွဲထုတ်ခြင်း
$os_md_no = '............'; 
$os_bank_township = '............'; 
$session_user = $_SESSION['user_id'] ?? $_SESSION['username'] ?? '';

if (!empty($session_user)) {
    $user_stmt = $conn->prepare("SELECT md_no, bank_township FROM user_register WHERE id = ? LIMIT 1");
    if ($user_stmt) {
        $user_stmt->bind_param("s", $session_user);
        $user_stmt->execute();
        $user_res = $user_stmt->get_result();
        if ($user_res && $user_res->num_rows > 0) {
            $user_row = $user_res->fetch_assoc();
            if (!empty($user_row['md_no'])) $os_md_no = htmlspecialchars($user_row['md_no']);
            if (!empty($user_row['bank_township'])) $os_bank_township = htmlspecialchars($user_row['bank_township']);
        }
        $user_stmt->close();
    }
}

// ၄။ URL ID မှ ဒေတာဆွဲထုတ်ခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    $query = "SELECT * FROM regular_data WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ဂဏန်းကို မြန်မာဂဏန်းပြောင်းရန် Function (လိုအပ်ပါက သုံးရန်)
if (!function_exists('toMMNum')) {
function toMMNum($num, $showComma = true) {
    if ($num === null || $num === '' ) return '၀';
    $mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
    $s = $showComma ? number_format($num) : (string)$num;
    return preg_replace_callback('/\d/', function($matches) use ($mDigits) {
        return $mDigits[$matches[0]];
    }, $s);
}
}

// မြန်မာစာသားပြောင်းရန် Function 
if (!function_exists('numToMyanmarText')) {
function numToMyanmarText($number) {
    if (!$number) return "သုည";
    $digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
    $units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
    $numStr = (string)floor($number);
    $result = "";
    $len = mb_strlen($numStr);
    for ($i = 0; $i < $len; $i++) {
        $digit = intval(mb_substr($numStr, $i, 1));
        $unitIndex = $len - $i - 1;
        if ($digit !== 0) {
            $result .= $digits[$digit] . $units[$unitIndex];
        }
    }
    return $result;
}
}

// ဒေတာများ ထည့်သွင်းခြင်း
$tax_year     = $db_data['taxYear'] ?? '';
$taxpayer_name = $db_data['taxpayer_name'] ?? '-';
$address      = $db_data['address'] ?? '-';
$township     = $db_data['township_name'] ?? '-';
$it_full      = ($db_data['it_no'] ?? '') . "/" . ($db_data['it_select'] ?? '');
$final_balance = $db_data['finalBalanceTax'] ?? 0;
$net_profit   = $db_data['netProfit'] ?? 0;
$biz_type1    = $db_data['businessType1'] ?? '-';
$panaty       = $db_data['itpanaty'] ?? 0;
$taxpanaty    = $db_data['taxpanaty'] ?? 0;
$DemandNo    = $db_data['itDemandNo'] ?? 0;

// သက်သာခွင့်များ
$basic_relief   = $db_data['basicRelief'] ?? 0;
$spouse_relief  = $db_data['spouse_relief'] ?? 0;
$parent_relief  = $db_data['parent_relief'] ?? 0;
$child_relief   = $db_data['child_relief'] ?? 0;
$total_relief   = $db_data['totalRelief'] ?? 0;
$taxable_income = $db_data['finalTaxableIncome'] ?? 0;
$income_tax     = $db_data['payableIncomeTax'] ?? 0;
$advance_tax    = $db_data['advancePaidTax'] ?? 0;

// နှစ်အပိုင်းအခြား တွက်ချက်ခြင်း
$years = explode('-', $tax_year);
$start_p_year = count($years) === 2 ? toMMNum(intval($years[0]) - 1, false) : '-';
$end_p_year   = count($years) === 2 ? toMMNum(intval($years[1]) - 1, false) : '-';

$os_terget_date = '............';
if (!empty($db_data['itDemandDate']) && $db_data['itDemandDate'] !== '0000-00-00' && strtotime($db_data['itDemandDate'])) {
    $os_terget_date = date('d-m-Y', strtotime($db_data['itDemandDate'] . ' + 14 days'));
}
?>
<style>
    /* Modal Layout ပိုင်း သန့်စင်ခြင်း */
    #formgeneral2Modal .modal-dialog {
        max-width: 810px !important; 
        width: 95% !important;
        margin: 20px auto !important;
    }

    #formgeneral2Modal .modal-content {
        background-color: #9ecaeb !important; 
        border: 1.5px solid #404446 !important;
        border-radius: 6px !important;
        overflow: hidden !important;
    }

    #formgeneral2Modal .modal-body {
        padding: 15px !important; 
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important; 
    }

    /* 🎯 စာရွက်ပုံစံ Container (A4 Size အချိုးအစား ကွက်တိဖြစ်စေရန်) */
    .print-container { 
        background: #ffffff !important;
        width: 100% !important;
        max-width: 210mm !important; 
        min-height: 297mm !important; 
        padding: 10mm 15mm !important; 
        box-sizing: border-box !important; 
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.4) !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: space-between !important; 
    }

    /* 🎯 အပေါ်/အောက် ဖြတ်ပိုင်းတစ်ခုချင်းစီ၏ ဘောင်ခတ်မှု */
    .outer-border-box {
        border: 2px solid #000000 !important;
        padding: 15px 10px !important; 
        box-sizing: border-box !important;
        width: 100% !important;
        height: 132mm !important; 
        position: relative !important;
    }

    /* ဇယားများဆိုင်ရာ Style */
    .inner-data-table {
        width: 100% !important;
        border-collapse: collapse !important;
        font-family: "Pyidaungsu", "Segoe UI" !important;
        font-size: 14px !important;
    }

    #formgeneral2Modal .inner-data-table {
        table-layout: fixed !important;
    }

    #formgeneral2Modal .inner-data-table > tbody > tr > td:nth-child(1),
    #formgeneral2Modal .inner-data-table > tr > td:nth-child(1) {
        width: 36% !important;
    }

    #formgeneral2Modal .inner-data-table > tbody > tr > td:nth-child(2),
    #formgeneral2Modal .inner-data-table > tr > td:nth-child(2) {
        width: 5% !important;
        text-align: center !important;
    }

    #formgeneral2Modal .inner-data-table > tbody > tr > td:nth-child(3),
    #formgeneral2Modal .inner-data-table > tr > td:nth-child(3) {
        width: 59% !important;
    }

    .inner-data-table td {
        padding: 4px 3px !important;
        vertical-align: middle !important;
    }

    /* အောက်ခြေ လက်မှတ်ဇယားကွက် */
    .signature-table {
        width: 100% !important;
        border-collapse: collapse !important;
    }

    .signature-table td {
        padding: 3px !important;
    }

    /* 🎯 စာသားအောက်က အစက်လိုင်း (...) သတ်မှတ်ချက် */
    .under-line2 { 
        border-bottom: 1.5px dotted #121212 !important; 
        display: inline-block !important; 
        min-width: 100% !important;
        padding-left: 5px !important;
    }
    .no-print-bottoms {
    display: flex !important;
    justify-content: right !important;    
    gap: 15px !important;
    margin-top: 0px !important;    
    margin-bottom: 30px !important;
    width: 100% !important;
}

.no-print-bottoms .btn {
    font-size: 16px !important;         
    font-weight: bold !important;     
    padding: 10px 24px !important;    
    border-radius: 5px !important;    
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important; 
    transition: all 0.2s ease-in-out !important;
}

.no-print-bottoms .btn:hover {
    transform: translateY(-1.5px) !important; 
    box-shadow: 0 6px 11.5px rgba(0, 0, 0, 0.2) !important;
}

#formgeneral2Modal .modal-header {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    background-color: #55bbee !important; /* လိုအပ်ပါက အရောင်ဆက်ထားရန် */
}
    /* ===== 🎯 ၂။ PRINT ထုတ်သည့်အခါ Layout အတိုင်း A4 Portrait ကွက်တိဖြစ်စေမည့် CSS ===== */
@media print {
    @page {
        size: A4 portrait !important;
        margin: 0 !important;
    }

    body:has(#formgeneral2Modal.show) > *:not(#formgeneral2Modal) {
        display: none !important;
    }

    #formgeneral2Modal {
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        width: 210mm !important;
        max-width: 210mm !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        overflow: hidden !important;
    }

    #formgeneral2Modal .modal-dialog,
    #formgeneral2Modal .modal-content,
    #formgeneral2Modal .modal-body {
        position: static !important;
        width: 210mm !important;
        max-width: 210mm !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        border: none !important;
        box-shadow: none !important;
    }

    #formgeneral2Modal #printableSheet {
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 210mm !important;
        max-width: 210mm !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 8mm 12mm 4mm 22mm !important;
        background: #ffffff !important;
        box-sizing: border-box !important;
        display: block !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
    }

    #formgeneral2Modal .print-container {
        width: 100% !important;
        max-width: 100% !important;
        min-height: 0 !important;
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
        box-shadow: none !important;
        display: block !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
    }

    #formgeneral2Modal .outer-border-box {
        height: 136mm !important;
        max-height: 136mm !important;
        margin: 0 0 4mm 0 !important;
        border: 1.5px solid #000000 !important;
        page-break-inside: avoid !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
        box-sizing: border-box !important;
        overflow: hidden !important;
    }

    #formgeneral2Modal .outer-border-box:last-child {
        margin-bottom: 0 !important;
    }

    #formgeneral2Modal,
    #formgeneral2Modal #printableSheet,
    #formgeneral2Modal #printableSheet * {
        visibility: visible !important;
    }

    #formgeneral2Modal .no-print,
    #formgeneral2Modal .modal-header,
    #formgeneral2Modal .modal-footer {
        display: none !important;
    }
}
</style>

<div class="modal fade" id="formgeneral2Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h4 class="modal-title">အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း ထုတ်ယူရန်</h4>
                <button type="button" class="close-modal-btn no-print" onclick="closeFormgeneral2()" style="background: none; border: none; color: #ff4d4d; font-size: 26px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            
            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    
                    <div class="outer-border-box">
                        <div style="text-align: right; font-size:15px; font-family: 'Pyidaungsu'; margin-bottom: 5px;">
                            ပတခ(ထွေ)-၂
                        </div>
                        <div style="text-align: center; font-weight: bold; font-size: 18px; font-family: 'Pyidaungsu'; margin-bottom: 20px;">
                            အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                        </div>
                        
                        <table class="inner-data-table">
                            <tr>
                                <td>အခွန်ထမ်းအမည်</td>
                                <td>-</td>
                                <td><span class="under-line2" id="general_name"><?php echo htmlspecialchars($taxpayer_name); ?></span></td>
                            </tr>
                            <tr>
                                <td>လုပ်ငန်းအမျိုးအစား</td>
                                <td>-</td>
                                <td><span class="under-line2" id="general_businessType1"><?php echo htmlspecialchars($biz_type1); ?></span></td>
                            </tr>
                            <tr>
                                <td>အခွန်ထမ်းလိပ်စာ</td>
                                <td>-</td>
                                <td><span class="under-line2" id="general_address"><?php echo htmlspecialchars($address); ?></span></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align: center; font-weight: bold; padding: 15px 0 !important; font-size:15px;">
                                    လက်ခံရရှိပါသည်။
                                </td>
                            </tr>
                            <tr>
                                <td>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ကသခ)-၀၄-၀၈/ ပတခ(ကသခ)-၀၂-၀၁</span>
                                </td>
                            </tr>
                            <tr>
                                <td>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ဝင)-၀၄-၀၈ / ပတခ(ဝင)-၀၂-၀၁(ခ)</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အခြားအကြောင်းကြားစာများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">&ensp;</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td style="padding-top: 10px !important;">
                                    <table class="signature-table">
                                        <tr>
                                            <td style="width: 30%; text-align: right; padding-right: 15px;">လက်မှတ်</td>
                                            <td style="width: 70%; border-bottom: 1.5px dotted black !important;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">အမည်</td>
                                            <td style="border-bottom: 1.5px dotted black !important;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">ရက်စွဲ</td>
                                            <td style="border-bottom: 1.5px dotted black !important;"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                    <div class="outer-border-box">
                        <div style="text-align: right; font-size:15px; font-family: 'Pyidaungsu'; margin-bottom: 5px;">
                            ပတခ(ထွေ)-၂
                        </div>
                        <div style="text-align: center; font-weight: bold; font-size: 18px; font-family: 'Pyidaungsu'; margin-bottom: 20px;">
                            အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                        </div>
                        
                        <table class="inner-data-table">
                            <tr>
                                <td>အခွန်ထမ်းအမည်</td>
                                <td>-</td>
                                <td><span class="under-line2" id="general_name1"><?php echo htmlspecialchars($taxpayer_name); ?></span></td>
                            </tr>
                            <tr>
                                <td>လုပ်ငန်းအမျိုးအစား</td>
                                <td>-</td>
                                <td><span class="under-line2" id="general_businessType2"><?php echo htmlspecialchars($biz_type1); ?></span></td>
                            </tr>
                            <tr>
                                <td>အခွန်ထမ်းလိပ်စာ</td>
                                <td>-</td>
                                <td><span class="under-line2" id="general_address1"><?php echo htmlspecialchars($address); ?></span></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align: center; font-weight: bold; padding: 15px 0 !important; font-size:15px;">
                                    လက်ခံရရှိပါသည်။
                                </td>
                            </tr>
                            <tr>
                                <td>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ကသခ)-၀၄-၀၈/ ပတခ(ကသခ)-၀၂-၀၁</span>
                                </td>
                            </tr>
                            <tr>
                                <td>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ဝင)-၀၄-၀၈ / ပတခ(ဝင)-၀၂-၀၁(ခ)</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အခြားအကြောင်းကြားစာများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">&ensp;</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td style="padding-top: 10px !important;">
                                    <table class="signature-table">
                                        <tr>
                                            <td style="width: 30%; text-align: right; padding-right: 15px;">လက်မှတ်</td>
                                            <td style="width: 70%; border-bottom: 1.5px dotted black !important;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">အမည်</td>
                                            <td style="border-bottom: 1.5px dotted black !important;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">ရက်စွဲ</td>
                                            <td style="border-bottom: 1.5px dotted black !important;"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                </div>
            </div>
            
           <div class="no-print-bottoms no-print">
                <button type="button" class="btn px-4" onclick="window.print()" 
                        style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                    <i class="fa fa-print"></i> Print ထုတ်မည်
                </button>
                <button type="button" class="btn px-4" 
                onclick="closeFormgeneral2()" 
                        style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                    ပိတ်မည်
                </button>
             
            </div>
        </div>
    </div>
</div>

<script>

function closeFormgeneral2() {
    var inFormsFolder = window.location.pathname.toLowerCase().indexOf('/forms/') !== -1;
    window.location.href = (inFormsFolder ? '../' : '') + 'IT_Demand_List.php';
}

function openFormgeneral2() {
    console.log("Selected Row Data:", selectedRowData);
    
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("Table ထဲမှ row ကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    try {
    // ၁။ မြန်မာဂဏန်းပြောင်းလဲခြင်း
    const toMM = (num, showComma = true) => {
        if (num === null || num === undefined || num === "") return '၀';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        let s = showComma ? Number(num).toLocaleString() : num.toString(); 
        return s.replace(/\d/g, d => mDigits[d]);
    };

    // ၂။ ဂဏန်းမှ မြန်မာစာသားသို့ ပြောင်းလဲခြင်း
    const numberToMyanmarText = (number) => {
        if (number === 0 || !number) return "သုည";
        const digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
        const units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
        let numStr = Math.floor(number).toString();
        let result = "";
        let len = numStr.length;
        for (let i = 0; i < len; i++) {
            let digit = parseInt(numStr[i]);
            let unitIndex = len - i - 1;
            if (digit !== 0) {
                result += digits[digit] + units[unitIndex];
            }
        }
        return result;
    };

    const setText = (id, val, isNum = false, showComma = true) => {
        const el = document.getElementById(id);
        if (el) el.innerText = isNum ? toMM(val, showComma) : (val || '-');
    };

    // --- Data ထည့်သွင်းခြင်း ---
    
    if (selectedRowData.taxYear) {
        setText('general_taxYear', toMM(selectedRowData.taxYear, false));
    }

    // ရက်စွဲတွက်ချက်ခြင်း (Bracket သေချာပြန်ပိတ်ထားသည်)
    if (selectedRowData.itDemandDate) {
        const d = new Date(selectedRowData.itDemandDate);
        
        // PHP Variable များကို ဤနေရာတွင် တိုက်ရိုက်မသုံးဘဲ HTML element ရှိလျှင် ထည့်ပေးပါ
        if(document.getElementById('user_bank_township')) {
            document.getElementById('user_bank_township').innerText = typeof phpBankTownship !== 'undefined' ? phpBankTownship : '';
        }

        d.setDate(d.getDate() + 14); 
        const day = toMM(d.getDate(), false);
        const month = toMM(d.getMonth() + 1, false);
        const year = toMM(d.getFullYear(), false);
        setText('general_demandDate', day + "-" + month + "-" + year);
    } // <--- ဒီနားမှာ bracket ကျန်ခဲ့တာပါ

    // အမည်နှင့် လိပ်စာ
    setText('general_name', selectedRowData.taxpayer_name);
    setText('general_address', selectedRowData.address);
    setText('general_businessType1', selectedRowData.businessType1);

    setText('general_name1', selectedRowData.taxpayer_name);
    setText('general_address1', selectedRowData.address);
    setText('general_businessType2', selectedRowData.businessType1);

    // ငွေကြေးဆိုင်ရာများ
    const totalAmount = selectedRowData.taxpanaty || 0;
    setText('general_taxTextMM', numberToMyanmarText(totalAmount));
    setText('general_incomeTax', selectedRowData.payableIncomeTax, true);
    } catch (err) {
        console.error(err);
    }

    if (typeof presentFormModal === 'function') {
        presentFormModal('formgeneral2Modal');
    } else {
        var modalElem = document.getElementById('formgeneral2Modal');
        if (modalElem) {
            var myModal = bootstrap.Modal.getOrCreateInstance(modalElem);
            myModal.show();
        }
    }
}
</script>