<style>
/* 🖥️ SCREEN VIEW & MODAL FIXES */
#orderSheetModal .modal-dialog {
    max-width: 820px !important;
    width: 100%;
    margin: 10px auto;
}

.print-container { 
    background: #ffffff;
    width: 100%;
    margin: 0 auto !important;
    padding: 0px !important;
    box-sizing: border-box !important;
}

/* Layout သာ။ Print အနားသတ်ကို မထိပါ။ */
@media screen {
    #orderSheetModal .modal-body {
        padding-left: 6px !important;
        padding-right: 6px !important;
    }

    #orderSheetModal #printableSheet,
    #orderSheetModal .print-container {
        width: 100% !important;
        max-width: none !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 8px 2px 12px !important;
        box-sizing: border-box !important;
    }
}

/* 📊 MAIN TABLE STYLES */
.main-content-table2 {
    width: 100% !important;
    border-collapse: collapse;
    font-size: 15px;
}

.main-content-table2 td {
    padding: 4px 2px;
}

.main-content-table {
    width: 100% !important;
    border-collapse: collapse;
    table-layout: fixed;
    border: 2px solid #000 !important;
}

.main-content-table thead th {
    background-color: #c1d3ef !important;
    border: 1px solid #000 !important;
    border-bottom: 2px solid #000 !important;
    padding: 8px 4px;
    font-size: 15px;
    font-weight: bold;
}

.main-content-table > tbody > tr > td {
    border-right: 1px solid #000 !important;
    border-left: 1px solid #000 !important;
    border-top: none !important;
    border-bottom: none !important;
    padding: 3px 3px;
    vertical-align: top;
    font-size: 14.5px;
    line-height: 1.5;
}

.main-content-table > tbody > tr:last-child > td {
    border-bottom: 2px solid #000 !important;
}

/* Hide only the outer left and right lines. The two inner column lines stay. */
.main-content-table {
    border-left: none !important;
    border-right: none !important;
}

.main-content-table thead tr > th:first-child,
.main-content-table > tbody > tr > td:first-child {
    border-left: none !important;
}

.main-content-table thead tr > th:last-child,
.main-content-table > tbody > tr > td:last-child {
    border-right: none !important;
}

/* 🧮 CALCULATION TABLE */
.calculation-table {
    width: 100% !important;
    border-collapse: collapse !important;
    border: none !important;
    margin: 5px 0;
}

.calculation-table tr, 
.calculation-table td,
.main-content-table td .calculation-table td {
    border-top: none !important;
    border-bottom: none !important;
    border-left: none !important;
    border-right: none !important;
    outline: none !important;
    padding: 2px 2px !important;
    font-size: 14.5px;
}

/* Underlines အတွက် သီးသန့် Border များ */
.border-b-single {
    border-bottom: 1px solid #000 !important;
}
.border-b-double {
    border-bottom: 3px double #000 !important;
}

/* 🖨️ FINAL PRINT FIXES */
@media print {
    /* Real A4: 210mm x 297mm. Margins must be positive or the browser drops them. */
    @page {
        size: A4 portrait;
        margin: 10mm 12mm 10mm 12mm;
    }

    html, body {
        width: auto !important;
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        overflow: visible !important;
    }

    /* Stay at the top of the A4 sheet, but never wider than the page content box. */
    #orderSheetModal,
    #orderSheetModal .modal-dialog,
    #orderSheetModal .modal-content,
    #orderSheetModal .modal-body,
    #printableSheet,
    #printableSheet .print-container {
        width: 100% !important;
        max-width: 100% !important;
        height: auto !important;
        margin: 0 !important;
        padding-left: .5mm !important;
        padding-right: .5mm !important;
        border: none !important;
        box-shadow: none !important;
        box-sizing: border-box !important;
        overflow: visible !important;
        transform: none !important;
    }

    #orderSheetModal,
    #printableSheet {
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
    }

    body * { 
        visibility: hidden !important; 
    }

    .modal-header, .modal-footer, .no-print, .btn, .btn-close { 
        display: none !important; 
    }

    #printableSheet, #printableSheet * { 
        visibility: visible !important; 
    }

    /* ၁။ ခေါင်းစဉ် — A4 အတွင်းမှာပဲ ထားရန်၊ အပေါ် 50px မတွန်းတော့ပါ */
    #printableSheet h6,
    #printableSheet h3,
    #printableSheet .sheet-title,
    #printableSheet .title-container {
        margin-top: 0 !important;
        margin-bottom: 8px !important;
        text-align: center !important;
        font-size: 18px !important;
        line-height: 1.5 !important;
        
    }

    /* ==========================================
        ၂။ အထက်ပိုင်း TABLE BORDERS FIX
       ========================================== */
    #printableSheet table.main-content-table2 {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border-collapse: collapse !important;
        border: none !important;
    }

    #printableSheet table.main-content-table2 td {
        border: none !important;
    }

    #printableSheet table.main-content-table2 td[style*="dotted"],
    #printableSheet table.main-content-table2 td .dotted-border {
        border-left: none !important;
        border-right: none !important;
        border-top: none !important;
        border-bottom: 1.5px dotted #000 !important;
    }

    #printableSheet table.main-content-table2 tr td:nth-last-child(2),
    #printableSheet table.main-content-table2 tr td:nth-last-child(3) {
        border: 1.5px dotted #000 !important;
    }

    /* ==========================================
        ၃။ အောက်ပိုင်း MAIN TABLE (ပင်မ Table ကြီး)
       ========================================== */
    #printableSheet table.main-content-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border-collapse: separate !important;
        border-spacing: 0 !important;
        border-top: 1px solid #000 !important;
        border-bottom: 1px solid #000 !important;
        border-left: none !important;
        border-right: none !important;
        margin-top: 8px !important;
    }
/*လေးလိုင်းနှစ်ဖက်*/
    #printableSheet table.main-content-table > tbody > tr > td,
    #printableSheet table.main-content-table > thead > tr > th {
        border-left: .01px solid #000 !important;
        border-right: .01px solid #000 !important;
        border-top: none !important;
        border-bottom: none !important;
        box-sizing: border-box !important;
    }

    #printableSheet table.main-content-table thead th {
        border-bottom: 1px solid #000 !important;
        background-color:rgb(216, 226, 242) !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        font-size: 12px !important;
    }

    /* Outer Table Border Overrides (ဘယ်/ညာ အစွန်းလိုင်းများ) */
    #printableSheet table.main-content-table tr > td:first-child,
    #printableSheet table.main-content-table thead tr > th:first-child {
        border-left: none !important;
    }

    #printableSheet table.main-content-table tr > td:last-child,
    #printableSheet table.main-content-table thead tr > th:last-child {
        border-right: none !important;
    }

    #printableSheet table.main-content-table tr {
        page-break-inside: avoid !important;
    }

    /* ==========================================
        ၄။ TD အထဲမှ NESTED TABLE (တွက်ချက်မှုဇယား)
       ========================================== */
    #printableSheet table.main-content-table td table,
    #printableSheet table.calculation-table,
    #printableSheet .calculation-table {
        width: 100% !important;
        margin: 10px auto !important;
        border-collapse: collapse !important;
        border: none !important;
    }

    /* Calculation Table ထဲမှ TD, TH အားလုံး၏ ဘေးလိုင်းများကို အကဲဆတ်စွာ ဖျောက်ခြင်း */
    #printableSheet table.main-content-table td table td,
    #printableSheet table.main-content-table td table th,
    #printableSheet table.calculation-table td,
    #printableSheet table.calculation-table th,
    #printableSheet .calculation-table td,
    #printableSheet .calculation-table th {
        border-left: none !important;
        border-right: none !important;
        border-top: none !important;
        border-bottom: none !important;
        padding: 3px 8px !important;
    }

    /* Single / Double Bottom Border များကို သီးသန့်ပြန်ဖော်ပေးခြင်း */
    #printableSheet .calculation-table td.border-b-single,
    #printableSheet td.border-b-single {
        border-bottom: 1.5px solid #000 !important;
    }

    #printableSheet .calculation-table td.border-b-double,
    #printableSheet td.border-b-double {
        border-bottom: 1px double #000 !important;
    }

    /* Print font 16px (12pt) with wider line spacing */
    #printableSheet,
    #printableSheet td,
    #printableSheet th,
    #printableSheet p,
    #printableSheet span,
    #printableSheet div,
    #printableSheet table.main-content-table2,
    #printableSheet table.main-content-table2 td,
    #printableSheet table.main-content-table th,
    #printableSheet table.main-content-table td,
    #printableSheet .calculation-table,
    #printableSheet .calculation-table td,
    #printableSheet .calculation-table span,
    #printableSheet .print-container > div > p {
        font-size: 14px !important;
        line-height: 1.7 !important;
    }

    #printableSheet h6 {
        font-size: 14px !important;
        line-height: 1.5 !important;
    }
}
</style>

<div class="modal fade" id="orderSheetModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <!-- Modal Header (Web view) -->
                <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 20px;">
                    <h5 class="modal-title" style="font-size: 16px; font-weight: bold; margin: 0; color: white;">
                        အမိန့်စာချပ် ထုတ်ယူရန် (Order Sheet)
                    </h5>
                    <button type="button" class="close-modal-btn" onclick="window.location.href='IT_Demand_List.php';" style="background: none; border: none; color:rgb(235, 20, 77); font-size: 40px; cursor: pointer; line-height: 1;">
                        ×
                    </button>
                </div>
                
                <!-- Printable Content Area -->
                <div id="printableSheet">
                    <div class="print-container">
                        <div style="text-align: center; margin-bottom: 15px;">
                            <br>
                            <h6 style="font-weight: bold; font-size: 20px; margin-bottom: 3px;">အမိန့်စာချပ်</h6>
                            <p style="font-weight: bold; font-size: 15px; margin: 0;">(အထွေထွေအမှုတွဲဖိုင်အတွက်အသုံးပြုရန်)</p>
                        </div>

                        <!-- Top Info Table -->
                        <table class="main-content-table2" style="margin-bottom: 12px;">
                            <tr>
                                <td style="width:17%; "><b style="padding-left: 5px;">မြို့နယ်ရုံးအမည်</b></td>
                                <td style="width:2%;"><b>-</b></td>
                                <td style="width:48%; border-bottom: 1.5px dotted #000;"><span id="os_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး</td>
                                <td style="width:2%;"></td>
                                <td style="width:14%; border: 0px dotted #000; text-align:right; padding-right: 5px;"><b>စည်းကြပ်နှစ်:</b></td>
                                <td style="width:16%; border: 1.5px dotted #000; text-align:center;"><span id="os_year"></span></td>
                                <td style="width:1%; "></td>
                            </tr>
                            <tr>
                                <td><b style="padding-left: 5px;">အခွန်ထမ်းအမည်</b></td>
                                <td><b>-</b></td>
                                <td style="border-bottom: 2px dotted #000;"><span id="os_name"></span> ( <span id="os_nrc"></span> )၊ 
                                ( <span id="os_phone"></span> )</td>
                                <td></td>
                                <td style="border: 0px dotted #000; text-align:right; padding-right: 5px;"><b>GIR-No:</b></td>
                                <td style="border: 1.5px dotted #000; text-align:center;"><span id="os_gir"></span></td>
                                <td ></td>
                            </tr>
                            <tr>
                                <td><b style="padding-left: 5px;">အခွန်ထမ်းလိပ်စာ</b></td>
                                <td><b>-</b></td>
                                <td style="border-bottom: 1.5px dotted #000;"><span id="os_address"></span></td>
                                <td></td>
                                <td style="border: 0px dotted #000; text-align:right; padding-right: 5px;"><b>အခွန်မှူး:</b></td>
                                <td style="border: 1.5px dotted #000; text-align:center;"><span id="os_officer"></span></td>
                                <td ></td>
                            </tr>
                            <tr>
                                <td><b style="padding-left: 5px;">လုပ်ငန်းအမျိုးအစား</b></td>
                                <td><b>-</b></td>
                                <td style="border-bottom: 1.5px dotted #000;"><span id="os_biz"></span></td>
                                <td></td>
                                <td style="border: 0px dotted #000; text-align:right; padding-right: 5px;"><b>ရာထူး:</b></td>
                                <td style="border: 1.5px dotted #000; text-align:center;"><span id="os_rank"></span></td>
                                <td ></td>
                            </tr>
                        </table>

                        <!-- Main Table -->
                        <table class="main-content-table">
                            <thead>
                                <tr>
                                    <th style="width: 15%; border-top:1px solid !important; border-bottom:1px solid !important; font-size: 12px;">ဆောင်ရွက်<br>သည့်နေ့စွဲ</th>
                                    <th style="width: 70%; border-top:1px solid !important; border-bottom:1px solid !important; ">လုပ်ငန်းအကြောင်းအရာအကျဉ်းချုပ်</th>
                                    <th style="width: 15%; border-top:1px solid !important; border-bottom:1px solid !important; font-size: 12px;">လိုက်နာဆောင်<br>ရွက်သည့်နေ့</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td style="text-align: center;">................</td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">အခွန်ထမ်းသည် ဝင်ငွေနှစ်အတွင်း ဝင်ငွေခွန်ကြိုတင်ခွန်(3,000,000)ကျပ်ပေးသွင်းထားပါသည်။ / မပေးသွင်းထားပါ။</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 35px;">စာရေးကြီး</div>
                                    </td>
                                    <td style="text-align: center;"></td>
                                </tr>

                                <tr>
                                    <td style="text-align: center;">................</td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">အခွန်ထမ်းသည် ဝင်ငွေနှစ်အတွင်း ဝင်ငွေကြေညာလွှာကို (................)ရက်နေ့တွင် 
                                            ဝင်စာ မှတ်ပုံတင်အမှတ်(......)ဖြင့် အချိန်မီတင်သွင်းထားပါသည်။/(အချိန်မီတင်သွင်းထားခြင်းမရှိပါ။)</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 40px;">စာရေးကြီး</div>
                                    </td>
                                    <td style="text-align: center;"></td>
                                </tr>

                                <tr>
                                    <td style="text-align: center;"><span class="os_orderDate_class"></span></td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">အခွန်ထမ်းအား ကြားနာစစ်ဆေးရန် ပတခ(ဝင)-၀၄-၀၅ဖြင့် အကြောင်းကြားစာထုတ်ဆင့်ပါ။</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 40px;">အခွန်မှူး</div>
                                    </td>
                                    <td style="text-align: center;"><span class="os_appointmentDate_class"></span> ချိန်း</td>
                                </tr>

                                <tr>
                                    <td style="text-align: center;"><span class="os_visitedDate_class"></span></td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">အခွန်ထမ်း/ကိုယ်စားလှယ် လာရောက်သဖြင့် တင်ပြချက်များနှင့် ထွက်ဆိုချက်များကို မှတ်တမ်း တင်သည်။</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 35px;">အခွန်မှူး</div>
                                    </td>
                                    <td style="text-align: center;"></td>
                                </tr>

                                <tr>
                                    <td style="text-align: center;"><span class="os_itDemandDate_class"></span></td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">အခွန်ထမ်းတင်ပြသော ဝင်ငွေကြေညာလွှာ၊ ပတ်ဝန်းကျင်အထောက်အထားများကို ကိုးကား၍ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၂၀၊ ၆၄ တို့အရ အောက်ပါအတိုင်းစည်းကြပ်မှုအမိန့် ချမှတ်လိုက်သည်-</p>
                                    
                                    
                                        <table class="calculation-table">
                                            <tr>
                                                <td style="width:60%; text-align:right;">အသားတင်အမြတ်</td>
                                                <td style="width:5%; text-align:center;">=</td>
                                                <td style="width:20%; text-align:right;" id="os_profit"></td>
                                                <td style="width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;">ကျသင့်ဝင်ငွေခွန်</td>
                                                <td style="text-align:center;">=</td>
                                                <td style="text-align:right;" id="os_income_tax"></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;">ပေးသွင်းထားသောကြိုတင်ခွန်</td>
                                                <td style="text-align:center;">=</td>
                                                <td style="text-align:right; border-bottom: 1.5px solid #000 !important;" class="border-b-single" id="os_advance"></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;">ထပ်မံပေးဆောင်ရမည့်ဝင်ငွေခွန်</td>
                                                <td style="text-align:center;">=</td>
                                                <td style="text-align:right;" id="os_balance"></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right;">ဒဏ်ကြေးငွေ</td>
                                                <td style="text-align:center;">=</td>
                                                <td style="text-align:right; border-bottom: 1.5px solid #000 !important;" class="border-b-single" id="os_penalty"></td>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <td style="text-align:right; font-weight: bold;">ပေးဆောင်ရန် အခွန်+ဒဏ်ကြေး</td>
                                                <td style="text-align:center; font-weight: bold;">=</td>
                                                <td style="text-align:right; font-weight: bold;" class="border-b-double" id="os_total_all"></td>
                                                <td></td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td style="text-align: center;">CDN-<span class="os_itDemandNo_class"></span><br>                                   
                                    <span class="os_itDemandDate_class"></span></td>
                                </tr>

                                <tr>
                                    <td style="text-align: center;"><span class="os_itDemandDate_class"></span></td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">ကျသင့်အခွန်( <strong><span id="os_balance1"></span></strong> ) နှင့်ဒဏ်ငွေ 
                                        ( <strong><span id="os_penalty1"></span></strong> )ကို ( <span id="rq_date1"></span> )နေ့မတိုင်မီ ပေးဆောင် စေရန် ချလန်ထုတ်ဆင့်ပါ။</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 60px;">အခွန်မှူး</div>
                                    </td>
                                    <td style="text-align: center;"></td>
                                </tr>

                                <tr id="os_paid_row">
                                    <td style="text-align: center;"><span class="os_itchalanDate_class"></span></td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေ( <strong><span id="os_taxpanaty"></span></strong> )ကို 
                                        ( <span class="os_itchalanDate_class"></span> )ရက်နေ့တွင် 
                                            ချလန်အမှတ် ( <span class="os_itchalanNo_class"></span> ) ဖြင့် ပြေကြေစွာပေးသွင်းပြီး ဖြစ်ပါသဖြင့် အမှုပိတ်သိမ်းသည်။</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 60px;">အခွန်မှူး</div>
                                    </td>
                                    <td style="text-align: center;"></td>
                                </tr>
                                <tr id="os_unpaid_row">
                                    <td style="text-align: center;">................</td>
                                    <td style="text-align: justify;">
                                        <p style="margin:0;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေ( ............................ )ကို 
                                        ( ....................... )ရက်နေ့တွင် 
                                            ချလန်အမှတ် ( ................. ) ဖြင့် ပြေကြေစွာပေးသွင်းပြီး ဖြစ်ပါသဖြင့် အမှုပိတ်သိမ်းသည်။</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 60px;">အခွန်မှူး</div>
                                    </td>
                                    <td style="text-align: center;"></td>
                                </tr>  
                                <tr>
                                    <td style="text-align: center; padding-bottom: 20px;">................</td>
                                    <td style="text-align: justify; padding-bottom: 20px;">
                                        <p style="margin:0;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေကို စည်းကြပ်သည့်နှစ်အတွင်း ပေးသွင်းခြင်း မရှိသည့်အတွက် 
                                            အခွန်ကြွေးမှတ်ပုံတင်စာရင်းသို့ ကူးပြောင်းမှတ်တမ်းတင်သည်။</p>
                                        <div style="text-align: right; padding-right: 40px; margin-top: 60px;">အခွန်မှူး 
                                            <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br>
                                        </div>
                                    </td>
                                    <td style="text-align: center;"></td>
                                </tr>
                               
                            </tbody>  
                        </table>
                        
                    </div>
                </div>
            </div>

            <!-- Modal Footer (Web view) -->
            <div class="modal-footer no-print" style="padding: 10px 20px;">
                <button type="button" class="btn btn-primary" onclick="printOrderSheet()">
                    <i class="fa fa-print"></i> Print ထုတ်မည်
                </button>
                <button type="button" class="btn btn-secondary" onclick="window.location.href='IT_Demand_List.php';" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
// 1. Date Format ပြောင်းပေးသည့် Helper Function (DD-MM-YYYY)
function getFormattedDate(dateStr, addDays = 0) {
    if (!dateStr || dateStr === '0000-00-00') return '-';
    
    // JS Date Object Parse မမှားအောင် - များကို / ဖြင့် ခဏအစားထိုးသည်
    const cleanStr = String(dateStr).replace(/-/g, '/');
    const d = new Date(cleanStr);
    
    if (isNaN(d.getTime())) return dateStr;

    // ရက်ပေါင်း ထပ်တိုးရန်ရှိပါက တိုးပေးမည်
    if (addDays > 0) {
        d.setDate(d.getDate() + addDays);
    }

    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();

    return `${dd}-${mm}-${yyyy}`; // DD-MM-YYYY ပုံစံဖြင့် ပြန်ပေးမည်
}

function openFormordersheet() {
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
        return;
    }

    var data = selectedRowData;
    var userRank = "<?php echo $rank ?? ''; ?>";

    const updateText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.innerText = value || '-';
    };

    const formatVal = (val) => typeof formatNumber === 'function' ? formatNumber(val || 0) : (val || 0);

    // Basic Info
    updateText('os_township', data.township_name);
    updateText('os_name', data.taxpayer_name);
    updateText('os_nrc', data.nrc_no);
    updateText('os_address', data.address);
    updateText('os_phone', data.ph_no);
    updateText('os_email', data.email);
    updateText('os_biz', data.businessType1);
    updateText('os_year', data.taxYear);
    updateText('os_officer', data.officer_name);
    updateText('os_rank', userRank);
    updateText('os_gir', (data.it_no || '') + " / " + (data.it_select || 'စီးပွား'));

    // Financial Values
    updateText('os_profit', formatVal(data.netProfit));
    updateText('os_income_tax', formatVal(data.payableIncomeTax));
    updateText('os_advance', formatVal(data.advancePaidTax));
    updateText('os_balance', formatVal(data.finalBalanceTax));
    updateText('os_penalty', formatVal(data.itpanaty));
    updateText('os_total_all', formatVal(data.taxpanaty));
    updateText('os_taxpanaty', formatVal(data.taxpanaty));

    const paidAmount = parseFloat(data.taxpanatyPaid) || 0;
    const paidRow = document.getElementById('os_paid_row');
    const unpaidRow = document.getElementById('os_unpaid_row');
    if (paidRow) paidRow.style.display = paidAmount > 0 ? '' : 'none';
    if (unpaidRow) unpaidRow.style.display = paidAmount > 0 ? 'none' : '';

    updateText('os_balance1', formatVal(data.finalBalanceTax));
    updateText('os_penalty1', formatVal(data.itpanaty));

    // Demand No
    document.querySelectorAll('.os_itDemandNo_class').forEach(el => el.innerText = data.itDemandNo || '-');

    // 📅 DATES & 14-DAYS ADDITIONS (getFormattedDate သုံး၍ ပြင်ဆင်ထားပါသည်)
    

 

    // 1. Demand Date & rq_date1
    document.querySelectorAll('.os_itDemandDate_class').forEach(el => el.innerText = getFormattedDate(data.itDemandDate));
    updateText('rq_date1', getFormattedDate(data.itDemandDate, 14));

    // 2. Order Date & rq_date2
    document.querySelectorAll('.os_orderDate_class').forEach(el => el.innerText = getFormattedDate(data.orderDate));
    updateText('rq_date2', getFormattedDate(data.orderDate, 14));

    // 3. Appointment Date & rq_date3
    document.querySelectorAll('.os_appointmentDate_class').forEach(el => el.innerText = getFormattedDate(data.appointmentDate));
    updateText('rq_date3', getFormattedDate(data.appointmentDate, 14));

    // 4. Visited Date & rq_date4
    document.querySelectorAll('.os_visitedDate_class').forEach(el => el.innerText = getFormattedDate(data.visitedDate));
    updateText('rq_date4', getFormattedDate(data.visitedDate, 14));

    // 5. Challan date, chalan number, and tax + penalty
    document.querySelectorAll('.os_itchalanDate_class').forEach(el => el.innerText = getFormattedDate(data.itchalanDate));
    document.querySelectorAll('.os_itchalanNo_class').forEach(el => el.innerText = data.itchalanNo || '-');
    updateText('rq_date5', getFormattedDate(data.itchalanDate, 14));

    // Modal Control
    if (typeof hideFormsModal === 'function') {
        hideFormsModal();
    } else {
        var formsModalEl = document.getElementById('formsModal') || document.getElementById('caseFormsModal');
        if (formsModalEl && window.bootstrap && bootstrap.Modal) {
            var formsModal = bootstrap.Modal.getInstance(formsModalEl) || bootstrap.Modal.getOrCreateInstance(formsModalEl);
            formsModal.hide();
        }
    }

    setTimeout(function() {
        var orderModalEl = document.getElementById('orderSheetModal');
        if (orderModalEl) {
            var myModal = bootstrap.Modal.getInstance(orderModalEl) || new bootstrap.Modal(orderModalEl);
            myModal.show();
        }
    }, 150);
}

function printOrderSheet() {
    window.print();
}
</script>