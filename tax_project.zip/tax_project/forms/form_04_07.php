<?php
// ၁။ DB Config ချိတ်ဆက်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}

// ၂။ Data ဆွဲထုတ်ခြင်း
$row = []; // default တန်ဖိုး
if(isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "SELECT * FROM regular_data WHERE id = '" . mysqli_real_escape_string($conn, $id) . "'";
    $result = mysqli_query($conn, $query);
    $fetched = $result ? mysqli_fetch_assoc($result) : null;
    if (is_array($fetched)) {
        $row = $fetched;
    }
}

if (!function_exists('f0407')) {
    function f0407($key) {
        global $row;
        return htmlspecialchars((string)($row[$key] ?? ''), ENT_QUOTES, 'UTF-8');
    }
}

// ၃။ PHP Function (မြန်မာဂဏန်းပြောင်းရန်)
function toMM($number) {
    $en = ["0","1","2","3","4","5","6","7","8","9"];
    $mm = ["၀","၁","၂","၃","၄","၅","၆","၇","၈","၉"];
    return str_replace($en, $mm, $number);
}

// ၄။ Logic ခွဲထုတ်ခြင်း (PHP ဘက်မှာပဲ လုပ်ပါ)
$displayTaxYear = "";
$startYear = "";
$endYear = "";

if (!empty($row['taxYear'])) {
    $years = explode('-', $row['taxYear']);
    if (count($years) === 2) {
        $startYear = (int)$years[0] - 1; 
        $endYear = (int)$years[1] - 1;
        $displayTaxYear = toMM($startYear . "-" . $endYear);
    }
}
?>



<style>
/* Modal ဖွင့်ထားစဉ် အပြင်အဆင် */
#form0407Modal .modal-dialog {
    max-width: 210mm !important;
    margin: 30px auto;
}

#form0407Modal .modal-content { 
    background-color: #f8f9fa; /* Modal နောက်ခံ */
    border: none;
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
}

/* စာရွက်အစစ်ပုံစံ */
.print-container { 
    background: #ffffff;
    width: 210mm;
    min-height: 297mm;
    margin: 20px auto;
    padding: 5mm 10mm 20mm 25mm !important;
    box-sizing: border-box;
    box-shadow: 0 0 10px rgba(0,0,0,0.2);
}

.print-container,
.print-container p,
.print-container div,
.print-container table,
.print-container td,
.print-container th,
.print-container span {
    font-size: 15px;
}

.dashed-line { border-bottom: 1px dotted black !important; display: inline-block; }
.solid-line { border-bottom: 1px solid black !important; display: inline-block; }
.info-lines {
    width: 100% !important;
    table-layout: fixed;
}
.info-lines td:first-child { width: 7%; }
.info-lines td:nth-child(2) { width: 34%; }
.under-line {
    border-bottom: 1px dashed #0d0d0d !important;
    text-align: left;
    width: auto;
}
.calc-lines { width: 100% !important; table-layout: fixed; }
.calc-lines td:nth-child(1) { width: 55%; text-align: right; }
.calc-lines td:nth-child(2) { width: 5%; text-align: center; }
.calc-lines td:nth-child(3) { width: 15%; text-align: right; }
.calc-lines td:nth-child(4) { width: 25%; }

/* Print ထုတ်သည့်အခါ */


@media print {
    @page {
        size: A4;
        margin: 0mm; /* Browser ရဲ့ default margin ကို ဖြုတ်လိုက်တာပါ */
    }

    body {
        margin: 0 !important;
        padding: 0 !important;
    }

    /* စာရင်းဇယားက စာရွက်ကို မတွန်းအောင် ဖျောက်ပြီး ဖောင်ကို ထိပ်ကနေ စမည် */
    body:has(#form0407Modal.show) > *:not(#form0407Modal) {
        display: none !important;
    }

    #form0407Modal {
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        width: 210mm !important;
        max-width: 210mm !important;
        margin: 0 !important;
        padding: 0 !important;
        transform: none !important;
    }

    #form0407Modal .modal-dialog,
    #form0407Modal .modal-content,
    #form0407Modal .modal-body {
        position: static !important;
        top: auto !important;
        left: auto !important;
        width: 210mm !important;
        max-width: 210mm !important;
        margin: 0 !important;
        margin-top: 0 !important;
        padding: 0 !important;
        transform: none !important;
    }

    #form0407Modal #printableSheet {
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 210mm !important;
        max-width: 210mm !important;
        margin: 0 !important;
        padding: 8mm 10mm 6mm 22mm !important;
        box-sizing: border-box !important;
    }

    #form0407Modal,
    #form0407Modal #printableSheet,
    #form0407Modal #printableSheet * {
        visibility: visible !important;
    }

    /* စာရွက်ရဲ့ Content အပိုင်း */
    #form0407Modal .print-container { 
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        min-height: 0 !important;
        height: auto !important;
        box-shadow: none !important;
        border: none !important;
        box-sizing: border-box !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
    }

    body:has(#form0407Modal.show) .modal:not(#form0407Modal) {
        display: none !important;
    }

    #form0407Modal .page-two {
        break-before: page;
        page-break-before: always;
    }

    #form0407Modal table.calc-lines td[style*="border-bottom"] {
        border-bottom: 1.5px solid #000 !important;
    }

    #form0407Modal table.calc-lines {
        margin-top: 6px !important;
        margin-bottom: 8px !important;
        page-break-inside: avoid !important;
    }

    #form0407Modal table.calc-lines td {
        padding-top: 2px !important;
        padding-bottom: 2px !important;
    }

    #form0407Modal table.law-box {
        border: 1.5px solid #000 !important;
        border-collapse: separate !important;
        border-spacing: 0 !important;
    }

    #form0407Modal table.law-box td {
        border: 1.5px solid #000 !important;
    }
    .dashed-line { border-bottom: 1.5px dotted black !important; display: inline-block; }
    .solid-line { border-bottom: 1.5px solid black !important; display: inline-block; }
    .info-lines { width: 100% !important; table-layout: fixed; }
    .info-lines td:first-child { width: 7% !important; }
    .info-lines td:nth-child(2) { width: 34% !important; }
    .under-line {
        border-bottom: 1px dashed #0d0d0d !important;
        text-align: left;
        width: auto !important;
        display: table-cell !important;
        min-width: 0 !important;
    }

    .calc-lines { width: 100% !important; table-layout: fixed !important; }
    .calc-lines td:nth-child(1) { width: 60% !important; text-align: right !important; }
    .calc-lines td:nth-child(2) { width: 5% !important; text-align: center !important; }
    .calc-lines td:nth-child(3) { width: 15% !important; text-align: right !important; }
    .calc-lines td:nth-child(4) { width: 20% !important; }


    #form0407Modal .print-container,
    #form0407Modal .print-container p,
    #form0407Modal .print-container div,
    #form0407Modal .print-container table,
    #form0407Modal .print-container tr,
    #form0407Modal .print-container td,
    #form0407Modal .print-container th,
    #form0407Modal .print-container span {
        font-size: 15px !important;
    }

    .modal-header, .modal-footer, .no-print, .btn { display: none !important; }
}

</style>


<div class="modal fade" id="form0407Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: none;">
                <h4 class="modal-title" style="font-size: 18px; font-weight: bold; margin: 0; color: white;">
                    ပတခ(ဝင)-၀၄-၀၇ ဆုံးဖြတ်ချက် ထုတ်ယူရန်</h4>
                <button type="button" class="close-modal-btn" onclick="closeForm0407()" style="background: none; border: none; color: #ff4d4d; font-size: 26px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <table class="law-box" style="border: 1px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:1.9; margin-bottom: 5px; border-collapse: separate; border-spacing: 0;">
                        <tr>
                            <td style='padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px;'>ပတခ(ဝင)-၀၄-၀၇</p>

                    <div style="text-align:center; font-weight:bold; line-height: 1.9; margin-bottom:20px;font-size:15px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀ နှင့် ၆၄ တို့အရ ဝင်ငွေခွန်စည်းကြပ်မှုနှင့် <br>
                        ဒဏ်ကြေးငွေစည်းကြပ်မှု ဆုံးဖြတ်ချက် 
                    </div>
                    <div style="text-align:center;  line-height: 1.9; margin-bottom:20px;font-size:15px;">
                        
                        ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                        (<span id="m0407_township_title"><?php echo f0407('township_name'); ?></span>အခွန်ဦးစီးဌာနမှူးရုံး)
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:60%'></td>
                            <td style='text-align:right;'>ရက်စွဲ၊ <span  id="m0407_demandDate" style="width: 100px;"><?php echo f0407('itDemandDate'); ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style='text-align:right;'>စည်းကြပ်နှစ်၊   <span  id="m0407_taxYear" style="width: 100px;"><?php echo f0407('taxYear'); ?></span></td>
                        </tr>
                    </table>

                    <table class="info-lines" style='width:100%; font-size:15px; line-height: 2;'>
                        <tr>
                            <td style='width:6%'>၁။</td>
                            <td style='width:170px; font-weight:bold;'>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ <span  id="m0407_it_full"><?php echo f0407('it_no'); ?>/<?php echo f0407('it_select'); ?></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၂။</td>
                            <td style='width:150px; font-weight:bold;'>အခွန်ထမ်းအမည်နှင့်လိပ်စာ</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ <span id="m0407_name"><?php echo f0407('taxpayer_name'); ?></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'></td>
                            <td style='width:150px'></td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ <span  id="m0407_address" ><?php echo f0407('address'); ?></span></td>
                        </tr>
                       
                        <tr>
                            <td style='width:6%'>၃။</td>
                            <td style='width:150px; font-weight:bold;'>အခွန်ထမ်းအမျိုးအစား</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ ပုဂ္ဂလိက</td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၄။</td>
                            <td style='width:150px; font-weight:bold;'>လုပ်ငန်းအမျိုးအစား</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ <span id="m0407_biz"><?php echo f0407('businessType1'); ?></span></td>
                        </tr>


                        <tr>
                            <td style='width:6%'>၅။</td>
                            <td style='width:150px; font-weight:bold;'>လုပ်ငန်းခွဲများ</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ <span id="m0407_biz_txt"><?php echo f0407('businessType2'); ?></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၆။</td>
                            <td style='width:150px; font-weight:bold;'>(က)ပုဂ္ဂိုလ်စုဝင်များ</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ </span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'></td>
                            <td style='width:150px; font-weight:bold;'>( ခ ) အစုများ</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ </span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၇။</td>
                            <td style='width:150px; font-weight:bold;'>ကြေညာသည့်ဝင်ငွေ</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ (ဝငခ)<span id="m0407_declaration"></span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၈။</td>
                            <td style='width:150px; font-weight:bold;'>တင်ပြသောစာရင်းများ</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ </span></td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၉။</td>
                            <td style='width:150px; font-weight:bold;'>စည်းကြပ်သည့်ပုဒ်မ</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊၂၈၊၃၀ နှင့် ၆၄ တို့အရ </td>
                        </tr>
                        <tr>
                            <td style='width:6%'>၁၀။</td>
                            <td style='width:150px; font-weight:bold;'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                            <td style='width:450px; text-align: left;' class='under-line'>၊ (၀၁-၀၄-<span id="m0407_periodStartYear"><?php echo toMM($startYear); ?></span>) မှ (၃၁-၀၃-<span id="m0407_periodEndYear"><?php echo toMM($endYear); ?></span>)ထိ ကာလ</td>
                        </tr>
                        
                    </table>

                    <p style='text-align:center; font-weight:bold; margin-top:20px; text-decoration: '>
                        ဝင်ငွေခွန်စည်းကြပ်မှုနှင့် ဒဏ်ကြေးငွေ စည်းကြပ်မှု ဆုံးဖြတ်ချက်
                    </p>

                    <div style="text-align:justify; line-height: 2.1; text-indent: 50px;">
                        အခွန်ထမ်းသည် ( <span style="color:red;" id="m0407_taxYear_txt"><?php echo $displayTaxYear; ?></span> ) ဝင်ငွေနှစ်အတွင်း ( <span style="color:red;" id="m0407_biz_para"><?php echo f0407('businessType1'); ?></span> ) လုပ်ငန်းမှ 
                        ကြိုတင်ခွန် ( <span style="color:red;" id="m0407_advancePaidTax"><?php echo f0407('advancePaidTax'); ?></span> )ကျပ် ပေးသွင်းထားပါသည်။/(မပေးသွင်းထားပါ။) ဝင်ငွေနှစ်အတွက်
                        ဝင်ငွေ ( <span style="color:red;" id="m0407_declaration_para"><?php echo f0407('declaredIncome1'); ?></span> ) ကျပ် ဖော်ပြထားသည့် ကြေညာလွှာကို အချိန်မီ တင်သွင်းထားပါသည်။ /(မတင်သွင်းထားပါ)
                        သို့ရာတွင် ခိုင်လုံသော စာရင်းအထောက်အထားများတင်ပြနိုင်ခြင်း မရှိပါ။
                    </div>
                    <div style="text-align:justify; line-height: 2.1; text-indent: 50px;">
                        အခွန်ထမ်းသည် အဆိုပါ ကြေညာသော ဝင်ငွေအတွက် အထောက်အကူပြုသော စာရင်းအင်း အထောက် အထား တစ်စုံတစ်ရာကိုလည်းကောင်း၊   
                        ခိုင်မာသောသက်သေခံ အထောက်အထားများကိုလည်းကောင်း ခိုင်လုံစွာ တင်ပြနိုင်ခြင်း မရှိပါသော ကြောင့် အခွန်ထမ်း၏ထွက်ဆိုတင်ပြချက်၊ လုပ်ငန်းပမာဏ၊ စီးပွားရေးလုပ်ငန်း အခြေအနေနှင့် စုံစမ်းလေ့လာတွေ့ရှိရသော သတင်းအချက်အလက်များကို အခြေခံ၍ 
                        ဝင်ငွေခွန် ဥပဒေပုဒ်မ ၁၉ နှင့် အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇ အရ အောက်ပါအတိုင်း စည်းကြပ်လိုက်သည်-
                        
                    </div>
                    
                    <div class="page-two">
                    <p style='text-align:right; font-size:15px; margin-top:0;'><br><br><br>ပတခ(ဝင)-၀၄-၀၇ (အဆက်)</p>
                     <div style="text-align:justify; line-height: 2.1; text-indent: 0px;">
                       
                    </div>

                    <table class="calc-lines" style="width:100%; margin: 20px auto; border-collapse: collapse; font-size: 15px;">
                        <tr>
                            <td style="padding: 5px; text-align: right;">စုစုပေါင်းရောင်းရငွေ</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_totalSales"><?php echo f0407('totalSales'); ?></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">(နုတ်) ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td>=</td>
                            <td style="text-align:right; color:red; border-bottom:1.5px solid;"  id="m0407_minusCT" ><?php echo f0407('minusCTInput'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ကုန်သွယ်လုပ်ငန်းခွန်မပါ ရောင်းရငွေ</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_netSales" ><?php echo f0407('netSales'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right; ">(<span id="m0407_otherIncomeTitle"><?php echo f0407('otherIncomeTitle'); ?></span>)အခြားရငွေ</td>
                            <td style="width:5%;">=</td>
                            <td style="text-align:right; border-bottom:1.5px solid;"  id="m0407_otherIncomeVal" ><?php echo f0407('otherIncomeVal'); ?></td>
                            <td ></td>
                        </tr>
                   
                        <tr>
                            <td style="padding: 5px; text-align: right;">ဝင်ငွေခွန်တွက်ချက်ရန်ရောင်းရငွေ</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_income" ><?php echo f0407('taxableSales'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; font-weight: bold; text-align: right;">(နုတ်) တိုက်ရိုက်ကုန်ကျစရိတ်</td>
                            <td>=</td>
                            <td style="text-align:right;color:red; border-bottom:1.5px solid;"  id="m0407_directCost" ><?php echo f0407('totalDirectCost'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">အကြမ်းအမြတ်</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_grossProfit"><?php echo f0407('grossProfit'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">(နုတ်) စီမံအုပ်ချုပ်မှုစရိတ်</td>
                            <td>=</td>
                            <td style="text-align:right;color:red; border-bottom:1.5px solid;"  id="m0407_AdminCost" ><?php echo f0407('totalAdminCost'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">အသားတင်အမြတ်</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_netProfit"><?php echo f0407('netProfit'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">(နုတ်) သက်သာခွင့်များ</td>
                            <td>=</td>
                            <td style="text-align:right; color:red; border-bottom:1.5px solid;"  id="m0407_totalRelief" ><?php echo f0407('totalRelief'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">အခွန်စည်းကြပ်ရန်ဝင်ငွေ</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_taxableIncome" ><?php echo f0407('finalTaxableIncome'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px;text-align: right;">ကျသင့်ဝင်ငွေခွန်</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_incomeTax"><?php echo f0407('payableIncomeTax'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ကြိုတင်ခွန်</td>
                            <td>=</td>
                            <td style="text-align:right; color:red; border-bottom:1.5px solid;"  id="m0407_advancePaidTax" ><?php echo f0407('advancePaidTax'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ထပ်မံပေးဆောင်ရန်ဝင်ငွေခွန်</td>
                            <td>=</td>
                            <td style="text-align:right;"  id="m0407_finalBalanceTax" ><?php echo f0407('finalBalanceTax'); ?></td>
                            <td ></td>
                        </tr>
                        <tr>
                            <td style="padding: 5px; text-align: right;">ပေးဆောင်ရမည့်ဒဏ်ကြေးငွေ</td>
                            <td>=</td>
                            <td style="text-align:right; color:red; border-bottom:1.5px solid;"  id="m0407_panaty" ><?php echo f0407('itpanaty'); ?></td>
                            <td ></td>
                        </tr>
                        <tr style="font-weight: bold; font-size: 15px;">
                            <td style="padding:  5px; text-align: right;">ပေးဆောင်ရန် စုစုပေါင်း (အခွန်+ဒဏ်ကြေး)</td>
                            <td>=</td>
                            <td style="text-align:right; border-bottom:1.5px solid;border-top:1.5px solid;"  id="m0407_taxpanaty" ><?php echo f0407('taxpanaty'); ?></td>
                            <td ></td>
                        </tr>
                    </table>
                    <br><br><br>
                    <table style='width:100%; margin-top:24px;'>
                        <tr>
                            <td style='width:30%; text-align:center;'>ရုံးတံဆိပ်</td>
                            <td style='width:20%; text-align:center;'></td>
                            <td style='width:50%; text-align:center; line-height: 1.8;'>
                                တာဝန်ခံအရာရှိ<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                <span id="m0407_township_footer"><?php echo f0407('township_name'); ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                    </div>
                </div>
            </div>
       
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn px-4" onclick="window.print()" 
                        style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                    <i class="fa fa-print"></i> Print ထုတ်မည်
                </button>
                <button type="button" class="btn px-4" 
                        onclick="closeForm0407()" 
                        style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                    ပိတ်မည်
                </button>
            </div>
        </div>
    </div>
</div>

<script>
function closeForm0407() {
    var inFormsFolder = window.location.pathname.toLowerCase().indexOf('/forms/') !== -1;
    window.location.href = (inFormsFolder ? '../' : '') + 'IT_Demand_List.php';
}

function openForm0407() {


    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("Table ထဲမှ row ကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    try {
    // ၁။ မြန်မာဂဏန်းပြောင်းလဲခြင်း (Comma မပါစေရန် logic ပါဝင်သည်)
    const toMM = (num, showComma = true) => {
        if (num === null || num === undefined || num === "") return '၀';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        
        // ဂဏန်းမဟုတ်တဲ့ (-) တို့ကို မဖျက်စေဘဲ ဂဏန်းတွေကိုပဲ replace လုပ်ဖို့ regex သုံးပါမယ်
        let s = showComma ? num.toLocaleString() : num.toString(); 
        return s.replace(/\d/g, d => mDigits[d]);
    };

       const setText = (id, val, isNum = false, showComma = true) => {
    const el = document.getElementById(id);
    if (el) {
        // Data ရောက်မရောက် စစ်ဆေးရန် console.log ထည့်ပါ
        console.log("Setting ID:", id, "Value:", val); 
        
        if (val === null || val === undefined || val === "") {
             el.innerText = "N/A"; // Data မရှိရင် N/A လို့ ပေါ်လာပါမယ်
        } else {
             el.innerText = isNum ? toMM(val, showComma) : val;
        }
    } else {
        console.error("Element not found:", id); // ID မှားနေလား စစ်တာပါ
    }
};

    // ၂။ စည်းကြပ်နှစ် (Tax Year) ကို မြန်မာလိုပြောင်းလဲခြင်း
    // အပေါ်ဘက် စည်းကြပ်နှစ် (ညာဘက်အပေါ်)
    if (selectedRowData.taxYear) {
        // toMM function သုံးပြီး အင်္ဂလိပ်ဂဏန်းကို မြန်မာပြောင်းလိုက်ပါမယ်
        const mmTaxYear = toMM(selectedRowData.taxYear, false); 
        setText('m0407_taxYear', mmTaxYear);
    }

    // ၃။ ဝင်ငွေနှစ် (Income Year) ကာလများအတွက် ခွဲထုတ်ခြင်း
    let years = (selectedRowData.taxYear || "").split('-');
    if (years.length === 2) {
        let startYear = parseInt(years[0]) - 1; 
        let endYear = parseInt(years[1]) - 1; 
        
        // ဝင်ငွေနှစ်စာသား (ဥပမာ- ၂၀၂၅-၂၀၂၆)
        const adjustedTaxYearMM = toMM(startYear + "-" + endYear, false);
        setText('m0407_taxYear_txt', adjustedTaxYearMM);

        // ၁၀။ ဝင်ငွေနှစ် (အခွန်ကာလ) ရက်စွဲများ
        setText('m0407_periodStartYear', startYear, true, false);
        setText('m0407_periodEndYear', endYear, true, false);
    }

    // ၄။ ရက်စွဲ (Demand Date) ပြင်ဆင်ခြင်း
    if (selectedRowData.itDemandDate) {
        const d = new Date(selectedRowData.itDemandDate);
        const formattedDate = toMM(d.getDate(), false) + "-" + toMM(d.getMonth() + 1, false) + "-" + toMM(d.getFullYear(), false);
        setText('m0407_demandDate', formattedDate);
    }

    // အခြား ဒေတာများ (အနီဝိုင်းပြထားသော နေရာများအတွက် ID များ စစ်ဆေးပါ)
    setText('m0407_name', selectedRowData.taxpayer_name);
    setText('m0407_address', selectedRowData.address);
    
    // လုပ်ငန်းအမျိုးအစား (၄)
    setText('m0407_biz', selectedRowData.businessType1);
    
    // အောက်က စာပိုဒ်ထဲမှာ ထပ်ပေါ်နေတဲ့ လုပ်ငန်းအမျိုးအစား ID (ရှိလျှင်)
    // ပုံထဲက မြားပြထားတဲ့ ( ) အတွင်းက နေရာအတွက် ID ကို m0407_biz_para လို့ ယာယီသတ်မှတ်ထားပါတယ်
    const bizParaEl = document.getElementById('m0407_biz_para');
    if (bizParaEl) bizParaEl.innerText = selectedRowData.businessType1;

    setText('m0407_biz_txt', selectedRowData.businessType2);
    setText('m0407_township_title', selectedRowData.township_name);
    setText('m0407_township_footer', selectedRowData.township_name);
    
    const itFull = (selectedRowData.it_no || '') + "/" + (selectedRowData.it_select || '');
    setText('m0407_it_full', itFull);

    // ငွေကြေးဆိုင်ရာများ
    setText('m0407_declaration', selectedRowData.declaredIncome1, true);
    // စာပိုဒ်ထဲက ဝင်ငွေနေရာအတွက် ( )
    const declParaEl = document.getElementById('m0407_declaration_para');
    if (declParaEl) declParaEl.innerText = toMM(selectedRowData.declaredIncome1, true);

    setText('m0407_totalSales', selectedRowData.totalSales, true);
    setText('m0407_minusCT', selectedRowData.minusCTInput, true);
    setText('m0407_netSales', selectedRowData.netSales, true);
    const otherTitleEl = document.getElementById('m0407_otherIncomeTitle');
    if (otherTitleEl) otherTitleEl.innerText = selectedRowData.otherIncomeTitle || '';
    setText('m0407_otherIncomeVal', selectedRowData.otherIncomeVal, true);
    setText('m0407_income', selectedRowData.taxableSales, true);
    setText('m0407_directCost', selectedRowData.totalDirectCost, true);
    setText('m0407_grossProfit', selectedRowData.grossProfit, true);
    setText('m0407_AdminCost', selectedRowData.totalAdminCost, true);

    setText('m0407_netProfit', selectedRowData.netProfit, true);
    setText('m0407_totalRelief', selectedRowData.totalRelief, true);
    setText('m0407_taxableIncome', selectedRowData.finalTaxableIncome, true);
    setText('m0407_incomeTax', selectedRowData.payableIncomeTax, true);
    setText('m0407_advancePaidTax', selectedRowData.advancePaidTax, true);
    setText('m0407_finalBalanceTax', selectedRowData.finalBalanceTax, true);
    setText('m0407_panaty', selectedRowData.itpanaty, true);
    setText('m0407_taxpanaty', selectedRowData.taxpanaty, true);
    } catch (err) {
        console.error(err);
    }

    if (typeof presentFormModal === 'function') {
        presentFormModal('form0407Modal');
    } else {
        var modalElem = document.getElementById('form0407Modal');
        if (modalElem) {
            var myModal = bootstrap.Modal.getOrCreateInstance(modalElem);
            myModal.show();
        }
    }
}
</script>