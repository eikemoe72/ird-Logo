<?php
// ၁။ Session စတင်ခြင်း
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ DB Config ချိတ်ဆက်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}



// ၃။ Session ထဲက User ID ကိုယူပြီး user_register မှ other (စာအမှတ်အတွက်) ဆွဲထုတ်ခြင်း
$u_id = $_SESSION['user_id'] ?? 0;
$user_other_info = ""; 

if ($u_id > 0) {
    $user_query = "SELECT other FROM user_register WHERE id = '$u_id'";
    $user_result = mysqli_query($conn, $user_query);
    if ($user_result && $user_row = mysqli_fetch_assoc($user_result)) {
        $user_other_info = str_replace(array("\r", "\n", "'", '"'), '', $user_row['other']);
    }
}

// ၄။ URL မှ ပါလာသော ID ဖြင့် မော်တော်ယာဉ်ဒေတာ ဆွဲထုတ်ခြင်း
$vehicle_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$v_data = [];

if ($vehicle_id > 0) {
    $v_query = "SELECT * FROM regular_data WHERE id = '$vehicle_id'";
    $v_result = mysqli_query($conn, $v_query);
    if ($v_result && mysqli_num_rows($v_result) > 0) {
        $v_data = mysqli_fetch_assoc($v_result);
    }
}

// ဂဏန်းများကို မြန်မာလိုပြောင်းပေးမည့် Function
function toMyanmarNumber($num) {
    if (empty($num)) return '';
    $en = array('0','1','2','3','4','5','6','7','8','9');
    $mm = array('၀','၁','၂','၃','၄','၅','၆','၇','၈','၉');
    return str_replace($en, $mm, $num);
}

// 🎯 ၅။ notify_date ကို ခုနှစ်၊ လ၊ ရက် ခွဲထုတ်ခြင်းစနစ်
$or_year = '....'; 
$or_year_short = '..'; 
$or_month = '..........'; 
$or_day = '....';

// ဒေတာဘေ့စ်ထဲရှိ notify_date အား စစ်ဆေးခြင်း
$target_date = $v_data['orderDate'] ?? ''; 

if (!empty($target_date) && $target_date != '0000-00-00') {
    $date_parts = explode('-', explode(' ', $target_date)[0]);
    if (count($date_parts) == 3) {
        $full_year = $date_parts[0]; // ဥပမာ - 2026
        $or_year = toMyanmarNumber($full_year);
        $or_year_short = toMyanmarNumber(substr($full_year, -2)); // နောက်ဆုံး ၂ လုံး (ဥပမာ - ၂၆)
        
        $mm_months = array('', 'ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ');
        $or_month = $mm_months[intval($date_parts[1])];
        $or_day = toMyanmarNumber(intval($date_parts[2])); // သုညဆွဲဖြုတ်ပြီး မြန်မာမှုပြုခြင်း
    }
}

// ၂။ URL ကနေ id ကို လှမ်းယူခြင်း
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$taxpayer_name = "";
$business_type = "";
$address = "";
$township_name = "";
$appointmentDate = "";
$taxYear= "";

if ($id > 0) {
    // 🎯 ၃။ ဇယားအမည်ကို 'taxpayers_table' အစား 'sakalakahdata' သို့ ပြောင်းလဲထားပါသည်
    $sql = "SELECT taxpayer_name, businessType1, township_name, appointmentDate, taxYear, address FROM regular_data WHERE id = $id";
    $result = $conn->query($sql);
    
    if ($result && $row = $result->fetch_assoc()) {
        $taxpayer_name = $row['taxpayer_name'];
        $business_type = $row['businessType1'];
        $address = $row['address'];
        $township_name = $row['township_name'];
        $taxYear = $row['taxYear'];
        $appointmentDate = $row['appointmentDate'];
        // AppointmentDate ကို 05-08-2026 ပုံစံပြောင်းခြင်း
        $formatted_date = "........"; // Data မရှိရင်ပေါ်မယ့်ဟာ
        if (!empty($appointmentDate) && $appointmentDate != '0000-00-00') {
            // DD-MM-YYYY ပုံစံပြောင်း
            $date_in_english = date('d-m-Y', strtotime($appointmentDate));
            
            // မြန်မာဂဏန်းလိုချင်ရင် ဒီအတိုင်းထားပါ
            $formatted_date = toMyanmarNumber($date_in_english); 
            
            // တကယ်လို့ မြန်မာဂဏန်းမလိုဘဲ အင်္ဂလိပ်ဂဏန်းပဲ လိုချင်ရင်တော့ 
            // $formatted_date = $date_in_english; ကိုသုံးပေးပါဗျ။
        }
        
    }
}
?>

<script>
window.onload = function() {
    console.log("မော်တော်ယာဉ် ပုံစံ ဝက-၀၄-၀၅ စာမျက်နှာ တက်လာပါပြီ။");
};
</script>

<style>
/* 🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် စာရွက်အစစ်ကဲ့သို့ မြင်ရစေရန်) */
#formsModal0405 .modal-dialog {
    max-width: 210mm; 
    margin: 30px auto;
}

/* 🚨 ပြဿနာဖြစ်စေသော background စတိုင်ကို Modal ပွင့်မှသာ အလုပ်လုပ်အောင် dialog အောက်တွင် ထည့်ရပါမည် */
#formsModal0405 .modal-content {   
    background-color: #f8f9fa;
    border: 1px solid rgba(0,0,0,0.2);
    box-shadow: 0 5px 15px rgba(0,0,0,0.5);
    border-radius: 6px;
}

#formsModal0405 .modal-body {
    padding: 0px !important;
    overflow-x: hidden;
}

/* 📄 စာရွက် Background စတိုင် (Screen ပေါ်တွင်ကြည့်ပါက အရိပ်ပါမည်) */
.print-container { 
    background: #ffffff;
    width: 210mm;
    min-height: 297mm;
    margin: 0 auto;
    padding: 5mm 5mm 5mm 10mm !important; /* ရုံးသုံး အနားသတ် */
    box-sizing: border-box;
}

/* 📊 ဇယားကွက် ပုံစံများ */
.main-content-table2 {
    width: 100% !important;
    margin-bottom: 5px;
    border-collapse: collapse;
}

.main-content-table2 td {
    padding: 2px 4px !important;
    font-size: 15px;
    vertical-align: middle;
}

.main-content-table {
    width: 100% !important;
    table-layout: fixed; 
    border-collapse: collapse !important;
    margin-top: 10px;
}

.main-content-table th, 
.main-content-table td {
    border: 1px solid #000000 !important; /* မျဉ်းနက်အပြည့်ခတ်ရန် */
    padding: 8px 10px !important;
    font-size: 15px;
    word-wrap: break-word !important;
}
.main-content-table tr { border-bottom: none !important; }
.main-content-table thead th {
    background-color: #f5f5f5 !important;
    font-weight: bold;
    text-align: center;
    vertical-align: middle;
}

/* Order Sheet ဇယားအတွက် သီးသန့် Border သတ်မှတ်ခြင်း */
.order-table {
    border-collapse: collapse;
    width: 100%;
}

.order-table th, .order-table td {
    border: 1px solid black; /* ပုံမှန် ဘောင်လိုင်းအမည်း */
    padding: 10px;
}

/* အလယ်က အလျားလိုက်လိုင်း များကို ဖျောက်ရန် Class */
.no-middle-border td {
    border-top: none !important;
    border-bottom: none !important;
}
#formsModal0405 .modal-dialog {
    max-width: 800px; 
    margin: 20px auto;
}

#formsModal0405 .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}

@media screen {
    #formsModal0405 .print-container {
        padding: 5mm 10px 5mm 70px !important;
    }
}

@media print {
    /* 🎯 စာရွက်မျက်နှာပြင်တစ်ခုလုံး၏ Margin ကို သုညလုပ်ပြီး အစွန်းချင်း ကပ်ခိုင်းခြင်း */
    @page {
        size: A4;
        margin: 0; /* Browser ရဲ့ Default margin များကို ဖျောက်ခြင်း */
    }

    /* 🎯 Body ထဲရှိ Screen သုံး Flexbox စနစ်များကို Print ထုတ်ချိန်တွင် အပြီးတိုင် ပိတ်ပစ်ခြင်း */
    body {
        background: none !important;
        display: block !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100% !important;
        height: auto !important;
    }

    /* မလိုအပ်သော ခလုတ်များနှင့် Element များ ဖျောက်ခြင်း */
    .modal-footer, .no-print, .btn, .btn-close, .modal-header, hr { 
        display: none !important; 
    }
    
    .modal-content, .modal-body { 
        border: none !important; 
        box-shadow: none !important; 
        padding: 0 !important;
        margin: 0 !important;
    }

    /* 🎯 စာမျက်နှာကို အပေါ်ဆုံးနှင့် ဘယ်ဘက်စွန်းသို့ ကွက်တိ ကပ်သွားစေရန် စနစ် */
    body * { visibility: hidden; }
    #formsModal0405, #formsModal0405 * { visibility: visible !important; }
    
    #formsModal0405 { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important; 
        margin: 0 !important; 
        padding: 0 !important; 
    }

    /* 🎯 A4 Container အား ဘယ်/အထက် ကပ်ပြီး ရုံးသုံး Margin အချိုးကျ ပြန်ချန်ခြင်း */
    .a4-container {
        width: 210mm !important; /* A4 အကျယ်စစ်စစ်အတိုင်း သတ်မှတ်ခြင်း */
        height: auto !important;
        margin: 0 !important;
        /* အပေါ်၊ ညာ၊ အောက်၊ ဘယ် အကွာအဝေးကို ရုံးသုံး Layout အတိုင်း စနစ်တကျ ချန်ခြင်း */
        padding: 20mm 30mm 20mm 20mm !important; 
        box-shadow: none !important;
        display: block !important; /* flex ကို ဖျက်ပစ်ပါသည် */
    }

    /* ဇယားကွက်များ အားလုံး စာရွက်အပြည့် ဆွဲဆန့်ခြင်း */
    .a4-container table {
        width: 100% !important;
        border-collapse: collapse !important;
    }

    table, tr, td { 
        border: none !important; 
    }

    #formsModal0405 .print-container {
        width: 210mm !important;
        max-width: 210mm !important;
        min-height: 0 !important;
        height: auto !important;
        margin: 0 !important;
        padding: 10mm 10mm 6mm 18mm !important;
        border: none !important;
        box-sizing: border-box !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
    }
}

</style>

<div class="modal fade" id="formsModal0405" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
          
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: none;">
                    <h5 class="modal-title" style="font-size: 16px; font-weight: bold; margin: 0; color: white;">
                        ၀၄-၀၅ ကြားနာစစ်ဆေးရန်အကြောင်းကြားစာ ထုတ်ယူရန်
                    </h5>
                    <button type="button" class="close-modal-btn" onclick="window.location.href='../IT_demand_list.php';" style="background: none; border: none; color: #ff4d4d; font-size: 26px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                    </button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:25px">
                        <tr>
                            <td style='border: 0px solid black; padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>
                                ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>
                    <div style="text-align:right; margin-bottom:10px;">
                        ပတခ(ဝင)-၀၄-၀၅
                    </div>
                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၆၊ ပုဒ်မခွဲ(က)၊ ပုဒ်မခွဲငယ်(၂)အရ<br>
                        စာရင်းအထောက်အထားများတင်ပြစေရန် သို့မဟုတ် ကြားနာစစ်ဆေးရန်အကြောင်းကြားစာ
                    </div>

                    <table style='width:100%; font-size:15px; border:none !important;'>
                        <tr>
                            <td style='text-align:right; width:60%'>
                                စာအမှတ်၊ ပတခ/<?php echo htmlspecialchars($user_other_info ?: '......'); ?>/ဝငခ/၂၀<?php echo $or_year_short; ?>(&emsp;&emsp;&emsp;)
                            </td>
                        </tr>
                        <tr>
                            <td style='text-align:right;'>ရက်&ensp;&ensp;စွဲ၊ 
                                <strong>
                                    <span><?php echo $or_year; ?></span>ခုနှစ်၊ &ensp;
                                    <span><?php echo $or_month; ?></span>လ &ensp;
                                    <span><?php echo $or_day; ?></span> &ensp;ရက်
                                </strong> 
                            </td>
                        </tr>
                    </table>

                    <div style="margin-left: 0px; text-align:left; margin-top:10px;">
                        သို့<br>
                        <span style='padding-left:70px;'></span><strong><span id="m0405_name"><?php echo htmlspecialchars($v_data['taxpayer_name'] ?? ''); ?></span></strong> <br>
                        <span style='padding-left:70px;'></span><strong><span id="m0405_address"><?php echo htmlspecialchars($v_data['address'] ?? ''); ?></span></strong> <br>
                        <span style='padding-left:70px;'></span><strong><span id="m0405_biz"><?php echo htmlspecialchars($v_data['businessType1'] ?? ''); ?></span></strong> 
                    </div>

                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၁။<span style='padding-left:46px;'></span>လူကြီးမင်း၏ <span id="m0405_biz"><?php echo htmlspecialchars($v_data['businessType1'] ?? ''); ?></span> အပေါ် ( <strong><span id="m0405_year"><?php echo toMyanmarNumber($v_data['taxYear'] ?? ''); ?></span></strong> )ဘဏ္ဍာနှစ်အတွက် 
                        ဝင်ငွေခွန်စည်းကြပ်ရန် အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၂ နှင့် ဝင်ငွေခွန်ဥပဒေပုဒ်မခွဲ( ၁၇ )အရ ပေးပို့ထားသော ဝင်ငွေကြေညာလွှာကို မှန်/မမှန် စိစစ်နိုင်ရန် လိုအပ်သဖြင့်  
                        လူကြီးမင်းကိုယ်တိုင်ဖြစ်စေ သို့တည်းမဟုတ် စာဖြင့် တာဝန်လွှဲအပ်ထားသည့် ကိုယ်စားလှယ်ဖြစ်စေ ( <strong><span id="m0405_appDate"><?php echo $formatted_date; ?></span></strong> )နေ့ရက်၊ ( <strong>၁၀:၀၀</strong> )နာရီ အချိန်တွင် ဤရုံးသို့ 
                        လာရောက်၍ အထောက်အထားများ၊ စာရင်းစာအုပ်၊ စာရွက်စာတမ်းများကို တင်ပြရန် အကြောင်းကြားသည်။ <br>
               
                        ၂။<span style='padding-left:46px;'></span>ဤအကြောင်းကြားစာအတိုင်း လိုက်နာဆောင်ရွက်ရန် ပျက်ကွက်ပါက အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေ ပုဒ်မ ၂၇(ဂ)အရ ရနိုင်သမျှ အထောက်အထားများကို အခြေပြု၍ 
                        အခွန်စည်းကြပ်ခြင်း၊ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၇၀ / ၇၃ တို့အရ ဒဏ်ငွေတပ်ရိုက်ခြင်း၊  ပုဒ်မ ၇၈ အရ အရေးယူခြင်းတို့ကို ခံရဖွယ်ရှိကြောင်း အသိ‌ပေးအပ်ပါသည်။ 
                    </div>
                     
                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        ပေးပို့ရန် သတင်းအချက်အလက်အထောက်အထား စာရွက်စာတမ်းများ
                    </div>
                    <p style='border:0px solid; text-align:left;font-size:15px;line-height:23px'>
                    <span style='padding-left:70px;'></span> (က) <span style='padding-left:30px;'> မှတ်ပုံတင်မူရင်း/မိတ္တူ </span><br/>
                    <span style='padding-left:70px;'></span> ( ခ ) <span style='padding-left:30px;'> အိမ်ထောင်စုဇယားမူရင်း/မိတ္တူ </span><br/>
                    <span style='padding-left:70px;'></span> ( ဂ ) <span style='padding-left:30px;'> စည်ပင်သာယာလုပ်ငန်းလိုင်စင်</span><br/>
                    <span style='padding-left:70px;'></span> (ဃ) <span style='padding-left:30px;'> စက်မှုလုပ်ငန်းလိုင်စင်</span><br/>
                    <span style='padding-left:70px;'></span> ( င ) <span style='padding-left:30px;'> အသေးစားအလတ်စားစက်မှုလုပ်ငန်းလိုင်စင်</span><br/>
                    <span style='padding-left:70px;'></span> ( စ ) <span style='padding-left:30px;'> အခြားသောလုပ်ငန်းလိုင်စင်များ</span><br/>
                    <span style='padding-left:70px;'></span> (ဆ) <span style='padding-left:30px;'> ....................................................</span><br/></p>
                    <table style='width:100%; margin-top:16px; border:none !important;'>
                        <tr>
                            <td style='width:50%; padding-left:50px; font-size: 16px; vertical-align: top;'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center; font-size: 16px; line-height: 1.8;'>
                                တာဝန်ခံအရာရှိ<br>
                                ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                
                                    <span id="m0405_township_direct">
                                        <?php echo !empty($township_name) ? htmlspecialchars($township_name) : '............'; ?>
                                    </span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>
                <div style="padding-left:540px; padding-top:15px" class="modal-footer no-print d-flex justify-content-end align-items-center gap-2" style="width: 100%; border-top: 1px solid #dee2e6; padding: 15px; ">

                        <button type="button" class="btn px-4" onclick="window.print()" 
                                style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                            <i class="fa fa-print"></i> Print ထုတ်မည်
                        </button>
                        <button type="button" class="btn px-4" 
                                onclick="window.location.href='../IT_demand_list.php?openModal=formsModal2';" 
                                style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                            ပိတ်မည်
                        </button>
                </div>
        </div>
    </div>
</div>
</div>
