<?php
// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    // အစ်ကို့ရဲ့ ပင်မ Table နာမည် 'sakalakahdata' ထဲမှ ဆွဲထုတ်ခြင်း
    $query = "SELECT * FROM regular_data WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း
$os_case_number     = htmlspecialchars($db_data['case_number'] ?? '-');
$os_name            = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_township_name   = htmlspecialchars($db_data['township_name'] ?? '-');
$os_taxYear         = htmlspecialchars($db_data['taxYear'] ?? '-');


$os_gir             = htmlspecialchars($db_data['it_no'] ?? '-');
$os_gir_type        = htmlspecialchars($db_data['it_select'] ?? '-');

$os_gir_ct1         = htmlspecialchars($db_data['ct1_no_real'] ?? '-');
$os_gir_type_ct1    = htmlspecialchars($db_data['ct1_select_real'] ?? '-');

$os_gir_ct2         = htmlspecialchars($db_data['ct2_no_real'] ?? '-');
$os_gir_type_ct2    = htmlspecialchars($db_data['ct2_select_real'] ?? '-');

$os_address         = htmlspecialchars($db_data['address'] ?? '-');
$os_ph_no           = htmlspecialchars($db_data['ph_no'] ?? '-');
$os_officer         = htmlspecialchars($db_data['officer_name'] ?? 'အခွန်မှူးအမည်');
$os_officer_rank    = htmlspecialchars($db_data['rank_'] ?? 'ရာထူး');
$os_officer_region   = htmlspecialchars($db_data['region'] ?? 'နယ်မြေ');
$os_biz1            = htmlspecialchars($db_data['businessType1'] ?? '-');
$os_biz2            = htmlspecialchars($db_data['businessType2'] ?? '-');

//ကြေညာလွှာတင်သွင်းခြင်း
$os_declaredIT      = htmlspecialchars($db_data['declaredIncome1'] ?? 'နယ်မြေ');
$os_declaredCT1     = htmlspecialchars($db_data['declaredCT1'] ?? '-');
$os_declaredCT2     = htmlspecialchars($db_data['declaredCT2'] ?? '-');

// (၄) ယခင်သုံးနှစ်စာ
$os_rowYear1        = htmlspecialchars($db_data['rowYear1'] ?? '-');
$os_income1         = htmlspecialchars($db_data['income1'] ?? '-');
$os_income_tax1     = htmlspecialchars($db_data['income_tax1'] ?? '-');
$os_sale_income1    = htmlspecialchars($db_data['sale_income1'] ?? '-');
$os_ct1             = htmlspecialchars($db_data['ct1'] ?? '-');

$os_rowYear2        = htmlspecialchars($db_data['rowYear2'] ?? '-');
$os_income2         = htmlspecialchars($db_data['income2'] ?? '-');
$os_income_tax2     = htmlspecialchars($db_data['income_tax2'] ?? '-');
$os_sale_income2    = htmlspecialchars($db_data['sale_income2'] ?? '-');
$os_ct2             = htmlspecialchars($db_data['ct2'] ?? '-');

$os_rowYear3        = htmlspecialchars($db_data['rowYear3'] ?? '-');
$os_income3         = htmlspecialchars($db_data['income3'] ?? '-');
$os_income_tax3     = htmlspecialchars($db_data['income_tax3'] ?? '-');
$os_sale_income3        = htmlspecialchars($db_data['sale_income3'] ?? '-');
$os_ct3             = htmlspecialchars($db_data['ct3'] ?? '-');

//ကုန်သွယ်ခွန်တွက်ချက်မှု1
$os_salesAmount1    = htmlspecialchars($db_data['salesAmount1'] ?? '-');
$os_ct1tax          = htmlspecialchars($db_data['ct1tax'] ?? '-');
$os_rule42_1        = htmlspecialchars($db_data['rule42_1'] ?? '-');
$os_afterRuler1     = htmlspecialchars($db_data['afterRuler1'] ?? '-');
$os_advanceTax1     = htmlspecialchars($db_data['advanceTax1'] ?? '-');
$os_netTax1         = htmlspecialchars($db_data['netTax1'] ?? '-');
$os_penalty1        = htmlspecialchars($db_data['penalty1'] ?? '-');
$os_totalTax1       = htmlspecialchars($db_data['totalTax1'] ?? '-');
$os_paidTax1        = htmlspecialchars($db_data['paidTax1'] ?? '-');
$os_ct1_chalan_no   = htmlspecialchars($db_data['ct1_chalan_no'] ?? '-');
$os_date1           = htmlspecialchars($db_data['date1'] ?? '............');

//ကုန်သွယ်ခွန်တွက်ချက်မှု2
$os_salesAmount2    = htmlspecialchars($db_data['salesAmount2'] ?? '-');
$os_ct2tax          = htmlspecialchars($db_data['ct2tax'] ?? '-');
$os_rule42_2        = htmlspecialchars($db_data['rule42_2'] ?? '-');
$os_afterRuler2     = htmlspecialchars($db_data['afterRuler2'] ?? '-');
$os_advanceTax2     = htmlspecialchars($db_data['advanceTax2'] ?? '-');
$os_netTax2         = htmlspecialchars($db_data['netTax2'] ?? '-');
$os_penalty2        = htmlspecialchars($db_data['penalty2'] ?? '-');
$os_totalTax2       = htmlspecialchars($db_data['totalTax2'] ?? '-');
$os_paidTax2        = htmlspecialchars($db_data['paidTax2'] ?? '-');
$os_ct2_chalan_no   = htmlspecialchars($db_data['ct2_chalan_no'] ?? '-');
$os_date2           = htmlspecialchars($db_data['date1'] ?? '............');

//ဝင်ငွေခွန်
$os_totalSales          = htmlspecialchars($db_data['totalSales'] ?? '-');
$os_minusCTInput        = htmlspecialchars($db_data['minusCTInput'] ?? '-');
$os_netSales            = htmlspecialchars($db_data['netSales'] ?? '-');
$os_otherIncomeTitle    = htmlspecialchars($db_data['otherIncomeTitle'] ?? '-');
$os_otherIncomeVal      = htmlspecialchars($db_data['otherIncomeVal'] ?? '-');
$os_taxableSales        = htmlspecialchars($db_data['taxableSales'] ?? '-');
$os_purchaseCost        = htmlspecialchars($db_data['purchaseCost'] ?? '-');
$os_otherDirectCost     = htmlspecialchars($db_data['otherDirectCost'] ?? '-');
$os_directGeneralCost   = htmlspecialchars($db_data['directGeneralCost'] ?? '-');
$os_totalDirectCost     = htmlspecialchars($db_data['totalDirectCost'] ?? '-');
$os_grossProfit         = htmlspecialchars($db_data['grossProfit'] ?? '-');

$os_salaryCost          = htmlspecialchars($db_data['salaryCost'] ?? '-');
$os_licence             = htmlspecialchars($db_data['licence'] ?? '-');
$os_socialWelfare       = htmlspecialchars($db_data['socialWelfare'] ?? '-');
$os_shopRent            = htmlspecialchars($db_data['shopRent'] ?? '-');
$os_electricity         = htmlspecialchars($db_data['electricity'] ?? '-');
$os_adminGeneralCost    = htmlspecialchars($db_data['adminGeneralCost'] ?? '-');
$os_totalAdminCost      = htmlspecialchars($db_data['totalAdminCost'] ?? '-');
$os_netProfit           = htmlspecialchars($db_data['netProfit'] ?? '-');

$os_basicRelief         = htmlspecialchars($db_data['basicRelief'] ?? '-');
$os_spouse_relief       = htmlspecialchars($db_data['spouse_relief'] ?? '-');
$os_parent_relief       = htmlspecialchars($db_data['parent_relief'] ?? '-');
$os_child_relief        = htmlspecialchars($db_data['child_relief'] ?? '-');
$os_totalRelief         = htmlspecialchars($db_data['totalRelief'] ?? '-');

$os_finalTaxableIncome  = htmlspecialchars($db_data['finalTaxableIncome'] ?? '-');
$os_payableIncomeTax    = htmlspecialchars($db_data['payableIncomeTax'] ?? '-');
$os_advanceTax          = htmlspecialchars($db_data['advancePaidTax'] ?? '-');
$os_finalBalanceTax     = htmlspecialchars($db_data['finalBalanceTax'] ?? '-');
$os_itpanaty            = htmlspecialchars($db_data['itpanaty'] ?? '-');
$os_taxpanaty           = htmlspecialchars($db_data['taxpanaty'] ?? '-');
$os_taxpanatyPaid       = htmlspecialchars($db_data['taxpanatyPaid'] ?? '-');
$os_itchalanNo          = htmlspecialchars($db_data['itchalanNo'] ?? '-');
$os_itchalanDate        = htmlspecialchars($db_data['itchalanDate'] ?? '-');

$os_summary             = htmlspecialchars($db_data['summary'] ?? '-');
$os_appraisal           = htmlspecialchars($db_data['appraisal'] ?? '-');


?>




<style>
/* ==========================================================================
   🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် တကယ့် A4 ကဲ့သို့ ဗဟိုကျကျပေါ်စေရန်)
   ========================================================================== */
#Form_regularculateModal .modal-dialog {
    max-width: 795px !important; 
    width: 95% !important;
    margin: 20px auto !important;
    position: relative; /* 🎯 Close Button ကို ပုံသေနေရာချရန် အရေးကြီးပါသည် */
}

#Form_regularculateModal .modal-content {
    background-color: #9ecaeb !important; /* အစ်ကိုကြီး ရွေးချယ်ထားသော အပြာနုရောင်နောက်ခံ */
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}

#Form_regularculateModal .modal-body {
    padding: 20px !important; 
    overflow-x: auto !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
    justify-content: center !important;
}

/* 🎯 ညာဘက်ထိပ်တွင် အနီရောင် X ခလုတ် ပေါ်စေရန် စတိုင် */
.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 36px !important;
    background-color: #dc3545 !important; /* အနီရောင် */
    color: #ffffff !important; /* အဖြူရောင် X */
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 36px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; /* မိုဒယ်စာမျက်နှာထက် အပေါ်စီးတွင် ရှိနေစေရန် */
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}

.custom-close-btn:hover {
    background-color: #bd2130 !important; /* Hover လုပ်လျှင် အနီရောင် ပိုရင့်သွားစေရန် */
}

/* 🎯 ကွန်ပျူတာပေါ်တွင် မြင်ရမည့် A4 စာရွက်ပုံစံအစစ် */
.print-container { 
    background: #ffffff !important;
    width: 210mm !important; 
    min-height: 297mm !important; 
    padding: 5mm 5mm 5mm 15mm !important; 
    margin: 0 auto 20px auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}

/* ဇယားများ ညာဘက်လုံးဝမကျွံစေရန် ထိန်းချုပ်မှု */
table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}

table, tr, td { 
    box-sizing: border-box !important;
}

/* ခလုတ်များရှိသော နေရာကို စာရွက်အထက်တွင် လှပစွာ ဗဟိုညှိပေးခြင်း */
.no-print-buttons {
    display: flex !important;
    justify-content: center !important;
    gap: 10px !important;
    margin-bottom: 30px !important;
    width: 100% !important;
}

/* 🎯 ခေါင်းစီးစာသားကို ဆိုက်ကြီးပြီး ညာဘက်သို့ လှပစွာ တွန်းရွှေ့ပေးခြင်း */
.custom-modal-title {
    font-size: 20px !important; 
    font-weight: bold !important; 
    color: #0a1a2b !important; 
    padding-left: 25px !important; 
    display: inline-block !important;
    line-height: 10px !important; 
}

.no-print-bottoms {
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    gap: 15px !important;
    margin-top: 0px !important;    
    margin-bottom: 30px !important;
    width: 100% !important;
}

.no-print-bottoms .btn {
    font-size: 16px !important;         
    font-weight: bold !important;     
    padding: 10px 24px !important;    
    border-radius: 5px !important;    
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important; 
    transition: all 0.2s ease-in-out !important;
}

.no-print-bottoms .btn:hover {
    transform: translateY(-1.5px) !important; 
    box-shadow: 0 6px 11.5px rgba(0, 0, 0, 0.2) !important;
}
#Form_regularculateModal .modal-header {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    background-color: #55bbee !important; /* လိုအပ်ပါက အရောင်ဆက်ထားရန် */
}



/* 🖨️ PRINT ထုတ်လျှင် X ခလုတ်ကိုပါ အလိုအလျောက် ဖျောက်ရန် */
@media print {
    .custom-close-btn { display: none !important; }
}

/* ==========================================================================
   🖨️ PRINT ထုတ်ယူသည့်အခါ စတိုင် (ညာဘက်မကျွံဘဲ အနားသတ်ကွက်တိဖြစ်စေမည့်စနစ်)
   ========================================================================== */
@media print {
    /* ၁။ မလိုအပ်သော ခလုတ်များနှင့် ခေါင်းစည်း မိုဒယ်ဘောက်များကို လုံးဝဖျောက်ခြင်း */

    .modal-header, .custom-modal-title, .modal-footer, .no-print, .btn, .btn-close { 
        display: none !important; 
    }
    
    body * { 
        visibility: hidden !important; 
    }
    
    /* ၂။ ပင်မ Modal ကြီးကို စာရွက်အပြည့်အဝ နေရာယူခိုင်းခြင်း */
    #Form_regularculateModal, #Form_regularculateModal * { 
        visibility: visible !important; 
    }
    
    #Form_regularculateModal { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .modal-dialog, .modal-content, .modal-body { 
        margin: 0 !important;
        padding: 0 !important;
        max-width: 100% !important; 
        width: 100% !important;
        border: none !important; 
        box-shadow: none !important;
        background: transparent !important;
    }

    html, body {
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    /* စာရွက် ၂ ရွက်တည်း။ အမြင့်အတင်းထည့်ထားခြင်းက အလွတ်စာရွက် ထပ်ပွင့်စေသည်။ */
    .print-container { 
        width: 100% !important;
        max-width: 100% !important;
        min-height: 0 !important;
        height: auto !important;
        max-height: none !important;
        padding: 5mm 7mm 5mm 20mm !important; 
        margin: 0 !important;
        display: block !important;
        box-sizing: border-box !important;
        page-break-after: auto !important;
        break-after: auto !important;
        page-break-inside: auto !important;
        overflow: visible !important;
        box-shadow: none !important;
        border: none !important;
    }

    .print-container + .print-container {
        page-break-before: always !important;
        break-before: page !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
    }

    /* ၄။ ဇယားများနှင့် အတွင်းစာသားများအားလုံးကို Box-Sizing ထည့်သွင်းခြင်း */
    table, .main-content-table, .main-content-table2, .order-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important; /* ညာဘက်ကျွံခြင်းကို ကာကွယ်ရန် */
    }
    
    table, tr, td { 
        border: none !important; 
        box-sizing: border-box !important;
    }
    
    .print-container table:first-child {
        border: none !important;
    }

    hr { display: none !important; }


    /* ၅။ Browser မူရင်း Margin ကို ပိတ်ပြီး ကျွန်တော်တို့ သတ်မှတ်ချက်အတိုင်း သုံးခြင်း */
    @page {
        size: A4 portrait;
        margin: 0mm !important; /* စာရွက်အနားသတ်ကို ၀ ထားပြီး Padding ဖြင့် ထိန်းချုပ်ခြင်း */
    }
}

/* ==========================================================================
   🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် မြင်ရမည့်ပုံစံ)
   ========================================================================== */
#Form_regularculateModal .modal-dialog {
    max-width: 900px; 
    margin: 5px auto;
}

#Form_regularculateModal .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}
</style>

<script>
    // 🎯 ပိတ်မည်ခလုတ်နှိပ်လျှင် မူလစာမျက်နှာသို့ ပြန်သွားရန်
    function closeAndReturnToDemandList() {
        window.location.href = '../IT_Demand_List.php';
    }

    // စာမျက်နှာပွင့်လာတာနဲ့ ချက်ချင်း အလုပ်လုပ်ရန်
    window.onload = function() {
        console.log("A4 Layout view successfully rendered via PHP data.");
    };
</script>


<div class="modal fade" id="Form_regularculateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="custom-modal-title">အခွန်တွက်ချက်မှုပုံစံ ထုတ်ယူရန်</h5>

                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            <div class="modal-body" style="padding: 0px !important;">

            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <div style="text-align: center; margin-bottom: 10px;">
                        <h6 style="font-weight: bold; font-size: 15px; margin-bottom: 5px;">ကုန်သွယ်လုပ်ငန်းခွန်/ဝင်ငွေခွန် တွက်ချက်မှုပုံစံ</h6>
                    </div>

                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:40%"><b>အမှုတွဲအမှတ်စဉ်( <span id="os_case_number"><?php echo $os_case_number; ?></span> )</b></td>
                            <td style="width:40%; text-align:right;"><b>စည်းကြပ်နှစ်&ensp;</b></td>
                            <td style="width:20%; border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_taxYear"><?php echo $os_taxYear; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်(IT)&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_gir"><?php echo $os_gir; ?></span>/<span id="os_gir_type"><?php echo $os_gir_type; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်(CT1)&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_gir_type_ct1"><?php echo $os_gir_type_ct1; ?></span>/<span id="os_gir_ct1"><?php echo $os_gir_ct1; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်(CT2)&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_gir_type_ct2"><?php echo $os_gir_type_ct2; ?></span>/<span id="os_gir_ct2"><?php echo $os_gir_ct2; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>အခွန်မှူးအမည်&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_officer "><?php echo $os_officer ; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>ရာထူး&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_officer_rank "><?php echo $os_officer_rank ; ?></span></td>
                        </tr>
                    </table>

                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%">၁။</td>
                            <td style="width:20%; text-align:left;"><b>အခွန်ထမ်းအမည်</b></td>
                            <td style="width:5%; text-align:center;">-</td>
                            <td style="width:70%; border-bottom: 1.5px dotted #000 !important; text-align:left;"> <span id="os_name"><?php echo $os_name; ?></span>&ensp;(<span id="os_ph_no "><?php echo $os_ph_no ; ?></span>)</td>
                        </tr>
                        <tr>
                            <td>၂။</td>
                            <td style="text-align:left;"><b>အခွန်ထမ်းလိပ်စာ</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;"> <span id="os_address"><?php echo $os_address; ?></span></td>
                        </tr>
                        <tr>
                            <td>၃။</td>
                            <td style="text-align:left;"><b>လုပ်ငန်းအမျိုးအစား</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;"> <span id="os_biz1"><?php echo $os_biz1; ?></span>/<span id="os_biz2"><?php echo $os_biz2; ?></span></td>
                        </tr>
                        <tr>
                            <td>၄။</td>
                            <td style="text-align:left;"><b>ကြေညာသည့်ဝင်ငွေ</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;"> ဝငခ(<span id="os_declaredIT"><?php echo $os_declaredIT; ?></span>)၊ 
                            ကသခ-၁(<span id="os_declaredCT1"><?php echo $os_declaredCT1; ?></span>)၊
                            ကသခ-၂(<span id="os_declaredCT2"><?php echo $os_declaredCT2; ?></span>)</td>
                        </tr>
                        <tr>
                            <td>၅။</td>
                            <td style="text-align:left;"><b>ကြိုတင်ခွန်</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;"> ဝငခ(<span id="os_advanceTax"><?php echo $os_advanceTax; ?></span>)၊ 
                            ကသခ-၁(<span id="os_advanceTax1"><?php echo $os_advanceTax1; ?></span>)၊
                            ကသခ-၂(<span id="os_advanceTax2"><?php echo $os_advanceTax2; ?></span>)</td>
                        </tr>
                       
                    </table>

                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၆။</td>
                            <td style="width:95%; border: none !important; text-align:left;"><b>လွန်ခဲ့သော(၃)နှစ်စည်းကြပ်မှုမှတ်တမ်း</b></td>
                            
                        </tr>
                    </table>

                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="width:17%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>စည်းကြပ်နှစ်</b></td>
                            <td style="width:19%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>သတ်မှတ်ဝင်ငွေ</b></td>
                            <td style="width:19%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>ဝင်ငွေခွန်</b></td>
                            <td style="width:20%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>သတ်မှတ်ရောင်းရငွေ</b></td>
                            <td style="width:20%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>ကုန်သွယ်လုပ်ငန်းခွန်</b></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"><span id="os_rowYear1"><?php echo $os_rowYear1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"><span id="os_income1"><?php echo $os_income1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"><span id="os_income_tax1"><?php echo $os_income_tax1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"> <span id="os_sale_income1"><?php echo $os_sale_income1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"> <span id="os_ct1"><?php echo $os_ct1; ?></span></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center; "><span id="os_rowYear2"><?php echo $os_rowYear2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income2"><?php echo $os_income2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income_tax2"><?php echo $os_income_tax2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_sale_income2"><?php echo $os_sale_income2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_ct2"><?php echo $os_ct2; ?></span></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"><span id="os_rowYear3"><?php echo $os_rowYear3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income3"><?php echo $os_income3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income_tax3"><?php echo $os_income_tax3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_sale_income3"><?php echo $os_sale_income3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_ct3"><?php echo $os_ct3; ?></span></td>
                        </tr>
                    </table>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၇။</td>
                            <td style="width:95%; border: none !important; text-align:left;"><b>အခွန်ထမ်း၏လုပ်ငန်းနှင့်ပတ်သက်၍ တင်ပြချက်</b></td>
                            
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td style="width:95%; border: none !important; text-align:left;">
                                <?php 
                                // 🎯 trim() သုံးပြီး အလွတ် (သို့မဟုတ်) null ဖြစ်နေသလားလို့ စိတ်ချရအောင် စစ်လိုက်ပါတယ်ဗျာ
                                if (empty($os_summary) || trim($os_summary) == "") { 
                                ?>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................
                                <?php 
                                } else { 
                                ?>
                                    
                                        <span style="padding-left:40px; text-align:justify; " id="os_summary">
                                            <?php echo $os_summary; ?>
                                        </span>
                                    
                                <?php 
                                } // အပိတ် 
                                ?>

                            </td>
                            
                        </tr>
                    </table>
                   
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၈။</td>
                            <td style="width:95%; border: none !important; text-align:left;"><b>အခွန်မှူး၏ သုံးသပ်တင်ပြချက်</b></td>
                            
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td style="width:95%; border: none !important; text-align:left;">
                                <?php 
                                // 🎯 trim() သုံးပြီး အလွတ် (သို့မဟုတ်) null ဖြစ်နေသလားလို့ စိတ်ချရအောင် စစ်လိုက်ပါတယ်ဗျာ
                                if (empty($os_appraisal) || trim($os_appraisal) == "") { 
                                ?>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................
                                
                                <?php 
                                } else { 
                                ?>
                                        <span style="padding-left:40px; text-align:justify;" id="os_appraisal">
                                            <?php echo $os_appraisal; ?>
                                        </span>
                                <?php 
                                } // အပိတ် 
                                ?>
                            </td>
                            
                        </tr>
                    </table>
                    
                    <?php 
                    if ($os_salesAmount2=="0" ) { 
                    ?>
                    <p style="text-align:center;"><b>ကုန်သွယ်လုပ်ငန်းခွန် တွက်ချက်မှု</b></P>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၉။</td>
                            <td style="width:50%; border: none !important; text-align:right;"></td>

                            <td colspan="2" style="width:24%; text-align:right;"><b><span id="os_biz1"><?php echo $os_biz1; ?></span></b></td>

                            <td style="width:19%; border: none !important; text-align:left;"></td>
                        </tr>
                        
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td style="width:5%; border: none !important; text-align:right;">သတ်မှတ်ရောင်းရငွေ</td>
                            <td style="width:5%; border: none !important; text-align:center;">=</td>
                            <td style="width:19%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_salesAmount1"><?php echo $os_salesAmount1; ?></span></td>

                            <td style="width:19%; border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="wborder: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;">ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_sct1tax"><?php echo $os_ct1tax; ?></span></td>

                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="wborder: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;">စည်းမျဉ်း-၄၂ အရ ခုနှိမ်သောအခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_rule42_1"><?php echo $os_rule42_1; ?></span></td>

                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="wborder: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;">ပေးဆောင်ရမည့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_afterRuler1"><?php echo $os_afterRuler1; ?></span></td>

                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                    </table>
                    <br><br>                     
                    <?php 
                    } else { 
                    ?>
                    <p style="text-align:center;"><b>ကုန်သွယ်လုပ်ငန်းခွန် တွက်ချက်မှု</b></P>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၉။</td>
                            <td style="width:41%; border: none !important; text-align:right;"></td>

                            <td colspan="2" style="width:24%; text-align:right;"><b><span id="os_biz1"><?php echo $os_biz1; ?></span></b></td>

                            <td colspan="2" style="width:24%; text-align:right;"><b><span id="os_biz2"><?php echo $os_biz2; ?></span></b></td>
                            <td style="width:6%; border: none !important; text-align:left;"></td>
                        </tr>
                        
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td style="width:41%; border: none !important; text-align:right;">သတ်မှတ်ရောင်းရငွေ</td>
                            <td style="width:5%; border: none !important; text-align:center;">=</td>
                            <td style="width:19%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_salesAmount1"><?php echo $os_salesAmount1; ?></span></td>
                            <td style="width:5%; border: none !important; text-align:center;">=</td>
                            <td style="width:19%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_salesAmount2"><?php echo $os_salesAmount2; ?></span></td>
                            <td style="width:6%; border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="wborder: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;">ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_sct1tax"><?php echo $os_ct1tax; ?></span></td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_ct2tax"><?php echo $os_ct2tax; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="wborder: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;">စည်းမျဉ်း-၄၂ အရ ခုနှိမ်သောအခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_rule42_1"><?php echo $os_rule42_1; ?></span></td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_rule42_2"><?php echo $os_rule42_2; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="wborder: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;">ပေးဆောင်ရမည့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_afterRuler1"><?php echo $os_afterRuler1; ?></span></td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_afterRuler2"><?php echo $os_afterRuler2; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                    </table>
                    <br><br>
                    <?php 
                    } // အပိတ် 
                    ?>
                    

                    
                     
                    <table style='width:100%; margin-top:30px; border:none !important;font-size:15px;'>
                        <tr>
                            <td style='width:50%; padding-left:100px'></td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br><span id="os_township_name"><?php echo $os_township_name; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div class="print-container">
                    <p style="text-align:center; margin-top:0;"><br><br><br><b>ဝင်ငွေခွန် တွက်ချက်မှု</b></p>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        
                          <?php 
                    if ($os_salesAmount2=="" || $os_biz2=="") { 
                    ?>  <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၁၀။</td>
                            <td colspan="2" style="width:60%; border: none !important; text-align:left;"><b>သတ်မှတ်ရောင်းရငွေ</b></td>
                            
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                            <td style="width:10%; border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="border: none !important; text-align:left;"></td>
                            <td colspan="2" style="width:60%; text-align:right;"><b>စုစုပေါင်းသတ်မှတ်ရောင်းရငွေ</b></td>
                          
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_totalSales"><?php echo $os_totalSales; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <?php 
                        } else { 
                        ?>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၁၀။</td>
                            <td colspan="2" style="width:60%; border: none !important; text-align:left;"><b>သတ်မှတ်ရောင်းရငွေ</b></td>
                            
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                            <td style="width:10%; border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td colspan="2" style="width:60%; border: none !important; text-align:right;"><span id="os_biz1"><?php echo $os_biz1; ?></span>မှရောင်းရငွေ</td>
                         
                            <td style="width:5%; border: none !important; text-align:center;">=</td>
                            <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_salesAmount1"><?php echo $os_salesAmount1; ?></span></td>
                            <td style="width:10%; border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="border: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;"></td>
                            <td style="text-align:right;"><span id="os_biz2"><?php echo $os_biz2; ?></span>မှရောင်းရငွေ</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_salesAmount2"><?php echo $os_salesAmount2; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="border: none !important; text-align:left;"></td>
                            <td colspan="2" style="width:60%; text-align:right;"><b>စုစုပေါင်းသတ်မှတ်ရောင်းရငွေ</b></td>
                          
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_totalSales"><?php echo $os_totalSales; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>

                        <?php 
                        } // အပိတ် 
                        ?>
                        <tr>
                            <td style="border: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;"></td>
                            <td style="text-align:right;">(နုတ်) ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;color:red;"><span id="os_minusCTInput"><?php echo $os_minusCTInput; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="border: none !important; text-align:left;"></td>
                            <td colspan="2" style="width:60%; text-align:right;">ကုန်သွယ်လုပ်ငန်းခွန်မပါရောင်းရငွေ</td>
                          
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1px dotted #000 !important; text-align:right;"><span id="$os_netSales "><?php echo $os_netSales ; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="border: none !important; text-align:left;"></td>
                            <td colspan="2" style="width:60%; text-align:right;"><span id="os_otherIncomeTitle"><?php echo $os_otherIncomeTitle; ?></span>(အခြားရငွေ)</td>

                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_otherIncomeVal"><?php echo $os_otherIncomeVal; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="border: none !important; text-align:left;"></td>
                            <td style="border: none !important; text-align:right;"></td>
                            <td style="text-align:right;"><b>ဝင်ငွေခွန်တွက်ချက်ရန်ရောင်းရငွေ</b></td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_taxableSales"><?php echo $os_taxableSales; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        </table>
                        <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;">၁၁။</td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:left;"><b>(နုတ်)တိုက်ရိုက်ကုန်ကျစရိတ်</b></td>
                               
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; text-align:right;"></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%;  text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">ကုန်စည်နှင့်ဝန်ဆောင်မှုစရိတ်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_purchaseCost"><?php echo $os_purchaseCost; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: 0px dotted #000 !important; text-align:right;">အခြားရငွေစရိတ်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1.5px dotted #000 !important; text-align:right;"><span id="os_otherDirectCost"><?php echo $os_otherDirectCost; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="4" style="width:65%; border: none !important; text-align:right;">စုစုပေါင်းတိုက်ရိုက်ကုန်ကျစရိတ်</td>

                               
                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_totalDirectCost"><?php echo $os_totalDirectCost; ?></span></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="4" style="width:65%; border: none !important; text-align:right;"><b>အကြမ်းအမြတ်</b></td>

                               
                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 0px solid #000 !important; text-align:right;"><span id="os_grossProfit"><?php echo $os_grossProfit; ?></span></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>

                             <tr>
                                <td style="width:5%; border: none !important; text-align:left;">၁၂။</td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:left;"><b>(နုတ်)စီမံရေးရာနှင့်အုပ်ချုပ်မှုစရိတ်</b></td>
                               
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; text-align:right;"></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%;  text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">ဝန်ထမ်းလစာ</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_salaryCost"><?php echo $os_salaryCost; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">လုပ်ငန်းလိုင်စင်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_licence"><?php echo $os_licence; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">ဆိုင်ခန်းဌားရမ်းခ</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_shopRent"><?php echo $os_shopRent; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">လျှပ်စစ်မီတာခ</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_electricity"><?php echo $os_electricity; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">လူမှုဖူလုံရေးရန်ပုံငွေ</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_socialWelfare"><?php echo $os_socialWelfare; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                                  <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: 0px dotted #000 !important; text-align:right;">အထွေထွေစရိတ်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1.5px dotted #000 !important; text-align:right;"><span id="os_adminGeneralCost"><?php echo $os_adminGeneralCost; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="4" style="width:65%; border: none !important; text-align:right;">စုစုပေါင်းစီမံရေးရာနှင့်အုပ်ချုပ်မှုစရိတ်</td>

                               
                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_totalAdminCost"><?php echo $os_totalAdminCost; ?></span></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="4" style="width:65%; border: none !important; text-align:right;"><b>အသားတင်အမြတ်</b></td>

                               
                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 0px solid #000 !important; text-align:right;"><span id="os_netProfit"><?php echo $os_netProfit; ?></span></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>

                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;">၁၃။</td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:left;"><b>(နုတ်) ပုဒ်မ ၆ အရ သက်သာခွင့်ပြုငွေများ</b></td>
                               
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; text-align:right;"></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%;  text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">အခြေခံသက်သာခွင့်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_basicRelief"><?php echo $os_basicRelief; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">အတူနေမိဘအတွက်သက်သာခွင့်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_parent_relief"><?php echo $os_parent_relief; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border: none !important; text-align:right;">အိမ်ထောင်ဖက်အတွက်သက်သာခွင့်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_spouse_relief"><?php echo $os_spouse_relief; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="2" style="width:40%; border:0px dotted #000 !important;  text-align:right;">သားသမီးအတွက်သက်သာခွင့်</td>

                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1.5px dotted #000 !important; text-align:right;"><span id="os_child_relief"><?php echo $os_child_relief; ?></span></td>
                                <td style="width:5%; border: none !important; text-align:center;"></td>
                                <td style="width:15%; border-bottom: 0px dotted #000 !important; text-align:right;"></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="4" style="width:65%; border: none !important; text-align:right;">စုစုပေါင်းသက်သာခွင့်</td>

                               
                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_totalRelief"><?php echo $os_totalRelief; ?></span></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                            <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="4" style="width:65%; border: none !important; text-align:right;">အခွန်စည်းကြပ်ရန်ဝင်ငွေ</td>

                               
                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_finalTaxableIncome"><?php echo $os_finalTaxableIncome; ?></span></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                             <tr>
                                <td style="width:5%; border: none !important; text-align:left;"></td>
                                <td colspan="4" style="width:65%; border: none !important; text-align:right;"><b>ကျသင့်ဝင်ငွေခွန်</b></td>

                               
                                <td style="width:5%; border: none !important; text-align:center;">=</td>
                                <td style="width:15%; border-bottom: 1px dotted #000 !important; text-align:right;"><span id="os_payableIncomeTax"><?php echo $os_payableIncomeTax; ?></span></td>
                                <td style="width:10%; border: none !important; text-align:left;"></td>
                            </tr>
                    </table>
                    <br><br><br><br><br>
                    <table style='width:100%; margin-top:18px; border:none !important;font-size:15px;'>
                        <tr>
                            <td style='width:50%; padding-left:100px'></td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br><span id="os_township_name"><?php echo $os_township_name; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                    <br><br><br><br>
                </div>
            </div>
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn px-4" onclick="window.print()" 
                        style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                    <i class="fa fa-print"></i> Print ထုတ်မည်
                </button>
                <button type="button" class="btn px-4" 
                        onclick="window.location.href='../IT_demand_list.php?openModal=formsModal2';" 
                        style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                    ပိတ်မည်
                </button>
            </div>
        </div>
    </div>
</div>
<script>
function openForregular() {
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြအောင် နှိပ်ပါ)။");
        return; 
    }
    
    console.log("Selected Row Data:", selectedRowData);

    // ၂။ Helper Functions
    const toMyanmarDigit = (num) => {
        if (!num) return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    const mmMonths = ['ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ'];

    // ၃။ Login User ရဲ့ Other Data
    const loginUserOther = "<?php echo $user_other_info; ?>"; 
    console.log("ရရှိလာသော Other Data:", loginUserOther);
    setText('regular_other_data', loginUserOther || '......');

    // ၄။ အခြေခံအချက်အလက်များ (🎯 ပင်မ Table နှင့် ကိုက်ညီအောင် Variable နာမည်များ ညှိလိုက်ပါပြီ)
    setText('regular_name', selectedRowData.taxpayer_name);
    setText('regular_address', selectedRowData.address);
    setText('regular_biz', selectedRowData.business_type || selectedRowData.businessType1);
    setText('regular_biz_detail', selectedRowData.business_type || selectedRowData.businessType2);
    setText('regular_township', selectedRowData.township_name || selectedRowData.state_name);
    
    let yearVal = selectedRowData.tax_year || selectedRowData.taxYear || '';
    setText('regular_year', toMyanmarDigit(yearVal));

    // ၅။ ရက်စွဲပိုင်းဆိုင်ရာ Process လုပ်ခြင်း
    const processDate = (dateStr, prefix) => {
        if (dateStr && dateStr.includes('-')) {
            const parts = dateStr.split('-');
            const yyyy = parts[0]; 
            const mm = parts[1];   
            const dd = parts[2].split(' ')[0];

            setText(prefix + '_year', toMyanmarDigit(yyyy));
            setText(prefix + '_month', mmMonths[parseInt(mm) - 1]);
            setText(prefix + '_day', toMyanmarDigit(dd));
            
            if (prefix === 'orDate') {
                setText('orDate_year_short', toMyanmarDigit(yyyy.slice(-2)));
                setText('regular_orDate', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            } else if (prefix === 'appDate') {
                setText('regular_appDate', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            }
        } else {
            setText(prefix + '_year', '....');
            setText(prefix + '_month', '....');
            setText(prefix + '_day', '....');
        }
    };

    // 🎯 ပင်မ Table Row မှ လာသော ရက်စွဲစာလုံးပေါင်းများနှင့် ကွက်တိညှိခြင်း
    let orderD = selectedRowData.order_date || selectedRowData.orderDate || selectedRowData.it_demand_date;
    let appD = selectedRowData.appointment_date || selectedRowData.appointmentDate;

    processDate(orderD, 'orDate');
    processDate(appD, 'appDate');

    // ၆။ Modal ကို ဖွင့်ခြင်း (🎯 HTML ID နှင့် ကိုက်ညီအောင် 'regularculateModal' ဟု ပြင်ဆင်လိုက်ပါပြီ)
    var modalElem = document.getElementById('Formregular_regularculateModal');
    if (modalElem) {
        var myModal = new bootstrap.Modal(modalElem);
        myModal.show();
    } else {
        console.error("Modal element 'Formregular_regularculateModal' ကို ရှာမတွေ့ပါဗျာ။");
    }
}
</script>
