<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}

if (!isset($conn)) {
    die('Database Connection Error: $conn variable is not defined.');
}
$conn->set_charset('utf8mb4');

function toMMNum($num, $showComma = true) {
    if ($num === null || $num === '') {
        return '';
    }
    $mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
    $s = $showComma ? number_format((float)$num) : (string)$num;
    return preg_replace_callback('/\d/', function ($matches) use ($mDigits) {
        return $mDigits[$matches[0]];
    }, $s);
}

function mmDate($date) {
    if (empty($date) || $date === '0000-00-00' || !strtotime($date)) {
        return '............';
    }
    return toMMNum(date('d-m-Y', strtotime($date)), false);
}

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];
if ($row_id > 0) {
    $stmt = $conn->prepare('SELECT * FROM regular_data WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $row_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
    $stmt->close();
}

$office_township = $_SESSION['township_name'] ?? '';
$u_id = intval($_SESSION['user_id'] ?? 0);
if ($u_id > 0) {
    $user_stmt = $conn->prepare('SELECT township_name FROM user_register WHERE id = ? LIMIT 1');
    if ($user_stmt) {
        $user_stmt->bind_param('i', $u_id);
        $user_stmt->execute();
        $user_res = $user_stmt->get_result();
        if ($user_res && $user_row = $user_res->fetch_assoc()) {
            if (!empty($user_row['township_name'])) {
                $office_township = $user_row['township_name'];
            }
        }
        $user_stmt->close();
    }
}
if ($office_township === '') {
    $office_township = $db_data['township_name'] ?? '';
}
if ($office_township !== '' && mb_strpos($office_township, 'အခွန်ဦးစီးဌာနမှူးရုံး') === false) {
    $office_township .= 'အခွန်ဦးစီးဌာနမှူးရုံး';
}

$taxpayer_name = $db_data['taxpayer_name'] ?? '';
$address = $db_data['address'] ?? '';
$business1 = $db_data['businessType1'] ?? '';
$business2 = $db_data['businessType2'] ?? '';
$it_select = trim($db_data['it_select'] ?? '');
$it_no = trim($db_data['it_no'] ?? '');
$tin = $it_no;
if ($it_select !== '') {
    $tin = $tin === '' ? $it_select : $it_no . ' / ' . $it_select;
}
$ct1_select = trim($db_data['ct1_select_real'] ?? '');
$ct2_select = trim($db_data['ct2_select_real'] ?? '');
if ($ct1_select === $ct2_select || $business2 === '') {
    $business_line = $business1;
} else {
    $business_line = trim($business1 . ' / ' . $business2, ' /');
}
$declared = $db_data['declaredIncome1'] ?? '';
$advance = $db_data['advancePaidTax'] ?? '';
$tax_year = $db_data['taxYear'] ?? '';
$officer_name = $db_data['officer_name'] ?? '';
$rank = $db_data['rank_'] ?? '';

$std = '............';
$etd = '............';
if ($tax_year !== '') {
    $by_stmt = $conn->prepare('SELECT start_date1, end_date1 FROM budget_year WHERE budget_year = ? LIMIT 1');
    if ($by_stmt) {
        $by_stmt->bind_param('s', $tax_year);
        $by_stmt->execute();
        $by_res = $by_stmt->get_result();
        if ($by_res && $by_row = $by_res->fetch_assoc()) {
            $std = mmDate($by_row['start_date1'] ?? '');
            $etd = mmDate($by_row['end_date1'] ?? '');
        }
        $by_stmt->close();
    }
}
if (($std === '............' || $etd === '............') && strpos($tax_year, '-') !== false) {
    $years = explode('-', $tax_year);
    if (count($years) === 2) {
        $start_year = intval($years[0]) - 1;
        $end_year = intval($years[1]) - 1;
        $std = toMMNum('01-04-' . $start_year, false);
        $etd = toMMNum('31-03-' . $end_year, false);
    }
}

function incomeCell($selected, $label, $amount) {
    if ($selected !== $label || $amount === '' || $amount === null) {
        return '&nbsp;';
    }
    return h(toMMNum($amount));
}

$part_a_labels = ['လစာ', 'သက်မွေး', 'စီးပွား', 'ပစ္စည်း', 'အခြေ', 'အခြား'];
$part_a_total = in_array($it_select, $part_a_labels, true) ? h(toMMNum($declared)) : '&nbsp;';
$advance_text = ($advance === '' || $advance === null) ? '&nbsp;' : h(toMMNum($advance));
$tax_year_text = $tax_year !== '' ? h(toMMNum($tax_year, false)) : '............';
?>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ပတခ(ဝင)-၀၃-၀၁(ဂ) ဝင်ငွေကြေညာလွှာ</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #d9dde2;
            font-family: "Pyidaungsu", "Myanmar Text", sans-serif;
            color: #000;
        }
        .sheet {
            width: 210mm;
            min-height: 297mm;
            margin: 12px auto;
            padding: 8mm 10mm 10mm 12mm;
            background: #fff;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.25);
        }
        .sheet, .sheet table, .sheet td, .sheet p {
            font-size: 15px;
            line-height: 1.7;
        }
        table { width: 100%; border-collapse: collapse; }
        td { vertical-align: top; }
        .banner {
            border: 1px solid #000;
            text-align: center;
            padding: 5px 8px;
        }
        .form-code { text-align: right; margin: 6px 0; }
        .title { text-align: center; font-weight: bold; margin: 4px 0 8px; }
        .dotted { border-bottom: 1.5px dotted #000; }
        .money { text-align: center; }
        .grid { border: 1.5px solid #000; border-collapse: collapse; }
        .grid td { border: none; }
        .grid .money { border-left: 1.5px solid #000; }
        .grid tr.head td { border-bottom: 1px solid #000; }
        .grid tr.line td { border-top: 1.5px solid #000; border-bottom: 1.5px solid #000; }
        .grid tr.band td { border-bottom: 1.5px solid #000; }
        .grid tr.line-top td { border-top: 1.5px solid #000; }
        .child-grid { width: 100%; border-collapse: separate; border-spacing: 0; }
        .child-grid td {
            border-top: 1px solid #000;
            border-bottom: 1px solid #000;
            border-left: 1px solid #000;
            border-right: 1px solid #000;
            text-align: center;
            vertical-align: middle;
            padding: 4px 2px;
        }
        .child-grid tr.blank td { height: 72px; }
        .left-gap { width: 7%; }
        .page-no { text-align: center; margin: 8px 0; }
        .justify { text-align: justify; }
        .no-print-bottoms {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin: 0 auto 30px;
            width: 210mm;
        }
        .no-print-bottoms button {
            font-family: "Pyidaungsu", "Myanmar Text", sans-serif;
            font-size: 16px;
            font-weight: bold;
            padding: 10px 24px;
            border-radius: 5px;
            cursor: pointer;
            color: #fff;
            border: 1px solid #222;
        }
        .btn-print { background: #28a745; }
        .btn-close { background: #dc3545; }
        .stamp {
            display: inline-block;
            border: 1px solid #000;
            border-radius: 50%;
            padding: 18px 10px;
            text-align: center;
        }
        @media print {
            body { background: #fff; }
            .no-print { display: none !important; }
            .sheet {
                width: auto;
                min-height: 0;
                margin: 0;
                padding: 5mm 10mm 8mm 10mm;
                box-shadow: none;
            }
            .sheet, .sheet table, .sheet td, .sheet p {
            font-size: 15px;
            line-height: 1.75;
             }
            .new-page {
                break-before: page;
                page-break-before: always;
            }
            .banner { border: 1.5px solid #000 !important; }
            .dotted { border-bottom: 2px dotted #000 !important; }
            .grid { border: 1.5px solid #000 !important; }
            .grid .money { border-left: 1.5px solid #000 !important; }
            .grid tr.head td { border-bottom: 1px solid #000 !important; }
            .grid tr.line td { border-top: 1px solid #000 !important; border-bottom: 1.5px solid #000 !important; }
            .grid tr.band td { border-bottom: 1px solid #000 !important; }
            .grid tr.line-top td { border-top: 1px solid #000 !important; }
            .child-grid td {
                border-top: 1px solid #000 !important;
                border-bottom: 1px solid #000 !important;
                border-left: 1px solid #000 !important;
                border-right: 1px solid #000 !important;
                text-align: center !important;
                vertical-align: middle !important;
            }
            @page { size: A4 portrait; margin: 0; }
        }
    </style>
</head>
<body>
    <div class="sheet" id="wangaSheet">
        <table>
            <tr>
                <td class="left-gap"></td>
                <td class="banner">၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။</td>
            </tr>
        </table>
        <p class="form-code">ပတခ(ဝင)-၀၃-၀၁(ဂ)</p>
        <p class="title">အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၂၊ ပုဒ်မခွဲ(က)နှင့် ဝင်ငွေခွန်ဥပဒေ ပုဒ်မ ၁၇၊ ပုဒ်မခွဲ(က)တို့အရ<br>တစ်ဦးချင်းပုဂ္ဂိုလ်အခွန်ထမ်းများက ပေးပို့ရမည့် ဝင်ငွေကြေညာလွှာ</p>

        <table>
            <tr>
                <td class="left-gap"></td>
                <td style="width:33%"><strong>အမည်</strong></td>
                <td class="dotted" style="width:60%"><?php echo h($taxpayer_name); ?></td>
            </tr>
            <tr>
                <td></td>
                <td><strong>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်(TIN/GIR)</strong></td>
                <td class="dotted"><?php echo h($tin); ?></td>
            </tr>
            <tr>
                <td></td>
                <td><strong>အလုပ်အကိုင် သို့မဟုတ် လုပ်ငန်း</strong></td>
                <td class="dotted"><?php echo h($business_line); ?></td>
            </tr>
            <tr>
                <td></td>
                <td><strong>လိပ်စာအပြည့်အစုံ</strong></td>
                <td class="dotted"><?php echo h($address); ?></td>
            </tr>
            <tr>
                <td></td>
                <td colspan="2">၁။&emsp;<?php echo h($std); ?> မှ <?php echo h($etd); ?> ထိ ကာလအတွင်း ရရှိသည့် ဝင်ငွေစာရင်း။</td>
            </tr>
        </table>

        <table style="margin-top:6px;">
            <tr>
                <td class="left-gap"></td>
                <td>
                    <table class="grid">
                        <tr class="head">
                            <td colspan="3" style="width:70%; text-align:center;">ဝင်ငွေခေါင်းစဉ်</td>
                            <td class="money" style="width:30%">ဝင်ငွေ<br>(ကျပ်)</td>
                        </tr>
                        <tr>
                            <td style="width:12%; text-align:center;"><strong>အပိုင်း(က)</strong></td>
                            <td colspan="2">ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံအတွင်း ရရှိသည့်ဝင်ငွေ-</td>
                            <td class="money">&nbsp;</td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td style="width:6%">(၁)</td>
                            <td>လစာ</td>
                            <td class="money"><?php echo incomeCell($it_select, 'လစာ', $declared); ?></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>(၂)</td>
                            <td>အသက်မွေးဝမ်းကျောင်းပညာလုပ်ငန်းမှ ဝင်ငွေ</td>
                            <td class="money"><?php echo incomeCell($it_select, 'သက်မွေး', $declared); ?></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>(၃)</td>
                            <td>စီးပွားရေးလုပ်ငန်းမှ ဝင်ငွေ</td>
                            <td class="money"><?php echo incomeCell($it_select, 'စီးပွား', $declared); ?></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>(၄)</td>
                            <td>ပစ္စည်းငှားရမ်းခ ဝင်ငွေ</td>
                            <td class="money"><?php echo incomeCell($it_select, 'ပစ္စည်း', $declared); ?></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>(၅)</td>
                            <td>အခြေပစ္စည်းမှ မြတ်စွန်းငွေ</td>
                            <td class="money"><?php echo incomeCell($it_select, 'အခြေ', $declared); ?></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>(၆)</td>
                            <td>စည်းကြပ်မှုမှလွှတ်ကင်းနေသော ဝင်ငွေ</td>
                            <td class="money">&nbsp;</td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>(၇)</td>
                            <td>အခြားရလမ်းများမှ ဝင်ငွေ</td>
                            <td class="money"><?php echo incomeCell($it_select, 'အခြား', $declared); ?></td>
                        </tr>
                        <tr>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td class="money">&nbsp;</td>
                        </tr>
                        <tr class="line">
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td style="text-align:center;"><strong>အပိုင်း(က)အတွက် စုစုပေါင်း</strong></td>
                            <td class="money"><?php echo $part_a_total; ?></td>
                        </tr>
                        <tr class="band">
                            <td style="text-align:center;"><strong>အပိုင်း(ခ)</strong></td>
                            <td colspan="2">အပိုင်း(က)တွင်မပါဝင်သော ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံပြင်ပတွင် ရရှိသည့်ဝင်ငွေနှင့်မြတ်စွန်းငွေ</td>
                            <td class="money">&nbsp;</td>
                        </tr>
                        <tr class="line-top">
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td style="text-align:center;"><strong>အပိုင်း( ခ )အတွက် စုစုပေါင်း</strong></td>
                            <td class="money">&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>

        <table style="margin-top:10px;">
            <tr>
                <td class="left-gap"></td>
                <td style="width:7%">၂။</td>
                <td style="width:5%">(က)</td>
                <td style="width:51%">ဝင်ငွေနှစ်အတွင်း ပေးသွင်းပြီးသည့်ဝင်ငွေခွန်</td>
                <td class="dotted money" style="width:30%"><?php echo $advance_text; ?></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>( ခ )</td>
                <td>ဝင်ငွေနှစ်အတွင်း ပေးသွင်းပြီးသည့် အသက်အာမခံပရီမီယံငွေ</td>
                <td class="dotted">&nbsp;</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>( ဂ )</td>
                <td>ဝင်ငွေနှစ်အတွင်း ပေးသွင်းပြီးသည့် လူမှုဖူလုံရေးရန်ပုံငွေ</td>
                <td class="dotted">&nbsp;</td>
            </tr>
        </table>

        <table style="margin-top:10px;">
            <tr>
                <td class="left-gap"></td>
                <td class="justify">၃။&emsp;&emsp;<strong><?php echo h($etd); ?></strong>&emsp;နေ့ 
                ကုန်ဆုံးသောနှစ်အတွင်း မိမိနှင့်အတူနေသည့် သို့မဟုတ် မိမိက စရိတ်ထောက်ပံ့ထားသည့် အိမ်ထောင်ဖက်.........................................သည် အဆိုပါနှစ်အတွင်း ဝင်ငွေခွန်ထိုက်သင့်သည့် ဝင်ငွေရရှိသူ မဟုတ်ပါ။</td>
            </tr>
            <tr>
                <td></td>
                <td class="justify">၄။&emsp;&emsp;<strong><?php echo h($etd); ?></strong>&emsp;နေ့ 
                ကုန်ဆုံးသောနှစ်အတွင်း မိမိနှင့်အတူနေသည့် မိမိ၏/အိမ်ထောင်ဖက်၏ မိခင်...............<br>................ 
                နှင့် ဖခင်..........................တို့သည် အဆိုပါနှစ်အတွင်း ဝင်ငွေခွန်ထိုက်သင့်သည့် ဝင်ငွေရရှိသူ မဟုတ်ပါ။</td>
            </tr>
            <tr>
                <td></td>
                <td class="justify">၅။&emsp;&emsp;<strong><?php echo h($etd); ?></strong>&emsp;နေ့ ကုန်ဆုံးသောနှစ်အတွင်း မိမိကထောက်ပံ့ရသည့် သားသမီးများ (လင်ပါ၊ မယားပါ သားသမီးနှင့် ဥပဒေတစ်ရပ်ရပ် နှင့်အညီ မွေးစားသည့် သားသမီးအပါအဝင်) မှာ အောက်ပါအတိုင်း ဖြစ်ပါသည်-</td>
            </tr>
        </table>
        <br><br>

  
        <p class="page-no new-page">၂</p><br>
        <table>
            <tr>
                <td class="left-gap"></td>
                <td>
                    <table class="child-grid">
                        <tr>
                            <td style="width:8%;">အမှတ်<br>စဉ်</td>
                            <td style="width:22%;">အမည်</td>
                            <td style="width:14%;">မွေးနေ့<br>သက္ကရာဇ်</td>
                            <td style="width:22%;">ကျောင်းအမည်</td>
                            <td style="width:14%;">အိမ်ထောင်<br>ရှိ/မရှိ</td>
                            <td style="width:20%;">ဝင်ငွေခွန်စည်းကြပ်<br>ထိုက်သည့်<br>ဝင်ငွေရှိ/မရှိ</td>
                        </tr>
                        <tr class="blank">
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                            <td>&nbsp;</td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>

        <p style="text-align:center;">ဝန်ခံချက်များ</p>
        <table>
            <tr>
                <td class="left-gap"></td>
                <td class="justify">&emsp;&emsp;&emsp;အထက်တွင် ဖော်ပြထားချက်များသည် ကျွန်ုပ် ယုံကြည်သိရှိသမျှ မှန်ကန်ပြည့်စုံသည့်အပြင် <strong><?php echo h($std); ?></strong> မှ <strong><?php echo h($etd); ?></strong> အထိကာလအတွင်း ကျွန်ုပ်/ကျွန်ုပ်တို့၏ပုဂ္ဂိုလ်စုတွင် အခြားဝင်ငွေ တစ်စုံတစ်ရာရရှိခဲ့ခြင်း မရှိပါကြောင်းနှင့် ကျွန်ုပ်သည် အဆိုပါ <?php echo h($std); ?> မှ <?php echo h($etd); ?> အထိကာလအတွင်း မြန်မာနိုင်ငံပြင်ပ၌ မနေထိုင်ခဲ့ပါ/ နေထိုင်ခဲ့ပါကြောင်း ဝန်ခံလက်မှတ်ရေးထိုးပါသည်။</td>
            </tr>
        </table>

        <table style="margin-top:8px;">
            <tr>
                <td class="left-gap"></td>
                <td colspan="2" style="width:56%; text-align:center;"><strong>အခကြေးငွေယူ၍ ကြေညာလွှာဖြည့်သွင်းသူ</strong></td>
                <td style="width:11%"></td>
                <td style="width:26%; text-align:center;"><strong>အခွန်ထမ်း</strong></td>
            </tr>
            <?php
            $sign_rows = ['လက်မှတ်', 'အမည်', 'နိုင်ငံသားစိစစ်ရေးကတ်ပြားအမှတ်', 'တာဝန်', 'ဖုန်း၊ email လိပ်စာ', 'ရက်စွဲ'];
            foreach ($sign_rows as $label) :
            ?>
            <tr>
                <td></td>
                <td style="width:30%"><strong><?php echo $label; ?></strong></td>
                <td class="dotted" style="width:26%">&nbsp;</td>
                <td></td>
                <td class="dotted">&nbsp;</td>
            </tr>
            <?php endforeach; ?>
        </table>

        <table style="margin-top:8px;">
            <tr>
                <td class="left-gap"></td>
                <td style="width:10%">မှတ်ချက်။</td>
                <td class="justify">ဝင်ငွေကြေညာလွှာတွင် ဖော်ပြထားသည့် ဝင်ငွေနှင့် ဝန်ခံချက်များကို အောက်ဖော်ပြပါ ပုဂ္ဂိုလ်များက လက်မှတ်ရေးထိုးရမည်-</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>( က ) တစ်ဦးချင်းပုဂ္ဂိုလ်ဖြစ်လျှင် ထိုတစ်ဦးချင်းပုဂ္ဂိုလ် ကိုယ်တိုင်၊</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td>(  ခ ) <span style="padding-left: 2mm;">ပုဂ္ဂိုလ်စုဖြစ်လျှင်</span></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td style="padding-left: 11mm;" class="justify">    (၁) သမဝါယမအသင်းဖြစ်ပါက ထိုအသင်း၏ ဥက္ကဌ သို့မဟုတ် အတွင်းရေးမှုူး၊<br>
                (၂) ကုမ္ပဏီဖြစ်ပါက ထိုကုမ္ပဏီ၏ ကိုယ်စားလှယ်၊ အတွင်းရေးမှူး၊ အထွေထွေမန်နေဂျာ <br><span style="padding-left: 6mm;">သို့မဟုတ် မန်နေဂျာ၊</span><br>
                (၃) အခြားပုဂ္ဂိုလ်စုဖြစ်ပါက ထိုပုဂ္ဂိုလ်စုတွင်ပါဝင်သူ တစ်ဦးဦးကိုယ်တိုင်၊</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class="justify">( ဂ ) <span style="padding-left: 1mm;">နိုင်ငံပိုင်စီးပွားရေးအဖွဲ့အစည်းဖြစ်ပါက စီမံခန့်ခွဲရေးဆိုင်ရာ၊ ငွေစာရင်းဆိုင်ရာ သို့မဟုတ် ဘဏ္ဍာ</span>
                    <span style="padding-left: 11mm;">ရေးဆိုင်ရာ အကြီးအကဲ</span></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class="justify">( ဃ) <span style="padding-left: 1mm;">အခကြေးငွေယူ၍ ကြေညာလွှာအားပြင်ဆင်ပေးရခြင်းဖြစ်ပါက ယင်းပုဂ္ဂိုလ်က အခွန်ကြေညာလွှာ</span>
                    <span style="padding-left: 11mm;">တွင် လက်မှတ်ရေးထိုးရမည်။ အခကြေးငွေယူ၍ ပြင်ဆင်ပေးရခြင်းမရှိပါက လက်မှတ်ရေးထိုးရန် </span>
                    <span style="padding-left: 11mm;">မလိုအပ်ပါ။</span>
                </td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td class="justify">( င ) <span style="padding-left: 2mm;">အခွန်ထမ်းသည် အခွန်ကြေညာလွှာ၏ မှန်ကန်တိကျမှုနှင့်ပြည့်စုံမှုကို တာဝန်ခံရမည်။ အခွန်ထမ်း</span>
                    <span style="padding-left: 11mm;">သည် ဥပဒေအရ မစွမ်းဆောင်နိုင်သူဖြစ်ပါက အခွန်ထမ်း၏ တရားဝင်ကိုယ်စားပြုသူသည် အခွန်
                    <span style="padding-left: 11mm;">ကြေညာလွှာ၏ မှန်ကန်တိကျမှုနှင့် ပြည့်စုံမှုကို တာဝန်ခံရမည်။</span></td>
            </tr>
        </table>


        <p class="page-no new-page">၃</p>
        <table style="margin-top:12px;">
         
            <tr>
                <td style="text-align:center;"><strong><br>ရှင်းလင်းချက်<br>အပိုင်း(က)</strong></td>
            </tr>
        </table>
        <table>
            <tr>
                <td class="left-gap"></td>
                <td colspan="2">ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတွင် ရရှိသောဝင်ငွေကိုသာလျှင် ဤအပိုင်း၌ ဖော်ပြရမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td style="width:5%">၁။</td>
                <td class="justify"><strong>လစာ။</strong>&emsp;လစာဟူသည့် ခေါင်းစဉ်ဖြင့် ဖော်ပြရမည့်ငွေတွင် သက်ဆိုင်ရာဝင်ငွေနှစ်အတွက် အလုပ်ရှင်ထံမှရရှိသည့် သို့မဟုတ် ရရန်ရှိသည့် လစာ၊ လုပ်ခ၊ နှစ်စဉ်ကြေး၊ စုကြေး၊ ချီးမြှင့်ငွေ၊ လစာနှင့်လုပ်ခအစား သို့မဟုတ် ယင်းတို့အပြင်ထပ်ဆောင်းရရှိသည့် အခကြေးငွေ ကော်မရှင်တို့လည်း ပါဝင်ပါသည်။ လစာဝင်ငွေ တစ်မျိုးတည်းသာရရှိသော အခွန်ထမ်းဖြစ်ပါက ဝင်ငွေကြေညာလွှာတင်သွင်းရန် မလိုအပ်သော်လည်း ပြန်အမ်းငွေရရန်ရှိပါက ထိုပြန်အမ်းငွေကို ရရှိလိုလျှင် ကြေညာလွှာတင်သွင်းရမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>၂။</td>
                <td class="justify"><strong>အသက်မွေးဝမ်းကျောင်းပညာလုပ်ငန်းမှဝင်ငွေ။</strong>&emsp;အောက်ပါစာပိုဒ်ခွဲ(၃)တွင် ဖော်ပြထားသည့် ညွှန်ပြချက်များသည် အသက်မွေးဝမ်းကျောင်းပညာလုပ်ငန်းမှ ရရှိသော အခွန်ထမ်းနှင့်လည်း ထပ်တူထပ်မျှ သက်ဆိုင်ပါသည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>၃။</td>
                <td class="justify"><strong>စီးပွားရေးလုပ်ငန်းမှဝင်ငွေ။</strong>&emsp;အခွန်ထမ်း၏ စီးပွားရေးလုပ်ငန်းနှင့်စပ်လျဉ်း၍ ကုန်စည်ထုတ်လုပ်မှုစာရင်း၊ ကုန်သွယ်မှုစာရင်း၊ အရှုံးအမြတ်စာရင်းနှင့် လက်ကျန်ရှင်းတမ်းအပါအဝင်ဖြစ်သည့် သက်ဆိုင်ရာနှစ်အတွက် စာရင်းရှင်းတမ်းတစ်စောင်ကို ဤဝင်ငွေကြေညာလွှာနှင့်ပူးတွဲပေးပို့ရန်လိုအပ်သည်။ အခွန်ထမ်းပိုင်ဆိုင်၍ လုပ်ငန်းအတွက်လည်းအသုံးပြုသည့် မ-တည်အပိုင်ပစ္စည်းများအတွက် တန်ဖိုးလျော့ငွေကို တောင်းခံနိုင်ခွင့်ရှိသည်ဖြစ်ရာ အဆိုပါ မ-တည်အပိုင်ပစ္စည်းများနှင့်စပ်လျဉ်းသည့် အချက်အလက်များကို ပတခ(ဝင)-၁၃ ပုံစံတွင် ဖြည့်ဆွက်ဖော်ပြရပါမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>၄။</td>
                <td class="justify"><strong>ပစ္စည်းငှားရမ်းခဝင်ငွေ။</strong>&emsp;အမှန်ရရှိသော ငှားရမ်းခကို အခြေပြု၍ ဝင်ငွေကို တွက်ချက်ရပါမည်။ ကုမ္ပဏီဖြစ်ပါက ပစ္စည်းအားလုံးအတွက် တန်ဖိုးလျော့စာရင်းပူးတွဲဖော်ပြရမည်။ တစ်ဦးချင်းပုဂ္ဂိုလ်ဖြစ်ပါက မလိုအပ်ပါ။</td>
            </tr>
            <tr>
                <td></td>
                <td>၅။</td>
                <td class="justify"><strong>အခြေပစ္စည်းမှမြတ်စွန်းငွေ။</strong>&emsp;မြေ၊ အဆောက်အအုံနှင့် ယင်းတို့၏အခန်းများ၊ ယာဉ်နှင့်လုပ်ငန်းဆိုင်ရာ မ-တည်ပစ္စည်း၊ အစုရှယ်ယာနှင့်ခံဝန်ချုပ်တို့အပြင် ငွေချေးသက်သေခံလက်မှတ်များ၊ ယင်းတို့ ကဲ့သို့သော အလားတူစာချုပ်စာတမ်းများကိုရောင်းချခြင်း၊ လဲလှယ်ခြင်း သို့မဟုတ် အခြားတစ်နည်းနည်းဖြင့် လွှဲပြောင်းပေးခြင်းပြုရာမှ ပေါ်ပေါက်သည့်အမြတ်အစွန်း သို့မဟုတ် အကျိုးအမြတ်များကို ဤခေါင်းစဉ်ဖြင့် ဖော်ပြရပါမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>၆။</td>
                <td class="justify"><strong>စည်းကြပ်မှုမှလွှတ်ကင်းနေသောဝင်ငွေ။</strong>&emsp;မည်ကဲ့သို့ ရရှိခဲ့သည်ကို အတိအကျ မဖြေရှင်းနိုင်သည့် မရွှေ့မပြောင်းနိုင်သောပစ္စည်း သို့မဟုတ် ငွေအပါအဝင်ဖြစ်သည့် ရွှေ့ပြောင်းနိုင်သော ပစ္စည်းတစ်ရပ်ရပ်အတွက် စည်းကြပ်မှုမှလွှတ်ကင်းနေသောဝင်ငွေကို ဤခေါင်းစဉ်ဖြင့် ဖော်ပြရပါမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>၇။</td>
                <td class="justify"><strong>အခြားရလမ်းများမှဝင်ငွေ။</strong>&emsp;အထက်ဖော်ပြပါ ဝင်ငွေခေါင်းစဉ်များနှင့် အကျုံးမဝင်သော ဝင်ငွေအရပ်ရပ်ကို ဤခေါင်းစဉ်ဖြင့် ဖော်ပြရပါမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td colspan="2" style="text-align:center;"><strong>အပိုင်း( ခ )</strong></td>
            </tr>
            <tr>
                <td></td>
                <td colspan="2" class="justify">&emsp;&emsp;ပြည်ပနေနိုင်ငံသားများမှအပ ကျန်အခွန်ထမ်းများက ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော်၏ ပြင်ပတွင် ဖြစ်ထွန်းပေါ်ပေါက်သည့်ဝင်ငွေ၊ အမြတ်အစွန်းများနှင့်အကျိုးအမြတ်များကို ဖော်ပြရန်ဖြစ်ပါသည်။</td>
            </tr>
        </table>

        <table style="margin-top:10px;">
            <tr>
                <td class="left-gap"></td>
                <td colspan="2" style="text-align:center;"><strong>အပိုဒ်(၂)</strong></td>
            </tr>
            <tr>
                <td></td>
                <td style="width:7%">(က)</td>
                <td class="justify">ဝင်ငွေနှစ်အတွင်း ပေးသွင်းပြီးသည့် ဝင်ငွေခွန်တွင် သုံးလတစ်ကြိမ်ပေးဆောင်ရသော ကြိုတင်ခွန်စုစုပေါင်း ပင်ရင်းမှနုတ်ယူပေးသွင်းရန် ဖြတ်တောက်ခံထားရသည့်ဝင်ငွေခွန်၊ နယ်စပ်ကုန်သွယ်ရေးစခန်းများတွင် ပေးသွင်းထားသည့် ဝင်ငွေခွန်၊ အကောက်ခွန်ဦးစီးဌာနသို့ ပေးသွင်းထားသည့် ဝင်ငွေခွန်၊ အခွန်နှစ်ထပ်မကျသင့်စေရေး စာချုပ်ဝင်နိုင်ငံများရှိ နိုင်ငံခြားအစိုးရများထံသို့ ပေးဆောင်ခဲ့သော ဝင်ငွေခွန်၊ ယခုနှစ်သို့ သယ်ယူလာသည့် ယခင်နှစ်တွင် ပိုမိုပေးဆောင်ထားခဲ့သော အခွန်ပမာဏတို့ကို ဖော်ပြရမည်။</td>
            </tr>
        </table>

        <p class="page-no new-page">၄</p><br>
        <table>
            <tr>
                <td class="left-gap"></td>
                <td style="width:7%">( ခ )</td>
                <td class="justify">ဝင်ငွေနှစ်အတွင်း ပေးသွင်းပြီးသည့် အသက်အာမခံပရီမီယံငွေတွင် အခွန်ထမ်းနှင့် ယင်းအိမ်ထောင်ဖက်၏ အသက်အာမခံအတွက် ပေးရသော ပရီမီယံငွေကို ဖော်ပြရပါမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>( ဂ )</td>
                <td class="justify">ဝင်ငွေနှစ်အတွင်း ပေးသွင်းပြီးသည့် လူမှုဖူလုံရေးရန်ပုံငွေတွင် အခွန်ထမ်းမှပေးသွင်းသည့် လူမှုဖူလုံရေး ထည့်ဝင်ငွေကြေးကို ဖော်ပြရပါမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>(ဃ)</td>
                <td class="justify">COVID-19 စီးပွားရေးကုစားမှု အစီအစဉ်အရ ပြန်အမ်းငွေရပိုင်ခွင့်မရှိသည့် ခုနှိမ်ရမည့်အခွန် အချပ်ပို-က၊ ဇယား-၁၊ အလျားကွက် ၆ နှင့် အချပ်ပို-က၊ ဇယား-၂၊ အလျားကွက် ၄ ရှိ ဂဏန်းအား ဖော်ပြရပါမည်။</td>
            </tr>
            <tr>
                <td></td>
                <td>( င )</td>
                <td class="justify">COVID-19 စီးပွားရေးကုစားမှု အစီအစဉ်အရ နုတ်ပယ်ခွင့်ပြုသည့် စရိတ်တိုးမြှင့်နုတ်ပယ်ခွင့် အသုံးစရိတ် အချပ်ပို-က၊ ဇယား-၁၊ အလျားကွက် ၅ နှင့် အချပ်ပို-က၊ ဇယား-၂၊ အလျားကွက် ၃ ရှိ ဂဏန်းအား ဖော်ပြရပါမည်။</td>
            </tr>
        </table>

        <table style="margin-top:16px;">
            <tr>
                <td class="left-gap"></td>
                <td style="width:18%"><span class="stamp">ရုံးတံဆိပ်</span></td>
                <td>-----------------------------------------------------------------------------------------------------------------</td>
            </tr>
        </table>
        <p style="text-align:center;"><strong>လက်ခံဖြတ်ပိုင်း</strong></p>
        <table>
            <tr>
                <td class="left-gap"></td>
                <td class="justify">&emsp;&emsp;&emsp;<strong><?php echo $tax_year_text; ?></strong> စည်းကြပ်နှစ်များအတွက် အခွန်ထမ်း(အမည်၊ <strong><?php echo h($taxpayer_name); ?></strong>၊ နေရပ်လိပ်စာ၊ <strong><?php echo h($address); ?></strong> ) က တင်သွင်းသော ဝင်ငွေကြေညာလွှာတစ်စောင်ကို လက်ခံရရှိပါသည်။</td>
            </tr>
        </table>
        <table style="margin-top:28px;">
            <tr>
                <td class="left-gap"></td>
                <td style="width:46%"></td>
                <td style="width:10%"><strong>လက်မှတ်</strong></td>
                <td class="dotted" style="width:37%">&nbsp;</td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><strong>အမည်</strong></td>
                <td class="dotted" style="text-align:center;"><?php echo h($officer_name); ?></td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td><strong>ရာထူး</strong></td>
                <td class="dotted" style="text-align:center";><?php echo h($rank); ?></td>
            </tr>
            <tr>
                <td></td>
                <td>နေ့စွဲ ----------------------</td>
                <td></td>
                <td class="dotted" style="text-align:center;"><?php echo h($office_township); ?></td>
            </tr>
        </table>
    </div>

    <div class="no-print-bottoms no-print">
        <button type="button" class="btn-print" onclick="window.print()">Print ထုတ်မည်</button>
        <button type="button" class="btn-close" onclick="closeWanga1()">ပိတ်မည်</button>
    </div>

    <script>
        function closeWanga1() {
            window.location.href = '../IT_demand_list.php?openModal=formsModal2';
        }
    </script>
</body>
</html>
