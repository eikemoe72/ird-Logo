
<style>
    /* မီးခိုးနောက်ခံပေါ်မှာ A4 စာရွက်ဖြူကို ခွဲပြသည် */
    #form0408CT1Modal .modal-dialog {
        max-width: 236mm;
        width: 236mm;
        margin: 12px auto;
    }

    #form0408CT1Modal .modal-header {
        background-color: #0b5ed7;
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 12px;
        border-bottom: none;
    }

    #form0408CT1Modal .modal-title {
        color: #fff;
        margin: 0;
    }

    #form0408CT1Modal .modal-content {
        background-color: #c8c8c8;
        background-image: linear-gradient(180deg, #d4d4d4 0%, #bdbdbd 100%);
        border: 1px solid rgba(0,0,0,.28);
        border-radius: 16px;
        padding: 0 0 14px;
        box-shadow: 0 10px 24px rgba(0,0,0,.28);
    }

    #form0408CT1Modal #printableSheet_0408CT1 {
        width: 210mm;
        min-height: 297mm;
        margin: 16px auto 10px;
        background: #fff;
        box-sizing: border-box;
        padding: 12mm 12mm 12mm 14mm;
        border-radius: 1px;
        box-shadow: 0 1px 0 rgba(255,255,255,.7), 0 8px 18px rgba(0,0,0,.35);
        flex: none;
    }

    /* th ရဲ့ ပုံသေ bold ကို ဖြုတ်သည်။ <b> နဲ့ ရေးထားသော ခေါင်းစဉ်များသာ bold ကျန်သည် */
    #form0408CT1Modal .print-page-2 th {
        font-weight: normal;
    }

    /* စာမျက်နှာ ၁ နှင့် ၂ ဖောင့်အရွယ် တူစေရန် */
    #form0408CT1Modal .print-page-1,
    #form0408CT1Modal .print-page-1 p,
    #form0408CT1Modal .print-page-1 div,
    #form0408CT1Modal .print-page-1 td,
    #form0408CT1Modal .print-page-1 th,
    #form0408CT1Modal .print-page-1 table,
    #form0408CT1Modal .print-page-2,
    #form0408CT1Modal .print-page-2 p,
    #form0408CT1Modal .print-page-2 div,
    #form0408CT1Modal .print-page-2 td,
    #form0408CT1Modal .print-page-2 th,
    #form0408CT1Modal .print-page-2 table {
        font-size: 15px;
    }

    @page {
        size: A4 portrait;
        margin: 8mm 10mm 8mm 12mm;
    }

    @media print {
        .modal-footer, .no-print, .btn, .btn-close, #form0408CT1Modal .sheet-gap { display: none !important; }

        body:has(#form0408CT1Modal.show) > *:not(#form0408CT1Modal),
        body:has(#form0408CT1Modal.show) .modal:not(#form0408CT1Modal),
        body:has(#form0408CT1Modal.show) .modal-backdrop,
        body:has(#form0408CT1Modal.show) #printableSheet {
            display: none !important;
        }

        #form0408CT1Modal,
        #form0408CT1Modal * {
            visibility: visible !important;
        }

        #form0408CT1Modal #printableSheet_0408CT1 {
            color: #000 !important;
        }

        #form0408CT1Modal {
            position: static !important;
            left: auto !important;
            top: auto !important;
            width: 100% !important;
            height: auto !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: visible !important;
            background: #fff !important;
        }

        #form0408CT1Modal .modal-dialog,
        #form0408CT1Modal .modal-content,
        #form0408CT1Modal .modal-body {
            position: static !important;
            display: block !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            max-height: none !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            box-shadow: none !important;
            overflow: visible !important;
            transform: none !important;
            background: #fff !important;
            background-image: none !important;
        }

        #form0408CT1Modal #printableSheet_0408CT1 {
            position: static !important;
            left: auto !important;
            top: auto !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            box-shadow: none !important;
            overflow: visible !important;
            background: #fff !important;
            color: #000 !important;
        }

        #form0408CT1Modal .print-page-2 table {
            height: auto !important;
            overflow: visible !important;
        }

        #form0408CT1Modal .print-container,
        #form0408CT1Modal .print-container2 {
            padding-left: 45px !important;
            padding-top: 10px !important;
            padding-right: 10px !important;
            border: none !important;
        }

        /* စာမျက်နှာ ၁ = အကြောင်းကြားစာ၊ စာမျက်နှာ ၂ = အဆက် */
        #form0408CT1Modal .print-page-2 {
            break-before: page;
            page-break-before: always;
        }

        #form0408CT1Modal .print-page-1,
        #form0408CT1Modal .print-page-1 p,
        #form0408CT1Modal .print-page-1 div,
        #form0408CT1Modal .print-page-1 td,
        #form0408CT1Modal .print-page-1 table {
            font-size: 15px !important;
            line-height: 1.7 !important;
        }

        #form0408CT1Modal .print-page-1 > div,
        #form0408CT1Modal .print-page-1 > table,
        #form0408CT1Modal .print-page-1 > p {
            margin-top: 6px !important;
            margin-bottom: 4px !important;
        }

        #form0408CT1Modal .print-page-2,
        #form0408CT1Modal .print-page-2 p,
        #form0408CT1Modal .print-page-2 div,
        #form0408CT1Modal .print-page-2 th,
        #form0408CT1Modal .print-page-2 td,
        #form0408CT1Modal .print-page-2 table {
            font-size: 15px !important;
            line-height: 1.7 !important;
        }

        #form0408CT1Modal .print-page-2 p {
            margin: 2px 0 !important;
        }

        #form0408CT1Modal .print-page-2 tr {
            height: auto !important;
        }

        #form0408CT1Modal .print-page-2 th,
        #form0408CT1Modal .print-page-2 td {
            padding-top: 1px !important;
            padding-bottom: 1px !important;
        }
    }
    .under-line { border-bottom: 1px dashed #0d0d0d; min-width:140px; display: inline-block; text-align: right; padding-right:30px;}
    .under-line2 { border-bottom: 2px dotted #121212; min-width:450px; display: inline-block; text-align: left; }
    .under-line3 { border-bottom: 1px solid #0e0d0d;  min-width:140px; display: inline-block; text-align: right; padding-right:30px;}

    /* ... အခြား style များ ... */
    .table-custom {
        width: 100%;
        border-collapse: collapse;
        table-layout: fixed; /* ဤအချက်က ကော်လံတွေကို အချိုးကျစေပါတယ် */
    }
    .table-custom th, .table-custom td {
        border: 0px solid black;
        padding: 5px;
        word-wrap: break-word; /* စာရှည်ရင် အောက်ဆင်းဖို့ */
    }
    .under-line-dot {
        border-bottom: 1px dotted #000;
        display: inline-block;
        width: 95%;
        min-height: 15px;
    }
</style>

<div class="modal fade" id="form0408CT1Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">၀၄-၀၈ စည်းကြပ်မှုအကြောင်းကြားစာ ထုတ်ယူရန်</h5>
                <button type="button" class="close-modal-btn" onclick="window.location.href='CT1_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div class="modal-body" id="printableSheet_0408CT1">
                <div class="print-container2 print-page-1">
                    <table style="border: 1.5px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:25px">
                        <tr>
                            <td style='border: 0px solid black; padding:3px;'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px; padding:2px; line-height: 18px;'>ပတခ(ကသခ)-၀၄-၀၈</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၁ အရ <br>
                        ကုန်သွယ်လုပ်ငန်းခွန် စည်းကြပ်မှုအကြောင်းကြားစာ  
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 0px;'>
                        <tr>
                            <td style='width:55%'></td>
                            <td style='width:30%; text-align:right;'>အခွန်တောင်းခံလွှာအမှတ်၊</td>
                            <td style='width:15%; text-align:right; border-bottom:2px dotted black;'><span id="m0408CT1_demandPrefix">CDN</span>-<span  id="m0408CT1_ct1DemandNo" ></span></td>
                        </tr>
                        <tr>
                            <td></td>   
                            <td style='text-align:right;'>ရက် စွဲ ၊ </td>
                            <td style='text-align:right; border-bottom:2px dotted black;'><span id="m0408CT1_ct1DemandDate"></span></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:10%'>သို့</td>
                            <td style='width:25%'>အခွန်ထမ်းအမည်</td>
                            <td style='width:65%' class="under-line2">၊&ensp;<span  id="m0408CT1_name"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:25%'>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</td>
                            <td style='width:65%' class="under-line2">၊&ensp;<span  id="m0408CT1_ct1_gir"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:25%'>အခွန်ထမ်းလိပ်စာ</td>
                            <td style='width:65%' class="under-line2">၊&ensp;<span  id="m0408CT1_address"></span></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:25%'>လုပ်ငန်းနှစ်(အခွန်ကာလ)</td>
                            <td style='width:65%' class="under-line2">၊&ensp;(၀၁-၀၄-<span id="m0408CT1_year_start"></span>) မှ (၃၁-၀၃-<span id="m0408CT1_year_end"></span>)ထိ ကာလ</td>
                        </tr>
                    </table>

                    

                    <div style="margin-top:15px; padding:2px; text-align:justify;">
                        ၁။<span style = 'padding-left:48px;'></span>( <strong><span id="m0408CT1_taxYear"></span></strong> )စည်းကြပ်နှစ်အတွက် 
                        ကျောဖက်ပါပုံစံတွင် အသေးစိပ်ဖော်ပြထားချက်အရ ပေးဆောင်ရန် တာဝန်ရှိသည့် အခွန်နှင့်စပ်လျဉ်း၍ အောက်ပါအတိုင်း ပေးဆောင်ရန် အကြောင်းကြားပါသည် -
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr id='original_row10'>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(က)</td>
                            <td style='width:55%'>ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"> <span  id="m0408CT1_netTax1"></span></td>
                        </tr>
                        <tr id='row_hide11'>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(က)</td>
                            <td style='width:55%'>ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"> <span  id="total_net_tax1"></span></td>
                        </tr>

                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ခ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၅ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဂ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၆ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ဃ)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၇ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( င )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၈ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"> </td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( စ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၉ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ဆ)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၀ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဇ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၁ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဈ )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၂ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>
                        <tr>
                            <td style='width:10%'></td>
                            <td style='width:5%'>(ည)</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၃ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%' class="under-line"></td>
                        </tr>

                        <tr id='original_row11'>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဋ  )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၄ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%;' class="under-line3"><span  id="m0408CT1_penalty1"></td>
                        </tr>
                        <tr id='row_hide12'>
                            <td style='width:10%'></td>
                            <td style='width:5%'>( ဋ  )</td>
                            <td style='width:55%'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၄ အရ ဒဏ်ကြေးငွေ</td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%;' class="under-line3"><span  id="total_penalty"></td>
                        </tr>

                        <tr id='original_row12'>
                            <td style='width:10%'></td>
                            <td style='width:5%'></td>
                            <td style='width:55%'><b>စုစုပေါင်းပေးဆောင်ရမည့်အခွန်ပမာဏ</b></td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%;' class="under-line3"><b><span  id="m0408CT1_totalTax1"></span></b></td>
                        </tr>
                        <tr id='row_hide13'>
                            <td style='width:10%'></td>
                            <td style='width:5%'></td>
                            <td style='width:55%'><b>စုစုပေါင်းပေးဆောင်ရမည့်အခွန်ပမာဏ</b></td>
                            <td style='width:10%'>ကျပ်</td>
                            <td style='width:20%;' class="under-line3"><b><span  id="total_final_tax"></span></b></td>
                        </tr>

                        <tr>
                            <td style='width:10%'></td>
                            <td colspan="5" style='padding-top: 5px;'>
                               <strong> စာသားဖြင့် ( <span id="m0408CT1_taxTextMM"></span> ) ကျပ်တိတိ၊</strong>
                            </td>     
                        </tr>
                    </table>
                    <div style="margin-top:15px; padding:2px; text-align:justify;">
                        ၂။<span style = 'padding-left:48px;'></span>အထက်ပါပေးဆောင်ရမည့် အခွန်ငွေပမာဏကို 
                            ( <span style ="color:red;" id="user_bank_township"></span> ) ရှိ မြန်မာ့စီးပွားရေးဘဏ်၊ 
                            ဘဏ်စာရင်းအမှတ် ( <span style ="color:red;" id="user_md_no"></span>) သို့ ပူးတွဲပါ ငွေသွင်းချလန်ဖြင့်
                            ( <span  style ="color:red;" id="m0408CT1_demandDate"></span> )ရက်နေ့ နောက်ဆုံးထား၍ ပေးသွင်းပြီး လက်ခံဖြတ်ပိုင်းကို
                            ရယူစေလိုပါသည်။ (Online Paymentဖြင့် ပေးသွင်း၍ရပါက ပေးသွင်းစေလိုပါသည်။) သတ်မှတ်ရက်အတွင်း အခွန်ပေးသွင်းရန် ပျက်ကွက်ပါက 
                            အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေ ပုဒ်မ ၇၄ ၊ ပုဒ်မခွဲ(က)အရ ဒဏ်ငွေ ထပ်မံတပ်ရိုက်ခြင်း ခံရဖွယ်ရှိပါ၍ မပျက်မကွက် ပေးဆောင်စေလိုပါသည်။<br>
                    
                        ၃။<span style = 'padding-left:48px;'></span>စည်းကြပ်မှု သို့မဟုတ် ဒဏ်ကြေးငွေတပ်ရိုက်မှုအတွက်ဆုံးဖြတ်ချက်ကို ကျေနပ်မှုမရှိပါက
                         အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၄ ပါ စီမံအုပ်ချုပ်မှုနည်းလမ်းအရ ပြန်လည်သုံးသပ်ပေးရန် ညွှန်ကြားရေးမှူးချုပ်၊ ပြည်တွင်းအခွန်များဦးစီးဌာန၊ 
                         ရုံးအမျတ်(၄၆)၊ နေပြည်တော်သို့ အကြောင်းကြားစာလက်ခံရရှိသည့်နေ့မှ ရက်ပေါင်း(၃၀)အတွင်း လျှောက်ထားနိုင်ပါသည်။<br><br>
                    </div>
                    
                    <table style='width:100%; margin-top:30px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br><span id="m0408CT1_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="sheet-gap"><br><br><br></div>

                <div class="print-container2 print-page-2">
                    

                    <p style='text-align:right; font-size:15px; padding:2px; line-height: 14px;'>ပတခ(ကသခ)-၀၄-၀၈(အဆက်)</p>
                    <p style='text-align:center; font-size:15px; line-height: 14px;'><b>ကုန်သွယ်လုပ်ငန်းခွန် အသေးစိပ်ဖော်ပြချက်</b></p>

                    
                    <table style="width: 100%; height: 23px;" >
                        
                        <tr >
                            <th style="width: 10%; text-align: left; padding:2px;"><b>အမည်</b></th>
                            <th style="width: 47%; text-align: left; padding:2px;  border-bottom: 2px dotted #121212;"><span id="m0408CT1_name1"></span></th>
                            <th style="width: 2%; text-align: left; padding:2px;"></th>
                            <th colspan="2"style="width: 41%; text-align: right;  border-bottom: 2px dotted #121212; padding:2px;"><span id="m0408CT1_township1"></span>အခွန်ဦးစီးဌာနမှူးရုံး</th>
                            <!--<th style="width: 20%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>-->
                        </tr>
                         <tr >
                            <th style="width: 10%; text-align: left; padding:2px;"><b>လိပ်စာ</b></th>
                            <th style="width: 47%; text-align: left; padding:2px;  border-bottom: 2px dotted #121212;"><span id="m0408CT1_address1"></span></th>
                            <th style="width: 2%; text-align: left; padding:2px;"></th>
                            <th colspan="2"style="width: 41%; text-align: right;  border-bottom: 2px dotted #121212; padding:2px;"><span id="m0408CT1_state"></th>
                            <!--<th style="width: 20%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>-->
                        </tr>
                         <tr >
                            <th style="width: 10%; text-align: left; padding:2px;"><b>လုပ်ငန်း</b></th>
                            <th style="width: 47%; text-align: left; padding:2px;  border-bottom: 2px dotted #121212;"><span id="m0408CT1_businessType11"></span></th>
                            <th style="width: 2%; text-align: left; padding:2px;"></th>
                            <th style="width: 28%; text-align: right;  border-bottom: 2px dotted #121212;"><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</b></th>
                            <th style="width: 13%; text-align: right; padding-right:30px; border-bottom: 2px dotted #121212; padding:2px;" ><span id="m0408CT1_ct1_gir1"></span></th>
                        </tr>
                       
                    </table>

                    <br style="line-height:5px">

                    <table style="width: 100%; border: 1.5px solid #000; height:24px;" >
                        
                        <tr style="height:26px; padding:2px; border: 1.5px solid #0a0a0a;">
                            <th style="width: 4%; text-align: center; border-left: 1.5px solid #0a0a0a;  padding:2px;">စဉ်</th>
                            <th style="width: 44%; text-align: center;  border: 1.5px solid #0a0a0a; border-right: 2px solid #0a0a0a; padding:2px;">လုပ်ငန်းအမျိုးအစား</th>
                            <th style="width: 25%; text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;">သတ်မှတ်ရောင်းရငွေ<br>သို့မဟုတ် ရငွေပေါင်း</th>
                            <th style="width: 9%; text-align: center; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" >အခွန်နှုန်းထား</th>
                            <th style="width: 18%; text-align: center; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" >ကျသင့်အခွန်<br>ကျပ်</th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: center; border-left: 1.5px solid #0a0a0a; padding:2px; vertical-align:top;">၁။</th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-right: 2px solid #0a0a0a; padding:2px;">
                                ကုန်စည်ထုတ်လုပ်ရောင်းချခြင်းလုပ်ငန်း <br>ကုန်ထုတ်လုပ်သည့် ကုန်စည်အမျိုးအစား </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #000; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၁)</span></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၂) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>

                        <!--ထုတ်လုပ်မှုအတွက်--->
                        <tr style="height:26px; padding:2px; " id="original_row1">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၃) <span id=""></span></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"> <span id=""> </th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" > </th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id=""></th>
                        </tr>
                        <tr style="height:26px; padding:2px; " id="row_hide1">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၃) <b><span id="m0408CT1_businessType1111"></span></b></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"> <b><span id="m0408CT1_salesAmount11"></span></b> </th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" > <b>၅%</b></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><b><span id="m0408CT1_ct1tax1"></span></b></th>
                        </tr>

                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၄) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၅) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: center; border-left: 1.5px solid #0a0a0a; padding:2px; vertical-align:top;">၂။</th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a; 
                                border-right: 2px solid #0a0a0a; padding:2px;">ကုန်သွယ်မှုလုပ်ငန်း <br>ကုန်သွယ်မှုပြုသည့် ကုန်စည်အမျိုးအစား </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၁) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၂) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>

                        <!--ကုန်သွယ်မှုအတွက်--->
                        <tr style="height:26px; padding:2px; " id="original_row2">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၃) <span id=""></span></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><span id=""></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id=""></th>
                        </tr>
                        <tr style="height:26px; padding:2px; " id="row_hide2">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၃) <b><span id="m0408CT1_businessType6"></span></b></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><b><span id="m0408CT1_salesAmount6"></span></b></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><b>၅%</b></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><b><span id="m0408CT1_ct1tax6"></span></b></th>
                        </tr>
                        <tr style="height:26px; padding:2px; " id="row_hide5">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၃) <span id="m0408CT1_businessType5"></span></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><span id="m0408CT1_salesAmount5"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id="m0408CT1_tradeRate3">၁%</span></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id="m0408CT1_ct1tax5"></th>
                        </tr>

                    
                        <!--ကသ=ကသ--->
                        <tr style="height:26px; padding:2px; " id="original_row4">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၄) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                         <tr style="height:26px; padding:2px; " id="row_hide4">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၄) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><span id="m0408CT2_salesAmount6"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" >၃%</th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id="m0408CT2_ct2tax6"></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၅) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: center; border-left: 1.5px solid #0a0a0a; padding:2px; vertical-align:top;">၃။</th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">ဝန်ဆောင်မှုလုပ်ငန်း ဆောင်ရွက်သည့်  <br>ဝန်ဆောင်မှုလုပ်ငန်းအမျိုးအစား </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                            border-right: 2px solid #0a0a0a; padding:2px;">(၁) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၂) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>

                        <!--ဝန်ဆောင်မှုအတွက်--->
                        <tr style="height:26px; padding:2px; " id="original_row3">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၃) <span id=""></span></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><span id=""></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id=""></th>
                        </tr>
                        <tr style="height:26px; padding:2px; " id="row_hide3">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 2px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၃) <b><span id="m0408CT1_businessType8"></span></b></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><b><span id="m0408CT1_salesAmount8"></span></b></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><b>၅%</b></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><b><span id="m0408CT1_ct1tax8"></span></b></th>
                        </tr>


                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 1.5px dotted #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၄) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:26px; padding:2px; ">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; border-bottom: 1.5px solid #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">(၅) </th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>

                        <!--rows hide--->
                        <tr style="height:26px; padding:2px; border: 1.5px solid #0a0a0a;" id="original_row5">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: center; border-left: 1.5px solid #0a0a0a; border-bottom: 1.5px solid #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">စုစုပေါင်း</span></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><span id="m0408CT1_salesAmount1"></span></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" >၅%</th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id="m0408CT1_ct1tax"></span></th>
                        </tr>
                        <tr style="height:26px; padding:2px; border: 1.5px solid #0a0a0a;" id="row_hide6">
                            <th style="text-align: left; border-left: 1.5px solid #0a0a0a; padding:2px;"></th>
                            <th style="text-align: center; border-left: 1.5px solid #0a0a0a; border-bottom: 1.5px solid #121212; 
                                border-right: 2px solid #0a0a0a; padding:2px;">စုစုပေါင်း</span></th>
                            <th style="text-align: center; border-right: 1.5px solid #0b0b0b;padding:2px;"><span id="total_sales_amount"></span></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id="total_ct_tax"></span></th>
                        </tr>


                        <tr style="height:28px; padding:2px; font-size:15px;" id="original_row6">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a; 
                                padding:2px;">(နုတ်) စည်းမျဥ်း ၄၂ အရ အခွန်တစ်ကြိမ်တည်းကျသင့်စေရေး ခုနှိမ်ရမည့် ကုန်သွယ်လုပ်ငန်းခွန်</th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px; color:red;" ><span id="m0408CT1_rule42_1"></span></th>
                        </tr>
                        <tr style="height:28px; padding:2px; font-size:15px;" id="row_hide7">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a; 
                                padding:2px;">(နုတ်) စည်းမျဥ်း ၄၂ အရ အခွန်တစ်ကြိမ်တည်းကျသင့်စေရေး ခုနှိမ်ရမည့် ကုန်သွယ်လုပ်ငန်းခွန်</th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px; color:red;" ><span id="total_rule42"></span></th>
                        </tr>


                        <tr style="height:28px; padding:2px; font-size:15px;">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a; 
                                padding:2px;">(နုတ်) ပတခ(ကသခ)-၀၅-၀၁ အရ ခုနှိမ်ခွင့်ရှိသည့် ကုန်သွယ်ခွန်</th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ></th>
                        </tr>
                        <tr style="height:28px; padding:2px; font-size:15px;">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a; 
                                padding:2px;">(နုတ်) ပတခ(ကသခ)-၀၅-၀၂ အရ ခုနှိမ်ခွင့်ရှိသည့် ကုန်သွယ်ခွန်</th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px; 
                                border-bottom: 1.5px solid #0a0a0a;" ></th>
                        </tr>


                        <tr style="height:28px; padding:2px; font-size:15px;" id="original_row7">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a; 
                                 padding:2px;">ပေးပို့ခဲ့သည့် (ဝင်ငွေခွန်တွက်ချက်ရာတွင် စရိတ်အဖြင့်ခွင့်ပြု)/ပေးဆောင်ရန်ကျန်ကုန်သွယ်လုပ်ငန်းခွန် </th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px; 
                                border-bottom: 1.5px solid #0a0a0a;" ><span id="m0408CT1_afterRuler1"></span></th>
                        </tr>
                        <tr style="height:28px; padding:2px; font-size:15px;" id="row_hide8">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a; 
                                 padding:2px;">ပေးပို့ခဲ့သည့် (ဝင်ငွေခွန်တွက်ချက်ရာတွင် စရိတ်အဖြင့်ခွင့်ပြု)/ပေးဆောင်ရန်ကျန်ကုန်သွယ်လုပ်ငန်းခွန် </th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px; 
                                border-bottom: 1.5px solid #0a0a0a;" ><span id="total_after_ruler"></span></th>
                        </tr>


                        <tr style="height:28px; padding:2px; font-size:15px;" id="original_row8">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a;  
                                padding:2px; color:red;">(နုတ်) ပုဒ်မ ၁၂ အရ လစဉ်ပေးဆောင်ခဲ့သည့် ကုန်သွယ်လုပ်ငန်းခွန် </th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;
                                 border-bottom: 1.5px solid #0a0a0a; color:red; " ><span id="m0408CT1_advanceTax1"></span></th>
                        </tr>
                        <tr style="height:28px; padding:2px; font-size:15px;" id="row_hide9">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; border-right: 1.5px solid #0a0a0a;  
                                padding:2px; color:red;">(နုတ်) ပုဒ်မ ၁၂ အရ လစဉ်ပေးဆောင်ခဲ့သည့် ကုန်သွယ်လုပ်ငန်းခွန် </th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;
                                 border-bottom: 1.5px solid #0a0a0a; color:red; " ><span id="total_advance_tax"></span></th>
                        </tr>


                        <tr style="height:28px; padding:2px; font-size:15px;  border-bottom: 1.5px solid #0a0a0a;" id="original_row9">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; 
                                border-right: 1.5px solid #0a0a0a; padding:2px;">ထပ်မံပေးဆောင်ရန်အခွန်ငွေ/ပြန်အမ်းရန်အခွန်ငွေ</th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id="m0408CT1_netTax11"></span></th>
                        </tr>
                        <tr style="height:28px; padding:2px; font-size:15px;  border-bottom: 1.5px solid #0a0a0a;" id="row_hide10">
                            <th colspan="4" style="text-align: right; border-left: 1.5px solid #0a0a0a; 
                                border-right: 1.5px solid #0a0a0a; padding:2px;">ထပ်မံပေးဆောင်ရန်အခွန်ငွေ/ပြန်အမ်းရန်အခွန်ငွေ</th>
                            
                            <th style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a; padding:2px;" ><span id="total_net_tax"></span></th>
                        </tr>
                        
 
                    </table>
                    
                </div>
            </div>
            <div class="modal-footer no-print">
                <botton type="botton" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</botton>
                <botton type="botton" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</botton>
            </div>
        </div>
    </div>
</div>

<script>
function openForm0408CT1() {
    console.log("Selected Row Data:", selectedRowData);
    
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("Table ထဲမှ row ကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    const phpBankTownship = "<?php echo htmlspecialchars(trim(str_replace('နယ်', '', $bank_township ?? '')), ENT_QUOTES, 'UTF-8'); ?>";
    const currentTaxYear = "<?php
        $ct1CurrentTaxYear = '';
        if (isset($conn)) {
            $ct1Today = date('Y-m-d');
            $ct1BudgetQuery = "SELECT budget_year FROM budget_year WHERE '$ct1Today' BETWEEN start_date2 AND end_date2 LIMIT 1";
            $ct1BudgetResult = $conn->query($ct1BudgetQuery);
            if ($ct1BudgetResult && $ct1BudgetRow = $ct1BudgetResult->fetch_assoc()) {
                $ct1CurrentTaxYear = $ct1BudgetRow['budget_year'] ?? '';
            }
        }
        if ($ct1CurrentTaxYear === '') {
            $ct1Y = (int) date('Y');
            $ct1M = (int) date('n');
            $ct1CurrentTaxYear = ($ct1M >= 4) ? ($ct1Y . '-' . ($ct1Y + 1)) : (($ct1Y - 1) . '-' . $ct1Y);
        }
        echo htmlspecialchars($ct1CurrentTaxYear, ENT_QUOTES, 'UTF-8');
    ?>";
    const phpMdNo = "<?php echo $md_no; ?>";

    // ၁။ မြန်မာဂဏန်းပြောင်းလဲခြင်း
    const toMM = (num, showComma = true) => {
        if (num === null || num === undefined || num === "") return '၀';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        let s = (showComma && !isNaN(num)) ? Number(num).toLocaleString() : num.toString(); 
        return s.replace(/\d/g, d => mDigits[d]);
    };

    // ၂။ ဂဏန်းမှ မြန်မာစာသားသို့ ပြောင်းလဲခြင်း
    const numberToMyanmarText = (number) => {
        if (number === 0 || !number) return "သုည";
        const digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
        const units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
        let numStr = Math.floor(number).toString();
        let result = "";
        let len = numStr.length;
        for (let i = 0; i < len; i++) {
            let digit = parseInt(numStr[i]);
            let unitIndex = len - i - 1;
            if (digit !== 0) {
                result += digits[digit] + units[unitIndex];
            }
        }
        return result;
    };

    const setText = (id, val, isNum = false, showComma = true) => {
        const el = document.getElementById(id);
        if (el) el.innerText = isNum ? toMM(val, showComma) : (val || '-');
    };

    // စည်းကြပ်နှစ် (taxYear) ရှိမရှိ စစ်ဆေးခြင်း
    if (selectedRowData.taxYear) {
        // တစ်နှစ်လုံးစာ ပြသရန် (ဥပမာ - ၂၀၂၅-၂၀၂၆)
        setText('m0408CT1_taxYear', toMM(selectedRowData.taxYear, false));

        // လုပ်ငန်းနှစ် (Start Year နှင့် End Year) ခွဲထုတ်ခြင်း
        let yearParts = selectedRowData.taxYear.split("-"); 
        
        if (yearParts.length === 2) {
            // yearParts[0] (ဥပမာ "2025") ကို နံပါတ်ပြောင်းပြီး ၁ နှုတ်ပါ
            let startYearCalc = Number(yearParts[0]) - 1;
            // yearParts[1] (ဥပမာ "2026") ကို နံပါတ်ပြောင်းပြီး ၁ နှုတ်ပါ
            let endYearCalc = Number(yearParts[1]) - 1;

            // ရလဒ်များကို မြန်မာဂဏန်းပြောင်းပြီး ထည့်သွင်းပါ
            setText('m0408CT1_year_start', toMM(startYearCalc.toString(), false));
            setText('m0408CT1_year_end', toMM(endYearCalc.toString(), false));
        }
    }

    if (selectedRowData.itDemandDate) {
        const d = new Date(selectedRowData.itDemandDate);
        d.setDate(d.getDate() + 14); 
        const day = toMM(d.getDate(), false);
        const month = toMM(d.getMonth() + 1, false);
        const year = toMM(d.getFullYear(), false);
        setText('m0408CT1_demandDate', `${day}-${month}-${year}`);
    }

    const bankT = document.getElementById('user_bank_township');
    const mdNo = document.getElementById('user_md_no');
    if (bankT) bankT.innerText = phpBankTownship;
    if (mdNo) mdNo.innerText = phpMdNo;

    // အမည်နှင့် လိပ်စာ
    setText('m0408CT1_name', selectedRowData.taxpayer_name);
    setText('m0408CT1_name1', selectedRowData.taxpayer_name);
    setText('m0408CT1_address', selectedRowData.address);
    setText('m0408CT1_address1', selectedRowData.address);
    setText('m0408CT1_township', selectedRowData.township_name);
    setText('m0408CT1_township1', selectedRowData.township_name);
    setText('m0408CT1_state', selectedRowData.state_name);
    setText('m0408CT1_taxYear1', toMM(selectedRowData.taxYear, false));
    setText('m0408CT1_businessType1', selectedRowData.businessType1, true);
    setText('m0408CT1_businessType11', selectedRowData.businessType1);
    const demandPrefix = (String(selectedRowData.taxYear || '').trim() === String(currentTaxYear).trim()) ? 'CDN' : 'LDN';
    setText('m0408CT1_demandPrefix', demandPrefix);
    setText('m0408CT1_ct1DemandNo', selectedRowData.ct1DemandNo);
    setText('m0408CT1_ct1_gir', (selectedRowData.ct1_select_real || '') + " / " + (selectedRowData.ct1_no_real || '') );
    setText('m0408CT1_ct1_gir1', (selectedRowData.ct1_select_real || '') + " / " + (selectedRowData.ct1_no_real || '') );

    // ငွေကြေးဆိုင်ရာများ
    setText('m0408CT1_salesAmount1', selectedRowData.salesAmount1, true);
    setText('m0408CT1_ct1tax', selectedRowData.ct1tax, true);
    setText('m0408CT1_rule42_1', selectedRowData.rule42_1, true);
    setText('m0408CT1_afterRuler1', selectedRowData.afterRuler1, true);
    setText('m0408CT1_advanceTax1', selectedRowData.advanceTax1, true);
    setText('m0408CT1_netTax1', selectedRowData.netTax1, true);
    setText('m0408CT1_netTax11', selectedRowData.netTax1, true);
    setText('m0408CT1_penalty1', selectedRowData.penalty1, true);
    setText('m0408CT1_totalTax1', selectedRowData.totalTax1, true);

    //ထုတ်လုပ်မှု  အတွက်
    setText('m0408CT1_businessType111', selectedRowData.businessType1);
  

    setText('m0408CT1_businessType1111', selectedRowData.businessType1);
    setText('m0408CT1_salesAmount11', selectedRowData.salesAmount1, true);
    setText('m0408CT1_ct1tax1', selectedRowData.ct1tax, true);

     //ကုန်သွယ်မှု  အတွက်
    setText('m0408CT1_businessType5', selectedRowData.businessType1);
    setText('m0408CT1_salesAmount5', selectedRowData.salesAmount1, true);
    setText('m0408CT1_ct1tax5', selectedRowData.ct1tax, true);

    setText('m0408CT1_businessType6', selectedRowData.businessType1);
    setText('m0408CT1_salesAmount6', selectedRowData.salesAmount1, true);
    setText('m0408CT1_ct1tax6', selectedRowData.ct1tax, true);

    setText('m0408CT2_businessType6', selectedRowData.businessType2);
    setText('m0408CT2_salesAmount6', selectedRowData.salesAmount2, true);
    setText('m0408CT2_ct2tax6', selectedRowData.ct2tax, true);

     //ဝန်ဆောင်မှု  အတွက်
    setText('m0408CT1_businessType7', selectedRowData.businessType1);
    setText('m0408CT1_salesAmount7', selectedRowData.salesAmount1, true);
    setText('m0408CT1_ct1tax7', selectedRowData.ct1tax, true);

    setText('m0408CT1_businessType8', selectedRowData.businessType1);
    setText('m0408CT1_salesAmount8', selectedRowData.salesAmount1, true);
    setText('m0408CT1_ct1tax8', selectedRowData.ct1tax, true);

    let ct1DemandDate = selectedRowData.ct1DemandDate || "";
    if (ct1DemandDate && ct1DemandDate.includes('-') && ct1DemandDate !== '0000-00-00') {
        const aParts = ct1DemandDate.split('-');
        const aY = aParts[0];
        const aM = aParts[1];
        const aD = (aParts[2] || '').split(' ')[0];
        setText('m0408CT1_ct1DemandDate', `${toMM(aD, false)}-${toMM(aM, false)}-${toMM(aY, false)}`);
    } else {
        setText('m0408CT1_ct1DemandDate', '');
    }


    // --- Status စစ်ဆေးခြင်း ---
    const s1 = selectedRowData.ct1_select_real;
    const s2 = selectedRowData.ct2_select_real;

    // အရင်ဆုံး row အားလုံးကို reset လုပ်ပါ
    const allRowIDs = ['row_hide1', 'row_hide2', 'row_hide3', 'row_hide4', 'row_hide5','row_hide6', 
    'row_hide7', 'row_hide8', 'row_hide4', 'row_hide9', 'row_hide10', 'row_hide11', 'row_hide12', 'row_hide13'];
    allRowIDs.forEach(id => { if(document.getElementById(id)) document.getElementById(id).style.display = 'none'; });
    
    const allOrigIDs = ['original_row1', 'original_row2', 'original_row3', 'original_row4', 
    'original_row5', 'original_row6', 'original_row7', 'original_row8', 'original_row9', 'original_row10', 'original_row11', 'original_row12'];
    allOrigIDs.forEach(id => { if(document.getElementById(id)) document.getElementById(id).style.display = 'table-row'; });

    // ပေါင်းလဒ်များအတွက် variable များ
    let finalTotalTax = Number(selectedRowData.totalTax1) || 0;

    if (s1 === "ကသ" && s2 === "ကသ") {
        // --- ၈ မျိုးပေါင်းခြင်း Logic ---
        const totalSales = (Number(selectedRowData.salesAmount1) || 0) + (Number(selectedRowData.salesAmount2) || 0);
        const totalCTTax = (Number(selectedRowData.ct1tax) || 0) + (Number(selectedRowData.ct2tax) || 0);
        const totalRule42 = (Number(selectedRowData.rule42_1) || 0) + (Number(selectedRowData.rule42_2) || 0);
        const totalAfter = (Number(selectedRowData.afterRuler1) || 0) + (Number(selectedRowData.afterRuler2) || 0);
        const totalAdv = (Number(selectedRowData.advanceTax1) || 0) + (Number(selectedRowData.advanceTax2) || 0);
        const totalNet = (Number(selectedRowData.netTax1) || 0) + (Number(selectedRowData.netTax2) || 0);
        const totalPen = (Number(selectedRowData.penalty1) || 0) + (Number(selectedRowData.penalty2) || 0);
        const totalFinal = (Number(selectedRowData.totalTax1) || 0) + (Number(selectedRowData.totalTax2) || 0);
        
        finalTotalTax = totalFinal; // စာသားပြောင်းရန်အတွက် သိမ်းထားပါ

        setText('total_sales_amount', totalSales, true);
        setText('total_ct_tax', totalCTTax, true);
        setText('total_rule42', totalRule42, true);
        setText('total_after_ruler', totalAfter, true);
        setText('total_advance_tax', totalAdv, true);
        setText('total_net_tax', totalNet, true);
        setText('total_net_tax1', totalNet, true);
        setText('total_penalty', totalPen, true);
        setText('total_final_tax', totalFinal, true);

        // Row display ပြောင်းလဲခြင်း
        if(document.getElementById('row_hide2')) document.getElementById('row_hide2').style.display = 'none';
        if(document.getElementById('row_hide4')) document.getElementById('row_hide4').style.display = 'table-row';
        const tradeRate3 = (String(selectedRowData.taxYear || '').trim() === String(currentTaxYear).trim()) ? '၃%' : '၁%';
        setText('m0408CT1_tradeRate3', tradeRate3);
        if(document.getElementById('row_hide5')) document.getElementById('row_hide5').style.display = 'table-row';
        if(document.getElementById('row_hide6')) document.getElementById('row_hide6').style.display = 'table-row';
        if(document.getElementById('row_hide7')) document.getElementById('row_hide7').style.display = 'table-row';
        if(document.getElementById('row_hide8')) document.getElementById('row_hide8').style.display = 'table-row';
        if(document.getElementById('row_hide9')) document.getElementById('row_hide9').style.display = 'table-row';
        if(document.getElementById('row_hide10')) document.getElementById('row_hide10').style.display = 'table-row';
        if(document.getElementById('row_hide11')) document.getElementById('row_hide11').style.display = 'table-row';
        if(document.getElementById('row_hide12')) document.getElementById('row_hide12').style.display = 'table-row';
        if(document.getElementById('row_hide13')) document.getElementById('row_hide13').style.display = 'table-row';

        if(document.getElementById('original_row2')) document.getElementById('original_row2').style.display = 'none';
        if(document.getElementById('original_row4')) document.getElementById('original_row4').style.display = 'none';
        if(document.getElementById('original_row5')) document.getElementById('original_row5').style.display = 'none';
        if(document.getElementById('original_row6')) document.getElementById('original_row6').style.display = 'none';
        if(document.getElementById('original_row7')) document.getElementById('original_row7').style.display = 'none';
        if(document.getElementById('original_row8')) document.getElementById('original_row8').style.display = 'none';
        if(document.getElementById('original_row9')) document.getElementById('original_row9').style.display = 'none';
        if(document.getElementById('original_row10')) document.getElementById('original_row10').style.display = 'none';
        if(document.getElementById('original_row11')) document.getElementById('original_row11').style.display = 'none';
        if(document.getElementById('original_row12')) document.getElementById('original_row12').style.display = 'none';
    } 
    else if (s1 === "ကသ") {
        // ကုန်သွယ်မှု အမှတ်စဉ် (၃)
        if(document.getElementById('row_hide2')) document.getElementById('row_hide2').style.display = 'table-row';
        if(document.getElementById('original_row2')) document.getElementById('original_row2').style.display = 'none';
    }
    else if (s1 === "ထလ") {
        // ကုန်စည်ထုတ်လုပ်ခြင်း အမှတ်စဉ် (၃)
        if(document.getElementById('row_hide1')) document.getElementById('row_hide1').style.display = 'table-row';
        if(document.getElementById('original_row1')) document.getElementById('original_row1').style.display = 'none';
    }
    else {
        // ကျန်တာ ဝန်ဆောင်မှု အမှတ်စဉ် (၃)
        if(document.getElementById('row_hide3')) document.getElementById('row_hide3').style.display = 'table-row';
        if(document.getElementById('original_row3')) document.getElementById('original_row3').style.display = 'none';
    }


    // မြန်မာစာသားပြောင်းခြင်း (စုစုပေါင်းအပေါ်မူတည်၍)
    setText('m0408CT1_taxTextMM', numberToMyanmarText(finalTotalTax));

    // Modal ပြသခြင်း
    const modalElem = document.getElementById('form0408CT1Modal');
    if (modalElem) {
        const myModal = bootstrap.Modal.getOrCreateInstance(modalElem);
        myModal.show();
    }
}

</script>