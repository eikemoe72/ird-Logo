<?php
// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    $query = "SELECT * FROM regular_data WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း
$os_case_number     = htmlspecialchars($db_data['case_number'] ?? '-');
$os_name            = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_township_name   = htmlspecialchars($db_data['township_name'] ?? '-');
$os_taxYear         = htmlspecialchars($db_data['taxYear'] ?? '-');
$end_year = '..............';
$end_month = '............';
$end_day = '......';
$tax_year_raw = trim((string)($db_data['taxYear'] ?? ''));
if ($tax_year_raw !== '') {
    $by_stmt = $conn->prepare('SELECT end_date1 FROM budget_year WHERE budget_year = ? LIMIT 1');
    if ($by_stmt) {
        $by_stmt->bind_param('s', $tax_year_raw);
        $by_stmt->execute();
        $by_res = $by_stmt->get_result();
        if ($by_res && $by_row = $by_res->fetch_assoc()) {
            $end_raw = $by_row['end_date1'] ?? '';
            if (!empty($end_raw) && $end_raw !== '0000-00-00' && strtotime($end_raw)) {
                $mm_digits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
                $mm_months = ['', 'ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'ဩဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ'];
                $to_mm = function ($value) use ($mm_digits) {
                    return str_replace(range(0, 9), $mm_digits, (string)$value);
                };
                $end_ts = strtotime($end_raw);
                $end_year = $to_mm(date('Y', $end_ts));
                $end_month = $mm_months[(int)date('n', $end_ts)];
                $end_day = $to_mm(date('j', $end_ts));
            }
        }
        $by_stmt->close();
    }
}

$os_gir_ct1         = htmlspecialchars($db_data['ct1_no_real'] ?? '-');
$os_gir_type_ct1    = htmlspecialchars($db_data['ct1_select_real'] ?? '-');

$os_gir_ct2         = htmlspecialchars($db_data['ct2_no_real'] ?? '-');
$os_gir_type_ct2    = htmlspecialchars($db_data['ct2_select_real'] ?? '-');

$os_address         = htmlspecialchars($db_data['address'] ?? '-');
$os_ph_no           = htmlspecialchars($db_data['ph_no'] ?? '-');
$os_nrc           = htmlspecialchars($db_data['nrc_no'] ?? '-');
$os_officer         = htmlspecialchars($db_data['officer_name'] ?? 'အခွန်မှူးအမည်');
$os_officer_rank    = htmlspecialchars($db_data['rank_'] ?? 'ရာထူး');
$os_biz1            = htmlspecialchars($db_data['businessType1'] ?? '-');
$os_biz2            = htmlspecialchars($db_data['businessType2'] ?? '-');

$declared_ct1_raw   = $db_data['declaredCT1'] ?? '';
$os_declaredCT1     = number_format($declared_ct1_raw === '' || $declared_ct1_raw === null ? '-' : (string)$declared_ct1_raw);
$os_declaredCT2     = htmlspecialchars($db_data['declaredCT2'] ?? '-');
$declared_ct1_num   = str_replace(',', '', (string)$declared_ct1_raw);
$os_ct1_due_num = null;
$os_ct1_rate = '၅ %';
if (is_numeric($declared_ct1_num)) {
    $declared_ct1_value = (float)$declared_ct1_num;
    if ($declared_ct1_value > 50000000) {
        $os_ct1_due_num = $declared_ct1_value * 0.05;
    } else {
        $os_ct1_due_num = 0;
        $os_ct1_rate = 'မစည်းကြပ်';
    }
}
$os_ct1_due         = $os_ct1_due_num === null ? '' : number_format($os_ct1_due_num, 0, '.', ',');
$advance_tax1_raw   = str_replace(',', '', (string)($db_data['advanceTax1'] ?? ''));
$advance_tax1_value = is_numeric($advance_tax1_raw) ? (float)$advance_tax1_raw : 0;
$os_ct1_balance_num = $os_ct1_due_num === null ? null : $os_ct1_due_num - $advance_tax1_value;
$os_ct1_balance     = $os_ct1_balance_num === null ? '' : number_format($os_ct1_balance_num, 0, '.', ',');

if (!function_exists('numToMyanmarText')) {
    function numToMyanmarText($number) {
        if (!$number) {
            return 'သုည';
        }
        $digits = ['', 'တစ်', 'နှစ်', 'သုံး', 'လေး', 'ငါး', 'ခြောက်', 'ခုနစ်', 'ရှစ်', 'ကိုး'];
        $units = ['', 'ဆယ်', 'ရာ', 'ထောင်', 'သောင်း', 'သိန်း', 'သန်း', 'ဆယ်သန်း', 'ရာသန်း'];
        $numStr = (string)floor($number);
        $result = '';
        $len = mb_strlen($numStr);
        for ($i = 0; $i < $len; $i++) {
            $digit = intval(mb_substr($numStr, $i, 1));
            $unitIndex = $len - $i - 1;
            if ($digit !== 0 && isset($units[$unitIndex])) {
                $result .= $digits[$digit] . $units[$unitIndex];
            }
        }
        return $result;
    }
}
$os_ct1_due_text = $os_ct1_balance_num === null ? '' : numToMyanmarText(abs($os_ct1_balance_num));

// (၄) ယခင်သုံးနှစ်စာ
$os_rowYear1        = htmlspecialchars($db_data['rowYear1'] ?? '-');
$os_income1         = htmlspecialchars($db_data['income1'] ?? '-');
$os_income_tax1     = htmlspecialchars($db_data['income_tax1'] ?? '-');
$os_sale_income1    = htmlspecialchars($db_data['sale_income1'] ?? '-');
$os_ct1             = htmlspecialchars($db_data['ct1'] ?? '-');

$os_rowYear2        = htmlspecialchars($db_data['rowYear2'] ?? '-');
$os_income2         = htmlspecialchars($db_data['income2'] ?? '-');
$os_income_tax2     = htmlspecialchars($db_data['income_tax2'] ?? '-');
$os_sale_income2    = htmlspecialchars($db_data['sale_income2'] ?? '-');
$os_ct2             = htmlspecialchars($db_data['ct2'] ?? '-');

$os_rowYear3        = htmlspecialchars($db_data['rowYear3'] ?? '-');
$os_income3         = htmlspecialchars($db_data['income3'] ?? '-');
$os_income_tax3     = htmlspecialchars($db_data['income_tax3'] ?? '-');
$os_sale_income3        = htmlspecialchars($db_data['sale_income3'] ?? '-');
$os_ct3             = htmlspecialchars($db_data['ct3'] ?? '-');

//ကုန်သွယ်ခွန်တွက်ချက်မှု1
$os_salesAmount1    = number_format($db_data['salesAmount1'] ?? '-');
$os_ct1tax          = htmlspecialchars($db_data['ct1tax'] ?? '-');
$os_rule42_1        = htmlspecialchars($db_data['rule42_1'] ?? '-');
$os_afterRuler1     = htmlspecialchars($db_data['afterRuler1'] ?? '-');
$os_advanceTax1     = number_format($db_data['advanceTax1'] ?? '-');

$os_salesAmount2    = htmlspecialchars($db_data['salesAmount2'] ?? '-');
$os_ct2tax          = htmlspecialchars($db_data['ct2tax'] ?? '-');
$os_rule42_2        = htmlspecialchars($db_data['rule42_2'] ?? '-');
$os_afterRuler2     = htmlspecialchars($db_data['afterRuler2'] ?? '-');
$os_advanceTax2     = htmlspecialchars($db_data['advanceTax2'] ?? '-');

$os_summary             = htmlspecialchars($db_data['summary'] ?? '-');
$os_appraisal           = htmlspecialchars($db_data['appraisal'] ?? '-');


?>




<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <title>ကုန်သွယ်လုပ်ငန်းခွန် တွက်ချက်မှုပုံစံ</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #d9dde2;
            font-family: "Pyidaungsu", "Myanmar Text", sans-serif;
            color: #000;
        }
        .sheet {
            width: 297mm;
            min-height: 210mm;
            margin: 12px auto;
            padding: 10mm 10mm 10mm 16mm;
            background: #fff;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.25);
        }
        .sheet table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            font-size: 15px;
            line-height: 1.55;
        }
        .sheet td { vertical-align: top; }
        .row-double td {
            height: 90px;
            vertical-align: middle;
        }
        .no-print-bottoms {
            display: flex;
            justify-content: center;
            gap: 15px;
            width: 297mm;
            margin: 12px auto 28px;
        }
        .no-print-bottoms button {
            font-family: "Pyidaungsu", "Myanmar Text", sans-serif;
            font-size: 16px;
            font-weight: bold;
            padding: 10px 24px;
            border-radius: 5px;
            cursor: pointer;
            color: #fff;
            border: 1px solid #222;
        }
        .btn-print { background: #28a745; }
        .btn-close { background: #dc3545; }
        @media print {
            body { background: #fff; }
            .no-print { display: none !important; }
            .sheet {
                width: auto;
                min-height: 0;
                margin: 0;
                padding: 6mm 10mm 0 14mm;
                box-shadow: none;
            }
            @page { size: A4 landscape; margin: 10mm 5mm 10mm 20mm; }
        }
    </style>
</head>
<body>
    <div class="sheet" id="printableSheet">
                    <div style="text-align: center; margin-bottom: 10px;">
                        <p style=" font-size: 15px; margin-bottom: 5px;text-align: right;">ပတခ(ကသခ)-၀၃-၀၁(င)အဆက်</p>
                    </div>
                    <p style="text-align: center; margin-bottom: 10px; font-weight: bold;"><span id="os_ct1_due"><?php echo htmlspecialchars($os_address); ?></span> ရှိ 
                        ကုန်သွယ်မှု/ဝန်ဆောင်မှုလုပ်ငန်း <span id="os_ct1_due"><?php echo htmlspecialchars($os_biz1); ?></span>၏ <span id="os_end_year"><?php echo htmlspecialchars($end_year); ?></span> ခုနှစ်၊ <span id="os_end_month"><?php echo htmlspecialchars($end_month); ?></span> လ <span id="os_end_day"><?php echo htmlspecialchars($end_day); ?></span> ရက်နေ့တွင် 
                        <br>ကုန်ဆုံးသော ဘဏ္ဍာရေးနှစ်အတွင်း ကုန်သွယ်မှုလုပ်ငန်းမှ ရောင်းရငွေ/ ဝန်ဆောင်မှုလုပ်ငန်းမှ ရငွေနှင့် ကျသင့်အခွန်စာရင်း
                    </P>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr style="text-align: center; border: 1.5px solid #000 !important; vertical-align: middle; line-height: 30px; font-weight: bold;">
                            <td style="width:5%; border-right: 1.5px solid #000 !important; vertical-align: middle;">အမှတ်<br>စဉ်</td>
                            <td style="width:25%; border-right: 1.5px solid #000 !important; vertical-align: middle;    ">လုပ်ငန်းအမျိုးအစား</td>
                            <td style="width:30%; border-right: 1.5px solid #000 !important; vertical-align: middle;">ကုန်သွယ်မှုလုပ်ငန်းမှ ရောင်းရငွေ/<br>ဝန်ဆောင်မှုလုပ်ငန်းမှ ရငွေ</td>
                            <td style="width:10%; border-right: 1.5px solid #000 !important; vertical-align: middle;">အခွန်နှုန်း</td>
                            <td style="width:25%; border-right: 1.5px solid #000 !important; vertical-align: middle;">ကျသင့်အခွန်</td>
                            <td style="width:10%; vertical-align: middle;">မှတ်ချက်</td>
                        </tr>
                        <tr style="text-align: center; border: 1.5px solid #000 !important; line-height: 30px;">
                            <td style="width:5%; border-right: 1.5px solid #000 !important;">(၁)</td>
                            <td style="width:25%; border-right: 1.5px solid #000 !important;">(၂)</td>
                            <td style="width:30%; border-right: 1.5px solid #000 !important;">(၃)</td>
                            <td style="width:10%; border-right: 1.5px solid #000 !important;">(၄)</td>
                            <td style="width:25%; border-right: 1.5px solid #000 !important;">(၅)</td>
                            <td style="width:10%; ">(၆)</td>
                        </tr>
                        <tr class="row-double" style="text-align: center; border: 1.5px solid #000 !important; line-height: 30px;">
                            <td style="width:5%; border-right: 1.5px solid #000 !important;">၁။</td>
                            <td style="width:25%; border-right: 1.5px solid #000 !important;"><span id="os_biz1"><?php echo $os_biz1; ?></span></td>
                            <td style="width:30%; border-right: 1.5px solid #000 !important;"><span id="os_declaredCT1"><?php echo $os_declaredCT1; ?></span></td>
                            <td style="width:10%; border-right: 1.5px solid #000 !important;"><?php echo htmlspecialchars($os_ct1_rate); ?></td>
                            <td style="width:25%; border-right: 1.5px solid #000 !important;"><span id="os_ct1_due"><?php echo htmlspecialchars($os_ct1_due); ?></span></td>
                            <td style="width:10%; "></td>
                        </tr>
                        <tr style="text-align: center; border: 0px solid #000 !important; line-height: 30px;">
                            <td colspan="4" style="width:5%; border-right: 1.5px solid #000 !important; text-align: left;">တစ်နှစ်လုံးအတွက်ကျသင့်အခွန်</td>
                            <!---<td style="width:25%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:30%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:10%; border-right: 1.5px solid #000 !important;"></td>--->
                            <td style="width:25%; border-left: 1.5px solid #000 !important; border-right: 1.5px solid #000 !important;"><span id="os_ct1_due"><?php echo htmlspecialchars($os_ct1_due); ?></span></td>
                            <td style="width:10%; border-left: 1.5px solid #000 !important; border-right: 1.5px solid #000 !important;"></td>
                        </tr>
                        <tr style="text-align: center; border: 0px solid #000 !important; line-height: 30px;">
                            <td colspan="4" style="width:5%; border-right: 1.5px solid #000 !important; text-align: left;">နုတ်-နှစ်အတွင်းလစဉ်ပေးသွင်းခဲ့သည့် အခွန်ပေါင်း</td>
                            <!---<td style="width:25%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:30%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:10%; border-right: 1.5px solid #000 !important;"></td>--->
                            <td style="width:25%; border-left: 1.5px solid #000 !important; border-right: 1.5px solid #000 !important;"><span id="os_advanceTax1"><?php echo htmlspecialchars($os_advanceTax1); ?></span></td>
                            <td style="width:10%; border-left: 1.5px solid #000 !important; border-right: 1.5px solid #000 !important;"></td>
                        </tr>
                        <tr style="text-align: center; border: 0px solid #000 !important; line-height: 30px;">
                            <td colspan="4" style="width:5%; border-right: 1.5px solid #000 !important; text-align: left;">ပေးသွင်းရန်ကျန်အခွန်/ပြန်အမ်းရန်ငွေ</td>
                            <!---<td style="width:30%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:10%; border-right: 1.5px solid #000 !important;"></td>--->
                            <td style="width:25%; border: 1.5px solid #000 !important;"><span id="os_ct1_balance"><?php echo htmlspecialchars($os_ct1_balance); ?></span></td>
                            <td style="width:10%; border: 1.5px solid #000 !important;"></td>
                        </tr>
                        <tr style="text-align: center; border: 0px solid #000 !important; line-height: 30px;">
                            <td colspan="6" style="width:5%; border-right: 0px solid #000 !important; text-align: center; font-weight: bold;">(စာဖြင့်)
                                <?php if ($os_ct1_due_text !== '') { ?>
                                    <span id="os_ct1_due_text"><?php echo htmlspecialchars($os_ct1_due_text); ?></span>
                                <?php } else { ?>
                                    ............................................................................................
                                <?php } ?>
                                ကျပ်တိတိ</td>
                            <!---<td style="width:30%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:10%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:25%; border: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:10%; border: 1.5px solid #000 !important;"></td>--->
                        </tr>
                        <tr style="text-align: center; border: 0px solid #000 !important; line-height: 30px;">
                            <td colspan="6" style="width:5%; border-right: 0px solid #000 !important; text-align: left;"><b>ဝန်ခံချက်။</b>&ensp;&ensp;&ensp;
                                အထက်ဖော်ပြထားသော အချက်အလက်များ မှန်ကန်ကြောင်း ဝန်ခံလက်မှတ်ရေးထိုးပါသည်။</td>
                            <!---<td style="width:30%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:10%; border-right: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:25%; border: 1.5px solid #000 !important;"></td>--->
                            <!---<td style="width:10%; border: 1.5px solid #000 !important;"></td>--->
                        </tr>
                    </table>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        
                        <tr style="text-align: right; border: 0px solid #000 !important; line-height: 30px;">
                            <td style="width:67%; border-right: 0px solid #000 !important; text-align: right;"></td>
                            <td style="width:13%; border: 0px solid #000 !important; text-align: left; vertical-align: bottom !important;">လက်မှတ်၊</td>
                            <td style="width:25%; border-bottom: 2px dotted #000 !important;"></td>
                        </tr>
                        <tr style="text-align: right; border: 0px solid #000 !important; line-height: 30px;">
                            <td style="width:67%; border-right: 0px solid #000 !important; text-align: right;"></td>
                            <td style="width:13%; border: 0px solid #000 !important; text-align: left; vertical-align: bottom !important;">အမည်၊</td>
                            <td style="width:25%; border-bottom: 2px dotted #000 !important; text-align: center;"><span id="os_name"><?php echo $os_name; ?></span></td>
                        </tr>
                        <tr style="text-align: right; border: 0px solid #000 !important; line-height: 30px;">
                            <td style="width:67%; border-right: 0px solid #000 !important; text-align: right;"></td>
                            <td style="width:13%; border: 0px solid #000 !important; text-align: left; vertical-align: bottom !important;">တာဝန်၊</td>
                            <td style="width:25%; border-bottom: 2px dotted #000 !important; text-align: center;"><span id="os_nrc"><?php echo $os_nrc; ?></span></td>
                        </tr>
                        <tr style="text-align: right; border: 0px solid #000 !important; line-height: 30px;">
                            <td style="width:67%; border-right: 0px solid #000 !important; text-align: right;"></td>
                            <td style="width:13%; border: 0px solid #000 !important; text-align: left; vertical-align: bottom !important;">ဖုန်း၊ e-mail လိပ်စာ၊</td>
                            <td style="width:25%; border-bottom: 2px dotted #000 !important; text-align: center;"><span id="os_ph_no"><?php echo $os_ph_no; ?></span></td>
                        </tr>
                        <tr style="text-align: right; border: 0px solid #000 !important; line-height: 30px;">
                            <td style="width:67%; border-right: 0px solid #000 !important; text-align: right;"></td>
                            <td colspan="2"style="width:13%; border-bottom: 2px dotted #000 !important; text-align: right; vertical-align: bottom !important;"><span id="os_address"><?php echo $os_address; ?></span></td>
                            
                        </tr>
                        
                    </table>
                    <p style="text-align: center; margin-bottom: 10px;"><b>မှတ်ချက်။</b>&ensp;&ensp;&ensp;ကုန်သွယ်မှုလုပ်ငန်းမှ ရောင်းရငွေ/ 
                        ဝန်ဆေင်မှုလုပ်ငန်းမှရငွေတို့ကို လုပ်ငန်းအမျိုးအစားအလိုက် စုပေါင်း၍ ဖော်ပြနိုင်ပါသည်။</p>
                    
    </div>
    <div class="no-print-bottoms no-print">
        <button type="button" class="btn-print" onclick="window.print()">Print ထုတ်မည်</button>
        <button type="button" class="btn-close" onclick="window.location.href='../CT1_Demand_List.php'">ပိတ်မည်</button>
    </div>
</body>
</html>