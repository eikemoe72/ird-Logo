<style>
    /* မီးခိုးနောက်ခံပေါ်မှာ A4 စာရွက်ဖြူကို ခွဲပြသည် */
    #form_CT1_KTK2Modal .modal-dialog {
        max-width: 236mm;
        width: 236mm;
        margin: 10px auto;
    }

    #form_CT1_KTK2Modal .modal-content {
        background-color: #c8c8c8;
        background-image: linear-gradient(180deg, #d4d4d4 0%, #bdbdbd 100%);
        border: 1px solid rgba(0,0,0,.28);
        border-radius: 16px;
        padding: 0 0 14px;
        box-shadow: 0 10px 24px rgba(0,0,0,.28);
    }

    #form_CT1_KTK2Modal #printableSheet {
        width: 210mm;
        min-height: 297mm;
        margin: 10px auto 10px;
        background: #fff;
        box-sizing: border-box;
        padding: 0mm 0mm;
        border: none !important;
        border-radius: 1px;
        box-shadow: 0 1px 0 rgba(255,255,255,.7), 0 8px 18px rgba(0,0,0,.35);
    }

    #form_CT1_KTK2Modal table.law-box,
    #form_CT1_KTK2Modal table.law-box td {
        border: 1.5px solid #000 !important;
        border-collapse: separate;
        border-spacing: 0;
    }

    #form_CT1_KTK2Modal .print-container {
        border: none !important;
        padding: 5mm 8mm 10mm 12mm !important;
        box-sizing: border-box;
        min-height: 0;
        line-height: 1.7;
    }

    #form_CT1_KTK2Modal .ktk-township-line {
        position: relative;
        display: block;
        text-align: center;
    }

    #form_CT1_KTK2Modal .ird-logo {
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 25.4mm;
        height: 25.4mm;
        object-fit: contain;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }

    #form_CT1_KTK2Modal .print-container div,
    #form_CT1_KTK2Modal .print-container p {
        line-height: 1.7 !important;
    }

    #form_CT1_KTK2Modal .print-container > table:last-child {
        margin-top: 12px !important;
    }

    @media print {
        .modal-footer, .no-print, .btn, .btn-close { display: none !important; }

        body:has(#form_CT1_KTK2Modal.show) > *:not(#form_CT1_KTK2Modal) {
            display: none !important;
        }

        #form_CT1_KTK2Modal,
        #form_CT1_KTK2Modal * {
            visibility: visible !important;
        }

        #form_CT1_KTK2Modal {
            position: static !important;
            left: auto !important;
            top: auto !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
        }

        #form_CT1_KTK2Modal .modal-dialog,
        #form_CT1_KTK2Modal .modal-content {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
            box-shadow: none !important;
            border: none !important;
        }

        #form_CT1_KTK2Modal #printableSheet {
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            max-height: none !important;
            margin: 0 !important;
            padding: 0 !important;
            box-sizing: border-box !important;
            box-shadow: none !important;
            background: #fff !important;
            overflow: visible !important;
        }

        #form_CT1_KTK2Modal .print-container {
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            margin: 0 !important;
            border: none !important;
            padding-: 10mm 5mm 10mm 20mm!important;
            box-sizing: border-box !important;
            line-height: 2 !important;
        }

        #form_CT1_KTK2Modal table.law-box {
            border-collapse: separate !important;
            border-spacing: 0 !important;
            border: 1px solid #000 !important;
        }

        #form_CT1_KTK2Modal table.law-box td {
            border: 0px solid #000 !important;
        }
    }
</style>

<div class="modal fade" id="form_CT1_KTK2Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 12px; border-bottom: none;">
                <h5 class="modal-title">ကုန်သွယ်လုပ်ငန်းခွန် မှတ်ပုံတင်လက်မှတ် ထုတ်ယူရန်</h5>
                <button type="button" class="close-modal-btn" onclick="window.location.href='CT1_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div id="printableSheet">
                <div class="print-container" >
                    
                <table class="law-box" style="border: 1px solid #000; text-align:center; font-size:14px; width:100%; line-height:25px; margin-bottom: 10px;">
                    <tr>
                        <td style='padding:5px'>
                            ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>
                            ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                        </td>
                    </tr>
                </table>
                    <p style='text-align:right; font-size:15px;'>ပတခ(ကသခ)-၀၁-၀၂</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:20px; font-size:17px;">
                    ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                    <span class="ktk-township-line"><img src="Image/ird-logo.png" alt="ပြည်တွင်းအခွန်များဦးစီးဌာန" class="ird-logo"><span id="CT1_KTK2_township"></span></span>
                    <span id="CT1_KTK2_state"></span><br>
                        ကုန်သွယ်လုပ်ငန်းခွန်စည်းမျဉ်း ၄ အရ ကုန်စည်ထုတ်လုပ်သူ သို့မဟုတ် ကုန်သွယ်မှုဆောင်ရွက်သူ သို့မဟုတ် <br>
                        ဝန်ဆောင်မှုဆောင်ရွက်သူအား ထုတ်ပေးသည့် လုပ်ငန်းမှတ်ပုံတင်လက်မှတ်<br>
                        

                    </div>
                    
                    <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>မှတ်ပုံတင်လက်မှတ် အမှတ်စဉ်</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%; border-bottom:2px dotted #000;'>
                                (.........) / <span id="CT1_KTK2_year"></span> 
                                <span style="padding-left:200px;">ရက်စွဲ၊</span>
                            </td>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>အခွန်ထမ်းအမည် </b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'>
                                <span id="CT1_KTK2_name"></td>
                        </tr>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'>
                                ( <span id="CT1_KTK2_ct1_gir"></span> ) / ( <span id="CT1_KTK2_ct2_gir"></span> )
                            </td>
                        </tr>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>နိုင်ငံသားစိစစ်ရေးကဒ်ပြားအမှတ်</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'></td>
                        </tr>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>ကုမ္ပဏီမှတ်ပုံတင်အမှတ်</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'></td>
                        </tr>
                       
                        <tr>
                            <td style='text-align:left; width:30%;'><b>လိပ်စာ</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'><span id="CT1_KTK2_address"></span></td>
                        </tr>
                        
                    </table>

                    
                    <div style="text-align:justify; line-height:1.8;font-size:15px; ">
                        ၁။<span style = 'padding-left:50px;  text-align:justify;'>အောက်ဖော်ပြပါ ကုန်စည်ထုတ်လုပ်မှု/ ကုန်သွယ်မှု/ ဝန်ဆောင်မှု(များ)ကို ဆောင်ရွက်သူ 
                            ( <strong><span id="CT1_KTK2_biz_name"></span></strong> ) သို့ မှတ်ပုံတင်လက်မှတ်ကိုကုန်သွယ်လုပ်ငန်းခွန် စည်းမျဉ်း၄ အရ ထုတ်ပေးလိုက်သည်- <br>
                            <span style="padding-left:62px;">ထုတ်လုပ်သည့်ကုန်စည်/ ဆောင်ရွက်သည့် ကုန်သွယ်မှု/ ဝန်ဆောင်မှု(များ) .......................................
                            <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                                <tr>
                                    <td style='text-align:left; width:9%;'></td>
                                    <td style='text-align:left; width:91%;border-bottom:2px dotted #000;'><b>( <span id="CT1_KTK2_biz"></span> )</b></td>
                                </tr>
                                <tr>
                                    <td style='text-align:left; width:9%;'></td>
                                    <td style='text-align:left; width:91%;border-bottom:2px dotted #000;'><b>( <span id="CT1_KTK2_biz_tatail"></span> )</b></td>
                                </tr>
                            </table>
                    </div>
                    

                    <div style="margin-top:15px; text-align:justify; line-height:1.8;">
                        ၂။<span style = 'padding-left:50px;'>ဤလက်မှတ်သည်  အောက်ဖော်ပြပါနေရာ၌ လုပ်ကိုင်ဆောင်ရွက်သော လုပ်ငန်းများအတွက်ဖြစ်သည်-
                        <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                            <tr>
                                <td style='text-align:left; width:40px;'></td>
                                <td style='text-align:right; width:140px;text-align:Left;'>လုပ်ငန်းအဓိက တည်ရှိရာနေရာ :</td>
                                <td style='text-align:center; width:10px;'>-</td>
                                <td style='text-align:left; width:200px;border-bottom:2px dotted #000;min-width:300px;'>
                                   <span id="CT1_KTK2_address2"></span></td>
                            </tr>
                            <tr>
                                <td style='text-align:left; width:40px;'></td>
                                <td style='text-align:right; width:140px;text-align:Left;'></td>
                                <td style='text-align:center; width:10px;'>-</td>
                                <td style='text-align:left; width:200px;border-bottom:2px dotted #000;min-width:300px;'>
                                   &ensp;</td>
                            </tr>
                            <tr>
                                <td style='text-align:left; width:40px;'></td>
                                <td colspan="3" style='text-align:right; width:140px;text-align:Left;'>လုပ်ငန်းခွဲများ( ၂ ခုထက်ပိုသော လုပ်ငန်းခွဲများအား နောက်ဆက်တွဲဖြင့် ဖော်ပြထားပါသည်။)-</td>
                                <!--<td style='text-align:right; width:10px;'>-</td>-->
                                <!--<td style='text-align:left; width:200px;border-bottom:2px dotted #000;min-width:300px;'></td>-->
                            </tr>
                        </table>
                        <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                            <tr>
                                <td style='text-align:left; width:40px'></td>
                                <td style='text-align:right; width:20px;text-align:Left;'></td>
                                <td style='text-align:right; width:20px;'>(၁)</td>
                                <td style='text-align:left; width:200px;border-bottom:2px dotted #000;min-width:300px;'></td>
                            </tr>
                            <tr>
                                <td style='text-align:left; width:40px'></td>
                                <td style='text-align:right; width:20px;text-align:Left;'></td>
                                <td style='text-align:right; width:20px;'>&ensp;</td>
                                <td style='text-align:left; width:200px;border-bottom:2px dotted #000;min-width:300px;'>&ensp;</td>
                            </tr>
                            <tr>
                                <td style='text-align:left; width:40px'></td>
                                <td style='text-align:right; width: 20px;px;text-align:Left;'></td>
                                <td style='text-align:right; width:20px;'>(၂)</td>
                                <td style='text-align:left; width:200px;border-bottom:2px dotted #000;min-width:300px;'></td>
                            </tr>
                            <tr>
                                <td style='text-align:left; width:40px'></td>
                                <td style='text-align:right; width: 20px;px;text-align:Left;'></td>
                                <td style='text-align:right; width:20px;'>&ensp;</td>
                                <td style='text-align:left; width:200px;border-bottom:2px dotted #000;min-width:300px;'>&ensp;</td>
                            </tr>
                        </table>
                    </div>
                    
                    
                    <div style="text-align:justify; line-height:1.8;">
                        ၅။<span style = 'padding-left:50px; text-align:justify;'>ဤလက်မှတ်သည်
                        ( ၃၁-၀၃-<span id="year_end"></span> )ရက်နေ့တွင် ကုန်ဆုံးသော နှစ်အထိသာ အတည်ဖြစ်သည်။
                    </div>
                    

                    <br><br>

                    <table style='width:100%; margin-top:40px;'>
                        <tr>
                            <td style='width:50%; padding-left:60px; vertical-align:top;'><br>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br>
                                ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                <span id="CT1_KTK2_township2"></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                    <p style='text-align:left; font-size:15px;'>ရက်စွဲ၊......................</p>
                    <br><br>
                    <p style='text-align:center; font-size:15px;'>-၂-</p>
                    <p style='text-align:center; font-size:15px;'><b>သတ်မှတ်ချက်များ</b></p>
                    <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'>၁။</td>
                            <td colspan="2" style='text-align:Justify; width:5%;'>ဤမှတ်ပုံတင်လက်မှတ် သို့မဟုတ် လက်မှတ်မိတ္တူများကို လုပ်ငန်းဥပစာ အသီးသီးတွင် အများမြင်သာအောင် ချိတ်ဆွဲထားရမည်။</td>
                            <!---<td style='text-align:Justify; width:80%;'></td>--->
                        </tr>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'>၂။</td>
                            <td colspan="2" style='text-align:Justify; width:5%;'>
                            အခွန်ထမ်းအမည်(လုပ်ငန်းအမည်အပါအဝင်)၊ လိပ်စာ၊ လုပ်ငန်းတည်နေရာ သို့မဟုတ် လုပ်ငန်းသဘော သဘာဝ တစ်ခုခု ပြောင်းလဲလျှင်
                            ပြောင်းလဲမှု ပြုလုပ်သည့်နေ့မှ (၁၅)ရက်အတွင်း မှတ်ပုံတင်လက်မှတ်နှင့်အတူ တာဝန်ခံအရာရှိထံသို့ အကြောင်းကြားရမည်။</td>
                            <!---<td style='text-align:Justify; width:80%;'></td>--->
                        </tr>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'>၃။</td>
                            <td colspan="2" style='text-align:Justify; width:5%;'>
                            လုပ်ငန်းရပ်စဲလျှင် သို့မဟုတ် ပိုင်ဆိုင်မှုလွှဲပြောင်းခြင်းကြောင့် လုပ်ငန်းဆက်လက်လုပ်ကိုင်ခြင်းမရှိလျှင် ရပ်စဲသည့်နေ့အထိ 
                            စည်းကြပ်ရန်ရှိသောကာလအတွက် ကြေညာလွှာကို မှတ်ပုံတင်လက်မှတ်နှင့်အတူ လုပ်ငန်းရပ်စဲသည့်နေ့မှ ၁၅ ရက်အတွင်း တာဝန်ခံအရာရှိထံသို့ တင်ပြရမည်။</td>
                            <!---<td style='text-align:Justify; width:80%;'></td>--->
                        </tr>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'>၄။</td>
                            <td colspan="2" style='text-align:Justify; width:5%;'>
                            မည်သူမဆို အောက်ပါပျက်ကွက်မှု တစ်ရပ်ရပ်ကို ကျူးလွန်ပါက ပေးဆောင်ရမည့်အခွန်၏ ၁၀ ရာခိုင်နှုန်းနှင့်ညီမျှသော ဒဏ်ကြေးငွေကို ပေးဆောင်ရမည်-</td>
                            <!---<td style='text-align:Justify; width:80%;'></td>--->
                        </tr>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'></td>
                            <td style='text-align:center; width:5%;text-align:Left;vertical-align:top;'>(က)</td>
                            <td style='text-align:Justify; width:80%;'>အခွန်ဥပဒေတစ်ရပ်ရပ်နှင့်အညီ မှတ်ပုံတင်ရန်ပျက်ကွက်ခြင်း၊ </td>
                        </tr>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'></td>
                            <td style='text-align:center; width:5%;text-align:Left;vertical-align:top;'>(ခ)</td>
                            <td style='text-align:Justify; width:80%;'>ပုဒ်မ ၉၊ ပုဒ်မခွဲ(စ)နှင့် ပုဒ်မခွဲ(ဆ)တို့အရ အခွန်ထမ်းဆိုင်ရာ 
                                သတင်းအချက်အလက် ပြောင်းလဲမှုကို ညွှန်ကြားရေးမှူးချုပ်သို့ အကြောင်းကြားရန် ပျက်ကွက်ခြင်း၊</td>
                        </tr>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'></td>
                            <td style='text-align:center; width:5%;text-align:Left;vertical-align:top;'>(ဂ)</td>
                            <td style='text-align:Justify; width:80%;'> 
                            အခွန်ဥပဒေတစ်ရပ်ရပ်အရ အခွန်ထမ်းမှတ်ပုံတင် ပယ်ဖျက်ခြင်းကို ဥပဒေနှင့်အညီ လျှောက်ထားရန် ပျက်ကွက်ခြင်း။၊</td>
                        </tr>
                        <tr>
                            <td style='text-align:center; vertical-align:top; width:15%'>၅။</td>
                            <td colspan="2" style='text-align:Justify; width:5%;'>
                            မှတ်ပုံတင်လက်မှတ် သက်တမ်းတိုး လျှောက်ထားလိုပါက ကုန်သွယ်လုပ်ငန်းခွန် စည်းမျဉ်း ၃၊ စည်းမျဉ်ခွဲ(ခ) အရ မှတ်ပုံတင်လက်မှတ် 
                        သက်တမ်းမကုန်ဆုံးမည် ၁ လကြိုတင်၍ တာဝန်ခံအရာရှိထံ လျှောက်ထားရမည်ဖြစ်သည်။</td>
                            <!---<td style='text-align:Justify; width:80%;'></td>--->
                        </tr>
                       
                    </table>

                    </div>
                </div>
            
            
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="universalPrint('form_CT1_KTK2Modal')">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
function openFormCT1_KTK2() {
    var data = window.selectedRowData;
    if (!data) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
        return;
    }

    const toMyanmarDigit = (num) => {
        if (num === null || num === undefined || num === "") return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    // ၁။ Tax Year ကို တစ်နှစ်လျှော့ပြီး ရှေ့နှစ်/နောက်နှစ် ခွဲထုတ်ခြင်း
    let rawYear = data.taxYear || ""; // e.g., "2026-2027"
    let reducedYear = rawYear.replace(/\d+/g, (match) => parseInt(match) - 1); // "2025-2026" ဖြစ်သွားမည်
    
    let yearParts = reducedYear.split("-"); // ["2025", "2026"]
    let startYear = yearParts[0] ? toMyanmarDigit(yearParts[0]) : ""; // "၂၀၂၅"
    let endYear = yearParts[1] ? toMyanmarDigit(yearParts[1]) : "";   // "၂၀၂၆"

    // ၂။ စဉ် ၅ နှင့် စဉ် ၆ နေရာတွင် Data ထည့်ခြင်း
    // HTML ထဲရှိ စဉ် ၅/၆ နေရာတွင် <span id="year_start"></span> နှင့် <span id="year_end"></span> ထည့်ထားရန် လိုသည်
    setText('year_start', startYear); // စဉ် ၆ (1-04-) ၏ နောက်တွင် ထည့်ရန်
    setText('year_end', endYear);     // စဉ် ၅ (31-03-) ၏ နောက်တွင် ထည့်ရန်

    const girText = (selectVal, noVal) => {
        const kind = selectVal || '';
        const no = toMyanmarDigit(noVal || '');
        if (!kind && !no) return '';
        return kind + (no ? ' / ' + no : '');
    };
    setText('CT1_KTK2_ct1_gir', girText(data.ct1_select_real, data.ct1_no_real));
    setText('CT1_KTK2_ct2_gir', girText(data.ct2_select_real, data.ct2_no_real));
    setText('CT1_KTK2_name', data.taxpayer_name);
    setText('CT1_KTK2_address', data.address);
    setText('CT1_KTK2_address2', data.address);
    setText('CT1_KTK2_biz', data.businessType1);
    setText('CT1_KTK2_biz_tatail', data.businessType2);
    setText('CT1_KTK2_state', data.state_name);
    const townshipName = data.township_name || data.township || '';
    setText('CT1_KTK2_township', townshipName);
    setText('CT1_KTK2_township2', townshipName);
    setText('CT1_KTK2_year', toMyanmarDigit(reducedYear)); // (၂၀၂၅-၂၀၂၆) တစ်ခုလုံးပြရန်
    setText('CT1_KTK2_biz_name', data.taxpayer_name);

    // Modal ဖွင့်ခြင်း
    const modalElem = document.getElementById('form_CT1_KTK2Modal');
    if (modalElem) {
        var myModal = bootstrap.Modal.getOrCreateInstance(modalElem);
        myModal.show();
    }
}
</script>