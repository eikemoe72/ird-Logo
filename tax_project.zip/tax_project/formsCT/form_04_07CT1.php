<style>
    /* မီးခိုးနောက်ခံပေါ်မှာ A4 စာရွက်ဖြူကို ခွဲပြသည် */
    #formCT10407Modal .modal-dialog {
        max-width: 236mm;
        width: 236mm;
        margin: 10px auto;
    }

    #formCT10407Modal .print-container {
        padding: 0;
        box-sizing: border-box;
    }

    #formCT10407Modal #printableSheet_0407,
    #formCT10407Modal #printableSheet_0407 p,
    #formCT10407Modal #printableSheet_0407 div,
    #formCT10407Modal #printableSheet_0407 table,
    #formCT10407Modal #printableSheet_0407 td {
        line-height: 1.7;
    }

    #formCT10407Modal #printableSheet_0407 table.law-box,
    #formCT10407Modal #printableSheet_0407 table.law-box td {
        line-height: 25px;
    }

    #formCT10407Modal .modal-header {
        margin-left: 0 !important;
        width: auto;
        background-color: #0b5ed7;
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 10px;
        border-bottom: none;
    }

    #formCT10407Modal .modal-title {
        color: #fff;
        margin: 0;
    }

    #formCT10407Modal table.law-box,
    #formCT10407Modal table.law-box td {
        border: 1.5px solid #000 !important;
    }
    #formCT10407Modal .modal-content {
        background-color: #c8c8c8;
        background-image: linear-gradient(180deg, #d4d4d4 0%, #bdbdbd 100%);
        border: 1px solid rgba(0,0,0,.28);
        border-radius: 16px;
        outline: 0;
        padding: 0 0 14px;
        box-shadow: 0 10px 24px rgba(0,0,0,.28);
    }

    #formCT10407Modal #printableSheet_0407 {
        width: 210mm;
        min-height: 297mm;
        margin: 10px auto 10px;
        background: #fff;
        box-sizing: border-box;
        padding: 5mm 5mm 5mm 5mm;
        border-radius: 1px;
        box-shadow: 0 1px 0 rgba(255,255,255,.7), 0 8px 18px rgba(0,0,0,.35);
    }
    #formCT10407Modal .print-container {
            padding: 10mm 5mm 10mm 10mm !important;
            border: none !important;
        }

    @media print {
        #formCT10407Modal .modal-footer,
        #formCT10407Modal .no-print,
        #formCT10407Modal .btn,
        #formCT10407Modal .btn-close {
            display: none !important;
        }

        body:has(#formCT10407Modal.show) > *:not(#formCT10407Modal) {
            display: none !important;
        }

        #formCT10407Modal,
        #formCT10407Modal * {
            visibility: visible !important;
        }

        #formCT10407Modal {
            position: static !important;
            left: auto !important;
            top: auto !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
        }

        #formCT10407Modal .modal-dialog,
        #formCT10407Modal .modal-content {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            box-shadow: none !important;
            background: #fff !important;
            background-image: none !important;
        }

        #formCT10407Modal #printableSheet_0407 {
            width: 100% !important;
            min-height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            box-shadow: none !important;
            background: #fff !important;
        }

        #formCT10407Modal .print-container {
            padding: 10mm 10mm 10mm 20mm !important;
            border: none !important;
        }

        #formCT10407Modal #printableSheet_0407,
        #formCT10407Modal #printableSheet_0407 p,
        #formCT10407Modal #printableSheet_0407 table,
        #formCT10407Modal #printableSheet_0407 td {
            line-height: 1.7 !important;
        }

        #formCT10407Modal #printableSheet_0407 table.law-box,
        #formCT10407Modal #printableSheet_0407 table.law-box td {
            line-height: 25px !important;
        }

        #formCT10407Modal table.law-box,
        #formCT10407Modal table.law-box td {
            border: 1.5px solid #000 !important;
        }
    }

  
</style>
<div class="modal fade" id="formCT10407Modal" tabindex="-1" data-bs-focus="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">စည်းကြပ်မှုဆုံးဖြတ်ချက် ပတခ(ကသခ)-၀၄-၀၇ ထုတ်ယူရန်</h5>
                <button type="button" class="close-modal-btn" onclick="window.location.href='CT1_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div id="printableSheet_0407">
                <div class="print-container">
                    <table class="law-box" style="border: 1.5px solid #000; text-align:center; font-size:15px; width:100%; line-height:28px; margin-bottom: 10px;">
                        <tr>
                            <td style='padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>
                                ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px;'>ပတခ(ကသခ)-၀၄-၀၇</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:15px; font-size:15px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေ ပုဒ်မ ၂၇၊ ၂၈၊ ၃၀ နှင့် ၆၄ တို့အရ ကုန်သွယ်လုပ်ငန်းခွန် <br>
                        စည်းကြပ်မှုနှင့် ဒဏ်ကြေးငွေစည်းကြပ်မှု ဆုံးဖြတ်ချက်
                    </div>

                    <table style="width:100%">
                        <tr>
                            <td style="width:85%; text-align:right;"><b>ရက်စွဲ၊</b></td>
                            <td style="width:15%; border-bottom: 1px dotted #000; text-align:center;"><span id="m0407CT1_ct1DemandDate"></span></td>
                        </tr>
                        <tr>
                            <td style="width:85%; text-align:right;"><b>စည်းကြပ်နှစ်၊</b></td>
                            <td style="width:15%; border-bottom: 1px dotted #000; text-align:center;"><span id="m0407CT1_taxYear"></span></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                        <tr>
                            <td style='width:5%;'><b>၁။</b></td>
                            <td style='width:40%;'><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</b></td>
                            <td style='width:55%; border-bottom:2px dotted #000;'><span id="m0407CT1_ct1_gir"></span></td>
                        </tr>
                        <tr>
                            <td><b>၂။</b></td>
                            <td><b>အခွန်ထမ်းအမည်နှင့်လိပ်စာ</b></td>
                            <td style='border-bottom:2px dotted #000;'><span id="m0407CT1_name"></span> / <span id="m0407CT1_address"></span></td>
                        </tr>
                        <tr>
                            <td><b>၃။</b></td>
                            <td><b>အခွန်ထမ်းအမျိုးအစား</b></td>
                            <td style='border-bottom:2px dotted #000;'>ပုဂ္ဂလိက</td>
                        </tr>
                        <tr>
                            <td><b>၄။</b></td>
                            <td><b>လုပ်ငန်းအမျိုးအစားနှင့်မှတ်ပုံတင်အမှတ်</b></td>
                            <td style='border-bottom:2px dotted #000;'><span id="m0407CT1_businessType1"></span></td>
                        </tr>
                        <tr>
                            <td><b>၅။</b></td>
                            <td><b>လုပ်ငန်းခွဲများ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b>၆။</b></td>
                            <td><b>(က) ပုဂ္ဂိုလ်စုဝင်များ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b></b></td>
                            <td><b>(ခ) အစုများ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b>၇။</b></td>
                            <td><b>ကြေညာသည့်ရောင်းရငွေ/ဝန်ဆောင်မှုရငွေ </b></td>
                            <td style='border-bottom:2px dotted #000;'>(ကသခ)<span id="m0407CT1_declaredCT1"></span></td>
                        </tr>
                        <tr>
                            <td><b>၈။</b></td>
                            <td><b>တင်ပြသောစာရင်းများ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b>၉။</b></td>
                            <td><b>စည်းကြပ်သည့်ပုဒ်မ</b></td>
                            <td style='border-bottom:2px dotted #000;'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀၊ ၆၄ </td>
                        </tr>
                        <tr>
                            <td><b>၁၀။</b></td>
                            <td><b>လုပ်ငန်းနှစ်(အခွန်ကာလ)</b></td>
                            <td style='border-bottom:2px dotted #000;'>( ၃၁-၀၃-<span id="m0407CT1_year_start"></span> ) ရက်နေ့တွင် ကုန်ဆုံးသည့်နှစ်</td>
                        </tr>
                    </table>

                    

                    <p style='text-align:center; font-size:15px;'><b>ကုန်သွယ်လုပ်ငန်းခွန်စည်းကြပ်မှုနှင့်ဒဏ်ငွေစည်းကြပ်မှုဆုံးဖြတ်ချက်</b></p>

                    <div style="text-align:justify; line-height:1.7; margin-top:5px;">
                        <span style='padding-left:50px;'>အခွန်ထမ်းသည် နှစ်ချုပ်စာရင်းကို ကုန်သွယ်လုပ်ငန်းခွန်ဥပဒေ ပုဒ်မ(၁၃-က) 
                            နှင့်အညီ အချိန်မီ တင်သွင်းထားပါသည်/ မတင်သွင်းပါ။ ကြိုတင်ခွန်( <span style="color:red;" id="m0407CT1_advanceTax1"></span> )ကျပ်ကို 
                            ပေးသွင်းထားပါသည်။/ မပေးသွင်းထားပါ။ ဝင်ငွေနှင့်ပတ်သက်သော စာရင်းဇယားအထောက်အထားများကို 
                            ခိုင်လုံစွာ တင်ပြထားပါသည်/ မတင်ပြပါ။ တင်သွင်းသော ဝင်ငွေကြေညာလွှာနှင့် နှစ်ချုပ်စာရင်းပါ 
                            အရှုံးအမြတ်စာရင်း၊ ရရှိထားသော သတင်းအချက်အလက်အထောက်အထားများ အခွန်ထမ်း၏ 
                            ထွက်ဆိုတင်ပြချက်၊ စီးပွားရေးလုပ်ငန်း အခြေအနေနှင့် ကွင်းဆင်း စုံစမ်းလေ့လာ တွေ့ရှိရသော 
                            သတင်းအချက်အလက်များကို အခြေခံ၍ ကုန်သွယ်လုပ်ငန်းခွန်ဥပဒေပုဒ်မ ၁၄၊ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု
                            ဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀၊ ၆၄ တို့အရ အောက်ပါအတိုင်း စည်းကြပ်မှုအမိန့်ချမှတ်လိုက်သည်-
                    </div>
                        <table style='width:100%; font-size:15px; margin-top: 10px; height:10px;'>
                            <tr>
                                <td style='width:60%; text-align:right;'>သတ်မှတ်ရောင်းရငွေ</td>
                                <td style='width:5%; text-align:center;'>=</td>
                                <td style='width:20%; border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_salesAmount1"></span></td>
                                <td style='width:15%; text-align:right;'></td>
                            </tr>
                            <tr>
                                <td style='text-align:right;'>ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_ct1tax"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="row_to_hide1">
                                <td style='text-align:right;'>သတ်မှတ်ရောင်းရငွေ(၂)</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_salesAmount2"></span></td>
                                <td></td>
                            </tr>

                            <tr id="row_to_hide2">
                                <td style='text-align:right;'>ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်(၂)</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right;'><span id="m0407CT1_ct2tax"></span></td>
                                <td></td>
                            </tr>
                            <tr id="row_to_hide3">
                                <td style='text-align:right;'>စုစုပေါင်းကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_minusCTInput"></span></td>
                                <td></td>
                            </tr>
                            <tr id="orig_row1">
                                <td style='text-align:right;'>စည်းမျဉ်း ၄၂ အရ ခုနှိမ်သောအခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:red;'><span id="m0407CT1_rule42_1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="orig_row2">
                                <td style='text-align:right;'>ပေးဆောင်ရမည့် ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_afterRuler1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="orig_row3">
                                <td style='text-align:right;'>(နုတ်) ကြိုတင်ခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:red;'><span id="m0407CT1_advanceTax11"></span></td>
                                <td style='text-align:right;'></td> 
                            </tr>
                            <tr id="orig_row4">
                                <td style='text-align:right;'>ထပ်မံပေးဆောင်ရန်အခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_netTax1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="orig_row5">
                                <td style='text-align:right;'>ပုဒ်မ-၂၁(က)၊(ခ)၊(ဂ)၊(ဃ)၊(င)၊(စ)တို့အရ ဒဏ်ငွေ</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:blue;'><span id="m0407CT1_penalty1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="orig_row6">
                                <td style='text-align:right;'>စုစုပေါင်းပေးဆောင်ရန်အခွန်နှင့်ဒဏ်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right;'><span id="m0407CT1_totalTax1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>



                            <tr id="total_row1">
                                <td style='text-align:right;'>စည်းမျဉ်း ၄၂ အရ ခုနှိမ်သောအခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:red;'><span id="m0407CT1_rule42_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="total_row2">
                                <td style='text-align:right;'>ပေးဆောင်ရမည့် ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_afterRuler_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="total_row3">
                                <td style='text-align:right;'>(နုတ်) ကြိုတင်ခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:red;'><span id="m0407CT1_advanceTax_total"></span></td>
                                <td style='text-align:right;'></td> 
                            </tr>
                            <tr id="total_row4">
                                <td style='text-align:right;'>ထပ်မံပေးဆောင်ရန်အခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT1_netTax_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="total_row5">
                                <td style='text-align:right;'>ပုဒ်မ-၂၁(က)၊(ခ)၊(ဂ)၊(ဃ)၊(င)၊(စ)တို့အရ ဒဏ်ငွေ</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:blue;'><span id="m0407CT1_penalty_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="total_row6">
                                <td style='text-align:right;'>စုစုပေါင်းပေးဆောင်ရန်အခွန်နှင့်ဒဏ်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right;'><span id="m0407CT1_Taxpenalty_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                        </table>

                 

                        <br><br><br><br>
                        <p style="text-align:right; line-height:1.8; margin-top:5px;">ပတခ(ကသခ)-၀၄-၀၇(အဆက်)</p>
                        <div style="text-align:justify; line-height:1.8; margin-top:5px;" id="orig_row7">
                        <span style='padding-left:50px;'>အခွန်နှင်ဒဏ်ငွေ( <span style="color:red;" id="m0407CT1_totalTax11"></span> )ကျပ်ကို 
                            ( <span style="color:red;" id="m0407CT1_rq_date1"></span> )ရက်နေ့ မတိုင်မီ ပေးဆောင်စေရန် 
                            စည်းကြပ်မှုအကြောင်းကြားစာ ပတခ(ကသခ)-၀၄-၀၈ နှင့် ငွေသွင်းချလန် ပတခ(ကသခ)-၁၉ တို့ကို ပေးပို့ပါရန်။
                        </div>
                        <div style="text-align:justify; line-height:1.8; margin-top:5px;" id="total_row7"><br><br><br><br>
                        <p style='text-align:right; font-size:15px;'>ပတခ(ကသခ)-၀၄-၀၇(အဆက်)</p>
                        <span style='padding-left:50px;'>ပေးဆောင်ရန် အခွန်နှင်ဒဏ်ငွေ( <span style="color:red;" id="m0407CT1_Taxpenalty1_total"></span> )ကျပ်ကို 
                            ( <span style="color:red;" id="m0407CT1_rq_date11"></span> )ရက်နေ့ မတိုင်မီ ပေးဆောင်စေရန် ကုန်သွယ်လုပ်ငန်းခွန် 
                            စည်းကြပ်မှုအကြောင်းကြားစာ ပတခ(ကသခ)-၀၄-၀၈ နှင့် ငွေသွင်းချလန် ပတခ(ကသခ)-၁၉ တို့ကို ပေးပို့ပါရန်။<br><br>
                        </div>

                        <br><br><br><br>
                    <table style='width:100%; margin-top:40px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px; vertical-align:top;'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br>
                                <span id="m0407CT1_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="universalPrint('formCT10407Modal')">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>

// ၁။ Print ထုတ်ရန် သီးသန့် Function (ဒါကို အပြင်မှာ သီးသန့် ထားရပါမယ်)
function universalPrint(modalId) {
    // ခေတ္တ hide လုပ်မယ့်အစား တိုက်ရိုက် print ထုတ်ကြည့်ပါ
    // အပေါ်က CSS logic က အလုပ်လုပ်ရင် hide လုပ်စရာ မလိုတော့ပါဘူး
    window.print();
}

function openFormCT1_0407() {
    console.log("၀၄-၀၇ ဒေတာချိတ်ဆက်မှု စတင်ပါပြီ");

    var data = window.selectedRowData;
    if (!data) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    const toMyanmarDigit = (num) => {
        if (!num) return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    // အခြေခံအချက်အလက်များ
    setText('m0407CT1_ct1DemandDate', toMyanmarDigit(data.ct1DemandDate)); 
    setText('m0407CT1_taxYear', toMyanmarDigit(data.taxYear));
    setText('m0407CT1_name', data.taxpayer_name);
     setText('m0407CT1_businessType1', data.businessType1);
    setText('m0407CT1_address', data.address);
    setText('m0407CT1_declaredCT1', toMyanmarDigit(data.declaredCT1));

    // ၅။ တွက်ချက်မှုဆိုင်ရာ ဂဏန်းများ
    setText('m0407CT1_salesAmount1', toMyanmarDigit(data.salesAmount1));
    setText('m0407CT1_ct1tax', toMyanmarDigit(data.ct1tax));
    setText('m0407CT1_salesAmount2', toMyanmarDigit(data.salesAmount2));
    setText('m0407CT1_ct2tax', toMyanmarDigit(data.ct2tax));
    setText('m0407CT1_rule42_1', toMyanmarDigit(data.rule42_1));
    setText('m0407CT1_afterRuler1', toMyanmarDigit(data.afterRuler1));
    setText('m0407CT1_advanceTax11', toMyanmarDigit(data.advanceTax1));
    setText('m0407CT1_netTax1', toMyanmarDigit(data.netTax1));
    setText('m0407CT1_penalty1', toMyanmarDigit(data.penalty1));
    setText('m0407CT1_totalTax1', toMyanmarDigit(data.totalTax1));
    setText('m0407CT1_totalTax11', toMyanmarDigit(data.totalTax1));

    
    setText('m0407CT1_ct1_gir', (data.ct1_select2_real || 'ကသ') + " / " + (data.ct1_no_real || '') );


    // လုပ်ငန်းနှစ် (Start Year နှင့် End Year) ခွဲထုတ်ခြင်း
    if (data.taxYear) {
        let yearParts = data.taxYear.split("-"); // "2025-2026"
        let startYear = yearParts[0] ? toMyanmarDigit(yearParts[0]) : "";
        setText('m0407CT1_year_start', startYear);
    }

    // ၁၄ ရက်ပေါင်းခြင်း logic
    if (data.ct1DemandDate && data.ct1DemandDate !== '0000-00-00') {
        let dateObj = new Date(data.ct1DemandDate);
        if (!isNaN(dateObj.getTime())) {
            dateObj.setDate(dateObj.getDate() + 14); // ၁၄ ရက်ပေါင်း
            
            let dd = toMyanmarDigit(String(dateObj.getDate()).padStart(2, '0'));
            let mm = toMyanmarDigit(String(dateObj.getDate()).padStart(2, '0')); // လ အမှန်ရရန်getMonth + 1 လုပ်ရမည်
            let myMonth = toMyanmarDigit(String(dateObj.getMonth() + 1).padStart(2, '0'));
            let yyyy = toMyanmarDigit(dateObj.getFullYear());
            
            setText('m0407CT1_rq_date1', dd + "-" + myMonth + "-" + yyyy);
            setText('m0407CT1_rq_date11', dd + "-" + myMonth + "-" + yyyy);
        }
    }

    // ကျန်ရှိသော ဒေတာများ
    setText('m0407CT1_advanceTax1', toMyanmarDigit(data.advanceTax1) || '၀');
    setText('m0407CT1_salesAmount1', toMyanmarDigit(data.salesAmount1));
    setText('m0407CT1_ct1tax', toMyanmarDigit(data.ct1tax));
    setText('m0407CT1_totalTax1', toMyanmarDigit(data.totalTax1));
    setText('m0407CT1_totalTax11', toMyanmarDigit(data.totalTax1));
    setText('m0407CT1_township', data.township_name);

    // ၁။ လိုအပ်သော Row ID များကို Array ဖြင့် သိမ်းထားပါ
    const row1 = document.getElementById('row_to_hide1');
    const row2 = document.getElementById('row_to_hide2');
    const row3 = document.getElementById('row_to_hide3');

    const originalRows = ['orig_row1', 'orig_row2', 'orig_row3', 'orig_row4', 'orig_row5', 'orig_row6', 'orig_row7'];
    const totalRows = ['total_row1', 'total_row2', 'total_row3', 'total_row4', 'total_row5', 'total_row6', 'total_row7'];

        // ၂။ Logic စစ်ဆေးပါ (ct1 ရော ct2 ရော "ကသ" ဖြစ်မှ)
        if (data.ct1_select_real === "ကသ" && data.ct2_select_real === "ကသ") {
            
            // Row အားလုံးကို ပြမည်
            if(row1) row1.style.display = 'table-row';
            if(row2) row2.style.display = 'table-row';
            if(row3) row3.style.display = 'table-row';
            
            // ဒေတာများ ထည့်သွင်းမည်
            setText('m0407CT1_salesAmount2', toMyanmarDigit(data.salesAmount2));
            setText('m0407CT1_ct2tax', toMyanmarDigit(data.ct2tax));
            setText('m0407CT1_minusCTInput', toMyanmarDigit(data.minusCTInput));

            originalRows.forEach(id => { if(document.getElementById(id)) document.getElementById(id).style.display = 'none'; });
            totalRows.forEach(id => { if(document.getElementById(id)) document.getElementById(id).style.display = 'table-row'; });

            // ၂။ ပေါင်းလဒ်များ တွက်ချက်ခြင်း (အရင်အတိုင်း)
            let totalRule42 = (parseFloat(data.rule42_1) || 0) + (parseFloat(data.rule42_2) || 0);
            let totalAfterRuler = (parseFloat(data.afterRuler1) || 0) + (parseFloat(data.afterRuler2) || 0);
            let totalAdvanceTax = (parseFloat(data.advanceTax1) || 0) + (parseFloat(data.advanceTax2) || 0);
            let totalNetTax = (parseFloat(data.netTax1) || 0) + (parseFloat(data.netTax2) || 0);
            let totalPenalty = (parseFloat(data.penalty1) || 0) + (parseFloat(data.penalty2) || 0);
            let totalAll = (parseFloat(data.totalTax1) || 0) + (parseFloat(data.totalTax2) || 0);

            // ၃။ ပေါင်းလဒ် data များ ထည့်သွင်းခြင်း
            setText('m0407CT1_rule42_total', toMyanmarDigit(totalRule42));
            setText('m0407CT1_afterRuler_total', toMyanmarDigit(totalAfterRuler));
            setText('m0407CT1_advanceTax_total', toMyanmarDigit(totalAdvanceTax));
            setText('m0407CT1_netTax_total', toMyanmarDigit(totalNetTax));
            setText('m0407CT1_penalty_total', toMyanmarDigit(totalPenalty));
            setText('m0407CT1_Taxpenalty_total', toMyanmarDigit(totalAll));
            setText('m0407CT1_Taxpenalty1_total', toMyanmarDigit(totalAll));
            
        } else {
            // သတ်မှတ်ချက်မကိုက်ညီလျှင် Row အားလုံးကို ဖျောက်မည်
            if(row1) row1.style.display = 'none';
            if(row2) row2.style.display = 'none';
            if(row3) row3.style.display = 'none';

            // ၄။ "ကသ" မတူရင် - မူလ Row များကို ပြ၊ ပေါင်းလဒ် Row များကို ဖျောက်
            originalRows.forEach(id => { if(document.getElementById(id)) document.getElementById(id).style.display = 'table-row'; });
            totalRows.forEach(id => { if(document.getElementById(id)) document.getElementById(id).style.display = 'none'; });

            // ၅။ မူလ data များကိုသာ ထည့်သွင်းခြင်း
            setText('m0407CT1_rule42_1', toMyanmarDigit(data.rule42_1));
            setText('m0407CT1_afterRuler1', toMyanmarDigit(data.afterRuler1));
            setText('m0407CT1_advanceTax11', toMyanmarDigit(data.advanceTax1));
            setText('m0407CT1_netTax1', toMyanmarDigit(data.netTax1));
            setText('m0407CT1_penalty1', toMyanmarDigit(data.penalty1));
            setText('m0407CT1_totalTax1', toMyanmarDigit(data.totalTax1));
            setText('m0407CT1_totalTax11', toMyanmarDigit(data.totalTax1));
            
        }

    // Modal ဖွင့်ခြင်း
    const modalElem = document.getElementById('formCT10407Modal');
    if (modalElem) {
        bootstrap.Modal.getOrCreateInstance(modalElem).show();
    }

       
}
</script>