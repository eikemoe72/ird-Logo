<?php
session_start();

include 'db_config.php';
$conn->set_charset('utf8mb4');

function loc_h($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

$id = ""; $state_name = ""; $state_code = ""; $township_name = ""; $township_code = ""; $town_name = ""; $town_code = ""; $letter_code = "";
$is_edit = false;
$search = trim($_GET['q'] ?? '');

if (isset($_GET['edit_id']) && $_GET['edit_id'] !== '') {
    $edit_id = (int) $_GET['edit_id'];
    $result = $conn->query("SELECT * FROM locations WHERE id = $edit_id");
    if ($result && $row = $result->fetch_assoc()) {
        $id            = $row['id'];
        $state_name    = $row['state_name'];
        $state_code    = $row['state_code'];
        $township_name = $row['township_name'];
        $township_code = $row['township_code'];
        $town_name     = $row['town_name'];
        $town_code     = $row['town_code'];
        $letter_code   = $row['letter_code'];
        $is_edit       = true;
    }
}

$list_sql = "SELECT * FROM locations";
if ($search !== '') {
    $like = '%' . mysqli_real_escape_string($conn, $search) . '%';
    $list_sql .= " WHERE state_name LIKE '$like'
        OR state_code LIKE '$like'
        OR township_name LIKE '$like'
        OR township_code LIKE '$like'
        OR town_name LIKE '$like'
        OR town_code LIKE '$like'
        OR letter_code LIKE '$like'";
}
$list_sql .= " ORDER BY state_code, township_code, town_code, id";
$list_result = $conn->query($list_sql);
$rows = [];
if ($list_result) {
    while ($row = $list_result->fetch_assoc()) {
        $rows[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <title>တည်နေရာအချက်အလက် စီမံခန့်ခွဲမှုပုံစံ</title>
    <style>
        html, body { height: 100%; }
        body { font-family: 'Pyidaungsu', sans-serif; background-color: #f4f6f9; margin: 0; padding: 0; box-sizing: border-box; overflow: hidden; display: flex; flex-direction: column; }
        .page-title-bar { position: relative; flex: 0 0 auto; background: #0b3d91; }
        .page-title { margin: 0; color: #fff; text-align: center; padding: 12px 64px; font-size: 1.35rem; font-weight: bold; line-height: 1.4; }
        .page-close { position: absolute; top: 50%; right: 14px; transform: translateY(-50%); width: 36px; height: 36px; background: #dc3545; color: #fff; border: none; border-radius: 4px; font-size: 24px; font-weight: bold; line-height: 1; cursor: pointer; box-shadow: 0 2px 5px rgba(0,0,0,0.3); }
        .page-close:hover { background: #bd2130; }
        .page-split { display: flex; align-items: stretch; gap: 12px; flex: 1 1 auto; min-height: 0; padding: 10px; box-sizing: border-box; }
        .form-container { flex: 0 0 380px; width: 380px; margin: 0; background: white; padding: 12px 14px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); overflow-y: auto; box-sizing: border-box; }
        .form-header { background: #007bff; color: white; padding: 8px 10px; text-align: center; border-radius: 6px; margin-bottom: 10px; font-size: 1.05rem; }
        .form-group { margin-bottom: 10px; }
        .form-group label { display: block; margin-bottom: 4px; font-weight: bold; color: #333; font-size: 14px; }
        .form-control { width: 100%; padding: 8px 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn-submit { width: 100%; padding: 8px; background-color: #28a745; color: white; border: none; border-radius: 4px; font-size: 1rem; cursor: pointer; }
        .btn-submit:hover { background-color: #218838; }
        .btn-cancel { width: 100%; padding: 8px; background-color: #6c757d; color: white; border: none; border-radius: 4px; font-size: 1rem; cursor: pointer; text-align:center; text-decoration: none; display: block; margin-top: 8px; box-sizing: border-box; }
        .list-wrap { flex: 1 1 auto; min-width: 0; margin: 0; background: white; padding: 14px 14px 10px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); display: flex; flex-direction: column; overflow: hidden; }
        .list-head { display: flex; justify-content: space-between; align-items: center; gap: 12px; margin-bottom: 14px; flex-wrap: wrap; }
        .list-head h2 { margin: 0; font-size: 1.15rem; color: #1f3b73; }
        .search-form { display: flex; gap: 8px; }
        .search-form input { padding: 8px 10px; border: 1px solid #ccc; border-radius: 4px; min-width: 220px; }
        .search-form button, .search-form a { padding: 8px 12px; border-radius: 4px; border: none; text-decoration: none; cursor: pointer; }
        .search-form button { background: #007bff; color: white; }
        .search-form a { background: #e9ecef; color: #333; }
        .table-scroll { flex: 1 1 auto; min-height: 0; overflow-y: scroll; overflow-x: auto; }
        table.loc-table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 14px; }
        table.loc-table th, table.loc-table td { border-right: 1px solid #d7dce3; border-bottom: 1px solid #d7dce3; padding: 6px 10px; text-align: left; white-space: nowrap; line-height: 1.35; }
        table.loc-table th { position: sticky; top: 0; z-index: 1; background: #007bff; color: white; border-top: 1px solid #007bff; text-align: center; font-weight: bold; padding: 14px 10px; }
        table.loc-table th:first-child, table.loc-table td:first-child { border-left: 1px solid #d7dce3; }
        table.loc-table tr.data-row { cursor: pointer; }
        table.loc-table tr.data-row:hover { background: #eef5ff; }
        table.loc-table tr.selected { background: #d9f2e3; }
        .row-actions { display: flex; gap: 6px; }
        .btn-edit { background: #ffc107; color: #222; border: none; border-radius: 4px; padding: 5px 10px; cursor: pointer; font-weight: bold; line-height: 1.3; }
        .btn-delete { background: #dc3545; color: white; border: none; border-radius: 4px; padding: 5px 10px; cursor: pointer; font-weight: bold; line-height: 1.3; }
        .empty { text-align: center; color: #666; padding: 18px; }
    </style>
</head>
<body>

<div class="page-title-bar">
    <h1 class="page-title">တိုင်းဒေသကြီး/ပြည်နယ်/မြို့နယ်ဆိုင်ရာ အချက်အလက်များ</h1>
    <button type="button" class="page-close" title="ပိတ်မည်" onclick="window.location.href='dashboard.php'">×</button>
</div>
<div class="page-split">
<div class="form-container" id="location-form">
    <div class="form-header">
        <?php echo $is_edit ? "တည်နေရာအချက်အလက် ပြင်ဆင်ရန် ပုံစံ" : "တည်နေရာအချက်အလက် အသစ်ထည့်သွင်းရန် ပုံစံ"; ?>
    </div>

    <form action="location_save.php" method="POST">
        <input type="hidden" name="id" value="<?php echo loc_h($id); ?>">

        <div class="form-group">
            <label>တိုင်းဒေသကြီး/ပြည်နယ် အမည် (state_name):</label>
            <input type="text" name="state_name" class="form-control" value="<?php echo loc_h($state_name); ?>" required placeholder="ဥပမာ - ကယားပြည်နယ်">
        </div>

        <div class="form-group">
            <label>တိုင်းဒေသကြီး/ပြည်နယ် ကုဒ် (state_code):</label>
            <input type="text" name="state_code" class="form-control" value="<?php echo loc_h($state_code); ?>" required placeholder="ဥပမာ - 02">
        </div>

        <div class="form-group">
            <label>ခရိုင်/မြို့နယ် အမည် (township_name):</label>
            <input type="text" name="township_name" class="form-control" value="<?php echo loc_h($township_name); ?>" required placeholder="ဥပမာ - ဒီးမော့ဆိုမြို့နယ်">
        </div>

        <div class="form-group">
            <label>ခရိုင်/မြို့နယ် ကုဒ် (township_code):</label>
            <input type="text" name="township_code" class="form-control" value="<?php echo loc_h($township_code); ?>" required placeholder="ဥပမာ - 01">
        </div>

        <div class="form-group">
            <label>မြို့ အမည် (town_name):</label>
            <input type="text" name="town_name" class="form-control" value="<?php echo loc_h($town_name); ?>" placeholder="ဥပမာ - ဒီးမော့ဆိုမြို့">
        </div>

        <div class="form-group">
            <label>မြို့ ကုဒ် (town_code):</label>
            <input type="text" name="town_code" class="form-control" value="<?php echo loc_h($town_code); ?>" placeholder="ဥပမာ - 01">
        </div>

        <div class="form-group">
            <label>စာလုံးကုဒ် (letter_code):</label>
            <input type="text" name="letter_code" class="form-control" value="<?php echo loc_h($letter_code); ?>" placeholder="ဥပမာ - ဓမဆ (သို့မဟုတ် NULL)">
        </div>

        <button type="submit" name="btn_save" class="btn-submit">
            <?php echo $is_edit ? "အချက်အလက်များ ပြင်ဆင်မည်" : "အချက်အလက်အသစ် သိမ်းဆည်းမည်"; ?>
        </button>

        <?php if ($is_edit): ?>
            <a href="location.php" class="btn-cancel">ပယ်ဖျက်မည်</a>
        <?php endif; ?>
    </form>
</div>

<div class="list-wrap" id="location-list">
    <div class="list-head">
        <h2>သိမ်းထားသော တည်နေရာစာရင်း (<?php echo count($rows); ?>)</h2>
        <form class="search-form" method="GET" action="location.php">
            <?php if ($is_edit): ?>
                <input type="hidden" name="edit_id" value="<?php echo loc_h($id); ?>">
            <?php endif; ?>
            <input type="text" name="q" value="<?php echo loc_h($search); ?>" placeholder="အမည် / ကုဒ် ရှာရန်">
            <button type="submit">ရှာမည်</button>
            <?php if ($search !== ''): ?>
                <a href="location.php<?php echo $is_edit ? '?edit_id=' . loc_h($id) : ''; ?>">အားလုံး</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="table-scroll">
        <table class="loc-table">
            <thead>
                <tr>
                    <th>စဉ်</th>
                    <th>တိုင်း/ပြည်နယ်</th>
                    <th>ကုဒ်</th>
                    <th>မြို့နယ်</th>
                    <th>ကုဒ်</th>
                    <th>မြို့</th>
                    <th>ကုဒ်</th>
                    <th>စာလုံးကုဒ်</th>
                    <th>လုပ်ဆောင်ချက်</th>
                </tr>
            </thead>
            <tbody>
            <?php if (count($rows) === 0): ?>
                <tr><td class="empty" colspan="9">ပြရန် အချက်အလက် မရှိပါ။</td></tr>
            <?php else: ?>
                <?php foreach ($rows as $index => $row): ?>
                    <?php
                        $selected = $is_edit && (string) $row['id'] === (string) $id;
                        $edit_url = 'location.php?edit_id=' . urlencode($row['id']);
                        if ($search !== '') {
                            $edit_url .= '&q=' . urlencode($search);
                        }
                    ?>
                    <tr class="data-row<?php echo $selected ? ' selected' : ''; ?>" onclick="window.location.href='<?php echo loc_h($edit_url); ?>#location-form'">
                        <td><?php echo $index + 1; ?></td>
                        <td><?php echo loc_h($row['state_name']); ?></td>
                        <td><?php echo loc_h($row['state_code']); ?></td>
                        <td><?php echo loc_h($row['township_name']); ?></td>
                        <td><?php echo loc_h($row['township_code']); ?></td>
                        <td><?php echo loc_h($row['town_name']); ?></td>
                        <td><?php echo loc_h($row['town_code']); ?></td>
                        <td><?php echo loc_h($row['letter_code']); ?></td>
                        <td>
                            <div class="row-actions">
                                <button type="button" class="btn-edit" onclick="event.stopPropagation(); window.location.href='<?php echo loc_h($edit_url); ?>'">
                                    <?php echo $selected ? 'ရွေးထားသည်' : 'ပြင်ဆင်မည်'; ?>
                                </button>
                                <form method="POST" action="location_save.php" onsubmit="event.stopPropagation(); return confirm('ဤအတန်းကို ဖျက်ရန် သေချာပါသလား။');">
                                    <input type="hidden" name="id" value="<?php echo loc_h($row['id']); ?>">
                                    <input type="hidden" name="q" value="<?php echo loc_h($search); ?>">
                                    <button type="submit" name="btn_delete" class="btn-delete" onclick="event.stopPropagation();">ဖျက်မည်</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>

</body>
</html>
