<?php
session_start();
include 'db_config.php';

function u48($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function u48_pick($value, $current) {
    return (string)$value === (string)$current ? 'selected' : '';
}

function u48_serial_int($value) {
    $ascii = strtr((string)$value, [
        '၀' => '0', '၁' => '1', '၂' => '2', '၃' => '3', '၄' => '4',
        '၅' => '5', '၆' => '6', '၇' => '7', '၈' => '8', '၉' => '9',
    ]);
    return preg_match('/\d+/', $ascii, $match) ? (int)$match[0] : 0;
}

$blank = [
    'id' => 0,
    'No' => '',
    'FormDemandDate' => '',
    'OfficeName' => '',
    'AssesseName' => '',
    'Appointment' => '',
    'Rank' => $_SESSION['rank'] ?? '',
    'StateName' => '',
    'TownshipName' => '',
    'Quarter' => '',
    'StreetName' => '',
    'AssesseAddress' => '',
    'HousingNo' => '',
    'StateCode' => '',
    'InitialCode' => '',
    'NRC' => '',
    'NRCNo' => '',
    'CompanyName' => '',
    'CompanyAddress' => '',
    'StateName1' => '',
    'TownshipName1' => '',
    'Quarter1' => '',
    'StreetName1' => '',
    'HousingNo1' => '',
    'DrawingOfficer' => '',
    'StateCode1' => '',
    'InitialCode1' => '',
    'NRC1' => '',
    'NRCNo1' => '',
    'SalaryRate' => '',
    'BudgetYear' => '',
    'StartDate' => '',
    'EndDate' => '',
    'TotalMonth' => '',
    'TotalSalary' => '',
    'Remark' => '',
    'IssueDate' => '',
    'IssueNo' => '',
    'IssueYear' => '',
    'TIN_GIR_No' => '',
    'LoginTownship' => $_SESSION['township_name'] ?? '',
];

$columns = array_keys($blank);
array_shift($columns);

$notice = '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $existing = $blank;
    if ($id > 0) {
        $stmt = $conn->prepare('SELECT * FROM under48data WHERE id = ? LIMIT 1');
        $stmt->bind_param('i', $id);
        $stmt->execute();
        $found = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($found) {
            $existing = array_merge($blank, $found);
        }
    }
    $values = [];
    foreach ($columns as $column) {
        $values[$column] = array_key_exists($column, $_POST)
            ? trim((string)$_POST[$column])
            : (string)($existing[$column] ?? '');
    }
    if ($values['LoginTownship'] === '') {
        $values['LoginTownship'] = (string)($_SESSION['township_name'] ?? '');
    }
    if ($values['No'] !== '' && $values['BudgetYear'] !== '') {
        $values['IssueNo'] = $values['No'] . '/' . $values['BudgetYear'];
    }

    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
    $quoted = implode(', ', array_map(function ($column) {
        return '`' . $column . '`';
    }, $columns));

    if ($id > 0) {
        $sets = implode(', ', array_map(function ($column) {
            return '`' . $column . '` = ?';
        }, $columns));
        $sql = "UPDATE under48data SET $sets WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $bind = array_values($values);
        $bind[] = $id;
        $stmt->bind_param(str_repeat('s', count($columns)) . 'i', ...$bind);
        $saved = $stmt->execute();
        $stmt->close();
    } else {
        $sql = "INSERT INTO under48data ($quoted) VALUES ($placeholders)";
        $stmt = $conn->prepare($sql);
        $bind = array_values($values);
        $stmt->bind_param(str_repeat('s', count($columns)), ...$bind);
        $saved = $stmt->execute();
        $id = (int)$stmt->insert_id;
        $stmt->close();
    }
    if ($saved) {
        echo '<!DOCTYPE html><html lang="my"><head><meta charset="UTF-8"><title>သိမ်းဆည်းပြီး</title></head><body>';
        echo '<script>alert("အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ");window.location.href="Under48_Demand_List.php";</script>';
        echo '</body></html>';
        exit;
    }
}

$row = $blank;
if ($id > 0) {
    $stmt = $conn->prepare('SELECT * FROM under48data WHERE id = ? LIMIT 1');
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $found = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($found) {
        $row = array_merge($blank, $found);
    } else {
        $id = 0;
    }
}
if ($id === 0) {
    $max_no = 0;
    $no_result = $conn->query('SELECT `No` FROM under48data');
    if ($no_result) {
        while ($no_row = $no_result->fetch_assoc()) {
            $max_no = max($max_no, u48_serial_int($no_row['No']));
        }
    }
    $row['No'] = (string)($max_no + 1);
}
if ($row['No'] !== '' && $row['BudgetYear'] !== '') {
    $row['IssueNo'] = $row['No'] . '/' . $row['BudgetYear'];
}
if (trim((string)($row['Rank'] ?? '')) === '') {
    $row['Rank'] = (string)($_SESSION['rank'] ?? '');
}
if (trim((string)($row['LoginTownship'] ?? '')) === '') {
    $row['LoginTownship'] = (string)($_SESSION['township_name'] ?? '');
}
if (isset($_GET['saved'])) {
    $notice = 'အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ။';
}
$login_officer = trim((string)($_SESSION['officer_name'] ?? ''));
if ($login_officer === '') {
    $login_officer = trim((string)($_SESSION['user_name'] ?? ''));
}

$states = [];
$state_result = $conn->query("SELECT DISTINCT state_name FROM locations WHERE state_name <> '' ORDER BY state_name");
if ($state_result) {
    while ($state_row = $state_result->fetch_assoc()) {
        $states[] = $state_row['state_name'];
    }
}

$budget_years = [];
$year_result = $conn->query("SELECT budget_year FROM budget_year WHERE budget_year <> '' ORDER BY id DESC");
if ($year_result) {
    while ($year_row = $year_result->fetch_assoc()) {
        $budget_years[] = $year_row['budget_year'];
    }
}

function u48_state_options($states, $current) {
    $html = '<option value="">ရွေးချယ်ပါ</option>';
    foreach ($states as $state) {
        $html .= '<option value="' . u48($state) . '" ' . u48_pick($state, $current) . '>' . u48($state) . '</option>';
    }
    return $html;
}

function u48_nrc_state($current) {
    $html = '<option value="">ရွေး</option>';
    for ($i = 1; $i <= 14; $i++) {
        $code = str_pad((string)$i, 2, '0', STR_PAD_LEFT);
        $selected = ($current === $code || (int)$current === $i) ? 'selected' : '';
        $html .= '<option value="' . $code . '" ' . $selected . '>' . $i . '</option>';
    }
    return $html;
}

function u48_citizen($current) {
    $html = '<option value="">ရွေး</option>';
    foreach (['(နိုင်)', '(ဧည့်)', '(ပြု)', '(သာ)'] as $type) {
        $html .= '<option value="' . u48($type) . '" ' . u48_pick($type, $current) . '>' . u48($type) . '</option>';
    }
    return $html;
}
?>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>under48</title>
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: #d9d9d9;
            color: #111;
            font-family: "Pyidaungsu", "Myanmar Text", sans-serif;
            font-size: 15px;
        }
        .page { width: fit-content; max-width: calc(100% - 12px); margin: 14px auto 28px; }
        .banner {
            background: #0000d0;
            color: #fff;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
            line-height: 1.45;
            padding: 8px 16px;
        }
        .serial {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 8px;
            margin: 8px 0;
            font-weight: bold;
        }
        .serial input { width: 180px; text-align: center; font-weight: bold; }
        .sheet {
            background: #f2f2f2;
            border: 1px solid #bdbdbd;
            padding: 12px;
        }
        .columns { display: grid; grid-template-columns: repeat(3, max-content); gap: 12px; align-items: start; }
        .col { display: flex; flex-direction: column; min-width: 0; }
        .head {
            background: #c65a12;
            color: #fff;
            text-align: center;
            font-weight: bold;
            padding: 6px 8px;
            margin-bottom: 8px;
            min-height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 1.35;
            width: 0;
            min-width: 100%;
        }
        .bar {
            background: #0047d6;
            color: #fff;
            text-align: center;
            font-weight: bold;
            padding: 3px 6px;
            margin: 8px 0 6px;
            width: 0;
            min-width: 100%;
        }
        .field { display: grid; grid-template-columns: minmax(max-content, 1fr) 221px; gap: 6px; align-items: center; margin-bottom: 4px; width: 100%; }
        .field label { text-align: right; line-height: 1.2; white-space: nowrap; font-size: 14px; }
        input, select, textarea {
            width: 100%;
            min-width: 0;
            max-width: 100%;
            height: 30px;
            border: 1px solid #9a9a9a;
            background: #fff;
            font-family: inherit;
            font-size: 14px;
            padding: 2px 6px;
        }
        textarea { height: 76px; resize: vertical; }
        .nrc { display: grid; grid-template-columns: 0.7fr 1.15fr 1.2fr 1fr; gap: 3px; width: 100%; min-width: 0; }
        .nrc select, .nrc input { padding: 1px 2px; font-size: 14px; }
        .with-note { display: flex; align-items: center; gap: 4px; min-width: 0; }
        .with-note input { flex: 1; min-width: 0; }
        .with-note span { white-space: nowrap; font-size: 14px; }
        .actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 12px; }
        .actions button, .actions a {
            min-width: 78px;
            height: 32px;
            border: 1px solid #222;
            color: #fff;
            font-family: inherit;
            font-weight: bold;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
        }
        .btn-reg { background: #c026d3; }
        .btn-save { background: #16a34a; }
        .btn-close { background: #dc2626; }
        .notice { text-align: center; color: #166534; font-weight: bold; margin-bottom: 6px; }
        @media (max-width: 980px) {
            .columns { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="banner">ဝင်ငွေခွန်ဥပဒေပုဒ်မ ၂၂ အရ လစာဝင်ငွေအပေါ် စည်းကြပ်သောအခွန် ထုတ်ပေးသည့် လက်မှတ်</div>
        <?php if ($notice !== '') { ?><div class="notice"><?php echo u48($notice); ?></div><?php } ?>
        <form method="post" action="Under48_Form.php">
            <input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>">
           
            <div class="sheet">
                <div class="columns">
                    <section class="col">
                        <div class="head">သက်သေခံအထောက်အထားလျှောက်ထားသူ ကိုယ်ရေးအချက်အလက်</div>
                        <div class="field"><label for="No">အမှတ်စဉ်</label><input id="No" name="No" maxlength="255" value="<?php echo u48($row['No']); ?>"></div>
                        <div class="field"><label for="AssesseName">လျှောက်ထားသူအမည်</label><input id="AssesseName" name="AssesseName" maxlength="255" value="<?php echo u48($row['AssesseName']); ?>"></div>
                        <div class="field nrc-row">
                            <label for="StateCode">မှတ်ပုံတင်အမှတ်</label>
                            <div class="nrc">
                                <select id="StateCode" name="StateCode" data-letter="InitialCode"><?php echo u48_nrc_state($row['StateCode']); ?></select>
                                <select id="InitialCode" name="InitialCode" data-selected="<?php echo u48($row['InitialCode']); ?>"><option value="">ရွေး</option></select>
                                <select id="NRC" name="NRC"><?php echo u48_citizen($row['NRC']); ?></select>
                                <input id="NRCNo" name="NRCNo" maxlength="6" inputmode="numeric" value="<?php echo u48($row['NRCNo']); ?>">
                            </div>
                        </div>
                        <div class="field"><label for="Appointment">ရာထူး</label><input id="Appointment" name="Appointment" maxlength="255" value="<?php echo u48($row['Appointment']); ?>"></div>
                        <div class="field"><label for="OfficeName">လျှောက်ထားသည့်ရုံးအမည်</label><input id="OfficeName" name="OfficeName" maxlength="255" value="<?php echo u48($row['OfficeName']); ?>"></div>
                        <div class="field"><label for="FormDemandDate">လျှောက်ထားသည့်ရက်</label><input type="date" id="FormDemandDate" name="FormDemandDate" value="<?php echo u48($row['FormDemandDate']); ?>"></div>
                        
                        <div class="bar">လျှောက်ထားသူလိပ်စာ</div>
                        <div class="field"><label for="StateName">တိုင်း/ပြည်နယ်</label><select id="StateName" name="StateName" data-target="TownshipName"><?php echo u48_state_options($states, $row['StateName']); ?></select></div>
                        <div class="field"><label for="TownshipName">မြို့နယ်</label><select id="TownshipName" name="TownshipName" data-selected="<?php echo u48($row['TownshipName']); ?>"><option value="">ရွေးချယ်ပါ</option></select></div>
                        <div class="field"><label for="Quarter">ရပ်ကွက်</label><input id="Quarter" name="Quarter" maxlength="255" value="<?php echo u48($row['Quarter']); ?>"></div>
                        <div class="field"><label for="StreetName">လမ်း</label><input id="StreetName" name="StreetName" maxlength="255" value="<?php echo u48($row['StreetName']); ?>"></div>
                        <div class="field"><label for="HousingNo">အိမ်အမှတ်</label><input id="HousingNo" name="HousingNo" maxlength="50" value="<?php echo u48($row['HousingNo']); ?>"></div>
                    </section>

                    <section class="col">
                        <div class="head">ရုံး/ဌာန/အဖွဲ့အစည်း/ကုမ္ပဏီဆိုင်ရာ အချက်အလက်</div>
                        <div class="field"><label for="CompanyName">ရုံး/ဌာန/အဖွဲ့အစည်း/ကုမ္ပဏီအမည်</label><input id="CompanyName" name="CompanyName" maxlength="255" value="<?php echo u48($row['CompanyName']); ?>"></div>
                        <div class="field"><label for="TIN_GIR_No">အခွန်ထမ်းမှတ်ပုံတင်အမှတ်(TIN/GIR)</label><input id="TIN_GIR_No" name="TIN_GIR_No" maxlength="50" value="<?php echo u48($row['TIN_GIR_No']); ?>"></div>
                        <div class="bar">ရုံး/ဌာန/အဖွဲ့အစည်း/ကုမ္ပဏီ လိပ်စာ</div>
                        <div class="field"><label for="StateName1">တိုင်း/ပြည်နယ်</label><select id="StateName1" name="StateName1" data-target="TownshipName1"><?php echo u48_state_options($states, $row['StateName1']); ?></select></div>
                        <div class="field"><label for="TownshipName1">မြို့နယ်</label><select id="TownshipName1" name="TownshipName1" data-selected="<?php echo u48($row['TownshipName1']); ?>"><option value="">ရွေးချယ်ပါ</option></select></div>
                        <div class="field"><label for="Quarter1">ရပ်ကွက်</label><input id="Quarter1" name="Quarter1" maxlength="255" value="<?php echo u48($row['Quarter1']); ?>"></div>
                        <div class="field"><label for="StreetName1">လမ်း</label><input id="StreetName1" name="StreetName1" maxlength="255" value="<?php echo u48($row['StreetName1']); ?>"></div>
                        <div class="field"><label for="HousingNo1">အိမ်အမှတ်</label><input id="HousingNo1" name="HousingNo1" maxlength="50" value="<?php echo u48($row['HousingNo1']); ?>"></div>
                        
                        <div class="bar">အလုပ်ရှင်/ငွေထုတ်ပေးရန် တာဝန်ရှိသူ</div>
                        <div class="field"><label for="DrawingOfficer">ငွေထုတ်ပေးရန် တာဝန်ရှိသူအမည်</label><input id="DrawingOfficer" name="DrawingOfficer" maxlength="255" value="<?php echo u48($row['DrawingOfficer']); ?>"></div>
                        <div class="field nrc-row">
                            <label for="StateCode1">မှတ်ပုံတင်အမှတ်</label>
                            <div class="nrc">
                                <select id="StateCode1" name="StateCode1" data-letter="InitialCode1"><?php echo u48_nrc_state($row['StateCode1']); ?></select>
                                <select id="InitialCode1" name="InitialCode1" data-selected="<?php echo u48($row['InitialCode1']); ?>"><option value="">ရွေး</option></select>
                                <select id="NRC1" name="NRC1"><?php echo u48_citizen($row['NRC1']); ?></select>
                                <input id="NRCNo1" name="NRCNo1" maxlength="6" inputmode="numeric" value="<?php echo u48($row['NRCNo1']); ?>">
                            </div>
                        </div>
                    </section>

                    <section class="col">
                        <div class="head">လစာနှင့်အခွန် အချက်အလက်</div>
                        <div class="field"><label for="SalaryRate">လစဉ်လစာနှုန်း</label><input id="SalaryRate" name="SalaryRate" maxlength="50" value="<?php echo u48($row['SalaryRate']); ?>"></div>
                        <div class="field">
                            <label for="BudgetYear">ဘဏ္ဍာနှစ်</label>
                            <select id="BudgetYear" name="BudgetYear">
                                <option value="">ရွေးချယ်ပါ</option>
                                <?php foreach ($budget_years as $year) { ?>
                                    <option value="<?php echo u48($year); ?>" <?php echo u48_pick($year, $row['BudgetYear']); ?>><?php echo u48($year); ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <div class="field"><label for="StartDate">စတင်သည့်ရက်</label><input type="date" id="StartDate" name="StartDate" value="<?php echo u48($row['StartDate']); ?>"></div>
                        <div class="field"><label for="EndDate">ပြီးဆုံးသည့်ရက်</label><input type="date" id="EndDate" name="EndDate" value="<?php echo u48($row['EndDate']); ?>"></div>
                        <div class="field"><label for="TotalMonth">စုစုပေါင်းလ</label><input id="TotalMonth" name="TotalMonth" maxlength="50" value="<?php echo u48($row['TotalMonth']); ?>"></div>
                        <div class="field"><label for="TotalSalary">လစာစုစုပေါင်း</label><input id="TotalSalary" name="TotalSalary" maxlength="50" value="<?php echo u48($row['TotalSalary']); ?>"></div>
                        <div class="field"><label for="Remark">မှတ်ချက်</label><textarea id="Remark" name="Remark" maxlength="255"><?php echo u48($row['Remark']); ?></textarea></div>
                        <div class="bar">ထုတ်ပေးသည့် အထောက်အထား</div>
                        <div class="field"><label for="IssueNo">ထုတ်ပေးသည့်အမှတ်စဉ်</label><input id="IssueNo" name="IssueNo" maxlength="50" value="<?php echo u48($row['IssueNo']); ?>"></div>
                        <div class="field"><label for="IssueDate">ထုတ်ပေးသည့်ရက်စွဲ</label><input type="date" id="IssueDate" name="IssueDate" value="<?php echo u48($row['IssueDate']); ?>"></div>
                        <div class="field"><label for="DrawingOfficerCopy">ထုတ်ပေးသည့်သူ</label><input id="DrawingOfficerCopy" maxlength="255" value="<?php echo u48($login_officer); ?>" readonly></div>
                        <div class="field"><label for="Rank">ရာထူးအဆင့်</label><input id="Rank" name="Rank" maxlength="100" value="<?php echo u48($row['Rank']); ?>"></div>
                        <div class="field">
                            <label for="LoginTownship">အခွန်ဦးစီးဌာနမှူးရုံးအမည်</label>
                            <div class="with-note">
                                <input id="LoginTownship" name="LoginTownship" maxlength="100" value="<?php echo u48($row['LoginTownship']); ?>">
                                
                            </div>
                        </div>
                    </section>
                </div>
                <div class="actions">
                    <a class="btn-reg" href="Under48_Form.php">Reg</a>
                    <button class="btn-save" type="submit">Save</button>
                    <a class="btn-close" href="dashboard.php">Close</a>
                </div>
            </div>
        </form>
    </div>
    <script>
        function limitNrcDigits(el) {
            const myanDigit = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
            let value = el.value;
            myanDigit.forEach(function (digit, index) {
                value = value.split(digit).join(String(index));
            });
            el.value = value.replace(/\D/g, '').slice(0, 6);
        }

        function loadTownships(stateEl) {
            const town = document.getElementById(stateEl.getAttribute('data-target'));
            const keep = town.getAttribute('data-selected') || '';
            town.innerHTML = '<option value="">ရွေးချယ်ပါ</option>';
            if (!stateEl.value) return;
            fetch('get_townships.php?state=' + encodeURIComponent(stateEl.value))
                .then(function (response) { return response.json(); })
                .then(function (rows) {
                    const seen = {};
                    (rows || []).forEach(function (item) {
                        if (!item.township || seen[item.township]) return;
                        seen[item.township] = true;
                        const opt = document.createElement('option');
                        opt.value = item.township;
                        opt.textContent = item.township;
                        if (item.township === keep) opt.selected = true;
                        town.appendChild(opt);
                    });
                    town.removeAttribute('data-selected');
                });
        }

        function loadLetters(stateEl) {
            const letter = document.getElementById(stateEl.getAttribute('data-letter'));
            const keep = letter.getAttribute('data-selected') || '';
            letter.innerHTML = '<option value="">ရွေး</option>';
            if (!stateEl.value) return;
            fetch('get_letters_by_state.php?state_code=' + encodeURIComponent(stateEl.value))
                .then(function (response) { return response.json(); })
                .then(function (res) {
                    if (!res || !Array.isArray(res.data)) return;
                    res.data.forEach(function (code) {
                        const opt = document.createElement('option');
                        opt.value = code;
                        opt.textContent = code;
                        if (code === keep) opt.selected = true;
                        letter.appendChild(opt);
                    });
                    letter.removeAttribute('data-selected');
                });
        }

        function refreshSalary() {
            const start = document.getElementById('StartDate').value;
            const end = document.getElementById('EndDate').value;
            const monthEl = document.getElementById('TotalMonth');
            const rate = parseFloat(String(document.getElementById('SalaryRate').value).replace(/,/g, ''));
            if (start && end) {
                const s = new Date(start);
                const e = new Date(end);
                if (!isNaN(s) && !isNaN(e) && e >= s) {
                    let months = (e.getFullYear() - s.getFullYear()) * 12 + (e.getMonth() - s.getMonth());
                    if (e.getDate() >= s.getDate()) months += 1;
                    monthEl.value = String(Math.max(months, 0));
                }
            }
            const months = parseFloat(monthEl.value);
            if (!isNaN(rate) && !isNaN(months)) {
                document.getElementById('TotalSalary').value = String(Math.round(rate * months));
            }
        }

        document.querySelectorAll('select[data-target]').forEach(function (stateEl) {
            stateEl.addEventListener('change', function () { loadTownships(stateEl); });
            loadTownships(stateEl);
        });
        document.querySelectorAll('select[data-letter]').forEach(function (stateEl) {
            stateEl.addEventListener('change', function () { loadLetters(stateEl); });
            loadLetters(stateEl);
        });
        ['NRCNo', 'NRCNo1'].forEach(function (id) {
            const el = document.getElementById(id);
            el.addEventListener('input', function () { limitNrcDigits(el); });
        });
        ['StartDate', 'EndDate', 'SalaryRate', 'TotalMonth'].forEach(function (id) {
            document.getElementById(id).addEventListener('input', refreshSalary);
        });

        function refreshIssueNo() {
            const no = document.getElementById('No').value.trim();
            const year = document.getElementById('BudgetYear').value.trim();
            if (no !== '' && year !== '') {
                document.getElementById('IssueNo').value = no + '/' + year;
            }
        }
        document.getElementById('No').addEventListener('input', refreshIssueNo);
        document.getElementById('BudgetYear').addEventListener('change', refreshIssueNo);
        refreshIssueNo();
    </script>
</body>
</html>
