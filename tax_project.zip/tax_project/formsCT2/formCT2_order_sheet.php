
<style>
/* မီးခိုးနောက်ခံပေါ်မှာ A4 စာရွက်ဖြူကို အလယ်ချပြီး ခွဲပြသည် */
#ct2orderSheetModal .modal-dialog {
    max-width: 236mm !important;
    width: 236mm !important;
    margin: 12px auto !important;
}

#ct2orderSheetModal .modal-content {
    background-color: #c8c8c8;
    background-image: linear-gradient(180deg, #d4d4d4 0%, #bdbdbd 100%);
    border: 1px solid rgba(0,0,0,.28);
    border-radius: 16px;
    padding: 0 0 14px;
    box-shadow: 0 10px 24px rgba(0,0,0,.28);
}

#ct2orderSheetModal .modal-header {
    width: 100%;
    margin: 0;
    border-radius: 16px 16px 0 0;
}

#ct2orderSheetModal .modal-body {
    padding: 0 !important;
    overflow-x: hidden;
    background: transparent;
    display: flex;
    flex-direction: column;
    align-items: center;
}

#ct2orderSheetModal #printableSheet {
    width: 210mm;
    max-width: calc(100% - 24px);
    margin: 14px auto 8px;
    background: #fff;
    box-sizing: border-box;
    padding: 5mm 5mm 5mm 5mm;
    box-shadow: 0 1px 0 rgba(255,255,255,.7), 0 8px 18px rgba(0,0,0,.35);
}

#ct2orderSheetModal .print-container {
    background: #ffffff;
    width: 100%;
    margin: 0 !important;
    padding: 0 !important;
    box-sizing: border-box !important;
}

.print-container table {
    width: 100% !important;
    max-width: 100% !important;
    margin: 0 auto !important;
    box-sizing: border-box !important;
}

.main-content-table {
    border: none !important;
}

.main-content-table > thead > tr > th:first-child,
.main-content-table > tbody > tr > td:first-child {
    border-left: none !important;
}

.main-content-table > thead > tr > th:last-child,
.main-content-table > tbody > tr > td:last-child {
    border-right: none !important;
}

.main-content-table > tbody > tr > td {
    border-top: none !important;
    border-bottom: none !important;
}

table.quarter-table {
    width: 100% !important;
    border-collapse: separate !important;
    border-spacing: 0 !important;
    border: none !important;
}

table.quarter-table td {
    border: 1px dotted #000 !important;
    text-align: center;
    padding: 3px 3px;
}

/* မူလ 22px (1.375) ထက် 0.2 ပိုချဲသည် */
#ct2orderSheetModal #printableSheet,
#ct2orderSheetModal #printableSheet p,
#ct2orderSheetModal #printableSheet td,
#ct2orderSheetModal #printableSheet div,
#ct2orderSheetModal #printableSheet span,
#ct2orderSheetModal #printableSheet h6,
#ct2orderSheetModal #printableSheet table {
    line-height: 1.575 !important;
}

#ct2orderSheetModal #printableSheet th {
    line-height: 2.2 !important;
}

/* 🖨️ PRINT STYLES - အဓိက ပြင်ဆင်ထားသည့်နေရာ */
@media print {
    @page { size: A4 portrait; margin: 4mm 4mm 4mm 4mm; }

    .modal-footer, .no-print, .btn, .btn-close { display: none !important; }
    body * { visibility: hidden; }
    #ct2orderSheetModal, #ct2orderSheetModal * { visibility: visible !important; }

    #ct2orderSheetModal {
        position: absolute !important;
        left: 0 !important;
        top: 0 !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }


    /* အဓိကပြင်ဆင်ရန် - Height နှင့် Overflow ကို auto ပေးမှသာ စာမျက်နှာအောက်ဘက်ထိ အပြည့်ပေါ်မည် */
    html, body {
        height: auto !important;
        overflow: visible !important;
    }

    #ct2orderSheetModal,
    #ct2orderSheetModal .modal-dialog,
    #ct2orderSheetModal .modal-content,
    #ct2orderSheetModal .modal-body {
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 100% !important;
        max-width: 100% !important;
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        box-shadow: none !important;
        overflow: visible !important;
        transform: none !important;
    }

    /* ခလုတ်များနှင့် Modal Header ကို Print ထဲမပါအောင် ဖျောက်မည် */
    .modal-header,
    .modal-footer, 
    .no-print, 
    .btn, 
    .btn-close { 
        display: none !important; 
    }

    .print-container { 
        padding: 0 !important;
        margin: 0 auto !important; 
        width: 100% !important;
        max-width: 100% !important;
        min-height: auto !important;
        height: auto !important;
        box-sizing: border-box !important;
        box-shadow: none !important;
        background: white !important;
        overflow: hidden !important;
    }

    #ct2orderSheetModal #printableSheet {
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 100% !important;
        max-width: 100% !important;
        box-sizing: border-box !important;
        padding: 5mm 0 0 5mm !important;
        margin: 0 !important;
        overflow: hidden !important;
    }

    /* Table များနှင့် layout ပုံစံမပျက်စေရန် */
    #ct2orderSheetModal table {
        display: table !important;
        height: auto !important;
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        box-sizing: border-box !important;
    }
    #ct2orderSheetModal tr {
        display: table-row !important;
    }
    #ct2orderSheetModal th, 
    #ct2orderSheetModal td {
        display: table-cell !important;
    }

    .page-break {
        display: block;
        page-break-before: always;
        height: 0;
        margin: 0;
        border: none;
    }

    thead { 
        display: table-header-group;
        background-color: #c1d3ef !important;
        color: black; 
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }

    thead tr th {
        border: 1px solid #000 !important;
        padding: 5px 5px;
        background-color: #c6c6f1 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
    }

    table {
        border-collapse: collapse;
        width: 100% !important;
    }

    #ct2orderSheetModal table.main-content-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border-collapse: separate !important;
        border-spacing: 0 !important;
        border-top: 1px solid #000 !important;
        border-bottom: 1px solid #000 !important;
        border-left: none !important;
        border-right: none !important;
        box-sizing: border-box !important;
    }

    #ct2orderSheetModal table.main-content-table > tbody > tr > td,
    #ct2orderSheetModal table.main-content-table > thead > tr > th {
        border-left: 1px solid #000 !important;
        border-right: 1px solid #000 !important;
        border-top: none !important;
        border-bottom: none !important;
        box-sizing: border-box !important;
    }

    #ct2orderSheetModal table.main-content-table > thead > tr > th {
        border-top: 1px solid #000 !important;
        border-bottom: 1px solid #000 !important;
    }

    #ct2orderSheetModal table.main-content-table > thead > tr > th:first-child,
    #ct2orderSheetModal table.main-content-table > tbody > tr > td:first-child {
        border-left: none !important;
        border-right: 1px solid #000 !important;
    }

    #ct2orderSheetModal table.main-content-table > thead > tr > th:last-child,
    #ct2orderSheetModal table.main-content-table > tbody > tr > td:last-child {
        border-left: 1px solid #000 !important;
        border-right: none !important;
    }

    #ct2orderSheetModal table.main-content-table > tbody > tr > td {
        height: auto !important;
    }

    #ct2orderSheetModal table.quarter-table {
        border-collapse: separate !important;
        border-spacing: 0 !important;
        width: 100% !important;
        height: auto !important;
        border: none !important;
    }

    #ct2orderSheetModal table.quarter-table td {
        border: 1px dotted #000 !important;
    }

    /* တခြား modal / စာရင်းစာမျက်နှာက နေရာယူပြီး အလွတ်စာရွက် ထွက်နေသည် */
    body:has(#ct2orderSheetModal.show) > *:not(#ct2orderSheetModal) {
        display: none !important;
    }

    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal {
        display: block !important;
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: visible !important;
        background: #fff !important;
    }

    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal,
    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal * {
        visibility: visible !important;
    }

    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal .modal-header,
    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal .modal-footer,
    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal .no-print,
    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal .btn {
        display: none !important;
    }

    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal .print-container,
    body:has(#ct2orderSheetModal.show) #ct2orderSheetModal #printableSheet {
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 100% !important;
        max-width: 100% !important;
        min-height: 0 !important;
        height: auto !important;
        margin: 0 !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
        overflow: visible !important;
        background: #fff !important;
        box-shadow: none !important;
    }

    #ct2orderSheetModal #printableSheet,
    #ct2orderSheetModal #printableSheet p,
    #ct2orderSheetModal #printableSheet td,
    #ct2orderSheetModal #printableSheet div,
    #ct2orderSheetModal #printableSheet span,
    #ct2orderSheetModal #printableSheet table {
        font-size: 15px !important;
        line-height: 1.5 !important;
    }

    #ct2orderSheetModal #printableSheet h6 {
        font-size: 17px !important;
        line-height: 1.5 !important;
    }

    #ct2orderSheetModal #printableSheet th {
        font-size: 12px !important;
        line-height: 2 !important;
    }

    #ct2orderSheetModal #printableSheet td.right_border,
    #ct2orderSheetModal #printableSheet td.right_border span {
        font-size: 13px !important;
    }
}
</style>



<div class="modal fade" id="ct2orderSheetModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-body">
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 12px; border-bottom: none;">
                    <h5 class="modal-title" style="font-size: 16px; font-weight: bold; margin: 0; color: white;">
                        အမိန့်စာချပ် ထုတ်ယူရန် (Order Sheet)
                    </h5>
                    <button type="button" class="close-modal-btn" onclick="window.location.href='CT1_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                    </button>
            </div>
            <div  id="printableSheet">
                <div class="print-container">
                    <div style="text-align: center;">
                        
                        <h6 style="font-weight: bold; font-size: 18px;">အမိန့်စာချပ်</h6>
                        <p>(အထွေထွေအမှုတွဲဖိုင်အတွက်အသုံးပြုရန်)</p>
                    </div>

                  
                    <table class="main-content-table2">
                        <tr style="border-top: none !important;">
                        <td style="width:18%"><b>မြို့နယ်ရုံးအမည်</b></td>
                        <td style="width:52%; border-bottom: 1.4px dashed #000 !important; padding-left:2px;">၊ <span id="ct2_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး</td>
                        <td style="width:13%; border: 1.4px dotted #000 !important; text-align:right;"><b>စည်းကြပ်နှစ်</b></td>
                        <td style="width:17%; border: 1.4px dotted #000 !important; text-align:right;"> <span id="ct2_year"></span></td>
                    </tr>

                        <tr >
                            <td style="width:18%"><b>အခွန်ထမ်းအမည်</b></td>
                            <td style="width:52%; border-bottom: 1.4px dashed #000 !important; padding-left:2px;">၊ <span id="ct2_name"></span> ( <span id="ct2_nrc"></span> )၊ ( <span id="ct2_phone"></span> )</td>
                            <td style="width:13%; border: 1.4px dotted #000 !important; text-align:right;"><b>GIR-No</b></td>
                            <td style="width:17%; border: 1.4px dotted #000 !important; text-align:right;"> <span id="ct2_gir"></td>
                        </tr>
    
                        <tr >
                            <td style="width:18%"><b>အခွန်ထမ်းလိပ်စာ</b></td>
                            <td style="width:52%; border-bottom: 1.4px dashed #000 !important; padding-left:2px;">၊ <span id="ct2_address"></td>
                            <td style="width:13%; border: 1.4px dotted #000 !important; text-align:right;"><b>အခွန်မှူး</b></td>
                            <td style="width:17%; border: 1.4px dotted #000 !important; text-align:right;"> <span id="ct2_officer"></td>
                        </tr>

                        <tr >
                            <td style="width:18%"><b>လုပ်ငန်းအမျိုးအစား</b></td>
                            <td style="width:52%; border-bottom: 1.4px dashed #000 !important; padding-left:2px;">၊ <span id="ct2_biz"></td>
                            <td style="width:13%; border: 1.4px dotted #000 !important; text-align:right;"><b>ရာထူး</b></td>
                            <td style="width:17%; border: 1.4px dotted #000 !important; text-align:right;"> <span id="ct2_rank"></td>
                        </tr>
                        <tr >
                            <td style="width:18%"></td>
                            <td style="width:52%; border-bottom: 0px dashed #000 !important; padding-left:2px;"></td>
                            <td style="width:13%; border: 0px dotted #000 !important; text-align:right;"></td>
                            <td style="width:17%; border: 0px dotted #000 !important; text-align:right;"></td>
                        </tr>
                    </table>

         
                    <table style="width: 100%; border-top: 0px solid #000 !important;" class="main-content-table">
                            <thead>
                                <tr>
                                    <th style="width: 14%; font-size:13px; text-align:center; border-top: 1px solid #000 !important; border-right:.5px solid #000 !important;">ဆောင်ရွက်<br>သည့်နေ့စွဲ</th>
                                    <th style="width: 73%; font-size:13px; text-align:center; border-top: 1px solid #000 !important; border-right:.5px solid #000 !important;" >လုပ်ငန်းအကြောင်းအရာအကျဉ်းချုပ်</th>
                                    <th style="width: 13%; font-size:13px; text-align:center; border-top: 1px solid #000 !important; " >လိုက်နာဆောင်<br>ရွက်သည့်နေ့</th>
                                </tr>
                            </thead>

                            <tbody  >
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-top: .5px solid #000 !important; border-right: 1px solid #000 !important; border-left: none;">................</td>
                                    <td style="height: 110px; text-align: justify; border-right: .5px solid #000 !important; padding-left: 5px; border-top: .5px solid #000 !important; padding-right: 5px;">
                                    <p style="text-align:justify;">အခွန်ထမ်းသည်( <strong><span style="color:red;" class="ct2_year_val"></span></strong> )ဘဏ္ဍာနှစ်အတွက် 
                                    လုပ်ငန်းစတင်ကြောင်း အကြောင်းကြားစာ တင်သွင်းထားပါသည်/ မတင်သွင်းထားပါ။</p>
                                    <br>
                                    <div style="text-align: right; padding-right: 80px;">စာရေးကြီး</div></td>
                                    <td style="text-align: center; vertical-align:top; border-top: .5px solid #000 !important; border-left: .5px solid #000 !important; border-right: none;">................</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: .5px solid #000 !important; border-left: none;">................</td>
                                    <td style="height: 150px;">
                                        <p style="text-align:justify;">အခွန်ထမ်းသည်( <strong><span style="color:red;" class="ct2_year_val2"></span></strong> )ဘဏ္ဍာနှစ်အတွက် လုပ်ငန်းမှတ်ပုံတင် ပြုလုပ်ပေးရန်/ 
                                        သက်တမ်းတိုးမြှင့်ပေးရန် လျှောက်ထားလာပါသဖြင့် (...................)ရက်နေ့တွင်မှတ်ပုံတင်လက်မှတ် ပတခ (ကသခ)-၂ အား ကျွန်ုပ် လက်မှတ်ရေးထိုး ထုတ်ပေးလိုက်သည်။</p><br><br>
                                        
                                        <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                    <td style="text-align: center; vertical-align:top;  border-left: 1px solid #000 !important; border-right: none;">................</td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;">................</td>
                                    <td style="height: 40px;">
                                        <p style="text-align:justify;">အခွန်ထမ်းသည် သုံးလပတ်အလိုက် ကုန်ရောင်း/ ဝန်ဆောင်မှုကြေညာလွှာများနှင့် အခွန်ငွေများကို အောက်ပါအတိုင်း တင်သွင်းထားပါသည်။/ မတင်သွင်းပါ </p>
                                        <table class="quarter-table">
                                            <tr>
                                                <td style="width:25%; border:1px dotted #000 !important;">သုံးလပတ်</td>
                                                <td style="width:26%; border:1px dotted #000 !important;">ကြေညာသည့်ဝင်ငွေ</td>
                                                <td style="width:25%; border:1px dotted #000 !important;">ပေးသွင်းငွေ</td>
                                                <td style="width:24%; border:1px dotted #000 !important;">ရက်စွဲ</td>
                                            </tr>
                                            <tr>
                                                <td style="border:1px dotted #000 !important;">ပထမသုံးလပတ်</td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:1px dotted #000 !important;">ဒုတိယသုံးလပတ်</td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:1px dotted #000 !important;">တတိယသုံးလပတ်</td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:1px dotted #000 !important;">စတုတ္ထသုံးလပတ်</td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:1px dotted #000 !important;">စုစုပေါင်း</td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                                <td style="border:1px dotted #000 !important; color: red;"><span id="ct2_advanceTax2"></span></td>
                                                <td style="border:1px dotted #000 !important;"></td>
                                            </tr>
                                        </table>
                                    </td>
                                    <td style="text-align: center; vertical-align:top; border-left: 1px solid #000 !important; border-right: none;"></td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;">................</td>
                                    <td style="height: 140px;">
                                        <p style="text-align:justify;">အခွန်ထမ်းသည်( <strong><span style="color:red;" class="ct2_year_val3"></span></strong> )ဝင်ငွေနှစ်အတွက် 
                                        နှစ်ချုပ်ကြေညာလွှာကို ဝင်စာမှတ်ပုံတင် အမှတ်(..........)ဖြင့်(....................)ရက်နေ့တွင် တင်သွင်းထားပါသည်-</p><br><br>
                                    
                                        <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                    <td style="text-align: center; vertical-align:top; border-left: 1px solid #000 !important; border-right: none;"></td>
                                </tr>
                                
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;"><span id="ct2_odDate"></span></td>
                                    <td style="height: 140px;">
                                        <p style="text-align:justify;vertical-align:top;">အခွန်ထမ်းအား ပတခ(ကသခ)-၀၄-၀၅ ဖြင့် အကြောင်းကြားစာ ထုတ်ဆင့်ပါ။</p>
                                        <br><br>
                                        <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div>
                                        <br><br>
                                    </td>
                                    <td style="text-align: center; vertical-align:top;  border-left: 1px solid #000 !important; border-right: none; font-size:14px;" class="right_border">(<span id="ct2_appDate"></span>)<br>ချိန်း</td>
                                </tr>
                                <tr>
                                    <td colspan="3"></td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;"><span id="ct2_vsDate"></span></td>
                                    <td style="height: 140px; vertical-align:top;">
                                        <p style="text-align:justify; vertical-align:top;">အခွန်ထမ်း/ကိုယ်စားလှယ် လာရောက်သဖြင့် တင်ပြချက်များနှင့်ထွက်ဆိုချက်များကို 
                                            မှတ်တမ်းတင်သည်။</p>
                                        <br><br>
                                        <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                    <td style="text-align: center; vertical-align:top;  border-left: 1px solid #000 !important; border-right: none;"></td>
                                </tr>
                                <tr class="print-page-2" style="height: 30px;">
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;"><span id="ct2_ct2DemandDate"></span></td>
                                    <td style="height: 0px;">
                                        <p style="text-align:justify;"> အခွန်ထမ်းတင်ပြသော ကုန်ရောင်း/ ဝန်ဆောင်မှုကြေညာလွှာ၊ ရရှိထားသော သတင်း အချက်အလက် 
                                            အထောက်အထားများ၊ ကွင်းဆင်းစစ်ဆေးချက်များကို အခြေခံပြီး အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀၊ ၆၄ တို့အရ အောက်ပါအတိုင်း 
                                            စည်းကြပ်မှုအမိန့်ချမှတ်လိုက်သည်- </p>
                                                    
                                        <table class="calc-lines" style="width:100%; border:none !important; height:23px;">
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right;">သတ်မှတ်ရောင်းရငွေ</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; text-align:right;"><span id="ct2_salesAmount2"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right;">ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; text-align:right;"><span id="ct2_ct2tax"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right;">စည်းမျဉ်း ၄၂ အရ ခုနှိမ်သောအခွန်</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; border-bottom: 1px solid #000 !important; text-align:right;"><span id="ct2_rule42_2"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right;">ခုနှိမ်ခွင့်ပြုပြီး ပေးဆောင်ရမည့် ကုန်သွယ်ခွန်</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; text-align:right;"><span id="ct2_afterRuler2"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right;">(နုတ်) ကြိုတင်ခွန်</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="ct2_advanceTax2"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right;">ထပ်မံပေးဆောင်ရမည့် ကုန်သွယ်ခွန်</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; text-align:right;"><span id="ct2_netTax2"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right;">ပုဒ်မ-၂၁(က)၊(ခ)၊(ဂ)၊(ဃ)၊(င)၊(စ)တို့အရ ဒဏ်ငွေ</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="ct2_penalty2"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:60%; text-align:right; font-weight: bold;">စုစုပေါင်း ပေးဆောင်ရန် အခွန်နှင့်ဒဏ်</td>
                                                <td style="border:none !important; width:4%;">=</td>
                                                <td style="border:none !important; width:18%; border-bottom: 1.5px double #000 !important; font-weight: bold; text-align:right;"><span id="ct2_totalTax2"></span></td>
                                                <td style="border:none !important; width:18%;"></td>
                                            </tr>
                                        </table></td>
                                    <td style="text-align: center; vertical-align:top; border-left: 1px solid #000 !important; border-right: none;">(<span id="ct2_demandPrefix">CDN</span>-<span id="ct2_ct2DemandNo"></span>)</b></td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;"><span id="ct2_ct2DemandDate2"></span></td>
                                    <td style="height: 140px;">
                                        <p style="text-align:justify;vertical-align:top;">ကျသင့်အခွန်( <strong><span style="color:red;" id="ct2_netTax22"></span></strong> )
                                        နှင့်ဒဏ်ငွေ( <strong><span style="color:red;" id="ct2_penalty22"></span></strong> )ကို 
                                        ( <span style="color:red;" id="rq_date2"></span> )နေ့မတိုင်မီ ပေးဆောင် စေရန် ချလန်ထုတ်ဆင့်ပါ။</p>
                                        <br><br>
                                        <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                    <td style="text-align: center; vertical-align:top;border-left: 1px solid #000 !important; border-right: none;"></td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;">................</td>
                                    <td style="height: 140px;">
                                        <p style="text-align:justify;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေး( <span style="color:red" id="ct2_paidTax2"></span> )ကို                                        ( <span style="color:red" id="ct2_paidDate"></span> )ရက်နေ့တွင် 
                                        ချလန်အမှတ်(<span style="color:red" id="ct2_paidNo"></span>) ဖြင့် ပြေကြေစွာပေးသွင်းပြီး ဖြစ်ပါသဖြင့် အမှုပိတ်သိမ်းသည်။</p>
                                        <br><br>
                                        <div style="text-align: right; padding-right: 80px;">အခွန်မှူး</div></td>
                                    <td style="text-align: center; vertical-align:top;border-left: 1px solid #000 !important; border-right: none;"></td>
                                </tr>
                                <tr>
                                    <td style="text-align: center; vertical-align:top; border-right: 1px solid #000 !important; border-left: none;">................</td>
                                    <td style="height: 140px;">
                                        <p style="text-align:justify;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေးကို စည်းကြပ်သည့နှစ်အတွင်း ပေးသွင်းခြင်း မရှိသည့်အတွက် အခွန်ကြွေးကျန်ငွေအား အခွန်ကြွေးမှတ်ပုံတင်စာရင်းသို့ ကူးပြောင်းမှတ်တမ်းတင်သည်။</p>
                                        <br><br>
                                        <div style="text-align: right; padding-right: 80px;">အခွန်မှူး<br><br><br><br><br><br></div></td>
                                    <td style="text-align: center; vertical-align:top;border-left: 1px solid #000 !important; border-right: none;">................</td>
                                </tr>
                        
                            </tbody>  
                        </table>
                    </div>
                </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
            </div>
        </div>
    </div>
</div>

<script>
// ၁။ ဒေတာဆွဲယူမည့် Function ကို သီးသန့် အပြင်မှာ ထားပါ
async function loadOrderSheetData(rowId) {
    try {
        // သင့်ရဲ့ get_data.php URL လမ်းကြောင်း မှန်မမှန် ပြန်စစ်ပေးပါ
        const response = await fetch(`get_data.php?id=${rowId}`); 
        const result = await response.json();
        window.selectedRowData = result; // Global variable ထဲ ထည့်သည်
        return result; 
    } catch (error) {
        console.error("Error loading data:", error);
        return null;
    }
}

// ၂။ Modal ဖွင့်မည့် ပင်မ Function
async function openFormordersheetCT2() {
    const selectedRow = document.querySelector('#tableBody tr.selected-row');
    if (!selectedRow) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    const rowId = selectedRow.cells[1].innerText.trim();

    // ဒေတာကို စောင့်ပြီး ဆွဲထုတ်မယ်
    const data = await loadOrderSheetData(rowId);

    if (!data) {
        console.error("Data is missing from server!");
        alert("ဒေတာ ရှာမတွေ့ပါ။");
        return;
    }

    console.log("Selected Data Check:", data);

    // --- ဒေတာများကို HTML ထဲ ထည့်သွင်းခြင်း ---
    var userRank = "<?php echo $rank; ?>";
    
    const updateText = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.innerText = value || '-';
    };

    const fmt = (val) => typeof formatNumber === 'function' ? formatNumber(val || 0) : (val || 0);

    // ရိုးရိုး ID များ
    updateText('ct2_township', data.township_name);
    updateText('ct2_name', data.taxpayer_name);
    updateText('ct2_nrc', data.nrc_no);
    updateText('ct2_phone', data.ph_no);
    updateText('ct2_address', data.address);
    updateText('ct2_biz', data.businessType2);
    updateText('ct2_year', data.taxYear);
    updateText('ct2_officer', data.officer_name);
    updateText('ct2_rank', userRank);

    updateText('ct2_gir', (data.ct2_select_real || 'ကသ') + " / " + (data.ct2_no_real || '') );

    // --- စည်းကြပ်နှစ် တစ်နှစ်လျှော့တွက်ခြင်း Logic ---
    let displayYear = '-';
    if (data.taxYear && data.taxYear.includes('-')) {
        // "2026-2027" ကို '-' နဲ့ ခွဲလိုက်ရင် ['2026', '2027'] ရမယ်
        const years = data.taxYear.split('-');
        const startYear = parseInt(years[0]) - 1; // 2026 -> 2025
        const endYear = parseInt(years[1]) - 1;   // 2027 -> 2026
        displayYear = startYear + "-" + endYear;   // "2025-2026"
    } else {
        displayYear = data.taxYear || '-';
    }

    // Class နှင့် Loop ပတ်ထည့်ခြင်း (Year အတွက်)
    const yearElements = document.querySelectorAll('.ct2_year_val, .ct2_year_val2, .ct2_year_val3');
    yearElements.forEach(el => {
        el.innerText = displayYear; // တစ်နှစ်လျော့ထားတဲ့ displayYear ကို သုံးမယ်
    });

    // ကိန်းဂဏန်းများ
    updateText('ct2_salesAmount2', fmt(data.salesAmount2));
    updateText('ct2_ct2tax', fmt(data.ct2tax));
    updateText('ct2_rule42_2', fmt(data.rule42_2));
    updateText('ct2_afterRuler2', fmt(data.afterRuler2));
    updateText('ct2_advanceTax2', fmt(data.advanceTax2));
    updateText('ct2_advanceTax22', fmt(data.advanceTax2));
    updateText('ct2_netTax2', fmt(data.netTax2));
    updateText('ct2_penalty2', fmt(data.penalty2));
    updateText('ct2_totalTax2', fmt(data.totalTax2));

    const paidRaw = data.paidTax2;
    const paidNum = Number(String(paidRaw ?? '').replace(/,/g, ''));
    const paidText = (paidRaw === null || paidRaw === undefined || String(paidRaw).trim() === '' || paidNum === 0)
        ? '.............'
        : fmt(paidRaw);
    updateText('ct2_paidTax2', paidText);

    const dateRaw = data.date1;
    const dateText = String(dateRaw ?? '').trim();
    const dateMissing = dateText === '' || dateText === '0' || dateText === '0000-00-00' || dateText.startsWith('0000-00-00');
    updateText('ct2_paidDate', dateMissing ? '.............' : formatDate(dateRaw));

    const chalanRaw = data.ct2_chalan_no;
    const chalanNum = Number(String(chalanRaw ?? '').replace(/,/g, ''));
    const chalanText = (chalanRaw === null || chalanRaw === undefined || String(chalanRaw).trim() === '' || chalanNum === 0)
        ? '.............'
        : String(chalanRaw);
    updateText('ct2_paidNo', chalanText);

    updateText('ct2_netTax22', fmt(data.netTax2));
    updateText('ct2_penalty22', fmt(data.penalty2));

    const currentTaxYear = "<?php
        $ct2OsCurrentTaxYear = '';
        if (isset($conn)) {
            $ct2OsToday = date('Y-m-d');
            $ct2OsBudgetQuery = "SELECT budget_year FROM budget_year WHERE '$ct2OsToday' BETWEEN start_date2 AND end_date2 LIMIT 1";
            $ct2OsBudgetResult = $conn->query($ct2OsBudgetQuery);
            if ($ct2OsBudgetResult && $ct2OsBudgetRow = $ct2OsBudgetResult->fetch_assoc()) {
                $ct2OsCurrentTaxYear = $ct2OsBudgetRow['budget_year'] ?? '';
            }
        }
        if ($ct2OsCurrentTaxYear === '') {
            $ct2OsY = (int) date('Y');
            $ct2OsM = (int) date('n');
            $ct2OsCurrentTaxYear = ($ct2OsM >= 4) ? ($ct2OsY . '-' . ($ct2OsY + 1)) : (($ct2OsY - 1) . '-' . $ct2OsY);
        }
        echo htmlspecialchars($ct2OsCurrentTaxYear, ENT_QUOTES, 'UTF-8');
    ?>";
    const demandPrefix = (String(data.taxYear || '').trim() === String(currentTaxYear).trim()) ? 'CDN' : 'LDN';
    updateText('ct2_demandPrefix', demandPrefix);
    updateText('ct2_ct2DemandNo', fmt(data.ct2DemandNo));
    
    // Function တစ်ခုတည်းကိုပဲ နေရာတိုင်းမှာ သုံးပါ
    function formatDate(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        if (isNaN(date)) return dateString; // မှန်ကန်သော date format မဟုတ်ရင် မူရင်းအတိုင်းပြန်ရန်
        
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        
        return `${day}/${month}/${year}`;
    }

    // နေရာတိုင်းမှာ formatDate တစ်ခုတည်းကိုပဲ ခေါ်သုံးပါ
    updateText('ct2_vsDate', formatDate(data.visitedDate));
    updateText('ct2_odDate', formatDate(data.orderDate));
    updateText('ct2_appDate', formatDate(data.appointmentDate));
    updateText('ct2_ct2DemandDate', formatDate(data.ct2DemandDate)); 
    updateText('ct2_ct2DemandDate2', formatDate(data.ct2DemandDate));    

    // ရက်စွဲ တွက်ချက်ခြင်း (+14 days)
    /*if (data.date1) {
        const d = new Date(data.date1);
        d.setDate(d.getDate() + 14); 
        const formattedDate = d.getDate() + "-" + (d.getMonth() + 1) + "-" + d.getFullYear();
        updateText('rq_date1', formattedDate);
    }*/
   if (data.ct2DemandDate && data.ct2DemandDate !== '0000-00-00') {
    const d = new Date(data.ct2DemandDate);
    
    // Date က Invalid ဖြစ်နေသလား ထပ်စစ်ပါ
    if (!isNaN(d.getTime())) {
        d.setDate(d.getDate() + 14); 
        
        // ရက်စွဲ format ကို သေသပ်အောင် (01-01-2026) ပုံစံမျိုး ပြင်ရေးပါ
        const dd = String(d.getDate()).padStart(2, '0');
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const yyyy = d.getFullYear();
        
        const formattedDate = dd + "-" + mm + "-" + yyyy;
        
        // id='rq_date1' ရှိတဲ့ element ထဲကို ထည့်ခြင်း
        const targetEl = document.getElementById('rq_date2');
        if (targetEl) {
            targetEl.innerText = formattedDate;
        }
    }
}

    // --- Modal များ ထိန်းချုပ်ခြင်း ---
    
    // အမှုတွဲပုံစံများ-၂ Modal ကို ပိတ်ပါ
    var formsModalEl = document.getElementById('formsModal2') || document.getElementById('formsModal');
    if (formsModalEl) {
        var formsInstance = bootstrap.Modal.getOrCreateInstance(formsModalEl);
        formsInstance.hide();
    }

    // ဒုတိယ Modal (Order Sheet Modal) ကို ဖွင့်ပါ
    var orderModalEl = document.getElementById('ct2orderSheetModal');
    if (orderModalEl) {
        var myModal = bootstrap.Modal.getOrCreateInstance(orderModalEl);
        myModal.show();
    }
}
</script>