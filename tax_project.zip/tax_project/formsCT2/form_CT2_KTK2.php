<style>
    /* မီးခိုးနောက်ခံပေါ်မှာ A4 စာရွက်ဖြူကို ခွဲပြသည် */
    #form_CT1_KTK2Modal .modal-dialog {
        max-width: 236mm;
        width: 236mm;
        margin: 10px auto;
    }

    #form_CT1_KTK2Modal .modal-content {
        background-color: #c8c8c8;
        background-image: linear-gradient(180deg, #d4d4d4 0%, #bdbdbd 100%);
        border: 1px solid rgba(0,0,0,.28);
        border-radius: 16px;
        padding: 0 0 14px;
        box-shadow: 0 10px 24px rgba(0,0,0,.28);
    }

    #form_CT1_KTK2Modal #printableSheet {
        width: 210mm;
        min-height: 297mm;
        margin: 10px auto 10px;
        background: #fff;
        box-sizing: border-box;
        padding: 0mm 0mm;
        border: none !important;
        border-radius: 1px;
        box-shadow: 0 1px 0 rgba(255,255,255,.7), 0 8px 18px rgba(0,0,0,.35);
    }

    #form_CT1_KTK2Modal table.law-box,
    #form_CT1_KTK2Modal table.law-box td {
        border: 1.5px solid #000 !important;
        border-collapse: separate;
        border-spacing: 0;
    }

    #form_CT1_KTK2Modal .print-container {
        border: none !important;
        padding: 10mm 10mm 10mm 10mm !important;
        box-sizing: border-box;
        min-height: 0;
        line-height: 1.7;
    }

    #form_CT1_KTK2Modal .print-container div,
    #form_CT1_KTK2Modal .print-container p {
        line-height: 1.7 !important;
    }

    #form_CT1_KTK2Modal .print-container > table:last-child {
        margin-top: 12px !important;
    }

    @media print {
        .modal-footer, .no-print, .btn, .btn-close { display: none !important; }

        body:has(#form_CT1_KTK2Modal.show) > *:not(#form_CT1_KTK2Modal) {
            display: none !important;
        }

        #form_CT1_KTK2Modal,
        #form_CT1_KTK2Modal * {
            visibility: visible !important;
        }

        #form_CT1_KTK2Modal {
            position: static !important;
            left: auto !important;
            top: auto !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
        }

        #form_CT1_KTK2Modal .modal-dialog,
        #form_CT1_KTK2Modal .modal-content {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
            box-shadow: none !important;
            border: none !important;
        }

        #form_CT1_KTK2Modal #printableSheet {
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            max-height: none !important;
            margin: 0 !important;
            padding: 0 !important;
            box-sizing: border-box !important;
            box-shadow: none !important;
            background: #fff !important;
            overflow: visible !important;
        }

        #form_CT1_KTK2Modal .print-container {
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            margin: 0 !important;
            border: none !important;
            padding-: 10mm 8mm 10mm 12mm!important;
            box-sizing: border-box !important;
            line-height: 2 !important;
        }

        #form_CT1_KTK2Modal table.law-box {
            border-collapse: separate !important;
            border-spacing: 0 !important;
            border: 1px solid #000 !important;
        }

        #form_CT1_KTK2Modal table.law-box td {
            border: 1px solid #000 !important;
        }
    }
</style>

<div class="modal fade" id="form_CT1_KTK2Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 12px; border-bottom: none;">
                <h5 class="modal-title">ကုန်သွယ်လုပ်ငန်းခွန် မှတ်ပုံတင်လက်မှတ် ထုတ်ယူရန်</h5>
                <button type="button" class="close-modal-btn" onclick="window.location.href='CT1_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div id="printableSheet">
                <div class="print-container" >
                    <table class="law-box" style="border: 1px solid #000; text-align:center; font-size:15px; width:100%; line-height:25px; margin-bottom: 10px;">
                        <tr>
                            <td style='padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>
                                ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px;'>ပတခ(ကသခ)-၂</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:20px; font-size:17px;">
                        ကုန်စည်ထုတ်လုပ်သူ သို့မဟုတ် ကုန်စည်တင်သွင်းသူ သို့မဟုတ် ကုန်သွယ်မှုဆောင်ရွက်သူ သို့မဟုတ် <br>
                        ဝန်ဆောင်မှုဆောင်ရွက်သူအား မှတ်ပုံတင်ခွင့်ပြုကြောင်း ထုတ်ပေးသည့် လက်မှတ်(စည်းမျဉ်း ၄ ညွှန်း)<br><br>
                        ဘဏ္ဍာရေးနှင့်အခွန်ဝန်ကြီးဌာန<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br><span id="CT1_KTK2_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး

                    </div>
                    <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>မှတ်ပုံတင်လက်မှတ် အမှတ်စဉ်</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%; border-bottom:2px dotted #000;'>
                                (.........) / <span id="CT1_KTK2_year"></span> / ( <span id="ct1_gir"></span> ) / ( <span id="ct2_gir"></span> )
                            </td>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>ကုန်စည်ထုတ်လုပ်သူ သို့မဟုတ် </b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'>
                                <span id="CT1_KTK2_name"></span>(<span id="CT1_KTK2_biz"></span>/<span id="CT1_KTK2_biz_tatail"></span>)</td>
                        </tr>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>ဝန်ဆောင်မှုဆောင်ရွက်သူအမည်</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'></td>
                        </tr>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>နိုင်ငံသားစိစစ်ရေးကဒ်ပြားအမှတ်</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'></td>
                        </tr>
                        <tr>
                            <td style='text-align:left; width:30%;'><b>အခွန်ထမ်းလိပ်စာ</b></td>
                            <td style='text-align:center; width:5%;'>-</td>
                            <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'><span id="CT1_KTK2_address"></span></td>
                        </tr>
                        
                    </table>

                    
                    <div style="text-align:justify; line-height:1.8;">
                        ၁။<span style = 'padding-left:50px;  text-align:justify;'>အောက်ဖော်ပြပါ ကုန်စည်များကို  ( တင်သွင်း/ ကုန်သွယ်/ ထုတ်လုပ် ) 
                            သို့မဟုတ် ဝန်ဆောင်မှု ဆောင်ရွက်သူ ( <strong><span id="CT1_KTK2_biz_name"></span></strong> )  သို့ မှတ်ပုံတင်ခွင့်ပြုကြောင်း  လက်မှတ်ကို 
                            ကုန်သွယ်လုပ်ငန်းခွန် စည်းမျဉ်း၄ အရ ထုတ်ပေးလိုက်သည်။       
                    </div>

                    <div style="margin-top:15px; text-align:justify; line-height:1.8;">
                        ၂။<span style = 'padding-left:50px;'>မှတ်ပုံတင်ခွင့်ပြုကြောင်း ထုတ်ပေးသော လက်မှတ်သည်  အောက်ဖော်ပြပါနေရာ၌ လုပ်ကိုင်ဆောင်ရွက်သော လုပ်ငန်းများအတွက်ဖြစ်သည်-
                        <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                            <tr>
                                <td style='text-align:right; width:33%;text-align:right;'><b>လုပ်ငန်းအဓိက တည်နေရာ :</b></td>
                                <td style='text-align:right; width:5%;'>-</td>
                                <td style='text-align:left; width:62%;border-bottom:2px dotted #000;min-width:300px;'>
                                   <span id="CT1_KTK2_address2"></span></td>
                            </tr>
                            <tr>
                                <td style='text-align:right; width:30%;text-align:right;'><b>လုပ်ငန်းခွဲများ :</b></td>
                                <td style='text-align:right; width:5%;'></td>
                                <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'>
                                   (က)</td>
                            </tr>
                            <tr>
                                <td style='text-align:right; width:30%;text-align:right;'></td>
                                <td style='text-align:right; width:5%;'></td>
                                <td style='text-align:left; width:65%;border-bottom:2px dotted #000;min-width:300px;'>
                                   ( ခ )</td>
                            </tr>
                        </table>
                    </div>
                    
                    <div style="text-align:justify; line-height:1.8;">
                        ၃။<span style = 'padding-left:50px; text-align:justify;'>လုပ်ငန်းရပ်စဲလျှင် ရပ်စဲသည့်နေ့အထိ စည်းကြပ်ရန်ရှိသော ကာလအတွက် ကြေညာလွှာကို
                             ရပ်စဲသည့်နေ့မှ (၁၅)ရက်အတွင်း မြို့နယ်အခွန်ဦးစီးဌာနမှူးထံသို့ ဤမှတ်ပုံတင်လက်မှတ်နှင့်အတူ ပေးပို့ရမည်။
                    </div>
                    <div style="text-align:justify; line-height:1.8;">
                        ၄။<span style = 'padding-left:50px; text-align:justify;'>ဤမှတ်ပုံတင်လက်မှတ် သို့မဟုတ် လက်မှတ်မိတ္တူများကို
                             လုပ်ငန်းဥပစာ အသီးသီးတွင် အများမြင်သာအောင်ချိတ်ဆွဲထားရမည်။
                    </div>
                    <div style="text-align:justify; line-height:1.8;">
                        ၅။<span style = 'padding-left:50px; text-align:justify;'>ဤမှတ်ပုံတင်လက်မှတ်သည်
                        ( ၃၁-၀၃-<span id="year_end"></span> )ရက်နေ့တွင်ကုန်ဆုံးသော နှစ်အတွက်သာ အတည်ဖြစ်သည်။
                    </div>
                    <div style="text-align:justify; line-height:1.8;">
                        ၆။<span style = 'padding-left:50px; text-align:justify;'>ဤမှတ်ပုံတင်လက်မှတ်သည်
                        ( ၁-၀၄-<span id="year_start"></span> )ရက်နေ့တွင် ရုံးတံဆိပ်ရိုက်နှိပ်၍ ကျန်ုပ်လက်မှတ်ရေးထိုး ထုတ်ပေးလိုက်သည်။
                    </div>

                    <br>

                    <table style='width:100%; margin-top:40px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px; vertical-align:top;'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br>
                                ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                <span id="CT1_KTK2_township"></span>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="universalPrint('form_CT1_KTK2Modal')">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
function openFormCT1_KTK2() {
    var data = window.selectedRowData;
    if (!data) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
        return;
    }

    const toMyanmarDigit = (num) => {
        if (num === null || num === undefined || num === "") return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    // ၁။ Tax Year ကို တစ်နှစ်လျှော့ပြီး ရှေ့နှစ်/နောက်နှစ် ခွဲထုတ်ခြင်း
    let rawYear = data.taxYear || ""; // e.g., "2026-2027"
    let reducedYear = rawYear.replace(/\d+/g, (match) => parseInt(match) - 1); // "2025-2026" ဖြစ်သွားမည်
    
    let yearParts = reducedYear.split("-"); // ["2025", "2026"]
    let startYear = yearParts[0] ? toMyanmarDigit(yearParts[0]) : ""; // "၂၀၂၅"
    let endYear = yearParts[1] ? toMyanmarDigit(yearParts[1]) : "";   // "၂၀၂၆"

    // ၂။ စဉ် ၅ နှင့် စဉ် ၆ နေရာတွင် Data ထည့်ခြင်း
    // HTML ထဲရှိ စဉ် ၅/၆ နေရာတွင် <span id="year_start"></span> နှင့် <span id="year_end"></span> ထည့်ထားရန် လိုသည်
    setText('year_start', startYear); // စဉ် ၆ (1-04-) ၏ နောက်တွင် ထည့်ရန်
    setText('year_end', endYear);     // စဉ် ၅ (31-03-) ၏ နောက်တွင် ထည့်ရန်

    // ၃။ ct1_gir ချိတ်ဆက်မှု စစ်ဆေးခြင်း
// ct1_gir အတွက် console log မှ နာမည်များအတိုင်း ပြင်ထားသည်
let gir1_text = (data.ct1_select_real || 'ကသ') + " / " + (data.ct1_no_real || '');
setText('ct1_gir', gir1_text);

    // ကျန်ရှိသော အချက်အလက်များ
    setText('ct2_gir', (data.ct2_select2_real || 'ကသ') + " / " + (data.ct2_no_real || '') );
    setText('CT1_KTK2_name', data.taxpayer_name);
    setText('CT1_KTK2_address', data.address);
    setText('CT1_KTK2_address2', data.address);
    setText('CT1_KTK2_biz', data.businessType1);
    setText('CT1_KTK2_biz_tatail', data.businessType2);
    setText('CT1_KTK2_township', data.township_name);
    setText('CT1_KTK2_year', toMyanmarDigit(reducedYear)); // (၂၀၂၅-၂၀၂၆) တစ်ခုလုံးပြရန်
    setText('CT1_KTK2_biz_name', data.taxpayer_name);

    // Modal ဖွင့်ခြင်း
    const modalElem = document.getElementById('form_CT1_KTK2Modal');
    if (modalElem) {
        var myModal = bootstrap.Modal.getOrCreateInstance(modalElem);
        myModal.show();
    }
}
</script>