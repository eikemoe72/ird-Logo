<?php
// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    // အစ်ကို့ရဲ့ ပင်မ Table နာမည် 'sakalakahdata' ထဲမှ ဆွဲထုတ်ခြင်း
    $query = "SELECT * FROM regular_data WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း
$os_case_number     = htmlspecialchars($db_data['case_number'] ?? '-');
$os_name            = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_township_name   = htmlspecialchars($db_data['township_name'] ?? '-');
$os_taxYear         = htmlspecialchars($db_data['taxYear'] ?? '-');


$os_gir             = htmlspecialchars($db_data['it_no'] ?? '-');
$os_gir_type        = htmlspecialchars($db_data['it_select'] ?? '-');

$os_gir_ct1         = htmlspecialchars($db_data['ct1_no_real'] ?? '-');
$os_gir_type_ct1    = htmlspecialchars($db_data['ct1_select_real'] ?? '-');

$os_gir_ct2         = htmlspecialchars($db_data['ct2_no_real'] ?? '-');
$os_gir_type_ct2    = htmlspecialchars($db_data['ct2_select_real'] ?? '-');

$os_address         = htmlspecialchars($db_data['address'] ?? '-');
$os_ph_no           = htmlspecialchars($db_data['ph_no'] ?? '-');
$os_officer         = htmlspecialchars($db_data['officer_name'] ?? 'အခွန်မှူးအမည်');
$os_officer_rank    = htmlspecialchars($db_data['rank_'] ?? 'ရာထူး');
$os_biz1            = htmlspecialchars($db_data['businessType1'] ?? '-');
$os_biz2            = htmlspecialchars($db_data['businessType2'] ?? '-');

//ကြေညာလွှာတင်သွင်းခြင်း
$os_declaredIT      = htmlspecialchars($db_data['declaredIncome1'] ?? 'နယ်မြေ');
$os_declaredCT1     = htmlspecialchars($db_data['declaredCT1'] ?? '-');
$os_declaredCT2     = htmlspecialchars($db_data['declaredCT2'] ?? '-');

// (၄) ယခင်သုံးနှစ်စာ
$os_rowYear1        = htmlspecialchars($db_data['rowYear1'] ?? '-');
$os_income1         = htmlspecialchars($db_data['income1'] ?? '-');
$os_income_tax1     = htmlspecialchars($db_data['income_tax1'] ?? '-');
$os_sale_income1    = htmlspecialchars($db_data['sale_income1'] ?? '-');
$os_ct1             = htmlspecialchars($db_data['ct1'] ?? '-');

$os_rowYear2        = htmlspecialchars($db_data['rowYear2'] ?? '-');
$os_income2         = htmlspecialchars($db_data['income2'] ?? '-');
$os_income_tax2     = htmlspecialchars($db_data['income_tax2'] ?? '-');
$os_sale_income2    = htmlspecialchars($db_data['sale_income2'] ?? '-');
$os_ct2             = htmlspecialchars($db_data['ct2'] ?? '-');

$os_rowYear3        = htmlspecialchars($db_data['rowYear3'] ?? '-');
$os_income3         = htmlspecialchars($db_data['income3'] ?? '-');
$os_income_tax3     = htmlspecialchars($db_data['income_tax3'] ?? '-');
$os_sale_income3        = htmlspecialchars($db_data['sale_income3'] ?? '-');
$os_ct3             = htmlspecialchars($db_data['ct3'] ?? '-');

//ကုန်သွယ်ခွန်တွက်ချက်မှု1
$os_salesAmount1    = htmlspecialchars($db_data['salesAmount1'] ?? '-');
$os_ct1tax          = htmlspecialchars($db_data['ct1tax'] ?? '-');
$os_rule42_1        = htmlspecialchars($db_data['rule42_1'] ?? '-');
$os_afterRuler1     = htmlspecialchars($db_data['afterRuler1'] ?? '-');
$os_advanceTax1     = htmlspecialchars($db_data['advanceTax1'] ?? '-');

$os_salesAmount2    = htmlspecialchars($db_data['salesAmount2'] ?? '-');
$os_ct2tax          = htmlspecialchars($db_data['ct2tax'] ?? '-');
$os_rule42_2        = htmlspecialchars($db_data['rule42_2'] ?? '-');
$os_afterRuler2     = htmlspecialchars($db_data['afterRuler2'] ?? '-');
$os_advanceTax2     = htmlspecialchars($db_data['advanceTax2'] ?? '-');
$os_advanceTax      = htmlspecialchars($db_data['advancePaidTax'] ?? '-');

$os_summary             = htmlspecialchars($db_data['summary'] ?? '-');
$os_appraisal           = htmlspecialchars($db_data['appraisal'] ?? '-');


?>




<style>
/* ==========================================================================
   🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် တကယ့် A4 ကဲ့သို့ ဗဟိုကျကျပေါ်စေရန်)
   ========================================================================== */
#Form_CT1_culateModal .modal-dialog {
    max-width: 795px !important; 
    width: 95% !important;
    margin: 20px auto !important;
    position: relative; /* 🎯 Close Button ကို ပုံသေနေရာချရန် အရေးကြီးပါသည် */
}

#Form_CT1_culateModal .modal-content {
    background-color: #9ecaeb !important; /* အစ်ကိုကြီး ရွေးချယ်ထားသော အပြာနုရောင်နောက်ခံ */
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}

#Form_CT1_culateModal .modal-body {
    padding: 0 !important; 
    overflow-x: hidden !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
}

/* 🎯 ညာဘက်ထိပ်တွင် အနီရောင် X ခလုတ် ပေါ်စေရန် စတိုင် */
.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 36px !important;
    background-color: #dc3545 !important; /* အနီရောင် */
    color: #ffffff !important; /* အဖြူရောင် X */
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 36px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; /* မိုဒယ်စာမျက်နှာထက် အပေါ်စီးတွင် ရှိနေစေရန် */
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}

.custom-close-btn:hover {
    background-color: #bd2130 !important; /* Hover လုပ်လျှင် အနီရောင် ပိုရင့်သွားစေရန် */
}

/* 🎯 ကွန်ပျူတာပေါ်တွင် မြင်ရမည့် A4 စာရွက်ပုံစံအစစ် */
.print-container { 
    background: #ffffff !important;
    width: 210mm !important;
    max-width: 100%;
    min-height: 0 !important;
    height: auto !important;
    padding: 5mm 8mm 5mm 20mm !important; 
    margin: 0 auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}

/* ဇယားများ ညာဘက်လုံးဝမကျွံစေရန် ထိန်းချုပ်မှု */
table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}

table, tr, td { 
    box-sizing: border-box !important;
}

/* 🎯 ခေါင်းစီးစာသား */
.custom-modal-title {
    font-size: 20px !important; 
    font-weight: bold !important; 
    color: #0a1a2b !important; 
    padding-left: 25px !important; 
    display: inline-block !important;
    line-height: 10px !important; 
}

.no-print-bottoms {
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    gap: 15px !important;
    margin-top: 0px !important;    
    margin-bottom: 30px !important;
    width: 100% !important;
}

.no-print-bottoms .btn {
    font-size: 16px !important;         
    font-weight: bold !important;     
    padding: 10px 24px !important;    
    border-radius: 5px !important;    
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important; 
    transition: all 0.2s ease-in-out !important;
}

.no-print-bottoms .btn:hover {
    transform: translateY(-1.5px) !important; 
    box-shadow: 0 6px 11.5px rgba(0, 0, 0, 0.2) !important;
}
#Form_CT1_culateModal .modal-header {
    display: flex !important;
    justify-content: space-between !important;
    align-items: center !important;
    background-color: #55bbee !important; /* လိုအပ်ပါက အရောင်ဆက်ထားရန် */
}



/* ==========================================================================
   🖨️ PRINT — အရှေ့စာရွက်တစ်ရွက်တည်းကို A4 အပြည့်ထုတ်သည်
   ========================================================================== */
@media print {
    #Form_CT1_culateModal .custom-close-btn,
    #Form_CT1_culateModal .modal-header,
    #Form_CT1_culateModal .custom-modal-title,
    #Form_CT1_culateModal .modal-footer,
    #Form_CT1_culateModal .no-print,
    #Form_CT1_culateModal .no-print-bottoms,
    #Form_CT1_culateModal .btn,
    #Form_CT1_culateModal .btn-close {
        display: none !important;
    }

    html, body {
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
        background-color: #fff !important;
    }

    #Form_CT1_culateModal,
    #Form_CT1_culateModal .modal-dialog,
    #Form_CT1_culateModal .modal-content,
    #Form_CT1_culateModal .modal-body {
        position: static !important;
        display: block !important;
        width: 210mm !important;
        max-width: 210mm !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        border-radius: 0 !important;
        box-shadow: none !important;
        background: #fff !important;
        background-color: #fff !important;
        background-image: none !important;
        overflow: visible !important;
        transform: none !important;
    }

    #Form_CT1_culateModal .print-container {
        width: 210mm !important;
        max-width: 210mm !important;
        min-height: 297mm !important;
        height: auto !important;
        margin: 0 !important;
        padding: 5mm 10mm 8mm 22mm !important;
        display: block !important;
        box-sizing: border-box !important;
        border: none !important;
        border-radius: 0 !important;
        box-shadow: none !important;
        background: #fff !important;
        background-color: #fff !important;
    }

    table, .main-content-table, .main-content-table2 {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important; /* ညာဘက်ကျွံခြင်းကို ကာကွယ်ရန် */
    }
    
    table, tr, td { 
        border: none !important; 
        box-sizing: border-box !important;
    }
    
    .print-container table:first-child {
        border: none !important;
    }

    hr { display: none !important; }


    /* ၅။ Browser မူရင်း Margin ကို ပိတ်ပြီး ကျွန်တော်တို့ သတ်မှတ်ချက်အတိုင်း သုံးခြင်း */
    @page {
        size: A4 portrait;
        margin: 0mm !important; /* စာရွက်အနားသတ်ကို ၀ ထားပြီး Padding ဖြင့် ထိန်းချုပ်ခြင်း */
    }
}
</style>

<script>
    function closeAndReturnToDemandList() {
        window.location.href = '../CT1_Demand_List.php';
    }
</script>


<div class="modal fade" id="Form_CT1_culateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="custom-modal-title">အခွန်တွက်ချက်မှုပုံစံ ထုတ်ယူရန်</h5>

                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            <div class="modal-body" style="padding: 0px !important;">

            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <div style="text-align: center; margin-bottom: 10px;">
                        <h6 style="font-weight: bold; font-size: 15px; margin-bottom: 5px;">ကုန်သွယ်လုပ်ငန်းခွန် တွက်ချက်မှုပုံစံ</h6>
                    </div>

                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:40%"><b>အမှုတွဲအမှတ်စဉ်( <span id="os_case_number"><?php echo $os_case_number; ?></span> )</b></td>
                            <td style="width:40%; text-align:right;"><b>စည်းကြပ်နှစ်&ensp;</b></td>
                            <td style="width:20%; border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_taxYear"><?php echo $os_taxYear; ?></span></td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်(CT2)&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_gir_type_ct2"><?php echo $os_gir_type_ct2; ?></span>/<span id="os_gir_ct2"><?php echo $os_gir_ct2; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>အခွန်မှူးအမည်&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_officer "><?php echo $os_officer ; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>ရာထူး&ensp;</b></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_officer_rank "><?php echo $os_officer_rank ; ?></span></td>
                        </tr>
                    </table>

                    <table class="main-content-table2" style="line-height:24px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%">၁။</td>
                            <td style="width:20%; text-align:left;"><b>အခွန်ထမ်းအမည်</b></td>
                            <td style="width:5%; text-align:center;">-</td>
                            <td style="width:70%; border-bottom: 1.5px dotted #000 !important; text-align:left;"> <span id="os_name"><?php echo $os_name; ?></span>&ensp;(<span id="os_ph_no "><?php echo $os_ph_no ; ?></span>)</td>
                        </tr>
                        <tr>
                            <td>၂။</td>
                            <td style="text-align:left;"><b>အခွန်ထမ်းလိပ်စာ</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;"> <span id="os_address"><?php echo $os_address; ?></span></td>
                        </tr>
                        <tr>
                            <td>၃။</td>
                            <td style="text-align:left;"><b>လုပ်ငန်းအမျိုးအစား</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;"> <span id="os_biz2"><?php echo $os_biz2; ?></span></td>
                        </tr>
                        <tr>
                            <td>၄။</td>
                            <td style="text-align:left;"><b>ကြေညာသည့်ဝင်ငွေ</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;">
                            ကသခ-၂(<span id="os_declaredCT2"><?php echo $os_declaredCT2; ?></span>)</td>
                        </tr>
                        <tr>
                            <td>၅။</td>
                            <td style="text-align:left;"><b>ကြိုတင်ခွန်</b></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dotted #000 !important; text-align:left;">
                            ကသခ-၂(<span id="os_advanceTax2"><?php echo $os_advanceTax2; ?></span>)</td>
                        </tr>
                       
                    </table>

                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၆။</td>
                            <td style="width:95%; border: none !important; text-align:left;"><b>လွန်ခဲ့သော(၃)နှစ်စည်းကြပ်မှုမှတ်တမ်း</b>
                            </td>
                           
                        </tr>
                    </table>

                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="width:17%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>စည်းကြပ်နှစ်</b></td>
                            <td style="width:19%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>သတ်မှတ်ဝင်ငွေ</b></td>
                            <td style="width:19%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>ဝင်ငွေခွန်</b></td>
                            <td style="width:20%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>သတ်မှတ်ရောင်းရငွေ</b></td>
                            <td style="width:20%; border: 1.5px dotted #000 !important; text-align:center; font-size:14px;"><b>ကုန်သွယ်လုပ်ငန်းခွန်</b></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"><span id="os_rowYear1"><?php echo $os_rowYear1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"><span id="os_income1"><?php echo $os_income1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"><span id="os_income_tax1"><?php echo $os_income_tax1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"> <span id="os_sale_income1"><?php echo $os_sale_income1; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px;"> <span id="os_ct1"><?php echo $os_ct1; ?></span></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center; "><span id="os_rowYear2"><?php echo $os_rowYear2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income2"><?php echo $os_income2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income_tax2"><?php echo $os_income_tax2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_sale_income2"><?php echo $os_sale_income2; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_ct2"><?php echo $os_ct2; ?></span></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:center;"></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:center;"><span id="os_rowYear3"><?php echo $os_rowYear3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income3"><?php echo $os_income3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"><span id="os_income_tax3"><?php echo $os_income_tax3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_sale_income3"><?php echo $os_sale_income3; ?></span></td>
                            <td style="border: 1.5px dotted #000 !important; text-align:right; padding-right:10px"> <span id="os_ct3"><?php echo $os_ct3; ?></span></td>
                        </tr>
                    </table>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၇။</td>
                            <td style="width:95%; border: none !important; text-align:justify;"><b>အခွန်ထမ်း၏လုပ်ငန်းနှင့်ပတ်သက်၍ တင်ပြချက်</b></td>
                            
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td style="width:95%; border: none !important; text-align:justify;">
                                <?php 
                                // 🎯 trim() သုံးပြီး အလွတ် (သို့မဟုတ်) null ဖြစ်နေသလားလို့ စိတ်ချရအောင် စစ်လိုက်ပါတယ်ဗျာ
                                if (empty($os_summary) || trim($os_summary) == "") { 
                                ?>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................
                                <?php 
                                } else { 
                                ?>
                                    
                                        <span style="padding-left:40px; text-align:justify; " id="os_summary">
                                            <?php echo $os_summary; ?>
                                        </span>
                                    
                                <?php 
                                } // အပိတ် 
                                ?>

                            </td>
                            
                        </tr>
                    </table>
                   
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၈။</td>
                            <td style="width:95%; border: none !important; text-align:justify;"><b>အခွန်မှူး၏ သုံးသပ်တင်ပြချက်</b></td>
                            
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td style="width:95%; border: none !important; text-align:justify;">
                                <?php 
                                // 🎯 trim() သုံးပြီး အလွတ် (သို့မဟုတ်) null ဖြစ်နေသလားလို့ စိတ်ချရအောင် စစ်လိုက်ပါတယ်ဗျာ
                                if (empty($os_appraisal) || trim($os_appraisal) == "") { 
                                ?>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................<br>
                                    ....................................................................................................................................................................
                                
                                <?php 
                                } else { 
                                ?>
                                        <span style="padding-left:40px; text-align:justify;" id="os_appraisal">
                                            <?php echo $os_appraisal; ?>
                                        </span>
                                <?php 
                                } // အပိတ် 
                                ?>
                            </td>
                            
                        </tr>
                    </table>
                    
                    <p style="text-align:center;"><b>ကုန်သွယ်လုပ်ငန်းခွန် တွက်ချက်မှု</b></P>
                    <table class="main-content-table2" style="line-height:23px; font-size:15px; border-collapse: collapse; width: 100%;">
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;">၉။</td>
                            <td style="width:50%; border: none !important; text-align:right;"></td>
                            <td colspan="2" style="width:24%; text-align:right;"><b><span id="os_biz2_calc"><?php echo $os_biz2; ?></span></b></td>
                            <td style="width:19%; border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td style="width:5%; border: none !important; text-align:left;"></td>
                            <td style="width:50%; border: none !important; text-align:right;">သတ်မှတ်ရောင်းရငွေ</td>
                            <td style="width:5%; border: none !important; text-align:center;">=</td>
                            <td style="width:19%; border-bottom: 0px dotted #000 !important; text-align:right;"><span id="os_salesAmount2"><?php echo $os_salesAmount2; ?></span></td>
                            <td style="width:19%; border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="border: none !important; text-align:right;">ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 0px dotted #000 !important; text-align:right;"><span id="os_ct2tax"><?php echo $os_ct2tax; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="border: none !important; text-align:right;">စည်းမျဉ်း-၄၂ အရ ခုနှိမ်သောအခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_rule42_2"><?php echo $os_rule42_2; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="border: none !important; text-align:right;">ပေးဆောင်ရမည့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                            <td style="border: none !important; text-align:center;">=</td>
                            <td style="border-bottom: 1.5px solid #000 !important; text-align:right;"><span id="os_afterRuler2"><?php echo $os_afterRuler2; ?></span></td>
                            <td style="border: none !important; text-align:left;"></td>
                        </tr>
                    </table>
                    <br><br><br><br>
                    <table style='width:100%; margin-top:12px; border:none !important;font-size:15px;'>
                        <tr>
                            <td style='width:50%; padding-left:100px'></td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br><span id="os_township_name"><?php echo $os_township_name; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                    
                </div>
            </div>
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn px-4" onclick="window.print()" 
                        style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                    <i class="fa fa-print"></i> Print ထုတ်မည်
                </button>
                <button type="button" class="btn px-4" 
                        onclick="window.location.href='../CT1_Demand_List.php';" 
                        style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                    ပိတ်မည်
                </button>
            </div>
        </div>
    </div>
</div>
