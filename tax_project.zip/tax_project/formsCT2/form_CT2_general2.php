<style>
    #formct2general2Modal .modal-dialog {
        max-width: 236mm;
        width: 236mm;
        margin: 12px auto;
    }

    #formct2general2Modal .modal-content {
        background-color: #c8c8c8;
        background-image: linear-gradient(180deg, #d4d4d4 0%, #bdbdbd 100%);
        border: 1px solid rgba(0,0,0,.28);
        border-radius: 16px;
        padding: 0 0 14px;
        box-shadow: 0 10px 24px rgba(0,0,0,.28);
    }

    #formct2general2Modal .modal-header {
        background-color: #0b5ed7;
        color: #fff;
    }

    #formct2general2Modal .modal-body {
        padding: 16px 0 10px;
        background: transparent;
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    #formct2general2Modal .print-container {
        width: 210mm !important;
        max-width: 210mm !important;
        min-height: 0 !important;
        height: auto !important;
        margin: 0 auto !important;
        padding: 10mm 10mm 10mm 25mm !important;
        box-sizing: border-box !important;
        background: #fff !important;
        border-radius: 1px;
        box-shadow: 0 1px 0 rgba(255,255,255,.7), 0 8px 18px rgba(0,0,0,.35) !important;
        display: block !important;
        page-break-after: avoid !important;
    }

    #formct2general2Modal .outer-border-box {
        border: 2px solid #000000;
        padding: 15px 10px;
        box-sizing: border-box;
        width: 100%;
        height: 132mm;
        position: relative;
        background: #fff;
    }

    #formct2general2Modal .inner-data-table {
        width: 100%;
        border-collapse: collapse;
        font-family: "Pyidaungsu", "Segoe UI";
        font-size: 14px;
    }

    #formct2general2Modal .inner-data-table td {
        padding: 4px 3px;
        vertical-align: middle;
    }

    #formct2general2Modal .signature-table {
        width: 100%;
        border-collapse: collapse;
    }

    #formct2general2Modal .signature-table td {
        padding: 3px;
    }

    #formct2general2Modal .under-line2 {
        border-bottom: 1.5px dotted #121212;
        display: inline-block;
        min-width: 100%;
        padding-left: 5px;
    }

    @media print {
        body:has(#formct2general2Modal.show) > *:not(#formct2general2Modal) {
            display: none !important;
        }

        #formct2general2Modal,
        #formct2general2Modal * {
            visibility: visible !important;
        }

        #formct2general2Modal {
            position: static !important;
            background: #fff !important;
        }

        #formct2general2Modal .modal-dialog,
        #formct2general2Modal .modal-content,
        #formct2general2Modal .modal-body {
            position: static !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
            border: none !important;
            box-shadow: none !important;
        }

        #formct2general2Modal .print-container {
            width: 100% !important;
            max-width: 100% !important;
            min-height: 0 !important;
            margin: 0 !important;
            padding: 10mm 10mm 10mm 15mm !important;
            box-shadow: none !important;
            background: #fff !important;
            display: block !important;
        }

        #formct2general2Modal .outer-border-box {
            height: 132mm !important;
            max-height: 132mm !important;
            margin: 0 0 6mm 0 !important;
            border: 1.5px solid #000 !important;
            page-break-inside: avoid !important;
        }

        #formct2general2Modal .no-print,
        #formct2general2Modal .modal-header,
        #formct2general2Modal .modal-footer {
            display: none !important;
        }
    }
</style>

<div class="modal fade" id="formct2general2Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း ထုတ်ယူရန်</h5>
                <button type="button" class="close-modal-btn" onclick="window.location.href='ct2_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>

            <div class="modal-body">
                <div class="print-container">
                    <div class="outer-border-box">
                        <div style="text-align: right; font-size: 14px; font-family: 'Pyidaungsu'; margin-bottom: 5px;">
                            ပတခ(ထွေ)-၂
                        </div>
                        <div style="text-align: center; font-weight: bold; font-size: 18px; font-family: 'Pyidaungsu'; margin-bottom: 20px;">
                            အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                        </div>

                        <table class="inner-data-table">
                            <tr>
                                <td style="width: 35%;">အခွန်ထမ်းအမည်</td>
                                <td style="width: 5%; text-align: center;">-</td>
                                <td style="width: 60%; border-bottom: 1.5px dotted black;"><span id="ct2g2_name"></span></td>
                            </tr>
                            <tr>
                                <td>လုပ်ငန်းအမျိုးအစား</td>
                                <td style="text-align: center;">-</td>
                                <td style="border-bottom: 1.5px dotted black;"><span id="ct2g2_biz"></span></td>
                            </tr>
                            <tr>
                                <td>အခွန်ထမ်းလိပ်စာ</td>
                                <td style="text-align: center;">-</td>
                                <td style="border-bottom: 1.5px dotted black;"><span id="ct2g2_address"></span></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align: center; font-weight: bold; padding: 15px 0; font-size: 14px;">
                                    လက်ခံရရှိပါသည်။
                                </td>
                            </tr>
                            <tr>
                                <td>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">ပတခ(ကသခ)-၀၄-၀၈/ ပတခ(ကသခ)-၀၂-၀၁</span></td>
                            </tr>
                            <tr>
                                <td>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td>အခြားအကြောင်းကြားစာများ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td style="padding-top: 10px;">
                                    <table class="signature-table">
                                        <tr>
                                            <td style="width: 30%; text-align: right; padding-right: 15px;">လက်မှတ်</td>
                                            <td style="width: 70%; border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">အမည်</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">ရက်စွဲ</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>

                    <div class="outer-border-box">
                        <div style="text-align: right; font-size: 14px; font-family: 'Pyidaungsu'; margin-bottom: 5px;">
                            ပတခ(ထွေ)-၂
                        </div>
                        <div style="text-align: center; font-weight: bold; font-size: 18px; font-family: 'Pyidaungsu'; margin-bottom: 20px;">
                            အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                        </div>

                        <table class="inner-data-table">
                            <tr>
                                <td style="width: 35%;">အခွန်ထမ်းအမည်</td>
                                <td style="width: 5%; text-align: center;">-</td>
                                <td style="width: 60%; border-bottom: 1.5px dotted black;"><span id="ct2g2_name2"></span></td>
                            </tr>
                            <tr>
                                <td>လုပ်ငန်းအမျိုးအစား</td>
                                <td style="text-align: center;">-</td>
                                <td style="border-bottom: 1.5px dotted black;"><span id="ct2g2_biz2"></span></td>
                            </tr>
                            <tr>
                                <td>အခွန်ထမ်းလိပ်စာ</td>
                                <td style="text-align: center;">-</td>
                                <td style="border-bottom: 1.5px dotted black;"><span id="ct2g2_address2"></span></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align: center; font-weight: bold; padding: 15px 0; font-size: 14px;">
                                    လက်ခံရရှိပါသည်။
                                </td>
                            </tr>
                            <tr>
                                <td>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">ပတခ(ကသခ)-၀၄-၀၈/ ပတခ(ကသခ)-၀၂-၀၁</span></td>
                            </tr>
                            <tr>
                                <td>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td>အခြားအကြောင်းကြားစာများ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td style="padding-top: 10px;">
                                    <table class="signature-table">
                                        <tr>
                                            <td style="width: 30%; text-align: right; padding-right: 15px;">လက်မှတ်</td>
                                            <td style="width: 70%; border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">အမည်</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">ရက်စွဲ</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="universalPrint('form_ct2_KTK2Modal')">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
function openFormgeneral2CT2() {
    var data = window.selectedRowData;
    if (!data) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    setText('ct2g2_name', data.taxpayer_name);
    setText('ct2g2_biz', data.businessType2);
    setText('ct2g2_address', data.address);
    setText('ct2g2_name2', data.taxpayer_name);
    setText('ct2g2_biz2', data.businessType2);
    setText('ct2g2_address2', data.address);

    var formsModalEl = document.getElementById('formsModal2') || document.getElementById('formsModal');
    if (formsModalEl && window.bootstrap) {
        bootstrap.Modal.getOrCreateInstance(formsModalEl).hide();
    }

    var modalElem = document.getElementById('formct2general2Modal');
    if (modalElem) {
        bootstrap.Modal.getOrCreateInstance(modalElem).show();
    }
}
</script>
