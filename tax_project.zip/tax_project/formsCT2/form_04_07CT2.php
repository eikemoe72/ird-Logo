<style>
    /* မီးခိုးနောက်ခံပေါ်မှာ A4 စာရွက်ဖြူကို ခွဲပြသည် */
    #formCT20407Modal .modal-dialog {
        max-width: 236mm;
        width: 236mm;
        margin: 10px auto;
    }

    #formCT20407Modal .print-container {
        padding: 0;
        box-sizing: border-box;
    }

    #formCT20407Modal #printableSheet_0407,
    #formCT20407Modal #printableSheet_0407 p,
    #formCT20407Modal #printableSheet_0407 div,
    #formCT20407Modal #printableSheet_0407 table,
    #formCT20407Modal #printableSheet_0407 td {
        line-height: 1.7;
    }

    #formCT20407Modal #printableSheet_0407 table.law-box,
    #formCT20407Modal #printableSheet_0407 table.law-box td {
        line-height: 25px;
    }

    #formCT20407Modal .modal-header {
        margin-left: 0 !important;
        width: auto;
        background-color: #0b5ed7;
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 10px 10px;
        border-bottom: none;
    }

    #formCT20407Modal .modal-title {
        color: #fff;
        margin: 0;
    }

    #formCT20407Modal table.law-box,
    #formCT20407Modal table.law-box td {
        border: 1.5px solid #000 !important;
    }
    #formCT20407Modal .modal-content {
        background-color: #c8c8c8;
        background-image: linear-gradient(180deg, #d4d4d4 0%, #bdbdbd 100%);
        border: 1px solid rgba(0,0,0,.28);
        border-radius: 16px;
        outline: 0;
        padding: 0 0 14px;
        box-shadow: 0 10px 24px rgba(0,0,0,.28);
    }

    #formCT20407Modal #printableSheet_0407 {
        width: 210mm;
        min-height: 297mm;
        margin: 10px auto 10px;
        background: #fff;
        box-sizing: border-box;
        padding: 5mm 5mm 5mm 5mm;
        border-radius: 1px;
        box-shadow: 0 1px 0 rgba(255,255,255,.7), 0 8px 18px rgba(0,0,0,.35);
    }
    #formCT20407Modal .print-container {
            padding: 10mm 5mm 10mm 15mm !important;
            border: none !important;
        }

    @media print {
        #formCT20407Modal .modal-footer,
        #formCT20407Modal .no-print,
        #formCT20407Modal .btn,
        #formCT20407Modal .btn-close {
            display: none !important;
        }

        body:has(#formCT20407Modal.show) > *:not(#formCT20407Modal) {
            display: none !important;
        }

        #formCT20407Modal,
        #formCT20407Modal * {
            visibility: visible !important;
        }

        #formCT20407Modal {
            position: static !important;
            left: auto !important;
            top: auto !important;
            width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #fff !important;
        }

        #formCT20407Modal .modal-dialog,
        #formCT20407Modal .modal-content {
            width: 100% !important;
            max-width: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            box-shadow: none !important;
            background: #fff !important;
            background-image: none !important;
        }

        #formCT20407Modal #printableSheet_0407 {
            width: 100% !important;
            min-height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            box-shadow: none !important;
            background: #fff !important;
        }

        #formCT20407Modal .print-container {
            padding: 5mm 5mm 5mm 20mm !important;
            border: none !important;
        }

        #formCT20407Modal #printableSheet_0407,
        #formCT20407Modal #printableSheet_0407 p,
        #formCT20407Modal #printableSheet_0407 div,
        #formCT20407Modal #printableSheet_0407 span,
        #formCT20407Modal #printableSheet_0407 table,
        #formCT20407Modal #printableSheet_0407 td {
            font-size: 15px !important;
            line-height: 1.5 !important;
        }

        #formCT20407Modal #printableSheet_0407 table.law-box,
        #formCT20407Modal #printableSheet_0407 table.law-box td {
            line-height: 27px !important;
        }

        #formCT20407Modal table.law-box,
        #formCT20407Modal table.law-box td {
            border: 1.5px solid #000 !important;
        }
    }

  
</style>
<div class="modal fade" id="formCT20407Modal" tabindex="-1" data-bs-focus="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="modal-title">စည်းကြပ်မှုဆုံးဖြတ်ချက် ပတခ(ကသခ)-၀၄-၀၇ ထုတ်ယူရန်</h5>
                <button type="button" class="close-modal-btn" onclick="window.location.href='ct2_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div id="printableSheet_0407">
                <div class="print-container">
                    <table class="law-box" style="border: 1.5px solid #000; text-align:center; font-size:15px; width:100%; line-height:28px; margin-bottom: 10px;">
                        <tr>
                            <td style='padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>
                                ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px;'>ပတခ(ကသခ)-၀၄-၀၇</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:15px; font-size:15px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေ ပုဒ်မ ၂၇၊ ၂၈၊ ၃၀ နှင့် ၆၄ တို့အရ ကုန်သွယ်လုပ်ငန်းခွန် <br>
                        စည်းကြပ်မှုနှင့် ဒဏ်ကြေးငွေစည်းကြပ်မှု ဆုံးဖြတ်ချက်
                    </div>

                    <table style="width:100%">
                        <tr>
                            <td style="width:85%; text-align:right;"><b>ရက်စွဲ၊</b></td>
                            <td style="width:15%; border-bottom: 1px dotted #000; text-align:center;"><span id="m0407CT2_ct2DemandDate"></span></td>
                        </tr>
                        <tr>
                            <td style="width:85%; text-align:right;"><b>စည်းကြပ်နှစ်၊</b></td>
                            <td style="width:15%; border-bottom: 1px dotted #000; text-align:center;"><span id="m0407CT2_taxYear"></span></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                        <tr>
                            <td style='width:5%;'><b>၁။</b></td>
                            <td style='width:40%;'><b>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</b></td>
                            <td style='width:55%; border-bottom:2px dotted #000;'><span id="m0407CT2_ct2_gir"></span></td>
                        </tr>
                        <tr>
                            <td><b>၂။</b></td>
                            <td><b>အခွန်ထမ်းအမည်နှင့်လိပ်စာ</b></td>
                            <td style='border-bottom:2px dotted #000;'><span id="m0407CT2_name"></span> / <span id="m0407CT2_address"></span></td>
                        </tr>
                        <tr>
                            <td><b>၃။</b></td>
                            <td><b>အခွန်ထမ်းအမျိုးအစား</b></td>
                            <td style='border-bottom:2px dotted #000;'>ပုဂ္ဂလိက</td>
                        </tr>
                        <tr>
                            <td><b>၄။</b></td>
                            <td><b>လုပ်ငန်းအမျိုးအစားနှင့်မှတ်ပုံတင်အမှတ်</b></td>
                            <td style='border-bottom:2px dotted #000;'><span id="m0407CT2_businessType1"></span></td>
                        </tr>
                        <tr>
                            <td><b>၅။</b></td>
                            <td><b>လုပ်ငန်းခွဲများ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b>၆။</b></td>
                            <td><b>(က) ပုဂ္ဂိုလ်စုဝင်များ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b></b></td>
                            <td><b>(ခ) အစုများ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b>၇။</b></td>
                            <td><b>ကြေညာသည့်ရောင်းရငွေ/ဝန်ဆောင်မှုရငွေ </b></td>
                            <td style='border-bottom:2px dotted #000;'>(ကသခ)<span id="m0407CT2_declaredct2"></span></td>
                        </tr>
                        <tr>
                            <td><b>၈။</b></td>
                            <td><b>တင်ပြသောစာရင်းများ</b></td>
                            <td style='border-bottom:2px dotted #000;'></td>
                        </tr>
                        <tr>
                            <td><b>၉။</b></td>
                            <td><b>စည်းကြပ်သည့်ပုဒ်မ</b></td>
                            <td style='border-bottom:2px dotted #000;'>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀၊ ၆၄ </td>
                        </tr>
                        <tr>
                            <td><b>၁၀။</b></td>
                            <td><b>လုပ်ငန်းနှစ်(အခွန်ကာလ)</b></td>
                            <td style='border-bottom:2px dotted #000;'>( ၃၁-၀၃-<span id="m0407CT2_year_start"></span> ) ရက်နေ့တွင် ကုန်ဆုံးသည့်နှစ်</td>
                        </tr>
                    </table>

                    

                    <p style='text-align:center; font-size:15px;'><b>ကုန်သွယ်လုပ်ငန်းခွန်စည်းကြပ်မှုနှင့်ဒဏ်ငွေစည်းကြပ်မှုဆုံးဖြတ်ချက်</b></p>

                    <div style="text-align:justify; line-height:1.7; margin-top:5px;">
                        <span style='padding-left:50px;'>အခွန်ထမ်းသည် နှစ်ချုပ်စာရင်းကို ကုန်သွယ်လုပ်ငန်းခွန်ဥပဒေ ပုဒ်မ(၁၃-က) 
                            နှင့်အညီ အချိန်မီ တင်သွင်းထားပါသည်/ မတင်သွင်းပါ။ ကြိုတင်ခွန်( <span style="color:red;" id="m0407CT2_advanceTax1"></span> )ကျပ်ကို 
                            ပေးသွင်းထားပါသည်။/ မပေးသွင်းထားပါ။ ဝင်ငွေနှင့်ပတ်သက်သော စာရင်းဇယားအထောက်အထားများကို 
                            ခိုင်လုံစွာ တင်ပြထားပါသည်/ မတင်ပြပါ။ တင်သွင်းသော ဝင်ငွေကြေညာလွှာနှင့် နှစ်ချုပ်စာရင်းပါ 
                            အရှုံးအမြတ်စာရင်း၊ ရရှိထားသော သတင်းအချက်အလက် အထောက်အထားများ အခွန်ထမ်း၏ 
                            ထွက်ဆိုတင်ပြချက်၊ စီးပွားရေးလုပ်ငန်း အခြေအနေနှင့် ကွင်းဆင်း စုံစမ်းလေ့လာ တွေ့ရှိရသော 
                            သတင်းအချက်အလက်များကို အခြေခံ၍ ကုန်သွယ်လုပ်ငန်းခွန်ဥပဒေပုဒ်မ ၁၄၊ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု
                            ဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀၊ ၆၄ တို့အရ အောက်ပါအတိုင်း စည်းကြပ်မှုအမိန့်ချမှတ်လိုက်သည်-
                    </div>
                        <table style='width:100%; font-size:15px; margin-top: 10px; height:10px;'>
                            <tr>
                                <td style='width:60%; text-align:right;'>သတ်မှတ်ရောင်းရငွေ</td>
                                <td style='width:5%; text-align:center;'>=</td>
                                <td style='width:20%; border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT2_salesAmount1"></span></td>
                                <td style='width:15%; text-align:right;'></td>
                            </tr>
                            <tr>
                                <td style='text-align:right;'>ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1.5px dotted #000; text-align:right;'><span id="m0407CT2_ct2tax"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_row_hide1">
                                <td style='text-align:right;'>သတ်မှတ်ရောင်းရငွေ(၂)</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT2_salesAmount2"></span></td>
                                <td></td>
                            </tr>

                            <tr id="ct2_row_hide2">
                                <td style='text-align:right;'>ကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်(၂)</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1.5px solid #000; text-align:right;'><span id="m0407CT2_ct2tax"></span></td>
                                <td></td>
                            </tr>
                            <tr id="ct2_row_hide3">
                                <td style='text-align:right;'>စုစုပေါင်းကျသင့်ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT2_minusCTInput"></span></td>
                                <td></td>
                            </tr>
                            <tr id="ct2_orig_row1">
                                <td style='text-align:right;'>စည်းမျဉ်း ၄၂ အရ ခုနှိမ်သောအခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:red;'><span id="m0407CT2_rule42_1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_orig_row2">
                                <td style='text-align:right;'>ပေးဆောင်ရမည့် ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1.5px dotted #000; text-align:right;'><span id="m0407CT2_afterRuler1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_orig_row3">
                                <td style='text-align:right;'>(နုတ်) ကြိုတင်ခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1.5px solid #000; text-align:right; color:red;'><span id="m0407CT2_advanceTax11"></span></td>
                                <td style='text-align:right;'></td> 
                            </tr>
                            <tr id="ct2_orig_row4">
                                <td style='text-align:right;'>ထပ်မံပေးဆောင်ရန်အခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT2_netTax1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_orig_row5">
                                <td style='text-align:right;'>ပုဒ်မ-၂၁(က)၊(ခ)၊(ဂ)၊(ဃ)၊(င)၊(စ)တို့အရ ဒဏ်ငွေ</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1.5px solid #000; text-align:right; color:blue;'><span id="m0407CT2_penalty1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_orig_row6">
                                <td style='text-align:right;'>စုစုပေါင်းပေးဆောင်ရန်အခွန်နှင့်ဒဏ်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right;'><span id="m0407CT2_totalTax1"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>



                            <tr id="ct2_total_row1">
                                <td style='text-align:right;'>စည်းမျဉ်း ၄၂ အရ ခုနှိမ်သောအခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:red;'><span id="m0407CT2_rule42_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_total_row2">
                                <td style='text-align:right;'>ပေးဆောင်ရမည့် ကုန်သွယ်လုပ်ငန်းခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT2_afterRuler_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_total_row3">
                                <td style='text-align:right;'>(နုတ်) ကြိုတင်ခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:red;'><span id="m0407CT2_advanceTax_total"></span></td>
                                <td style='text-align:right;'></td> 
                            </tr>
                            <tr id="ct2_total_row4">
                                <td style='text-align:right;'>ထပ်မံပေးဆောင်ရန်အခွန်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px dotted #000; text-align:right;'><span id="m0407CT2_netTax_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_total_row5">
                                <td style='text-align:right;'>ပုဒ်မ-၂၁(က)၊(ခ)၊(ဂ)၊(ဃ)၊(င)၊(စ)တို့အရ ဒဏ်ငွေ</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right; color:blue;'><span id="m0407CT2_penalty_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                            <tr id="ct2_total_row6">
                                <td style='text-align:right;'>စုစုပေါင်းပေးဆောင်ရန်အခွန်နှင့်ဒဏ်</td>
                                <td style='text-align:center;'>=</td>
                                <td style='border-bottom:1px solid #000; text-align:right;'><span id="m0407CT2_Taxpenalty_total"></span></td>
                                <td style='text-align:right;'></td>
                            </tr>
                        </table>
                        <br><br><br><br>
                        <table style='width:100%; margin-top:40px;'>
                            <tr>
                                <td style='width:50%; padding-left:50px; vertical-align:top;'>ရုံးတံဆိပ်</td>
                                <td style='text-align:center;'>
                                    တာဝန်ခံအရာရှိ<br>
                                    <span id="m0407CT2_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး
                                </td>
                            </tr>
                        </table>

            
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="universalPrint('formCT20407Modal')">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>

// ၁။ Print ထုတ်ရန် သီးသန့် Function (ဒါကို အပြင်မှာ သီးသန့် ထားရပါမယ်)
function universalPrint(modalId) {
    // ခေတ္တ hide လုပ်မယ့်အစား တိုက်ရိုက် print ထုတ်ကြည့်ပါ
    // အပေါ်က CSS logic က အလုပ်လုပ်ရင် hide လုပ်စရာ မလိုတော့ပါဘူး
    window.print();
}

function openFormCT2_0407() {
    console.log("၀၄-၀၇ CT2 ဒေတာချိတ်ဆက်မှု စတင်ပါပြီ");

    var data = window.selectedRowData;
    if (!data) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ");
        return;
    }

    const modalRoot = document.getElementById('formCT20407Modal');

    const toMyanmarDigit = (num) => {
        if (num === null || num === undefined || num === '') return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        if (!modalRoot) return;
        modalRoot.querySelectorAll('[id="' + id + '"]').forEach(el => {
            el.innerText = val || '';
        });
    };

    const showEl = (id) => {
        const el = modalRoot ? modalRoot.querySelector('#' + id) : null;
        if (!el) return;
        el.style.display = el.tagName === 'TR' ? 'table-row' : '';
    };
    const hideEl = (id) => {
        const el = modalRoot ? modalRoot.querySelector('#' + id) : null;
        if (el) el.style.display = 'none';
    };
//ရက် လ နစ် ပြင်ဆင်ခြင်း
    let demandDateText = '';
    if (data.ct2DemandDate && data.ct2DemandDate !== '0000-00-00' && String(data.ct2DemandDate).includes('-')) {
        const dParts = String(data.ct2DemandDate).split(' ')[0].split('-');
        if (dParts.length === 3) {
            demandDateText = toMyanmarDigit(dParts[2]) + '-' + toMyanmarDigit(dParts[1]) + '-' + toMyanmarDigit(dParts[0]);
        }
    }
    setText('m0407CT2_ct2DemandDate', demandDateText);
    setText('m0407CT2_taxYear', toMyanmarDigit(data.taxYear));
    setText('m0407CT2_name', data.taxpayer_name);
    setText('m0407CT2_businessType1', data.businessType2);
    setText('m0407CT2_address', data.address);
    setText('m0407CT2_declaredct2', toMyanmarDigit(data.declaredCT2));

    setText('m0407CT2_salesAmount1', toMyanmarDigit(data.salesAmount2));
    setText('m0407CT2_ct2tax', toMyanmarDigit(data.ct2tax));
    setText('m0407CT2_rule42_1', toMyanmarDigit(data.rule42_2));
    setText('m0407CT2_afterRuler1', toMyanmarDigit(data.afterRuler2));
    setText('m0407CT2_advanceTax1', toMyanmarDigit(data.advanceTax2) || '၀');
    setText('m0407CT2_advanceTax11', toMyanmarDigit(data.advanceTax2));
    setText('m0407CT2_netTax1', toMyanmarDigit(data.netTax2));
    setText('m0407CT2_penalty1', toMyanmarDigit(data.penalty2));
    setText('m0407CT2_totalTax1', toMyanmarDigit(data.totalTax2));
    setText('m0407CT2_totalTax11', toMyanmarDigit(data.totalTax2));
    setText('m0407CT2_ct2_gir', (data.ct2_select_real || 'ကသ') + " / " + (data.ct2_no_real || ''));


    // လုပ်ငန်းနှစ် (Start Year နှင့် End Year) ခွဲထုတ်ခြင်း
    if (data.taxYear) {
        let yearParts = data.taxYear.split("-"); // "2025-2026"
        let startYear = yearParts[0] ? toMyanmarDigit(yearParts[0]) : "";
        setText('m0407CT2_year_start', startYear);
    }

    // ၁၄ ရက်ပေါင်းခြင်း logic
    if (data.ct2DemandDate && data.ct2DemandDate !== '0000-00-00') {
        let dateObj = new Date(data.ct2DemandDate);
        if (!isNaN(dateObj.getTime())) {
            dateObj.setDate(dateObj.getDate() + 14); // ၁၄ ရက်ပေါင်း
            
            let dd = toMyanmarDigit(String(dateObj.getDate()).padStart(2, '0'));
            let mm = toMyanmarDigit(String(dateObj.getDate()).padStart(2, '0')); // လ အမှန်ရရန်getMonth + 1 လုပ်ရမည်
            let myMonth = toMyanmarDigit(String(dateObj.getMonth() + 1).padStart(2, '0'));
            let yyyy = toMyanmarDigit(dateObj.getFullYear());
            
            setText('m0407CT2_rq_date1', dd + "-" + myMonth + "-" + yyyy);
            setText('m0407CT2_rq_date11', dd + "-" + myMonth + "-" + yyyy);
        }
    }

    setText('m0407CT2_township', data.township_name);

    ['ct2_row_hide1', 'ct2_row_hide2', 'ct2_row_hide3',
     'ct2_total_row1', 'ct2_total_row2', 'ct2_total_row3', 'ct2_total_row4', 'ct2_total_row5', 'ct2_total_row6', 'ct2_total_row7'
    ].forEach(hideEl);
    ['ct2_orig_row1', 'ct2_orig_row2', 'ct2_orig_row3', 'ct2_orig_row4', 'ct2_orig_row5', 'ct2_orig_row6', 'ct2_orig_row7'
    ].forEach(showEl);

    var formsModalEl = document.getElementById('formsModal2') || document.getElementById('formsModal');
    if (formsModalEl && window.bootstrap) {
        bootstrap.Modal.getOrCreateInstance(formsModalEl).hide();
    }

    if (modalRoot) {
        bootstrap.Modal.getOrCreateInstance(modalRoot).show();
    }

       
}
</script>