<?php
// ၁။ Session စတင်ခြင်း
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ DB Config ချိတ်ဆက်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}



// ၃။ Session ထဲက User ID ကိုယူပြီး user_register မှ other (စာအမှတ်အတွက်) ဆွဲထုတ်ခြင်း
$u_id = $_SESSION['user_id'] ?? 0;
$user_other_info = ""; 

if ($u_id > 0) {
    $user_query = "SELECT other FROM user_register WHERE id = '$u_id'";
    $user_result = mysqli_query($conn, $user_query);
    if ($user_result && $user_row = mysqli_fetch_assoc($user_result)) {
        $user_other_info = str_replace(array("\r", "\n", "'", '"'), '', $user_row['other']);
    }
}

// ၄။ URL မှ ပါလာသော ID ဖြင့် မော်တော်ယာဉ်ဒေတာ ဆွဲထုတ်ခြင်း
$vehicle_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$v_data = [];

if ($vehicle_id > 0) {
    $v_query = "SELECT * FROM regular_data WHERE id = '$vehicle_id'";
    $v_result = mysqli_query($conn, $v_query);
    if ($v_result && mysqli_num_rows($v_result) > 0) {
        $v_data = mysqli_fetch_assoc($v_result);
    }
}

// ဂဏန်းများကို မြန်မာလိုပြောင်းပေးမည့် Function (CT1 ပုံစံမှာ ရှိပြီးသားဖြစ်ရင် ထပ်မကြေညာပါ)
if (!function_exists('toMyanmarNumber')) {
    function toMyanmarNumber($num) {
        if (empty($num)) return '';
        $en = array('0','1','2','3','4','5','6','7','8','9');
        $mm = array('၀','၁','၂','၃','၄','၅','၆','၇','၈','၉');
        return str_replace($en, $mm, $num);
    }
}

// 🎯 ၅။ notify_date ကို ခုနှစ်၊ လ၊ ရက် ခွဲထုတ်ခြင်းစနစ်
$or_year = '....'; 
$or_year_short = '..'; 
$or_month = '..........'; 
$or_day = '....';

// ဒေတာဘေ့စ်ထဲရှိ notify_date အား စစ်ဆေးခြင်း
$target_date = $v_data['orderDate'] ?? ''; 

if (!empty($target_date) && $target_date != '0000-00-00') {
    $date_parts = explode('-', explode(' ', $target_date)[0]);
    if (count($date_parts) == 3) {
        $full_year = $date_parts[0]; // ဥပမာ - 2026
        $or_year = toMyanmarNumber($full_year);
        $or_year_short = toMyanmarNumber(substr($full_year, -2)); // နောက်ဆုံး ၂ လုံး (ဥပမာ - ၂၆)
        
        $mm_months = array('', 'ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ');
        $or_month = $mm_months[intval($date_parts[1])];
        $or_day = toMyanmarNumber(intval($date_parts[2])); // သုညဆွဲဖြုတ်ပြီး မြန်မာမှုပြုခြင်း
    }
}

// ၂။ URL ကနေ id ကို လှမ်းယူခြင်း
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$taxpayer_name = "";
$business_type = "";
$address = "";
$township_name = "";
$appointmentDate = "";
$taxYear= "";

if ($id > 0) {
    // 🎯 ၃။ ဇယားအမည်ကို 'taxpayers_table' အစား 'sakalakahdata' သို့ ပြောင်းလဲထားပါသည်
    $sql = "SELECT taxpayer_name, businessType2, township_name, appointmentDate, taxYear, address FROM regular_data WHERE id = $id";
    $result = $conn->query($sql);
    
    if ($result && $row = $result->fetch_assoc()) {
        $taxpayer_name = $row['taxpayer_name'];
        $business_type = $row['businessType2'];
        $address = $row['address'];
        $township_name = $row['township_name'];
        $taxYear = $row['taxYear'];
        $appointmentDate = $row['appointmentDate'];
        // AppointmentDate ကို 05-08-2026 ပုံစံပြောင်းခြင်း
        $formatted_date = "........"; // Data မရှိရင်ပေါ်မယ့်ဟာ
        if (!empty($appointmentDate) && $appointmentDate != '0000-00-00') {
            // DD-MM-YYYY ပုံစံပြောင်း
            $date_in_english = date('d-m-Y', strtotime($appointmentDate));
            
            // မြန်မာဂဏန်းလိုချင်ရင် ဒီအတိုင်းထားပါ
            $formatted_date = toMyanmarNumber($date_in_english); 
            
            // တကယ်လို့ မြန်မာဂဏန်းမလိုဘဲ အင်္ဂလိပ်ဂဏန်းပဲ လိုချင်ရင်တော့ 
            // $formatted_date = $date_in_english; ကိုသုံးပေးပါဗျ။
        }
        
    }
}
?>
<style>
    /* စာတမ်းတစ်ခုလုံးကို ဘယ်မှ ညာသို့ တွန်းသည်။ ID ပါမှ နောက်ပိုင်း .print-container စည်းမျဉ်းက ပြန်မဖျက်ပါ */
    #form0405CT2Modal .print-container {
        padding-left: 16mm !important;
        box-sizing: border-box;
    }

    /* အပြာရောင်နောက်ခံဘားကို အောက်က စာတမ်းဘယ်ဘက်အစနှင့် တပြေးညီ */
    #form0405CT2Modal .modal-header {
        margin-left: 16mm !important;
        width: auto;
    }

    /* ပုံနှိပ်ချိန်တွင် ဤစာတမ်းတစ်မျက်နှာတည်း။ စာရင်းစာမျက်နှာက နေရာယူပြီး အလွတ်စာမျက်နှာ မထွက်စေရန်။ */
    @media print {
        @page {
            size: A4 portrait;
            margin: 8mm 5mm 8mm 5mm;
        }

        body:has(#form0405CT2Modal.show) > *:not(#form0405CT2Modal) {
            display: none !important;
        }

        body:has(#form0405CT2Modal.show) {
            margin: 0 !important;
            padding: 0 !important;
            height: auto !important;
            background: #fff !important;
        }

        #form0405CT2Modal,
        #form0405CT2Modal * {
            visibility: visible !important;
        }

        #form0405CT2Modal {
            display: block !important;
            position: static !important;
            left: auto !important;
            top: auto !important;
            width: 100% !important;
            height: auto !important;
            min-height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            overflow: visible !important;
            background: #fff !important;
        }

        #form0405CT2Modal .modal-dialog,
        #form0405CT2Modal .modal-content,
        #form0405CT2Modal #printableSheet {
            position: static !important;
            display: block !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            max-height: none !important;
            min-height: 0 !important;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            box-shadow: none !important;
            overflow: visible !important;
            transform: none !important;
            background: #fff !important;
            background-image: none !important;
        }

        #form0405CT2Modal .modal-header,
        #form0405CT2Modal .modal-footer,
        #form0405CT2Modal .no-print,
        #form0405CT2Modal .btn,
        #form0405CT2Modal .btn-close {
            display: none !important;
        }

        #form0405CT2Modal .print-container {
            width: 100% !important;
            max-width: 100% !important;
            min-height: 0 !important;
            height: auto !important;
            margin: 0 !important;
            padding: 7mm 7mm 10mm 20mm !important;
            border: none !important;
            box-shadow: none !important;
            overflow: visible !important;
            page-break-after: avoid !important;
            break-after: avoid !important;
        }
    }
    /* Modal ထဲတွင် စာသားများ ထပ်မနေစေရန် */
    #form0405CT2Modal .modal-content {
        background-color: #fff;
        border: 2px solid rgba(0,0,0,.2);
        border-radius: .3rem;
        outline: 0;
        padding: 30px;
    }
</style>

<div class="modal fade" id="form0405CT2Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content"> 
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 12px; border-bottom: none;">
                <h5 class="modal-title">၀၄-၀၅ ကြားနာစစ်ဆေးရန်အကြောင်းကြားစာ ထုတ်ယူရန်</h5>
                <button type="button" class="close-modal-btn" onclick="window.location.href='CT1_Demand_List.php';" style="background: none; border: none; color: #ff4d4d; font-size: 40px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                </button>
            </div>
            <div id="printableSheet">
                <div class="print-container">
                    <table style="border: 1.5px solid rgba(0,0,0,.2)  !important; text-align:center; font-size:15px; width:100%; line-height:25px; margin-bottom: 10px;">
                        <tr>
                            <td style='padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>
                                ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px;'>ပတခ(ကသခ)-၀၄-၀၅</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:20px; font-size:17px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၆၊ ပုဒ်မခွဲ(က)၊ ပုဒ်မခွဲငယ်(၂)အရ<br>
                        စာရင်းအထောက်အထားများတင်ပြစေရန် သို့မဟုတ် ကြားနာစစ်ဆေးရန် အကြောင်းကြားစာ
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 10px;'>
                        <tr>
                            <td style='text-align:right; width:60%'>
                                စာအမှတ်၊ ပတခ/<?php echo htmlspecialchars($user_other_info ?: '......'); ?>/ဝငခ/၂၀<span id="orDateCT2_year_short"></span>(&emsp;&emsp;&emsp;)
                            </td>
                        </tr>
                        <tr>
                            <td style='text-align:right;'>
                                ရက်&emsp;စွဲ၊ <strong><span id="orDateCT2_year"></span> ခုနှစ်၊ 
                                <span id="orDateCT2_month"></span> လ၊ 
                                &emsp;<span id="orDateCT2_day"></span> ရက်</strong>
                            </td>
                        </tr>
                    </table>

                    <div style="text-align:left; margin-bottom:15px;">
                        သို့<br>
                        <div style="padding-left:70px;">
                            <span id="m0405CT2_name" style="border-bottom:2px dotted #000; display:inline-block; min-width:300px;"></span><br>
                            <span id="m0405CT2_address" style="border-bottom:2px dotted #000; display:inline-block; min-width:300px;"></span><br>
                            <span id="m0405CT2_biz" style="border-bottom:2px dotted #000; display:inline-block; min-width:300px;"></span>
                        </div>
                    </div>

                    <div style="text-align:justify; line-height:1.6;">
                        ၁။<span style = 'padding-left:50px;'>လူကြီးမင်း၏ <strong><span id="m0405CT2_biz_name"></span></strong> လုပ်ငန်းအပေါ် ( <strong><span id="m0405CT2_year"></span></strong> ) 
                        ဘဏ္ဍာရေးနှစ်အတွက် ကုန်သွယ်လုပ်ငန်းခွန် စည်းကြပ်ရန် အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၂ နှင့်အညီ 
                        ကုန်သွယ်လုပ်ငန်းခွန်ဥပဒေပုဒ်မ ၁၃ တို့အရ ပေးပို့ထားသော နှစ်ချုပ်ကြေညာလွှာကို မှန်/မမှတ် စိစစ်ရန် လိုအပ်ပါသဖြင့် 
                        လူကြီးမင်းကိုယ်တိုင်ဖြစ်စေ သို့မဟုတ် စာဖြင့်တာဝန်လွှဲအပ်ထားသည့် ကိုယ်စားလှယ်ဖြစ်စေ ( <strong><span id="m0405CT2_appDate"></span></strong> ) ရက်နေ့၊
                        ( ၁၀:၀၀ ) နာရီအချိန်တွင် ဤရုံးသို့ လာရောက်၍ အထောက်အထားများ၊ စာရင်းစာအုပ်၊ စာရွက်စာတမ်းများကိုတင်ပြရန် အကြောင်းကြားပါသည်။
                    </div>

                    <div style="margin-top:15px; text-align:justify; line-height:1.6;">
                        ၂။<span style = 'padding-left:50px;'>ဤအကြောင်းကြားစာအတိုင်း လိုက်နာရန်ပျက်ကွက်ပါက 
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊ ပုဒ်မခွဲ(ဂ)အရ ရနိုင်သမျှအထောက်အထားများကို အခြေပြု၍ အခွန်စည်းကြပ်ခြင်း၊ 
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၇၀ နှင့် ၇၃ တို့အရ ဒဏ်ငွေတပ်ရိုက်ခြင်းနှင့် ပုဒ်မ ၇၈ အရ အရေးယူခြင်းတို့ကို ခံရဖွယ်ရှိကြောင်း အသိပေးအပ်ပါသည်။
                    </div>
                    
                    <div style="text-align:center; margin-top:20px; font-weight:bold;">
                        ပေးပို့ရန် သတင်းအချက်အလက်အထောက်အထား စာရွက်စာတမ်းများ
                    </div>

                    <div style="margin-left:70px; margin-top:10px; line-height:2;">
                        (က) မှတ်ပုံတင်မိတ္တူ <br>
                        ( ခ ) အိမ်ထောင်စုဇယားမိတ္တူ <br>
                        ( ဂ ) လုပ်ငန်းလိုင်စင်မိတ္တူ <br>
                        (ဃ) ........................................ <br>
                        ( င ) ........................................ 
                    </div>
                    <br>
                    <table style='width:100%; margin-top:40px;'>
                        <tr>
                            <td style='width:50%; padding-left:60px; vertical-align:top;'><br>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br>
                                ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                <span id="m0405CT2_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="universalPrint('form0405CT2Modal')">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
function openForm0405CT2() {
    console.log("ခေါ်ဆိုမှု စတင်ပါပြီ");

    // ၁။ Global Variable ကို ရှာခြင်း
    var data = window.selectedRowData;

    if (!data) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
        return;
    }

    // ၂။ Helper Functions (တစ်ကြိမ်စီပဲ ကြေညာပါ)
    const toMyanmarDigit = (num) => {
        if (num === null || num === undefined || num === "") return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    // ၃။ Tax Year ကို တစ်နှစ်လျှော့သည့် Logic
    let rawYear = data.taxYear || "";
    let reducedYear = rawYear.replace(/\d+/g, (match) => {
        return parseInt(match) - 1;
    });

    // ၄။ အခြေခံ အချက်အလက်များ ထည့်ခြင်း
    setText('m0405CT2_name', data.taxpayer_name);
    setText('m0405CT2_address', data.address);
    setText('m0405CT2_biz', data.businessType2);
    setText('m0405CT2_township', data.township_name);
    setText('m0405CT2_year', toMyanmarDigit(reducedYear));
    setText('m0405CT2_biz_name', data.businessType2);

    // ၅။ Order Date (အပေါ်ပိုင်း ရက်စွဲအတွက်)
    let oDate = data.orderDate || "";
    if (oDate && oDate.includes('-')) {
        const oParts = oDate.split('-');
        const oY = oParts[0];
        const oM = oParts[1];
        const oD = oParts[2].split(' ')[0];
        const mmMonths = ['ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ'];
        
        setText('orDateCT2_year', toMyanmarDigit(oY));
        setText('orDateCT2_month', mmMonths[parseInt(oM) - 1]);
        setText('orDateCT2_day', toMyanmarDigit(oD));
        setText('orDateCT2_year_short', toMyanmarDigit(oY.toString().slice(-2)));
    }

    // ၆။ Appointment Date (စာပိုဒ်ထဲက ရက်စွဲအတွက်)
    let appDate = data.appointmentDate || "";
    if (appDate && appDate.includes('-')) {
        const aParts = appDate.split('-');
        const aY = aParts[0]; 
        const aM = aParts[1];   
        const aD = aParts[2].split(' ')[0];
        const formattedAppDate = `${toMyanmarDigit(aD)}-${toMyanmarDigit(aM)}-${toMyanmarDigit(aY)}`;
        setText('m0405CT2_appDate', formattedAppDate);
    }

    var formsModalEl = document.getElementById('formsModal2') || document.getElementById('formsModal');
    if (formsModalEl && window.bootstrap) {
        var formsInstance = bootstrap.Modal.getOrCreateInstance(formsModalEl);
        formsInstance.hide();
    }

    // ၇။ Modal ကို ဖွင့်ခြင်း
    const modalElem = document.getElementById('form0405CT2Modal');
    if (modalElem) {
        var myModal = bootstrap.Modal.getOrCreateInstance(modalElem);
        myModal.show();
    } else {
        console.error("Modal ID 'form0405CT2Modal' ကို ရှာမတွေ့ပါ");
    }
}
</script>