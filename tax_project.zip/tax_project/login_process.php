<?php
session_start();
include 'db_config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_name = $_POST['username']; 
    $password = $_POST['password'];

    if (isset($conn)) {
        $sql = "SELECT id, user_name, password, role FROM user_register WHERE user_name = ?";
        $stmt = $conn->query_provider = $conn->prepare($sql);
        $stmt->bind_param("s", $user_name);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if (password_verify($password, $user['password']) || $password == $user['password']) {
                
                // --- အရေးကြီးဆုံး ပြင်ဆင်ချက် ---
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['user_name']; // Dashboard က စစ်တဲ့ နာမည်နဲ့ တူရပါမယ်
                $_SESSION['user_role'] = $user['role'];      // Role စစ်တဲ့နေရာအတွက်ပါ
                
                header("Location: dashboard.php");
                exit();
            } else {
                echo "Password မှားယွင်းနေပါသည်။";
            }
        } else {
            echo "အသုံးပြုသူအမည် မရှိပါ။";
        }
    } else {
        die("Database ချိတ်ဆက်မှု မရှိပါ။");
    }
}
?>
