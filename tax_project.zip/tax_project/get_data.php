<?php
header('Content-Type: application/json');
include 'db_config.php'; 

if (isset($_GET['id'])) {
    // mysqli_real_escape_string လို့ ပြင်ထားပါတယ်
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    
    // table နာမည် regular_data ကို သင့် table နာမည်အမှန်ဖြင့် လိုအပ်ပါက ပြောင်းလဲပါ
    $sql = "SELECT * FROM regular_data WHERE id = '$id'";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        echo json_encode($row);
    } else {
        // ဒေတာ ရှာမတွေ့ပါက စစ်ဆေးရန် error message
        echo json_encode(['error' => 'Data not found for ID: ' . $id]);
    }
} else {
    echo json_encode(['error' => 'No ID provided']);
}
?>