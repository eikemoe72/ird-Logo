<?php
session_start();
session_unset(); // Session variable အားလုံးကို ရှင်းလင်းမည်
session_destroy(); // Session ကို ဖျက်သိမ်းမည်

// Login Page သို့ ပြန်ပို့မည်
header("Location: login.php");
exit();
?>