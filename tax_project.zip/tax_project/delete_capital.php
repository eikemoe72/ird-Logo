<?php
include 'db_config.php';

// 🎯 URL မှတစ်ဆင့် ပေးပို့လိုက်သော id (သို့မဟုတ် edit_id) ကို လက်ခံခြင်း
if (isset($_GET['edit_id']) && !empty($_GET['edit_id'])) {
    $id = intval($_GET['edit_id']);
} elseif (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = intval($_GET['id']);
} else {
    $id = null;
}

if ($id !== null && $id > 0) {
    // 🎯 မူရင်း 'sakalakahdata' Table ထဲကနေ ကွက်တိ ရှာဖျက်ခြင်း
    // (အကယ်၍ Table ရဲ့ Column နာမည်က edit_id ဖြစ်နေလျှင် 'WHERE edit_id = $id' ဟု ပြောင်းပေးပါ)
    $sql = "DELETE FROM sakalakahdata WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('အောင်မြင်စွာ ဖျက်သိမ်းပြီးပါပြီ');
                window.location.href = 'capital_demand_list.php';
              </script>";
    } else {
        echo "ဖျက်သိမ်းရာတွင် အမှားအယွင်းရှိခဲ့ပါသည်: " . $conn->error;
    }
} else {
    echo "<script>
            alert('ID ရှာမတွေ့ပါ သို့မဟုတ် မှားယွင်းနေပါသည်');
            window.location.href = 'capital_demand_list.php';
          </script>";
}

$conn->close();
?>