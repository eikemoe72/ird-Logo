<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include_once 'db_config.php';

function u48h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function u48_money($value) {
    $clean = str_replace(',', '', (string)$value);
    if ($clean === '' || !is_numeric($clean)) {
        return '0';
    }
    return number_format((float)$clean, 0, '.', ',');
}

function u48_date($value) {
    $value = trim((string)$value);
    if ($value === '' || $value === '0000-00-00') {
        return '-';
    }
    $time = strtotime($value);
    return $time ? date('d-m-Y', $time) : u48h($value);
}

function u48_nrc($row, $prefix = '') {
    $state = ltrim((string)($row['StateCode' . $prefix] ?? ''), '0');
    $letter = (string)($row['InitialCode' . $prefix] ?? '');
    $type = (string)($row['NRC' . $prefix] ?? '');
    $number = (string)($row['NRCNo' . $prefix] ?? '');
    $text = '';
    if ($state !== '') {
        $text .= $state . '/';
    }
    $text .= $letter . $type . $number;
    return $text !== '' ? $text : '-';
}

function u48_issue_month($row) {
    $no = trim((string)($row['IssueNo'] ?? ''));
    $year = trim((string)($row['IssueYear'] ?? ''));
    if ($no !== '' && $year !== '' && strpos($no, '/') === false) {
        return $no . '/' . $year;
    }
    if ($no !== '') {
        return $no;
    }
    return trim((string)($row['TotalMonth'] ?? ''));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = (int)$_POST['delete_id'];
    if ($delete_id > 0) {
        $stmt = $conn->prepare('DELETE FROM under48data WHERE id = ?');
        $stmt->bind_param('i', $delete_id);
        $stmt->execute();
        $stmt->close();
    }
    $back = 'Under48_Demand_List.php';
    $query = $_GET;
    if ($query) {
        $back .= '?' . http_build_query($query);
    }
    header('Location: ' . $back);
    exit;
}

$user_township = trim((string)($_SESSION['township_name'] ?? ''));
$user_state = trim((string)($_SESSION['state_name'] ?? ''));
$search = trim((string)($_GET['search'] ?? ''));
$from_num = isset($_GET['from_num']) ? (int)$_GET['from_num'] : 0;
$to_num = isset($_GET['to_num']) ? (int)$_GET['to_num'] : 0;

$where = [];
$types = '';
$params = [];

if ($user_township !== '' && $user_township !== '-') {
    $where[] = '(LoginTownship = ? OR TownshipName = ?)';
    $types .= 'ss';
    $params[] = $user_township;
    $params[] = $user_township;
}
if ($search !== '') {
    $like = '%' . $search . '%';
    $where[] = '(`No` LIKE ? OR AssesseName LIKE ? OR NRCNo LIKE ? OR CompanyName LIKE ? OR TIN_GIR_No LIKE ? OR OfficeName LIKE ?)';
    $types .= 'ssssss';
    array_push($params, $like, $like, $like, $like, $like, $like);
}
if ($from_num > 0) {
    $where[] = 'CAST(`No` AS UNSIGNED) >= ?';
    $types .= 'i';
    $params[] = $from_num;
}
if ($to_num > 0) {
    $where[] = 'CAST(`No` AS UNSIGNED) <= ?';
    $types .= 'i';
    $params[] = $to_num;
}

$where_sql = $where ? ' WHERE ' . implode(' AND ', $where) : '';

function u48_query($conn, $sql, $types, $params) {
    $stmt = $conn->prepare($sql);
    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }
    $stmt->execute();
    return $stmt->get_result();
}

$sum_sql = "SELECT COUNT(*) AS total_cases,
            COALESCE(SUM(CAST(REPLACE(TotalSalary, ',', '') AS DECIMAL(18,0))), 0) AS total_salary,
            SUM(CASE WHEN IssueNo IS NOT NULL AND IssueNo <> '' THEN 1 ELSE 0 END) AS issued_cases
            FROM under48data" . $where_sql;
$sum = u48_query($conn, $sum_sql, $types, $params)->fetch_assoc();
$total_cases = (int)($sum['total_cases'] ?? 0);
$total_salary = (float)($sum['total_salary'] ?? 0);
$issued_cases = (int)($sum['issued_cases'] ?? 0);

$limit = 16;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($page - 1) * $limit;
$total_pages = max(1, (int)ceil($total_cases / $limit));
if ($page > $total_pages) {
    $page = $total_pages;
    $offset = ($page - 1) * $limit;
}

$list_sql = 'SELECT * FROM under48data' . $where_sql . ' ORDER BY id DESC LIMIT ? OFFSET ?';
$list_types = $types . 'ii';
$list_params = $params;
$list_params[] = $limit;
$list_params[] = $offset;
$result = u48_query($conn, $list_sql, $list_types, $list_params);

$query_string = $_GET;
unset($query_string['page']);
$keep_filters = http_build_query($query_string);
$keep_filters = $keep_filters ? '&' . $keep_filters : '';
$office_label = $user_township !== '' ? $user_township : ($user_state !== '' ? $user_state : '');
?>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ပုဒ်မ ၂၂ လစာဝင်ငွေ မှတ်တမ်း</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #f8f9fa; font-family: "Pyidaungsu", "Myanmar Text", sans-serif; font-size: 14px; }
        .header-bar { background: #0b5ed7; color: #fff; padding: 10px 20px; font-weight: bold; font-size: 18px; display: flex; justify-content: space-between; align-items: center; gap: 12px; }
        .summary-badge { font-size: 15px; font-weight: bold; padding: 8px 12px; border-radius: 10px; color: #fff; min-width: 180px; }
        .bg-demand { background: #1e45a9; }
        .bg-paid { background: #198754; }
        .bg-remain { background: #b02a37; }
        .case-count-text { font-size: 13px; background: rgba(255,255,255,.25); padding: 2px 10px; border-radius: 20px; margin-left: 6px; }
        .table-responsive { background: #fff; padding: 15px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,.05); margin-top: 15px; overflow-x: auto; }
        .table-custom-header th { background: #fad157 !important; color: #000; text-align: center; vertical-align: middle; white-space: nowrap; }
        .table td { vertical-align: middle; white-space: nowrap; }
        .address-col { max-width: 220px; overflow: hidden; text-overflow: ellipsis; }
        .sticky-action-col { position: sticky; right: 0; background: #eff3af; z-index: 5; min-width: 150px; }
        th.sticky-action-col { background: #ffd966; z-index: 6; }
        .table-hover tbody tr:hover td.sticky-action-col { background: #5f5fda; }
    </style>
</head>
<body>
    <div class="header-bar">
        <div>ပုဒ်မ ၂၂ လစာဝင်ငွေ ထုတ်ပေးမှုမှတ်တမ်း</div>
        <div>Under 48</div>
        <div style="font-size: 15px;"><i class="fa-solid fa-location-dot"></i> <?php echo u48h($office_label); ?>အခွန်ဦးစီးဌာနမှူးရုံး</div>
    </div>

    <div class="container-fluid mt-3">
        <div class="row g-3 mb-3">
            <div class="col-md-4">
                <div class="summary-badge bg-demand w-100 d-flex justify-content-between align-items-center">
                    <div>မှတ်တမ်း <span class="case-count-text">( <?php echo number_format($total_cases); ?> ) စောင်</span></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="summary-badge bg-paid w-100 d-flex justify-content-between align-items-center">
                    <div>ထုတ်ပေးပြီး <span class="case-count-text">( <?php echo number_format($issued_cases); ?> ) စောင်</span></div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="summary-badge bg-remain w-100 d-flex justify-content-between align-items-center">
                    <span>လစာစုစုပေါင်း</span>
                    <span><?php echo number_format($total_salary); ?></span>
                </div>
            </div>
        </div>

        <div class="card p-3 shadow-sm mb-2">
            <form method="get" action="Under48_Demand_List.php" class="row g-2 align-items-center">
                <div class="col-md-1"><input type="number" name="from_num" class="form-control form-control-sm" value="<?php echo $from_num > 0 ? $from_num : ''; ?>" placeholder="မှ"></div>
                <div class="col-md-1"><input type="number" name="to_num" class="form-control form-control-sm" value="<?php echo $to_num > 0 ? $to_num : ''; ?>" placeholder="ထိ"></div>
                <div class="col-md-4">
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
                        <input type="text" name="search" class="form-control" value="<?php echo u48h($search); ?>" placeholder="အမှတ်၊ အမည်၊ မှတ်ပုံတင်၊ အလုပ်ရှင် ဖြင့်ရှာရန်...">
                    </div>
                </div>
                <div class="col-md-6 text-end">
                    <div class="d-inline-flex gap-1 flex-wrap justify-content-end">
                        <button type="submit" class="btn btn-sm btn-primary"><i class="fa-solid fa-search"></i> ရှာဖွေရန်</button>
                        <a href="Under48_Demand_List.php" class="btn btn-sm btn-outline-danger"><i class="fa-solid fa-rotate-right"></i></a>
                        <button type="button" class="btn btn-sm btn-success" onclick="exportUnder48Excel()"><i class="fa-solid fa-file-excel"></i> Excel</button>
                        <a href="dashboard.php" class="btn btn-sm btn-dark"><i class="fa-solid fa-gauge"></i> Dashboard</a>
                        <a href="Under48_Form.php" class="btn btn-sm btn-success"><i class="fa-solid fa-plus"></i> အသစ်ထည့်ရန်</a>
                    </div>
                </div>
            </form>
        </div>

        <div class="table-responsive">
            <table id="under48Table" class="table table-bordered table-hover table-sm m-0">
                <thead>
                    <tr class="table-custom-header">
                        <th>ID</th>
                        <th>စဉ်</th>
                        <th>လျှောက်ထားသည့်ရက်</th>
                        <th>လျှောက်ထားသူအမည်</th>
                        <th>လစာဝင်ငွေအမှတ်</th>
                        <th>မှတ်ပုံတင်အမှတ်</th>
                        <th>ရာထူးအမည်</th>
                        <th>လစာဝင်ငွေရုံး</th>
                        <th>ရုံး/ဌာနအမည်</th>
                        <th>အလုပ်ရှင်အမည်</th>
                        <th>တာဝန်ရှိသူအမည်</th>
                        <th>အလုပ်ရှင်/လစာပေးသူလိပ်စာ</th>
                        <th>အလုပ်ရှင်မှတ်ပုံတင်အမှတ်</th>
                        <th>ရရှိသောလစာနှုန်း</th>
                        <th>ဘဏ္ဍာနှစ်</th>
                        <th>စတင်သည့်နေ့</th>
                        <th>ပြီးဆုံးသည့်နေ့</th>
                        <th>ရရှိသည့်လစာစုစုပေါင်း</th>
                        <th>ထုတ်ပေးသည့်လ</th>
                        <th>သက်သေခံထုတ်ပေးသည့်ရက်</th>
                        <th>မှတ်ချက်</th>
                        <th class="sticky-action-col">လုပ်ဆောင်ချက်</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0) { ?>
                        <?php while ($row = $result->fetch_assoc()) { ?>
                            <tr>
                                <td class="text-center"><?php echo (int)$row['id']; ?></td>
                                <td class="text-center"><?php echo u48h($row['No']); ?></td>
                                <td class="text-center"><?php echo u48_date($row['FormDemandDate']); ?></td>
                                <td><?php echo u48h($row['AssesseName']); ?></td>
                                <td><?php echo u48h($row['TIN_GIR_No']); ?></td>
                                <td><?php echo u48h(u48_nrc($row)); ?></td>
                                <td><?php echo u48h($row['Appointment']); ?></td>
                                <td><?php echo u48h($row['LoginTownship']); ?></td>
                                <td><?php echo u48h($row['OfficeName']); ?></td>
                                <td><?php echo u48h($row['CompanyName']); ?></td>
                                <td><?php echo u48h($row['DrawingOfficer']); ?></td>
                                <td class="address-col" title="<?php echo u48h($row['CompanyAddress']); ?>"><?php echo u48h($row['CompanyAddress']); ?></td>
                                <td><?php echo u48h(u48_nrc($row, '1')); ?></td>
                                <td class="text-end"><?php echo u48_money($row['SalaryRate']); ?></td>
                                <td class="text-center"><?php echo u48h($row['BudgetYear']); ?></td>
                                <td class="text-center"><?php echo u48_date($row['StartDate']); ?></td>
                                <td class="text-center"><?php echo u48_date($row['EndDate']); ?></td>
                                <td class="text-end fw-bold"><?php echo u48_money($row['TotalSalary']); ?></td>
                                <td class="text-center"><?php echo u48h(u48_issue_month($row)); ?></td>
                                <td class="text-center"><?php echo u48_date($row['IssueDate']); ?></td>
                                <td><?php echo u48h($row['Remark']); ?></td>
                                <td class="sticky-action-col">
                                    <div class="d-flex justify-content-center gap-1">
                                        <a class="btn btn-warning btn-sm py-0 px-2" href="Under48_Form.php?id=<?php echo (int)$row['id']; ?>"><i class="fa-solid fa-pen-to-square"></i> Edit</a>
                                        <form method="post" action="Under48_Demand_List.php?<?php echo u48h(http_build_query($_GET)); ?>" onsubmit="return confirm('ဤမှတ်တမ်းကို ဖျက်ရန် သေချာပါသလား။');">
                                            <input type="hidden" name="delete_id" value="<?php echo (int)$row['id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm py-0 px-2"><i class="fa-solid fa-trash"></i> Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php } ?>
                    <?php } else { ?>
                        <tr><td colspan="22" class="text-center text-danger p-4">သတ်မှတ်ချက်နှင့်ကိုက်ညီသော အချက်အလက်များ မရှိသေးပါ။</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1) { ?>
            <div class="d-flex justify-content-center my-4">
                <ul class="pagination pagination-sm gap-1">
                    <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>"><a class="page-link" href="?page=<?php echo max(1, $page - 1) . $keep_filters; ?>">&laquo;</a></li>
                    <?php for ($p = 1; $p <= $total_pages; $p++) { ?>
                        <li class="page-item <?php echo $p === $page ? 'active' : ''; ?>"><a class="page-link" href="?page=<?php echo $p . $keep_filters; ?>"><?php echo $p; ?></a></li>
                    <?php } ?>
                    <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>"><a class="page-link" href="?page=<?php echo min($total_pages, $page + 1) . $keep_filters; ?>">&raquo;</a></li>
                </ul>
            </div>
        <?php } ?>
    </div>
    <script>
        function exportUnder48Excel() {
            const table = document.getElementById('under48Table').cloneNode(true);
            table.querySelectorAll('tr').forEach(function (row) {
                if (row.cells.length) row.deleteCell(row.cells.length - 1);
            });
            const html = '<html><head><meta charset="UTF-8"></head><body>' + table.outerHTML + '</body></html>';
            const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = 'Under48_Demand_List.xls';
            link.click();
        }
    </script>
</body>
</html>
