
<?php $case_number = $_POST['case_number'] ?? ''; ?>
<?php
/*$summary = $_POST['summary'] ?? 'Summary မပါလာပါ';
$appraisal = $_POST['appraisal'] ?? 'Appraisal မပါလာပါ';
die("Textarea Data: " . $summary . " | " . $appraisal);*/
/*$edit_id = $_POST['edit_id'] ?? '';*/

session_start();
include 'db_config.php';

// ၁။ Form 1 ကနေ POST နဲ့ ပါလာတဲ့ ID ကို အရင်ယူပါ
$edit_id        = $_POST['edit_id'] ?? ($_GET['id'] ?? '');
$return_page    = $_GET['return'] ?? ($_POST['return_page'] ?? '');
if ($return_page !== 'CT1_Demand_List.php') {
    $return_page = '';
}
$case_number    = $_POST['case_number'] ?? ($_GET['case_number'] ?? '');
$taxpayer_name  = $_POST['taxpayer_name'] ?? ($_GET['taxpayer_name'] ?? ''); 
$address        = $_POST['address'] ?? ($_GET['address'] ?? '');
$ph_no          = $_POST['ph_no'] ?? ($_GET['ph_no'] ?? '');
$email          = $_POST['email'] ?? ($_GET['email'] ?? '');
$taxYear        = $_POST['taxYear'] ?? ($_GET['taxYear'] ?? ''); 

$businessType1  = $_POST['businessType1'] ?? ($_GET['businessType1'] ?? '');
$businessType2  = $_POST['businessType2'] ?? ($_GET['businessType2'] ?? '');
$declaredCT2    = $_POST['declaredCT2'] ?? ($_GET['declaredCT2'] ?? '');
$rank_          = $_POST['rank_'] ?? ($_GET['rank_'] ?? '');
// ၂။ အကယ်၍ POST မှာ မပါရင် GET (URL) ကနေ ထပ်စစ်ပါ (ပိုသေချာအောင်)
if (empty($edit_id)) {
    $edit_id = $_GET['id'] ?? '';
}

// ၃။ အဲဒီ $edit_id ကို သုံးပြီး ဒေတာဟောင်းတွေ ဆွဲထုတ်ပါ
$data = [];
if (!empty($edit_id)) {
    $stmt = $conn->prepare("SELECT * FROM regular_data WHERE id = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data = $row;
    }
}
// ၁။ Default တန်ဖိုးပေးထားခြင်း
$state_name = "ပြည်နယ်/တိုင်း";
$township_name = "မြို့နယ်အခွန်ဦးစီးဌာနမှူးရုံး";

// ၂။ Login ဝင်ထားသူရဲ့ ဒေတာကို ဆွဲထုတ်ခြင်း
if (isset($_SESSION['user_name'])) {
    $current_user = $_SESSION['user_name'];
    $query = "SELECT state_name, township_name FROM user_register WHERE user_name = '$current_user'"; 
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $state_name = $row['state_name'];     
        $township_name = $row['township_name']; 
    }
}


// Form 1 Next sends the edited values on the URL. Those must replace the saved row,
// otherwise salesAmount1, salesAmount2 and the other fields stay on the old numbers.
foreach ($_GET as $key => $value) {
    if ($key === 'id') {
        continue;
    }
    $data[$key] = $value;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    foreach ($_POST as $key => $value) {
        $data[$key] = $value;
    }
    $data['email'] = $_POST['email'] ?? $email;
}

// Form 1 က ပို့သော မှတ်ပုံတင်အပိုင်း ၄ ခု။ Form 2 ကို တိုက်ရိုက်ဖွင့်လျှင် သိမ်းပြီးသားစာကြောင်းကို ပြန်ခွဲသည်။
$nrc_state  = $_POST['state_code'] ?? '';
$nrc_letter = $_POST['letter_code'] ?? '';
$nrc_type   = $_POST['national_name'] ?? '';
$nrc_number = $_POST['nrc_no'] ?? '';
if ($nrc_state === '' && $nrc_letter === '' && $nrc_type === '' && !empty($data['nrc_no'])
    && preg_match('/^([^\/]+)\/([^\(]+)(\([^\)]+\))(.*)$/u', $data['nrc_no'], $nrc_matches)) {
    $nrc_state  = trim($nrc_matches[1]);
    $nrc_letter = trim($nrc_matches[2]);
    $nrc_type   = trim($nrc_matches[3]);
    $nrc_number = trim($nrc_matches[4]);
}

function form_number($value) {
    $value = str_replace(
        ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉', ',', ' '],
        ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '', ''],
        (string)$value
    );
    return (float)$value;
}

// (နုတ်) ကုန်သွယ်ခွန် follows the commercial tax just calculated on Form 1.
if (isset($_POST['ct1tax']) || isset($_POST['ct2tax']) || isset($_GET['ct1tax']) || isset($_GET['ct2tax'])) {
    $data['minusCTInput'] = round(form_number($data['ct1tax'] ?? 0) + form_number($data['ct2tax'] ?? 0));
}
?>


<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tax Calculation System - Form 2</title>
    <style>
        body { font-family: 'Pyidaungsu', sans-serif; background-color: #f0f0f0; margin: 0; padding: 10px; }
        .container { width: 100%; max-width: 1400px; margin: auto; background: white; border: 1px solid #000; }
        header { background: #0000FF; color: white; display: flex; justify-content: space-between; padding: 8px; font-weight: bold; font-size: 16px; }
        
        .main-content { display: flex; gap: 20px; padding: 15px; }
        .section { flex: 1; border: 1px solid #ccc; padding: 10px; }
        
        .section-title { background: yellow; text-align: center; padding: 6px; margin-bottom: 10px; font-weight: bold; border: 1px solid #000; }
        .sub-title { background: #00FF00; text-align: center; padding: 2px; margin: 10px 0; font-size: 14px; font-weight: bold; }

        /* Grid Layout */
        .calc-grid { display: grid; grid-template-columns: 1.5fr 1fr 1.5fr 1fr; gap: 4px 10px; align-items: center; }
        
        label { font-size: 14px; display: flex; align-items: center; height: 28px; }
        input, select { height: 28px; padding: 2px 5px; border: 1px solid #777; width: 100%; box-sizing: border-box; text-align: right; font-size: 14px; }
        input[readOnly] { background-color: #e9e9e9; font-weight: normal; }

        /* Buttons */
        .button-group { display: flex; flex-direction: column; gap: 8px; margin-top: 20px; }
        .btn { height: 30px; border: none; color: white; font-weight: bold; cursor: pointer; border-radius: 15px; }
        .save { background: green; } .clear { background: gray; } .exit { background: red; }
        .back-btn { background: #5d46e2; width: 120px; margin-top: 10px; }

        .red-text { color: red; }
        .blue-text { color: black; font-weight:5px; }
        .relief_box{width: 69%;}
        .form-select2{width: 27%;}

        .chalantext{width: 26%;}
        .date{width: 70%;}
        .link{color: white;}

    
    </style>
</head>
<body>

<div class="container">
    <header>
        <div><span id="display_state"><?php echo $state_name; ?></span></div>
        <div>Tax Calculation And Case Printing System</div>
        <div><span id="display_township"><?php echo $township_name; ?></span></div>
    </header>

<form id="mainForm" action="save_data.php" method="POST" onsubmit="return beforeSave(event)">
    <input type="hidden" name="edit_id" value="<?php echo $edit_id; ?>">
    <input type="hidden" name="return_page" value="<?php echo htmlspecialchars($return_page); ?>">
    <input type="hidden" name="case_number" value="<?php echo $case_number; ?>">
    <input type="hidden" name="taxpayer_name" value="<?php echo $taxpayer_name; ?>">
    <input type="hidden" name="address" value="<?php echo $address; ?>">
    <input type="hidden" name="ph_no" value="<?php echo $ph_no; ?>">
    <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
    <input type="hidden" name="rank_" value="<?php echo htmlspecialchars($rank_); ?>">

    <input type="hidden" name="taxYear" value="<?php echo htmlspecialchars($_POST['taxYear'] ?? ($_GET['taxYear'] ?? $data['taxYear'] ?? '')); ?>">
    <input type="hidden" name="state_code" value="<?php echo htmlspecialchars($nrc_state, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="letter_code" value="<?php echo htmlspecialchars($nrc_letter, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="national_name" value="<?php echo htmlspecialchars($nrc_type, ENT_QUOTES, 'UTF-8'); ?>">
    <input type="hidden" name="nrc_no" value="<?php echo htmlspecialchars($nrc_number, ENT_QUOTES, 'UTF-8'); ?>">



    <div class="main-content">
        <div class="section">
            <div class="section-title">ဝင်ငွေခွန်တွက်ချက်မှု</div>
            <div class="calc-grid">
                <input type="text" id="businessType1" name="businessType1" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['businessType1'] ?? ''); ?>" placeholder="လုပ်ငန်း">
                <input type="text" 
                        id="salesAmount1" 
                        name="salesAmount1" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['salesAmount1'] ?? ''); ?>">
                <div class="sub-title" style="grid-column: span 2; margin:0;">စီမံရေးရာနှင့် အုပ်ချုပ်မှုစရိတ်</div>


                <input type="text" 
                        id="businessType2" 
                        name="businessType2" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['businessType2'] ?? ''); ?>">
                <input type="text" 
                        id="salesAmount2" 
                        name="salesAmount2" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['salesAmount2'] ?? ''); ?>">
                <label>ဝန်ထမ်းလစာ</label>
                <input type="text" 
                        id="salaryCost" 
                        name="salaryCost" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['salaryCost'] ?? ''); ?>">


                <label>စုစုပေါင်းရောင်းရငွေ</label>
                <input type="text" 
                        id="totalSales" 
                        name="totalSales"
                        oninput="calculateAll()"  
                        value="<?php echo htmlspecialchars($data['totalSales'] ?? ''); ?>" readOnly>
                <label>လုပ်ငန်းလိုင်စင်</label>
                <input type="text" 
                        id="licence" 
                        name="licence" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['licence'] ?? ''); ?>">


                <label class="red-text">(နုတ်) ကုန်သွယ်ခွန်</label>
                <input type="text" 
                        id="minusCTInput" 
                        name="minusCTInput" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['minusCTInput'] ?? ''); ?>" 
                        class="red-text">
                <label>လူမှုဖူလုံရေး</label>
                 <input type="text" 
                        id="socialWelfare" 
                        name="socialWelfare" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['socialWelfare'] ?? ''); ?>">


                <label>အသားတင်ရောင်းရငွေ</label>
                 <input type="text" 
                        id="netSales" 
                        name="netSales" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['netSales'] ?? ''); ?>"  readOnly>
                <label>ဆိုင်ခန်းငှားခ</label>
                 <input type="text" 
                        id="shopRent" 
                        name="shopRent" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['shopRent'] ?? ''); ?>">


                <input type="text" 
                        id="otherIncomeTitle" 
                        name="otherIncomeTitle" 
                        value="<?php echo htmlspecialchars($data['otherIncomeTitle'] ?? ''); ?>" placeholder="အခြားရငွေအမည်" >
                <input type="text" 
                        id="otherIncomeVal" 
                        name="otherIncomeVal" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['otherIncomeVal'] ?? ''); ?>">
                <label>လျှပ်စစ်မီတာ</label>
                <input type="text" 
                        id="electricity" 
                        name="electricity" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['electricity'] ?? ''); ?>">


                <label><b>စည်းကြပ်ရန်ရောင်းရငွေ</b></label>
                <input type="text" 
                        id="taxableSales" 
                        name="taxableSales" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['taxableSales'] ?? ''); ?>" readOnly>
                <label>အထွေထွေစရိတ်(စီမံ)</label>
                <input type="text" 
                        id="adminGeneralCost" 
                        name="adminGeneralCost" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['adminGeneralCost'] ?? ''); ?>" >


                <div class="sub-title" style="grid-column: span 2; margin:0;">တိုက်ရိုက်ကုန်ကျစရိတ်</div>
                <label><b>စီမံစရိတ်ပေါင်း</b></label>
                <input type="text" 
                        id="totalAdminCost" 
                        name="totalAdminCost" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['totalAdminCost'] ?? ''); ?>" readOnly>


                <label>ကုန်ဝယ်စရိတ်</label>
                <input type="text" 
                        id="purchaseCost" 
                        name="purchaseCost" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['purchaseCost'] ?? ''); ?>" >
                <label><b>အသားတင်အမြတ်</b></label>
                <input type="text" 
                        id="netProfit" 
                        name="netProfit" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['netProfit'] ?? ''); ?>" readOnly>


                <label>အခြားကုန်ကျစရိတ်</label>
                <input type="text" 
                        id="otherDirectCost" 
                        name="otherDirectCost" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['otherDirectCost'] ?? ''); ?>" >
                <label></label>
                <label></label>

                <label>အထွေထွေစရိတ်(တိုက်)</label>
                <input type="text" 
                        id="directGeneralCost" 
                        name="directGeneralCost" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['directGeneralCost'] ?? ''); ?>" >
                <label></label>
                <label></label>

                <label><b>တိုက်ရိုက်စရိတ်ပေါင်း</b></label>
                <input type="text" 
                        id="totalDirectCost" 
                        name="totalDirectCost" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['totalDirectCost'] ?? ''); ?>" readOnly>
                <label></label>
                <label></label>

                <label><b>အကြမ်းအမြတ်</b></label>
                <input type="text" 
                        id="grossProfit" 
                        name="grossProfit" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['grossProfit'] ?? ''); ?>" readOnly>
            </div>
            <button type="button" class="btn back-btn" onclick="goBack()">« BACK</button>
        </div>

        <div class="section">
            <div class="section-title">ဝင်ငွေခွန်စည်ကြပ်မှု</div>
            <div class="calc-grid">

                <div class="sub-title" style="grid-column: span 2; margin:0;">(နုတ်)သက်သာခွင့်များ</div>
                <div class="sub-title" style="grid-column: span 2; margin:0;">အကြောင်းကြားစာချအပ်ခြင်း</div>

                <label>အခြေခံသက်သာခွင့်</label>
                <input type="text" 
                        id="basicRelief" 
                        name="basicRelief" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['basicRelief'] ?? ''); ?>" readOnly>
                <label>အကြောင်းကြားစာချသည့်ရက်</label>
                 <input type="date" 
                        id="orderDate" 
                        name="orderDate" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['orderDate'] ?? ''); ?>" >

                <label>အိမ်ထောင်ဖက်သက်သာခွင့်</label>
                <div class="relief-group"> 
                    <input type="text" 
                        id="spouse_relief" 
                        name="spouse_relief" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['spouse_relief'] ?? ''); ?>" 
                        class="relief_box">
                        <select id="numberSelect" name="numberSelect" onchange="updateValue('spouse')" class="form-select2">
                            <option value="0" <?php echo (isset($data['numberSelect']) && $data['numberSelect'] == '0') ? 'selected' : ''; ?>></option>
                            <option value="1" <?php echo (isset($data['numberSelect']) && $data['numberSelect'] == '1') ? 'selected' : ''; ?>>1</option>
                        </select>
                </div>
                <label>ချိန်းဆိုသည့်ရက်</label>
                <input type="date" 
                        id="appointmentDate" 
                        name="appointmentDate" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['appointmentDate'] ?? ''); ?>" >


                <label>မိဘအတွက်သက်သာခွင့်</label>
                <div class="relief-group"> 
                    <input type="text" 
                        id="parent_relief" 
                        name="parent_relief" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['parent_relief'] ?? ''); ?>" 
                        class="relief_box">
                            <select id="numberSelect1" name="numberSelect1" onchange="updateValue('parents')" class="form-select2">
                            <option value="0" <?php echo (isset($data['numberSelect1']) && $data['numberSelect1'] == '0') ? 'selected' : ''; ?>></option>
                            <option value="1" <?php echo (isset($data['numberSelect1']) && $data['numberSelect1'] == '1') ? 'selected' : ''; ?>>1</option>
                            <option value="2" <?php echo (isset($data['numberSelect1']) && $data['numberSelect1'] == '2') ? 'selected' : ''; ?>>2</option>
                        </select>
                </div>  
                <label>လာရောက်သည့်ရက်</label>
                <input type="date" 
                        id="visitedDate" 
                        name="visitedDate" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['visitedDate'] ?? ''); ?>" >


                <label>သားသမီးအတွက်သက်သာခွင့်</label>
                <div class="relief-group"> 
                    <input type="text" 
                        id="child_relief" 
                        name="child_relief" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['child_relief'] ?? ''); ?>" 
                        class="relief_box">
                            <select id="numberSelect2" name="numberSelect2" onchange="updateValue('child')" class="form-select2">
                            <option value="0" <?php echo (isset($data['numberSelect2']) && $data['numberSelect2'] == '0') ? 'selected' : ''; ?>></option>
                            <option value="1" <?php echo (isset($data['numberSelect2']) && $data['numberSelect2'] == '1') ? 'selected' : ''; ?>>1</option>
                            <option value="2" <?php echo (isset($data['numberSelect2']) && $data['numberSelect2'] == '2') ? 'selected' : ''; ?>>2</option>
                        </select>
                </div>  
                <label></label><label></label>

                

                <label><b>စုစုပေါင်းသက်သာခွင့်</b></label>
                <input type="text" 
                        id="totalRelief" 
                        name="totalRelief" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['totalRelief'] ?? ''); ?>" readOnly>
                <div class="sub-title" style="grid-column: span 2; margin:0;">အခွန်စည်းကြပ်မှုမှတ်တမ်း</div>

                <label>စည်းကြပ်ရန်ဝင်ငွေ</label>
                <input type="text" 
                        id="finalTaxableIncome" 
                        name="finalTaxableIncome" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['finalTaxableIncome'] ?? ''); ?>" readOnly>
                <label>IT Demand No.</label>
                <div class="relief-group">
                    <input type="text" 
                        id="itDemandNo" 
                        name="itDemandNo" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['itDemandNo'] ?? ''); ?>" class="chalantext">
                    <input type="date" 
                        id="itDemandDate" 
                        name="itDemandDate" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['itDemandDate'] ?? ''); ?>" class="date">
                </div>

                <label><b>ကျသင့်ဝင်ငွေခွန်</b></label>
                <input type="text" 
                        id="payableIncomeTax" 
                        name="payableIncomeTax" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['payableIncomeTax'] ?? ''); ?>" style="background: #00FF00;">
                <label>CT1 Demand No.</label>
                <div class="relief-group">
                    <input type="text" 
                        id="ct1DemandNo" 
                        name="ct1DemandNo" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['ct1DemandNo'] ?? ''); ?>" class="chalantext">
                    <input type="date" 
                        id="ct1DemandDate" 
                        name="ct1DemandDate" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['ct1DemandDate'] ?? ''); ?>" class="date">
                </div>

                <label>ကြိုတင်ခွန်</label>
                <input type="text" 
                        id="advancePaidTax" 
                        name="advancePaidTax" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['advancePaidTax'] ?? ''); ?>" class="red-text">
                <label>CT2 Demand No.</label>
                <div class="relief-group">
                    <input type="text" 
                        id="ct2DemandNo" 
                        name="ct2DemandNo" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['ct2DemandNo'] ?? ''); ?>" class="chalantext">
                    <input type="date" 
                        id="ct2DemandDate" 
                        name="ct2DemandDate" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['ct2DemandDate'] ?? ''); ?>" class="date">
                </div>

                <label><b>ထပ်မံပေးဆောင်ရန်</b></label>
                <input type="text" 
                        id="finalBalanceTax" 
                        name="finalBalanceTax" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['finalBalanceTax'] ?? ''); ?>" class="blue-text" readOnly>
                <label></label><label></label>

                <label><b>ဒဏ်ကြေး</b></label>
                <input type="text" 
                        id="itpanaty" 
                        name="itpanaty" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['itpanaty'] ?? ''); ?>" class="red-text" readOnly>
                <label></label><label></label>

                <label><b>စုစုပေါင်းအခွန်နှင့်ဒဏ်ကြေး</b></label>
                <input type="text" 
                        id="taxpanaty" 
                        name="taxpanaty" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['itpanaty'] ?? ''); ?>">
                 <button type="submit" class="btn save" style="grid-column: span 2; margin:0;">SAVE DATA</button>
           
                <!--<button style="grid-column: span 2; margin:0;" class="btn save" onclick="saveToLocal()">SAVE DATA</button>-->

                <label><b>ပေးသွင်းသည့်အခွန်နှင့်ဒဏ်ကြေး</b></label>
                <input type="text" 
                        id="taxpanatyPaid" 
                        name="taxpanatyPaid" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['taxpanatyPaid'] ?? ''); ?>">
                <button type="button" style="grid-column: span 2; margin:010;" class="btn exit" onclick="exitToList()">EXIT</button>

                <label><b>ချလန်အမှတ်/ရက်စွဲ</b></label>
                <div class="relief-group">
                    <input type="text" 
                        id="itchalanNo" 
                        name="itchalanNo" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['itchalanNo'] ?? ''); ?>" class="chalantext">
                <input type="date" 
                        id="itchalanDate" 
                        name="itchalanDate" 
                        oninput="calculateAll()" 
                        value="<?php echo htmlspecialchars($data['itchalanDate'] ?? ''); ?>" class="date">
                </div>
                <button type="button" style="grid-column: span 2; margin:010;" class="btn clear" ><a href="IT_Demand_List.php" class="link">IT Demand List</a></button>

                <label></label><label></label>
                <label></label><label></label>

                <label></label><label></label>
                <label></label><label></label>

            </div>
        </div>
    </div>
</form>

<script>
// ၁။ ဂဏန်းပြောင်းလဲခြင်း (ကော်မာပါနေလျှင် ဖယ်ပြီးမှ ဂဏန်းပြောင်းရန်)
function parseVal(id) {
    let el = document.getElementById(id);
    if (!el) return 0;
    let val = el.value.replace(/,/g, '');
    return parseFloat(val) || 0;
}

// ၂။ ကော်မာ ပြန်ထည့်သွင်းခြင်း
function formatVal(id, num) {
    let el = document.getElementById(id);
    if (el) el.value = Math.round(num); //.toLocaleString();
}

// ၃။ ရိုက်ထည့်နေစဉ် ကော်မာထည့်ပေးခြင်း
//function formatInput(event) {
   /* let input = event.target;
    let value = input.value.replace(/,/g, '');
    if (!isNaN(value) && value !== "") {
        input.value = parseFloat(value).toLocaleString();
    }
}*/


// ၅။ သက်သာခွင့် Dropdown များအတွက်
function updateValue(type) {
    let selectBox, textBox;
    if (type === 'spouse') {
        selectBox = document.getElementById("numberSelect");
        textBox = document.getElementById("spouse_relief");
        textBox.value = (selectBox.value === "1") ? "1000000" : "0";
    } else if (type === 'parents') {
        selectBox = document.getElementById("numberSelect1");
        textBox = document.getElementById("parent_relief");
        let val = parseInt(selectBox.value) || 0;
        textBox.value = (val * 1000000);//.toLocaleString();
    } else if (type === 'child') {
        selectBox = document.getElementById("numberSelect2");
        textBox = document.getElementById("child_relief");
        let val = parseInt(selectBox.value) || 0;
        textBox.value = (val * 500000); //.toLocaleString();
    }
    calculateAll(false); 
}
// ၆။ အခွန်မှ စည်းကြပ်ရန်ဝင်ငွေသို့ ပြောင်းပြန်တွက်ခြင်း (သင်ပြပေးထားသော Logic)
function calculateIncomeFromTax(tax) {
    if (tax <= 0) return 0;
    if (tax <= 400000) return (tax / 0.05) + 2000000;
    if (tax <= 2400000) return ((tax - 400000) / 0.10) + 10000000;
    if (tax <= 5400000) return ((tax - 2400000) / 0.15) + 30000000;
    if (tax <= 9400000) return ((tax - 5400000) / 0.20) + 50000000;
    return ((tax - 9400000) / 0.25) + 70000000;
}

// ၇။ အဓိက တွက်ချက်မှု Function (အကုန်လုံး စုံလင်အောင် ပြန်လည်ပေါင်းစပ်ထားသည်)
function calculateAll(isTaxInput = false) {
    let spouse = parseVal('spouse_relief');
    let parents = parseVal('parent_relief');
    let child = parseVal('child_relief');
    let currentNetProfit = 0;

    // --- (၁) ရောင်းရငွေဆိုင်ရာ တွက်ချက်မှုများ ---
    let s1 = parseVal('salesAmount1');
    let s2 = parseVal('salesAmount2');
    let ct = parseVal('minusCTInput');
    let otherInc = parseVal('otherIncomeVal');

    let totalS = s1 + s2;
    let netS = totalS - ct; 
    let taxableS = netS + otherInc; 

    formatVal('totalSales', totalS);
    formatVal('netSales', netS);
    formatVal('taxableSales', taxableS);

    // --- (၂) စီမံစရိတ်ပေါင်း (Admin Cost) အရင်တွက်မည် ---
    let adminCosts = parseVal('salaryCost') + parseVal('licence') + parseVal('socialWelfare') + 
                    parseVal('shopRent') + parseVal('electricity') + parseVal('adminGeneralCost');
    formatVal('totalAdminCost', adminCosts);

    // --- (၃) အသားတင်အမြတ်နှင့် သက်သာခွင့်များ တွက်ချက်ခြင်း ---
    let currentTaxVal = parseVal('payableIncomeTax');
    if (currentTaxVal > 0) isTaxInput = true;

    if (isTaxInput === true) {
        // --- ပြောင်းပြန်တွက်ချက်မှု (Reverse Logic) ---
        let tax = currentTaxVal;
        let taxableIncome = calculateIncomeFromTax(tax);
        formatVal('finalTaxableIncome', taxableIncome);

        // သက်သာခွင့်များ ပြန်တွက်ရန် (၂၀% သို့မဟုတ် ၁၀၀ သိန်း)
        let tempNetProfit = (taxableIncome + spouse + parents + child) / 0.8;
        let bRelief = (tempNetProfit >= 50000000) ? 10000000 : (tempNetProfit * 0.2);
        
        currentNetProfit = taxableIncome + bRelief + spouse + parents + child;
        
        formatVal('basicRelief', bRelief);
        formatVal('netProfit', currentNetProfit);
        formatVal('totalRelief', bRelief + spouse + parents + child);
        formatVal('grossProfit', currentNetProfit + adminCosts);
    } 
    else {
        // --- ပုံမှန်တွက်ချက်မှု (Normal Logic) ---
        // အကယ်၍ အခွန်မရှိသေးလျှင် user ရိုက်ထားသော purchaseCost ကို အခြေခံတွက်မည်
        let pCost = parseVal('purchaseCost');
        let totalDirect = pCost + parseVal('otherDirectCost') + parseVal('directGeneralCost');
        let gross = taxableS - totalDirect;
        currentNetProfit = gross - adminCosts;

        formatVal('grossProfit', gross);
        formatVal('netProfit', currentNetProfit);

        let bRelief = (currentNetProfit >= 50000000) ? 10000000 : (currentNetProfit * 0.2);
        if (currentNetProfit <= 0) bRelief = 0;
        formatVal('basicRelief', bRelief);

        let totalRelief = bRelief + spouse + parents + child;
        formatVal('totalRelief', totalRelief);
        formatVal('finalTaxableIncome', Math.max(0, currentNetProfit - totalRelief));
    }

    // --- (၄) ကုန်ဝယ်စရိတ် (Purchase Cost) ကို ပြန်ရှာခြင်း (အရေးကြီးဆုံးအပိုင်း) ---
    // သင်အလိုရှိသော ပုံသေနည်းအရ - ပြောင်းပြန်တွက်ချက်မှုတွင် အသုံးဝင်သည်
    if (isTaxInput === true) {
        let otherDirect = parseVal('otherDirectCost');
        let directGeneral = parseVal('directGeneralCost');
        
        // ကုန်ဝယ်စရိတ် = စည်းကြပ်ရန်ရောင်းရငွေ - (အသားတင်အမြတ် + စီမံစရိတ် + အခြားတိုက်ရိုက်စရိတ် + အထွေထွေတိုက်ရိုက်စရိတ်)
        let calculatedPurchaseCost = taxableS - (currentNetProfit + adminCosts + otherDirect + directGeneral);
        
        formatVal('purchaseCost', calculatedPurchaseCost);
        
        // တိုက်ရိုက်စရိတ်ပေါင်းကို Update ပြန်လုပ်ခြင်း
        formatVal('totalDirectCost', calculatedPurchaseCost + otherDirect + directGeneral);
    } else {
        // ပုံမှန်တွက်ချက်မှုဆိုလျှင် လက်ရှိရှိသော Direct Cost များကိုပေါင်းပြမည်
        formatVal('totalDirectCost', parseVal('purchaseCost') + parseVal('otherDirectCost') + parseVal('directGeneralCost'));
    }

    // --- (၅) အခွန်နှင့် ဒဏ်ကြေးများ ---
    let payableTax = parseVal('payableIncomeTax');
    let adv = parseVal('advancePaidTax');
    let finalBalance = payableTax - adv;
    formatVal('finalBalanceTax', finalBalance);

    let penalty = (finalBalance > 0) ? Math.round(finalBalance * 0.1) : 0;
    formatVal('itpanaty', penalty);
    formatVal('taxpanaty', finalBalance + penalty);
}

function beforeSave(event) {
    // ၁။ Element များကို ID သို့မဟုတ် Name ဖြင့် ဖမ်းယူခြင်း
    var itDemandDateEle = document.getElementById('itDemandDate') || document.getElementsByName('itDemandDate')[0];
    var ct1_select_realEle = document.getElementById('ct1_select_real') || document.getElementsByName('ct1_select_real')[0];
    var ct1DemandDateEle = document.getElementById('ct1DemandDate') || document.getElementsByName('ct1DemandDate')[0];
    var ct2_select_realEle = document.getElementById('ct2_select_real') || document.getElementsByName('ct2_select_real')[0];
    var ct2DemandDateEle = document.getElementById('ct2DemandDate') || document.getElementsByName('ct2DemandDate')[0];

    // တန်ဖိုးများကို ဆွဲထုတ်ခြင်း
    var itDemandDate = itDemandDateEle ? itDemandDateEle.value : "";
    var ct1_select_real = ct1_select_realEle ? ct1_select_realEle.value : "";
    var ct1DemandDate = ct1DemandDateEle ? ct1DemandDateEle.value : "";
    var ct2_select_real = ct2_select_realEle ? ct2_select_realEle.value : "";
    var ct2DemandDate = ct2DemandDateEle ? ct2DemandDateEle.value : "";

    // ၂။ စစ်ဆေးမှုများ ပြုလုပ်ခြင်း
    // (က) itDemandDate မရှိလျှင် တားမြစ်ခြင်း
    if (itDemandDate.trim() === "") {
        alert("itDemandDate ထည့်သွင်းရန် လိုအပ်ပါသည်!");
        event.preventDefault(); // 🎯 ပြကွက်မပျက်စေဘဲ Form Submit ဖြစ်သွားခြင်းကို တားဆီးသည်
        if(itDemandDateEle) itDemandDateEle.focus();
        return false;
    }

    // (ခ) ct1_select_real ရှိပြီး ct1DemandDate မရှိလျှင် တားမြစ်ခြင်း
    if (ct1_select_real.trim() !== "" && ct1DemandDate.trim() === "") {
        alert("ct1_select_real ဒေတာရှိသဖြင့် ct1DemandDate ထည့်သွင်းရန် လိုအပ်ပါသည်!");
        event.preventDefault(); // 🎯 တားဆီးသည်
        if(ct1DemandDateEle) ct1DemandDateEle.focus();
        return false;
    }

    // (ဂ) ct2_select_real ရှိပြီး ct2DemandDate မရှိလျှင် တားမြစ်ခြင်း
    if (ct2_select_real.trim() !== "" && ct2DemandDate.trim() === "") {
        alert("ct2_select_real ဒေတာရှိသဖြင့် ct2DemandDate ထည့်သွင်းရန် လိုအပ်ပါသည်!");
        event.preventDefault(); // 🎯 တားဆီးသည်
        if(ct2DemandDateEle) ct2DemandDateEle.focus();
        return false;
    }

    // ---------------------------------------------------------
    // 🎯 သင့်ထံတွင် မူလရှိပြီးသား beforeSave ကုဒ်များကို အောက်ပါနေရာတွင် ဆက်ရေးပါ
    // ---------------------------------------------------------
    // ဥပမာ - ကော်မာပြန်ထည့်တာတွေ၊ အခြား တွက်ချက်မှု လုပ်တာတွေ ရှိရင် ဒီအောက်မှာ ဆက်လုပ်နိုင်ပါတယ်
    

    // သိမ်းခါနီးမှာ ကော်မာတွေကို အကုန်ဖြုတ်ချလိုက်တာပါ
    const inputs = document.querySelectorAll('input[type="text"]');
    inputs.forEach(input => {
        input.value = input.value.replace(/,/g, '');
    });
    return true;
}


window.addEventListener('DOMContentLoaded', () => {
    const inputs = document.querySelectorAll('input[type="text"]');
    inputs.forEach(input => {
        if (!input.readOnly) {
            //input.addEventListener('input', formatInput);
        }
    });
});

window.onload = function() {
    // ၁။ localStorage က ဒေတာကို ယူမည်
    const savedData = localStorage.getItem('TaxSystem_Data_Share');
    
    if (savedData) {
        const formData = JSON.parse(savedData);
        const isEditMode = document.getElementsByName('edit_id')[0]?.value !== "";
        const pageUrl = new URLSearchParams(window.location.search);
        const cameFromForm1 = pageUrl.has('salesAmount1') || pageUrl.has('taxpayer_name') || pageUrl.has('summary');

        Object.keys(formData).forEach(id => {
  
            if (id === 'email') {
                return; 
            }

            const element = document.getElementById(id);
            if (element) {
                if (element.value === "" || !isEditMode || cameFromForm1) {
                    element.value = formData[id];
                }
            } else {
                // 🎯 Form 2 ထဲမှာ ဒီကောင်တွေ ကိုယ်ထည်မရှိလို့ Hidden Input အဖြစ် ဆောက်ပြီး Form 2 ထဲ ညှပ်ထည့်ပေးမည့်အပိုင်း
                let hiddenInput = document.createElement("input");
                hiddenInput.type = "hidden";
                
                if (id === 'case_number') hiddenInput.name = "case_number";
                else if (id === 'it_no') hiddenInput.name = "it_no"; 
                else if (id === 'taxYear') hiddenInput.name = "taxYear";
                else if (id === 'assesse_name' || id === 'taxpayer_name') hiddenInput.name = "taxpayer_name";
                else if (id === 'officer_name') hiddenInput.name = "officer_name";
                else hiddenInput.name = id; // summary နဲ့ appraisal က ဒီနေရာကနေ name="summary", name="appraisal" အဖြစ် ရောက်သွားမှာပါ

                hiddenInput.value = formData[id];
                document.forms[0].appendChild(hiddenInput);
            }
        });
    }

    const ct1Field = document.getElementById('ct1tax') || document.querySelector('[name="ct1tax"]');
    const ct2Field = document.getElementById('ct2tax') || document.querySelector('[name="ct2tax"]');
    const minusField = document.getElementById('minusCTInput');
    if (minusField && (ct1Field || ct2Field)) {
        const asNumber = (el) => parseFloat(String(el && el.value ? el.value : '').replace(/,/g, '')) || 0;
        minusField.value = Math.round(asNumber(ct1Field) + asNumber(ct2Field));
    }
    if (typeof calculateAll === "function") calculateAll();

    // ၂။ 🎯 [နောက်ဆုံးပိတ် အသေချာဆုံးအပိုင်း] Form Submit မဖြစ်ခင် လက်ရှိမျက်နှာပြင်ပေါ်က တန်ဖိုးအမှန်ကို အတင်းဆွဲထည့်ခြင်း
    document.querySelectorAll('form').forEach(currentForm => {
        currentForm.addEventListener('submit', function() {
            
            // =========================================================================
            // 🎯 စည်းကြပ်နှစ် (taxYear) အတွက် အသစ်ထည့်သွင်းထားသော ကုဒ်အပိုင်း
            // =========================================================================
            // URL Query String ထဲက taxYear တန်ဖိုးအမှန် (ဥပမာ - 2026-2027) ကို အရင်ဆွဲဖတ်ပါမည်
            const urlParams = new URLSearchParams(window.location.search);
            const taxYearFromUrl = urlParams.get('taxYear');

            if (taxYearFromUrl) {
                // Form ထဲမှာ အပေါ်က localStorage ကြောင့် မှားဝင်သွားတဲ့ taxYear field အဟောင်းရှိရင် အကုန်အရင်ဖျက်ပါမည်
                let oldTaxYears = currentForm.querySelectorAll('input[name="taxYear"]');
                oldTaxYears.forEach(el => el.remove());
                
                // URL ကလာတဲ့ တန်ဖိုးအသစ်စက်စက်ဖြင့် Hidden Input အသစ်တစ်ခုကို လုံးဝအသန့် ပြန်ဆောက်ပါမည်
                let taxYearInput = document.createElement("input");
                taxYearInput.type = "hidden"; 
                taxYearInput.name = "taxYear";
                taxYearInput.value = taxYearFromUrl.trim();
                currentForm.appendChild(taxYearInput);
            }

            // email အတွက်
            let emailEl = document.getElementById('email');
            if (emailEl) {
                let oldEmail = currentForm.querySelectorAll('input[name="email"]');
                oldEmail.forEach(el => el.remove()); // ရှိပြီးသားအဟောင်းများကို အကုန်ဖျက်ပစ်ပါ
                
                // email input field ကိုယ်ထည်ရှိပါက ၎င်း၏ value ကို ယူပါမည်
                let mailInput = document.createElement("input");
                mailInput.type = "hidden"; mailInput.name = "email";
                mailInput.value = emailEl.value.trim();
                currentForm.appendChild(mailInput);
            }
            
            // summary / appraisal come from Calculation_Form1 in the URL
            ['summary', 'appraisal'].forEach(function(fieldName) {
                const fromUrl = urlParams.get(fieldName);
                const fieldEl = document.getElementById(fieldName) || document.getElementsByName(fieldName)[0];
                const value = (fieldEl && fieldEl.value !== '') ? fieldEl.value : fromUrl;
                if (value === null) return;
                currentForm.querySelectorAll('input[name="' + fieldName + '"]').forEach(el => el.remove());
                const hidden = document.createElement("input");
                hidden.type = "hidden";
                hidden.name = fieldName;
                hidden.value = value.trim();
                currentForm.appendChild(hidden);
            });
        });
    });
};

function goBack() {
    // URL ထဲက id ကို ယူမယ်
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get('id');

    const returnPage = new URLSearchParams(window.location.search).get('return');
    const returnQuery = (returnPage === 'CT1_Demand_List.php') ? ('&return=' + encodeURIComponent(returnPage)) : '';

    if (id) {
        window.location.href = "Calculation_Form1.php?id=" + id + returnQuery;
    } else {
        window.location.href = "Calculation_Form1.php" + (returnQuery ? ('?' + returnQuery.slice(1)) : '');
    }
}

// ၄။ Save Data Button (Optional: File သို့မဟုတ် Database သို့ သိမ်းရန်)
function saveToLocal() {
    alert("ဒေတာများကို သိမ်းဆည်းပြီးပါပြီ။");
    // ဒီနေရာမှာ PHP သို့မဟုတ် Database သို့ ပို့ရန် ကုဒ်ထည့်နိုင်သည်
}

function exitToList() {
    // အတည်ပြုချက် မေးချင်ရင် ဒီလို သုံးနိုင်ပါတယ်
    if (confirm("ပင်မစာမျက်နာသို့ သွားရန်သေချာပါသလား?")) {
        window.location.href = "dashboard.php";
    }
}
</script>

</body>
</html>