<?php
session_start();

if (!isset($_SESSION['user_name'])) {
    header('Location: login.php');
    exit;
}
if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: dashboard.php');
    exit;
}

include 'db_config.php';
$conn->set_charset('utf8mb4');

function admin_go($message, $url) {
    $message = json_encode($message, JSON_UNESCAPED_UNICODE);
    $url = json_encode($url, JSON_UNESCAPED_UNICODE);
    echo "<script>alert($message); window.location.href=$url;</script>";
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: admin_setting.php');
    exit;
}

$q = trim($_POST['q'] ?? '');
$list_url = 'admin_setting.php' . ($q !== '' ? '?q=' . urlencode($q) : '');

if (isset($_POST['btn_delete'])) {
    $id = (int) ($_POST['id'] ?? 0);
    if ($id <= 0) {
        admin_go('ဖျက်ရန် အတန်းကို ရွေးပါ။', $list_url);
    }
    if ($id === (int) ($_SESSION['user_id'] ?? 0)) {
        admin_go('မိမိအကောင့်ကို ဖျက်၍ မရပါ။', $list_url);
    }

    $stmt = $conn->prepare('DELETE FROM user_register WHERE id = ?');
    $stmt->bind_param('i', $id);
    $ok = $stmt->execute() && $stmt->affected_rows > 0;
    $stmt->close();
    admin_go($ok ? 'ရွေးထားသော အသုံးပြုသူကို ဖျက်ပြီးပါပြီ။' : 'ဖျက်၍ မရပါ။', $list_url);
}

$id = (int) ($_POST['id'] ?? 0);
$state_name = trim($_POST['state_name'] ?? '');
$township_name = trim($_POST['township_name'] ?? '');
$md_no = trim($_POST['md_no'] ?? '');
$bank_township = trim($_POST['bank_township'] ?? '');
$state_office = trim($_POST['state_office'] ?? '');
$state_city = trim($_POST['state_city'] ?? '');
$township_code = trim($_POST['township_code'] ?? '');
$officer_name = trim($_POST['officer_name'] ?? '');
$rank = trim($_POST['rank_'] ?? '');
$region = trim($_POST['region'] ?? '');
$user_name = trim($_POST['user_name'] ?? '');
$password = $_POST['password'] ?? '';
$other = trim($_POST['other'] ?? '');
$role = ($_POST['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
$edit_url = 'admin_setting.php?edit_id=' . $id . ($q !== '' ? '&q=' . urlencode($q) : '');

if ($user_name === '' || $officer_name === '' || $state_name === '' || $township_name === '') {
    admin_go('လိုအပ်သော အချက်အလက်များ ပြည့်စုံအောင် ဖြည့်ပါ။', $id > 0 ? $edit_url : $list_url);
}
if ($id === 0 && trim($password) === '') {
    admin_go('Password ထည့်ပါ။', $list_url);
}
if ($id > 0 && $id === (int) ($_SESSION['user_id'] ?? 0) && $role !== 'admin') {
    admin_go('မိမိအကောင့်၏ admin အဆင့်ကို ပြောင်း၍ မရပါ။', $edit_url);
}

$check = $conn->prepare('SELECT id FROM user_register WHERE user_name = ? AND id <> ?');
$check->bind_param('si', $user_name, $id);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
    $check->close();
    admin_go('ဤ User Name ကို အသုံးပြုပြီးသား ဖြစ်ပါသည်။', $id > 0 ? $edit_url : $list_url);
}
$check->close();

if ($id > 0) {
    if (trim($password) !== '') {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare('UPDATE user_register SET state_name=?, township_name=?, md_no=?, bank_township=?, state_office=?, state_city=?, township_code=?, officer_name=?, `rank_`=?, region=?, user_name=?, password=?, role=?, other=? WHERE id=?');
        $stmt->bind_param('ssssssssssssssi', $state_name, $township_name, $md_no, $bank_township, $state_office, $state_city, $township_code, $officer_name, $rank, $region, $user_name, $hashed, $role, $other, $id);
    } else {
        $stmt = $conn->prepare('UPDATE user_register SET state_name=?, township_name=?, md_no=?, bank_township=?, state_office=?, state_city=?, township_code=?, officer_name=?, `rank_`=?, region=?, user_name=?, role=?, other=? WHERE id=?');
        $stmt->bind_param('sssssssssssssi', $state_name, $township_name, $md_no, $bank_township, $state_office, $state_city, $township_code, $officer_name, $rank, $region, $user_name, $role, $other, $id);
    }
    $ok = $stmt->execute();
    $stmt->close();
    admin_go($ok ? 'အသုံးပြုသူအချက်အလက်ကို ပြင်ဆင်ပြီးပါပြီ။' : 'ပြင်ဆင်၍ မရပါ။', $edit_url);
}

$hashed = password_hash($password, PASSWORD_DEFAULT);
$stmt = $conn->prepare('INSERT INTO user_register (state_name, township_name, md_no, bank_township, state_office, state_city, township_code, officer_name, `rank_`, region, user_name, password, role, other) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
$stmt->bind_param('ssssssssssssss', $state_name, $township_name, $md_no, $bank_township, $state_office, $state_city, $township_code, $officer_name, $rank, $region, $user_name, $hashed, $role, $other);
$ok = $stmt->execute();
$stmt->close();
admin_go($ok ? 'အသုံးပြုသူအသစ်ကို သိမ်းဆည်းပြီးပါပြီ။' : 'သိမ်းဆည်း၍ မရပါ။', $list_url);
