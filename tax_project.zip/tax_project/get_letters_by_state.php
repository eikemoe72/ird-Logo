<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ဒေတာဘေ့စ် Config ကို ချိတ်ဆက်ခြင်း
include_once 'db_config.php'; 

if (isset($_GET['state_code'])) {
    $state_code = mysqli_real_escape_string($conn, $_GET['state_code']);
    
    // ရွေးချယ်လိုက်သော state_code အလိုက် letter_code များကို ထပ်နေခြင်းမရှိအောင် (DISTINCT) ဖြင့် ဆွဲထုတ်ခြင်း
    $query = "SELECT DISTINCT letter_code FROM locations 
              WHERE state_code = '$state_code' 
              AND letter_code IS NOT NULL 
              AND letter_code != ''
              ORDER BY letter_code ASC";
              
    $result = $conn->query($query);
    $letters = [];
    
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $letters[] = $row['letter_code'];
        }
        // ရှာဖွေတွေ့ရှိသော စာလုံးကုဒ်များကို JSON Array အဖြစ် ပြန်ထုတ်ပေးခြင်း
        echo json_encode(['status' => 'success', 'data' => $letters]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Query Failed']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No state code provided']);
}

$conn->close();
?>