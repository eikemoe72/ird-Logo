<?php
// Database connection အား ခေါ်ယူခြင်း
include 'db_connect.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Form မှ လက်ခံရရှိသော data များ
    $user_name = $_POST['user_name'];
    $password = $_POST['password'];
    $role = $_POST['role']; // admin သို့မဟုတ် user
    
    // Password ကို hash လုပ်၍ လုံခြုံအောင် ပြုလုပ်ခြင်း
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // ကျန်ရှိသော အချက်အလက်များ (သင့် Table structure အတိုင်း)
    $state_name = $_POST['state_name'];
    $township_name = $_POST['township_name'];
    $md_no = $_POST['md_no'];
    $officer_name = $_POST['officer_name'];
    $rank = $_POST['rank'];
    $region = $_POST['region'];

    // Database ထဲသို့ ထည့်သွင်းခြင်း (Prepared Statement သုံးထားပါသည်)
    $sql = "INSERT INTO user_register (state_name, township_name, md_no, officer_name, rank, region, user_name, password, role) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssssss", $state_name, $township_name, $md_no, $officer_name, $rank, $region, $user_name, $hashed_password, $role);

    if ($stmt->execute()) {
        echo "အသုံးပြုသူအသစ် မှတ်ပုံတင်ခြင်း အောင်မြင်ပါသည်။";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>