<?php
session_start();
include 'db_config.php';

$error = ""; // Error variable ကို ကြိုတင်သတ်မှတ်ထားခြင်းဖြင့် Undefined error ကို ကာကွယ်ပါသည်

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user = $_POST['username'] ?? '';
    $pass = $_POST['password'] ?? '';

    // Database query (Screenshot အရ user_name column ကို သုံးထားပါသည်)
    $stmt = $conn->prepare("SELECT * FROM user_register WHERE user_name = ?");
    $stmt->bind_param("s", $user);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        // Password တိုက်စစ်ခြင်း
        if ($pass === $row['password'] || password_verify($pass, $row['password'])) { 
            
            // Session ထဲသို့ အချက်အလက်များ သိမ်းဆည်းခြင်း
            $_SESSION['user_id']       = $row['id'];
            $_SESSION['user_name']     = $row['user_name'];
            $_SESSION['user_role']     = $row['role'];
            
            // အရာရှိ အချက်အလက်များ (Database column အမည်မှာ rank_ ဖြစ်ပါသည်)
            $_SESSION['officer_name']  = $row['officer_name']; 
            $_SESSION['rank']          = $row['rank_']; 
            $_SESSION['region']        = $row['region'];
            $_SESSION['state_name']    = $row['state_name'] ?? '';
            $_SESSION['township_name'] = $row['township_name'] ?? '';

            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Password မှားယွင်းနေပါသည်။";
        }
    } else {
        $error = "အသုံးပြုသူအမည် မရှိပါ။";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Tax Calculation System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --body-bg:rgb(172, 242, 234); --desh-purple: #2e004f; --desh-gold: #c5a059; }
        body { font-family: 'Inter', sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; background-color: var(--body-bg); margin: 0; }
        .login-box { background:rgb(37, 73, 235); padding: 40px; border-radius: 24px; box-shadow: 0 20px 40px rgba(46,0,79,0.1); width: 100%; max-width: 320px; text-align: center; }
        .logo-area img { width: 100px; margin-bottom: 10px; }
        .field { margin-bottom: 22px; text-align: left; }
        .field label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 8px; }
        .field input { width: 100%; padding: 14px; border-radius: 12px; border: 1.5px solid #b3c6ea; box-sizing: border-box; }
        .login-btn { width: 100%; padding: 16px; background: var(--desh-purple); color: white; border: none; border-radius: 12px; font-weight: 700; cursor: pointer; }
    </style>
</head>
<body>

    <div class="login-box">
        <div class="logo-area">
            <img src="https://raw.githubusercontent.com/KyawaungMoe/TaxCalculation/main/ird-logo.png" alt="IRD Logo">
        </div>
        <h2 style="color: gold;">Sign In</h2>
        <div style="color: gold;" class="system-title">Tax Calculation & Printing System</div><br><br>

        <?php if(!empty($error)): ?>
            <div style="color: red; font-size: 13px; margin-bottom: 15px; background: #fee; padding: 10px; border-radius: 8px;">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="field">
                <label style="color: white;">Username / Officer ID</label>
                <input type="text" name="username" placeholder="e.g. admin_01" required>
            </div>

            <div class="field">
                <label style="color: white;">Password</label>
                <input type="password" name="password" placeholder="••••••••" required>
            </div>

            <button style="color: gold;" type="submit" class="login-btn">Secure Login</button>
        </form>

        <div class="footer" style="margin-top: 20px; font-size: 12px; color: white;">
            Tax Calculation © 2026
        </div>
    </div>

</body>
</html>