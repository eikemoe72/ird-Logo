<?php
include 'db_config.php';

// ၁။ URL မှ ID ကိုယူပြီး Database မှ ဒေတာဆွဲထုတ်ခြင်း
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $result = $conn->query("SELECT * FROM regular_data WHERE id = $id");
    $data = $result->fetch_assoc(); // $row ကို $data လို့ ပြောင်းလိုက်ပါ
}

if (!$data) {
    echo "<script>alert('ဒေတာ ရှာမတွေ့ပါ'); window.location.href='IT_Demand_List.php';</script>";
    exit;
}

// ဂဏန်းတွေကို ကော်မာပြန်ထည့်ရန် Function
function numF($val) {
    return is_numeric($val) ? number_format($val) : $val;
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Case - <?= $data['case_number'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Pyidaungsu', sans-serif; background-color: #f4f7f9; }
        .main-card { border-radius: 15px; border: none; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        .section-header { background: #0000FF; color: white; padding: 10px 20px; border-radius: 10px 10px 0 0; font-weight: bold; }
        .sub-title { background: #e9ecef; padding: 5px 15px; font-weight: bold; border-left: 4px solid #0000FF; margin-top: 20px; margin-bottom: 15px; }
        .form-label { font-size: 0.9rem; font-weight: 600; color: #555; }
        .form-control:focus { border-color: #0000FF; box-shadow: 0 0 0 0.2rem rgba(0,0,255,0.25); }
        .readonly-bg { background-color: #f8f9fa !important; }
        .btn-update { background: #198754; color: white; padding: 10px 30px; border-radius: 25px; font-weight: bold; }
    </style>
</head>
<body>

<div class="container my-5">
    <form action="update_data.php" method="POST">
        <input type="hidden" name="id" value="<?= $data['id'] ?>">

        <div class="card main-card">
            <div class="section-header d-flex justify-content-between">
                <span><i class="bi bi-pencil-square"></i> တွက်ချက်မှုပြင်ဆင်ရန်</span>
                <span>ID: <?= $data['id'] ?></span>
            </div>
            
            <div class="card-body p-4">
                
                <div class="sub-title text-primary">အခြေခံအချက်အလက်များ (Form 1)</div>
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">အမှုတွဲနံပါတ်</label>
                        <input type="text" name="case_number" class="form-control" value="<?= $data['case_number'] ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">အခွန်ထမ်းအမည်</label>
                        <input type="text" name="taxpayer_name" class="form-control" value="<?= $data['taxpayer_name'] ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">ရာထူး/အဆင့်</label>
                        <input type="text" name="rank_" class="form-control" value="<?= $data['rank_'] ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">အခွန်နှစ်</label>
                        <input type="text" name="taxYear" class="form-control" value="<?= $data['taxYear'] ?>">
                    </div>
                </div>

                <div class="sub-title text-success">ဝင်ငွေခွန်တွက်ချက်မှု</div>
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label">လုပ်ငန်း-၁</label>
                        <input type="text" name="businessType1" class="form-control mb-2" value="<?= $data['businessType1'] ?>">
                        <input type="text" id="salesAmount1" name="salesAmount1" class="form-control text-end" value="<?= numF($data['salesAmount1']) ?>" oninput="calculateAll()">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">လုပ်ငန်း-၂</label>
                        <input type="text" name="businessType2" class="form-control mb-2" value="<?= $data['businessType2'] ?>">
                        <input type="text" id="salesAmount2" name="salesAmount2" class="form-control text-end" value="<?= numF($data['salesAmount2']) ?>" oninput="calculateAll()">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">အခြားရငွေအမည်/တန်ဖိုး</label>
                        <input type="text" name="otherIncomeTitle" class="form-control mb-2" value="<?= $data['otherIncomeTitle'] ?>">
                        <input type="text" id="otherIncomeVal" name="otherIncomeVal" class="form-control text-end" value="<?= numF($data['otherIncomeVal']) ?>" oninput="calculateAll()">
                    </div>
                </div>

                <div class="row g-3 mt-3">
                    <div class="col-md-3">
                        <label class="form-label text-danger">(-) ကုန်သွယ်ခွန်</label>
                        <input type="text" id="minusCTInput" name="minusCTInput" class="form-control text-end text-danger fw-bold" value="<?= numF($data['minusCTInput']) ?>" oninput="calculateAll()">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">စည်းကြပ်ရန်ရောင်းရငွေ</label>
                        <input type="text" id="taxableSales" name="taxableSales" class="form-control text-end readonly-bg" value="<?= numF($data['taxableSales']) ?>" readonly>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">ကုန်ဝယ်စရိတ် (Purchase)</label>
                        <input type="text" id="purchaseCost" name="purchaseCost" class="form-control text-end" value="<?= numF($data['purchaseCost']) ?>" oninput="calculateAll()">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">အသားတင်အမြတ်</label>
                        <input type="text" id="netProfit" name="netProfit" class="form-control text-end readonly-bg fw-bold text-primary" value="<?= numF($data['netProfit']) ?>" readonly>
                    </div>
                </div>

                <div class="sub-title text-warning text-dark">သက်သာခွင့်နှင့် အခွန်စည်ကြပ်မှု</div>
                <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">အခြေခံသက်သာခွင့်</label>
                        <input type="text" id="basicRelief" name="basicRelief" class="form-control text-end" value="<?= numF($data['basicRelief']) ?>" readonly>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">အိမ်ထောင်ဖက်သက်သာခွင့်</label>
                        <input type="text" id="spouse_relief" name="spouse_relief" class="form-control text-end" value="<?= numF($data['spouse_relief']) ?>" oninput="calculateAll()">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">မိဘ/သားသမီး သက်သာခွင့်</label>
                        <div class="input-group">
                            <input type="text" id="parent_relief" name="parent_relief" class="form-control text-end" value="<?= numF($data['parent_relief']) ?>" placeholder="မိဘ">
                            <input type="text" id="child_relief" name="child_relief" class="form-control text-end" value="<?= numF($data['child_relief']) ?>" placeholder="သားသမီး">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">စည်းကြပ်ရန်ဝင်ငွေ</label>
                        <input type="text" id="finalTaxableIncome" name="finalTaxableIncome" class="form-control text-end readonly-bg fw-bold" value="<?= numF($data['finalTaxableIncome']) ?>" readonly>
                    </div>
                </div>

                <div class="row g-3 mt-3">
                    <div class="col-md-4">
                        <label class="form-label">ကျသင့်ဝင်ငွေခွန် (IT)</label>
                        <input type="text" id="payableIncomeTax" name="payableIncomeTax" class="form-control text-end bg-success text-white fw-bold" value="<?= numF($data['payableIncomeTax']) ?>" oninput="calculateAll(true)">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">IT Demand No. & Date</label>
                        <div class="input-group">
                            <input type="text" name="itDemandNo" class="form-control" value="<?= $data['itDemandNo'] ?>">
                            <input type="date" name="itDemandDate" class="form-control" value="<?= $data['itDemandDate'] ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">ဒဏ်ကြေး (Penalty)</label>
                        <input type="text" id="itpanaty" name="itpanaty" class="form-control text-end text-danger fw-bold" value="<?= numF($data['itpanaty']) ?>">
                    </div>
                </div>

                <div class="row g-3 mt-3 border-top pt-4">
                    <div class="col-12 text-center">
                        <a href="IT_Demand_List.php" class="btn btn-secondary px-4 rounded-pill me-2">မပြင်တော့ပါ (Exit)</a>
                        <button type="submit" class="btn btn-update shadow">ပြင်ဆင်ချက်များသိမ်းမည် (Update Data)</button>
                    </div>
                </div>

            </div>
        </div>
    </form>
</div>

<script>
// (သင့် Form 2 မှ တွက်ချက်မှု Script အတိုင်း ပြန်သုံးထားပါသည်)
function parseVal(id) {
    let el = document.getElementById(id);
    if (!el) return 0;
    let val = el.value.replace(/,/g, '');
    return parseFloat(val) || 0;
}

function formatVal(id, num) {
    let el = document.getElementById(id);
    if (el) el.value = Math.round(num).toLocaleString();
}

function calculateAll(isTaxInput = false) {
    let s1 = parseVal('salesAmount1');
    let s2 = parseVal('salesAmount2');
    let ct = parseVal('minusCTInput');
    let otherInc = parseVal('otherIncomeVal');
    
    let taxableS = (s1 + s2) - ct + otherInc;
    formatVal('taxableSales', taxableS);

    // အသားတင်အမြတ် (ရိုးရှင်းသော တွက်ချက်မှု နမူနာ)
    let pCost = parseVal('purchaseCost');
    let currentNetProfit = taxableS - pCost; // ဒီနေရာမှာ admin costs တွေ နှုတ်ဖို့လိုရင် ထပ်ပေါင်းထည့်ပါ
    formatVal('netProfit', currentNetProfit);

    // သက်သာခွင့်များ
    let spouse = parseVal('spouse_relief');
    let parents = parseVal('parent_relief');
    let child = parseVal('child_relief');
    let bRelief = (currentNetProfit >= 50000000) ? 10000000 : (currentNetProfit * 0.2);
    if(currentNetProfit <= 0) bRelief = 0;
    formatVal('basicRelief', bRelief);

    let totalRelief = bRelief + spouse + parents + child;
    let finalIncome = Math.max(0, currentNetProfit - totalRelief);
    formatVal('finalTaxableIncome', finalIncome);
}

// Input တွင် ကော်မာထည့်ခြင်း
document.querySelectorAll('input[type="text"]').forEach(input => {
    input.addEventListener('input', function(e) {
        let value = this.value.replace(/,/g, '');
        if (!isNaN(value) && value !== "") {
            this.value = parseFloat(value).toLocaleString();
        }
    });
});

</script>
</body>
</html>