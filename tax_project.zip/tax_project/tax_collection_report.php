<?php
// 🎯 ၁။ Session စတင်ခြင်းနှင့် Database ချိတ်ဆက်ခြင်း
if (session_status() === PHP_SESSION_NONE) session_start();
include_once 'db_config.php'; 
$conn->set_charset("utf8mb4");

// 🎯 ၂။ ကနဦး Filter Variable များ သတ်မှတ်ခြင်း
$tax_year = $_GET['tax_year'] ?? '2025-2026';

// =========================================================================
// 🎯 ၃။ SESSION သို့မဟုတ် စနစ်အတွင်းမှ တိုင်းနှင့် မြို့နယ်ကို အသေအချာ ဖတ်ယူခြင်း
// =========================================================================
$user_state = '-';
$user_township = '-';

// နည်းလမ်း (က) Session ထဲတွင် အကောင့်အမည် တိုက်ရိုက်ရှိမရှိ စစ်ဆေးခြင်း
$current_user = $_SESSION['user_name'] ?? ($_SESSION['username'] ?? '');

// နည်းလမ်း (ခ) အကယ်၍ Session ပျောက်နေပါက လက်ရှိ Dashboard တွင် မြင်တွေ့ရသော အမည်ဖြင့် တိုက်ရိုက်ရှာဖွေခြင်း
if (empty($current_user)) {
    $backup_query = "SELECT state_name, township_name FROM user_register WHERE officer_name LIKE '%ကျော်အောင်မိုး%' OR user_name = 'KAM' LIMIT 1";
    $backup_res = $conn->query($backup_query);
    if ($backup_res && $backup_res->num_rows > 0) {
        $user_row = $backup_res->fetch_assoc();
        $user_state = $user_row['state_name'];
        $user_township = $user_row['township_name'];
    }
} else {
    $user_query = "SELECT state_name, township_name FROM user_register WHERE user_name = '$current_user' LIMIT 1";
    $user_res = $conn->query($user_query);
    if ($user_res && $user_res->num_rows > 0) {
        $user_row = $user_res->fetch_assoc();
        $user_state = $user_row['state_name'];
        $user_township = $user_row['township_name'];
    }
}

if ($user_state === '-' || $user_township === '-') {
    $user_state = $_SESSION['user_state'] ?? ($_SESSION['state'] ?? '-');
    $user_township = $_SESSION['user_township'] ?? ($_SESSION['township'] ?? '-');
}

// =========================================================================
// 🎯 ၄။ BUDGET_YEAR ဇယားမှ START_DATE2 နှင့် END_DATE2 ကို ရှာဖွေရယူခြင်း
// =========================================================================
$start_date_reg = ""; 
$end_date_reg   = "";

if (!empty($tax_year)) {
    $budget_stmt = $conn->prepare("SELECT start_date2, end_date2 FROM budget_year WHERE budget_year = ?");
    $budget_stmt->bind_param("s", $tax_year);
    $budget_stmt->execute();
    $budget_res = $budget_stmt->get_result();
    
    if ($budget_res && $budget_row = $budget_res->fetch_assoc()) {
        $start_date_reg = !empty($budget_row['start_date2']) ? $budget_row['start_date2'] : date('Y-04-01');
        $end_date_reg   = !empty($budget_row['end_date2']) ? $budget_row['end_date2'] : date('Y-m-d');
    } else {
        $start_date_reg = date('Y-04-01');
        $end_date_reg   = date('Y-m-d');
    }
    $budget_stmt->close();
}

if (!empty($_GET['start_date'])) {
    $start_date_reg = DateTime::createFromFormat('d/m/Y', $_GET['start_date']) 
        ? DateTime::createFromFormat('d/m/Y', $_GET['start_date'])->format('Y-m-d') 
        : $_GET['start_date'];
}

if (!empty($_GET['end_date'])) {
    $end_date_reg = DateTime::createFromFormat('d/m/Y', $_GET['end_date']) 
        ? DateTime::createFromFormat('d/m/Y', $_GET['end_date'])->format('Y-m-d') 
        : $_GET['end_date'];
}

// =========================================================================
// 🛠 ၅။ တိုင်းနှင့် မြို့နယ်အလိုက် ဒေတာကို စစ်ထုတ်မည့် SQL Condition
// =========================================================================
$loc_cond = "";
if ($user_state !== '-' && $user_state !== '' && $user_township !== '-' && $user_township !== '') {
    $loc_cond = " AND state_name = '$user_state' AND township_name = '$user_township'";
} else {
    $loc_cond = " AND state_name = 'မန္တလေးတိုင်းဒေသကြီး' AND township_name = 'ချမ်းမြသာစည်မြို့နယ်'";
}

// =========================================================================
// 🎯 ၆။ အမှုတွဲစုစုပေါင်းကို အကုန်ရေတွက်ပြီး Query ထုတ်ခြင်း
// =========================================================================
$main_sql = "
    /* (၁) ဝင်ငွေခွန် - Current Year Demand */
    SELECT 'ဝင်ငွေခွန်' AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(taxpanaty,'0') != '0' AND IFNULL(taxpanaty,'0') != '' AND (REPLACE(IFNULL(taxpanaty,'0'), ',', '') + 0 - REPLACE(IFNULL(taxpanatyPaid,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(taxpanaty,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(taxpanatyPaid,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM regular_data
    WHERE taxYear = '$tax_year' 
      AND it_select IS NOT NULL 
      AND it_select != ''
      AND itDemandDate BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond

    UNION ALL

    /* (၂) ဝင်ငွေခွန် - Late Year Demand */
    SELECT 'ဝင်ငွေခွန် (Late)' AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(taxpanaty,'0') != '0' AND IFNULL(taxpanaty,'0') != '' AND (REPLACE(IFNULL(taxpanaty,'0'), ',', '') + 0 - REPLACE(IFNULL(taxpanatyPaid,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(taxpanaty,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(taxpanatyPaid,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM regular_data
    WHERE taxYear < '$tax_year' 
      AND it_select IS NOT NULL 
      AND it_select != ''
      AND itDemandDate BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond

    UNION ALL

    /* (၃) ကုန်သွယ်လုပ်ငန်းခွန်-၁ - Current Year Demand */
    SELECT 'ကုန်သွယ်လုပ်ငန်းခွန်-၁' AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(totalTax1,'0') != '0' AND IFNULL(totalTax1,'0') != '' AND (REPLACE(IFNULL(totalTax1,'0'), ',', '') + 0 - REPLACE(IFNULL(paidTax1,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(totalTax1,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(paidTax1,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM regular_data
    WHERE taxYear = '$tax_year' 
      AND ct1_select_real IS NOT NULL 
      AND ct1_select_real != ''
      AND ct1DemandDate BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond

    UNION ALL

    /* (၄) ကုန်သွယ်လုပ်ငန်းခွန်-၁ - Late Year Demand */
    SELECT 'ကုန်သွယ်လုပ်ငန်းခွန်-၁ (Late)' AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(totalTax1,'0') != '0' AND IFNULL(totalTax1,'0') != '' AND (REPLACE(IFNULL(totalTax1,'0'), ',', '') + 0 - REPLACE(IFNULL(paidTax1,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(totalTax1,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(paidTax1,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM regular_data
    WHERE taxYear < '$tax_year' 
      AND ct1_select_real IS NOT NULL 
      AND ct1_select_real != ''
      AND ct1DemandDate BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond

    UNION ALL

    /* (၅) ကုန်သွယ်လုပ်ငန်းခွန်-၂ - Current Year Demand */
    SELECT 'ကုန်သွယ်လုပ်ငန်းခွန်-၂' AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(totalTax2,'0') != '0' AND IFNULL(totalTax2,'0') != '' AND (REPLACE(IFNULL(totalTax2,'0'), ',', '') + 0 - REPLACE(IFNULL(paidTax2,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(totalTax2,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(paidTax2,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM regular_data
    WHERE taxYear = '$tax_year' 
      AND ct2_select_real IS NOT NULL 
      AND ct2_select_real != ''
      AND ct2DemandDate BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond

    UNION ALL

    /* (၆) ကုန်သွယ်လုပ်ငန်းခွန်-၂ - Late Year Demand */
    SELECT 'ကုန်သွယ်လုပ်ငန်းခွန်-၂ (Late)' AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(totalTax2,'0') != '0' AND IFNULL(totalTax2,'0') != '' AND (REPLACE(IFNULL(totalTax2,'0'), ',', '') + 0 - REPLACE(IFNULL(paidTax2,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(totalTax2,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(paidTax2,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM regular_data
    WHERE taxYear < '$tax_year' 
      AND ct2_select_real IS NOT NULL 
      AND ct2_select_real != ''
      AND ct2DemandDate BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond

    UNION ALL

    /* (ခ) sakalakahdata */
    SELECT gir_type AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(total_tax,'0') != '0' AND IFNULL(total_tax,'0') != '' AND (REPLACE(IFNULL(total_tax,'0'), ',', '') + 0 - REPLACE(IFNULL(paid_amount,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(total_tax,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(paid_amount,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM sakalakahdata
    WHERE tax_year = '$tax_year' AND it_demand_date BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond
    GROUP BY gir_type

    UNION ALL

    /* (ဂ) vehicledata */
    SELECT gir_type AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(total_tax,'0') != '0' AND IFNULL(total_tax,'0') != '' AND (REPLACE(IFNULL(total_tax,'0'), ',', '') + 0 - REPLACE(IFNULL(paid_amount,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(total_tax,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(paid_amount,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM vehicledata
    WHERE tax_year = '$tax_year' AND it_demand_date BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond
    GROUP BY gir_type

    UNION ALL

    /* (ဃ) sharedata */
    SELECT gir_type AS business_type,
           COUNT(id) as total_cases,
           COUNT(CASE WHEN IFNULL(total_tax,'0') != '0' AND IFNULL(total_tax,'0') != '' AND (REPLACE(IFNULL(total_tax,'0'), ',', '') + 0 - REPLACE(IFNULL(paid_amount,'0'), ',', '') + 0) = 0 THEN id END) as paid_cases,
           SUM(CAST(REPLACE(IFNULL(total_tax,'0'), ',', '') AS UNSIGNED)) as demand_tax,
           SUM(CAST(REPLACE(IFNULL(paid_amount,'0'), ',', '') AS UNSIGNED)) as paid_tax
    FROM sharedata
    WHERE tax_year = '$tax_year' AND it_demand_date BETWEEN '$start_date_reg' AND '$end_date_reg' $loc_cond
    GROUP BY gir_type
";

$result = $conn->query($main_sql);

// =========================================================================
// 🎯 ၇။ REPORT Template သတ်မှတ်ချက်
// =========================================================================
$report_rows = [
    'ဝင်ငွေခွန်' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'ဝင်ငွေခွန် (Late)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'ကုန်သွယ်လုပ်ငန်းခွန်-၁' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'ကုန်သွယ်လုပ်ငန်းခွန်-၁ (Late)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'ကုန်သွယ်လုပ်ငန်းခွန်-၂' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'ကုန်သွယ်လုပ်ငန်းခွန်-၂ (Late)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'စကလက(အိမ်မြေ)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'အခြေ(အိမ်မြေ)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'စကလက(ယာဉ်)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'အခြေ(ယာဉ်)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'စကလက(ရေယာဉ်)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'အခြေ(ရေယာဉ်)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'စကလက(ရှယ်ယာ)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'အခြေ(ရှယ်ယာ)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0],
    'စကလက(အခြား)' => ['total_cases' => 0, 'paid_cases' => 0, 'demand_tax' => 0, 'paid_tax' => 0]
];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $db_type = trim($row['business_type']);
        if (empty($db_type)) continue;

        $target_key = '';

        if (strpos($db_type, 'ဝင်ငွေခွန်') !== false) {
            if (strpos($db_type, 'Late') !== false || strpos($db_type, 'late') !== false) {
                $target_key = 'ဝင်ငွေခွန် (Late)';
            } else {
                $target_key = 'ဝင်ငွေခွန်';
            }
        } 
        elseif (strpos($db_type, 'ကုန်သွယ်လုပ်ငန်းခွန်') !== false && (strpos($db_type, '၁') !== false || strpos($db_type, '1') !== false)) {
            if (strpos($db_type, 'Late') !== false || strpos($db_type, 'late') !== false) {
                $target_key = 'ကုန်သွယ်လုပ်ငန်းခွန်-၁ (Late)';
            } else {
                $target_key = 'ကုန်သွယ်လုပ်ငန်းခွန်-၁';
            }
        } 
        elseif (strpos($db_type, 'ကုန်သွယ်လုပ်ငန်းခွန်') !== false && (strpos($db_type, '၂') !== false || strpos($db_type, '2') !== false)) {
            if (strpos($db_type, 'Late') !== false || strpos($db_type, 'late') !== false) {
                $target_key = 'ကုန်သွယ်လုပ်ငန်းခွန်-၂ (Late)';
            } else {
                $target_key = 'ကုန်သွယ်လုပ်ငန်းခွန်-၂';
            }
        } 
        elseif (strpos($db_type, 'စကလက') !== false && strpos($db_type, 'အိမ်မြေ') !== false) {
            $target_key = 'စကလက(အိမ်မြေ)';
        } elseif (strpos($db_type, 'အခြေ') !== false && strpos($db_type, 'အိမ်မြေ') !== false) {
            $target_key = 'အခြေ(အိမ်မြေ)';
        } elseif (strpos($db_type, 'စကလက') !== false && strpos($db_type, 'ယာဉ်') !== false && strpos($db_type, 'ရေ') === false) {
            $target_key = 'စကလက(ယာဉ်)';
        } elseif (strpos($db_type, 'အခြေ') !== false && strpos($db_type, 'ယာဉ်') !== false && strpos($db_type, 'ရေ') === false) {
            $target_key = 'အခြေ(ယာဉ်)';
        } elseif (strpos($db_type, 'စကလက') !== false && strpos($db_type, 'ရေယာဉ်') !== false) {
            $target_key = 'စကလက(ရေယာဉ်)';
        } elseif (strpos($db_type, 'အခြေ') !== false && strpos($db_type, 'ရေယာဉ်') !== false) {
            $target_key = 'အခြေ(ရေယာဉ်)';
        } elseif (strpos($db_type, 'စကလက') !== false && strpos($db_type, 'ရှယ်ယာ') !== false) {
            $target_key = 'စကလက(ရှယ်ယာ)';
        } elseif (strpos($db_type, 'အခြေ') !== false && strpos($db_type, 'ရှယ်ယာ') !== false) {
            $target_key = 'အခြေ(ရှယ်ယာ)';
        } elseif (strpos($db_type, 'အခြား') !== false) {
            $target_key = 'စကလက(အခြား)';
        }

        if (!empty($target_key) && isset($report_rows[$target_key])) {
            $report_rows[$target_key]['total_cases'] += intval($row['total_cases'] ?? 0);
            $report_rows[$target_key]['paid_cases']  += intval($row['paid_cases'] ?? 0); 
            $report_rows[$target_key]['demand_tax']  += floatval($row['demand_tax'] ?? 0);
            $report_rows[$target_key]['paid_tax']    += floatval($row['paid_tax'] ?? 0);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>အခွန်ကောက်ခံရရှိမှု အစီရင်ခံစာ ပုံစံ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background-color: #f1f3f5; font-family: 'Pyidaungsu', 'Segoe UI', sans-serif; font-size: 14px; }
        .top-green-banner { background-color: #00e676; color: #000; font-weight: bold; text-align: center; padding: 10px; font-size: 16px; }
        .filter-card { background: #ffffff; border-radius: 8px; padding: 15px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
        .report-title-section { text-align: center; margin: 20px 0; }
        .table-custom th { background-color: #f8f9fa !important; color: #000; text-align: center; vertical-align: middle; border: 1.5px solid #dee2e6 !important; font-weight: bold; }
        .table-custom td { text-align: center; vertical-align: middle; border: 1.5px solid #dee2e6 !important; }
        .text-end-custom { text-align: right !important; padding-right: 15px !important; }
        .text-start-custom { text-align: left !important; padding-left: 10px !important; }
  
        @media print { .filter-card, .top-green-banner { display: none !important; } }
    </style>
</head>
<body>

<div class="top-green-banner">
    <h4>အခွန်အမျိုးအစားအလိုက် စည်းကြပ်တောင်းခံခြင်း၊ ကောက်ခံရရှိခြင်းနှင့် ကောက်ခံရန်ကျန်ရှိမှု စာရင်းဇယား</h4>
</div>

<div class="container mt-3">
    <div class="filter-card">
        <form method="GET" action="" class="row g-3 align-items-center justify-content-center">
            <div class="col-md-3">
                <div class="input-group input-group-sm">
                    <span class="input-group-text fw-bold">စည်းကြပ်နှစ်</span>
                    <select name="tax_year" class="form-select" onchange="location.href='tax_collection_report.php?tax_year=' + this.value;">
                        <?php
                        $years = ['2024-2025', '2025-2026', '2026-2027'];
                        foreach ($years as $y) {
                            echo "<option value='$y' ".($tax_year == $y ? 'selected' : '').">$y</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">

            <div class="col-md-2">
                <div class="input-group input-group-sm">
                    <span class="input-group-text fw-bold">Start Date</span>
                    <input type="text" id="start_date" name="start_date" class="form-control bg-white" 
                        value="<?= !empty($start_date_reg) ? date('d/m/Y', strtotime($start_date_reg)) : '' ?>" 
                        placeholder="dd/mm/yyyy">
                </div>
            </div>

            <div class="col-md-2">
                <div class="input-group input-group-sm">
                    <span class="input-group-text fw-bold">End Date</span>
                    <input type="text" id="end_date" name="end_date" class="form-control bg-white" 
                        value="<?= !empty($end_date_reg) ? date('d/m/Y', strtotime($end_date_reg)) : '' ?>" 
                        placeholder="dd/mm/yyyy">
                </div>
            </div>

            <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
            <script>
                flatpickr("#start_date", { dateFormat: "d/m/Y", allowInput: true });
                flatpickr("#end_date", { dateFormat: "d/m/Y", allowInput: true });
            </script>

            <div class="col-md-5 d-flex gap-2 justify-content-end">
                <button type="submit" class="btn btn-sm btn-primary px-3"><i class="fa-solid fa-eye"></i> VIEW</button>
                <button type="button" onclick="exportTableToExcel()" class="btn btn-sm btn-success px-3"><i class="fa-solid fa-file-excel"></i> Export Excel</button>
                <button type="button" onclick="window.print()" class="btn btn-sm btn-outline-secondary px-3"><i class="fa-solid fa-print"></i> Print</button>
                <a href="dashboard.php" class="btn btn-sm btn-danger px-3"><i class="fa-solid fa-circle-xmark"></i> CLOSE</a>
            </div>
        </form>
    </div>

    <div class="report-title-section" id="report-header-area">
        <h6 class="fw-bold my-1">ဘဏ္ဍာရေးနှင့်အခွန်ဝန်ကြီးဌာန</h6>
        <h6 class="fw-bold text-decoration-underline">ပြည်တွင်းအခွန်များဦးစီးဌာန</h6>
        <h7 class="fw-bold text-decoration-underline"><?= htmlspecialchars($user_township) ?>အခွန်များဦးစီးဌာနမှူးရုံး</h6>
        <p class="fw-bold small text-muted mt-2">( <?= htmlspecialchars(date('d-m-Y', strtotime($start_date_reg))) ?> ) ရက်မှ ( <?= htmlspecialchars(date('d-m-Y', strtotime($end_date_reg))) ?> ) ရက်နေ့အထိ အခွန်ကောက်ခံရရှိမှုစာရင်း</p>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover table-custom" id="taxReportTable">
            <thead class="table-dark text-center align-middle">
                <tr>
                    <th>စဉ်</th>
                    <th>လုပ်ငန်းအမျိုးအစား</th>
                    <th>စည်းကြပ် (အမှု) ပေါင်း</th>
                    <th>ပေးသွင်းပြီး (အမှု)</th>
                    <th>ပေးသွင်းရန်ကျန် (အမှု)</th> 
                    <th>စည်းကြပ်တောင်းခံ (ကျပ်)</th>
                    <th>ပေးသွင်းပြီး (ကျပ်)</th>
                    <th>ပေးသွင်းရန်ကျန် (ကျပ်)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $i = 1;
                $grand_cases        = 0;
                $grand_paid_cases   = 0;
                $grand_pending_cases= 0;
                $grand_demand       = 0;
                $grand_paid         = 0;

                foreach ($report_rows as $b_type => $row) {
                    $cases      = intval($row['total_cases'] ?? 0);
                    $paid_cases = intval($row['paid_cases'] ?? 0);
                    $pending_cases = $cases - $paid_cases; 
                    
                    $demand     = floatval($row['demand_tax'] ?? 0);
                    $paid       = floatval($row['paid_tax'] ?? 0);
                    $remain     = $demand - $paid;

                    $grand_cases         += $cases;
                    $grand_paid_cases    += $paid_cases;
                    $grand_pending_cases += $pending_cases;
                    $grand_demand        += $demand;
                    $grand_paid          += $paid;
                    ?>
                    <tr class="text-center align-middle">
                        <td><?= $i++ ?></td>
                        <td class="text-start-custom"><?= htmlspecialchars($b_type) ?></td>
                        <td><?= number_format($cases) ?></td>
                        <td><?= number_format($paid_cases) ?></td>
                        <td class="<?= $pending_cases > 0 ? 'text-danger fw-bold' : '' ?>">
                            <?= number_format($pending_cases) ?>
                        </td>
                        <td class="text-end-custom"><?= number_format($demand) ?></td>
                        <td class="text-end-custom"><?= number_format($paid) ?></td>
                        <td class="text-end-custom <?= $remain > 0 ? 'text-danger fw-bold' : '' ?>"><?= number_format($remain) ?></td>
                    </tr>
                    <?php
                }
                $grand_remain = $grand_demand - $grand_paid;
                ?>
                
                <tr class="table-light fw-bold text-center align-middle">
                    <td colspan="2">စုစုပေါင်း</td>
                    <td><?= number_format($grand_cases) ?></td>
                    <td><?= number_format($grand_paid_cases) ?></td>
                    <td class=""><?= number_format($grand_pending_cases) ?></td> 
                    <td class="text-end-custom"><?= number_format($grand_demand) ?></td>
                    <td class="text-end-custom"><?= number_format($grand_paid) ?></td>
                    <td class="text-end-custom "><?= number_format($grand_remain) ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script>
function exportTableToExcel() {
    // 🎯 ၁။ ခေါင်းစည်းစာသားများကို Excel Column ၈ ခုလုံးရဲ့ အလယ်ဗဟို ရောက်အောင် သတ်မှတ်ခြင်း
    let excelTemplate = `
    <table>
        <tr><td colspan="8" style="text-align:center; font-weight:bold; font-size:16px;">ဘဏ္ဍာရေးနှင့်အခွန်ဝန်ကြီးဌာန</td></tr>
        <tr><td colspan="8" style="text-align:center; font-weight:bold; font-size:16px; ">ပြည်တွင်းအခွန်များဦးစီးဌာန</td></tr>
        <tr><td colspan="8" style="text-align:center; font-weight:bold; font-size:16px; "><?= htmlspecialchars($user_township) ?>အခွန်များဦးစီးဌာနမှူးရုံး</td></tr>
        <tr><td colspan="8" style="text-align:center; font-weight:bold; font-size:15px; ">( <?php echo date('d-m-Y', strtotime($start_date_reg)); ?> ) ရက်မှ ( <?php echo date('d-m-Y', strtotime($end_date_reg)); ?> ) ရက်နေ့အထိ အခွန်ကောက်ခံရရှိမှုစာရင်း</td></tr>
        
    `;
    
    let table = document.getElementById("taxReportTable");
    
    // 🎯 ၂။ ဇယား ခေါင်းစဉ်ပိုင်း (Thead)
    let thead = table.querySelector("thead");
    if(thead) {
        excelTemplate += "<tr>";
        for (let cell of thead.rows[0].cells) {
            excelTemplate += `<th style="background-color:#343a40; color:#ffffff; font-weight:bold; border:1px solid #dee2e6; text-align:center;">${cell.innerText}</th>`;
        }
        excelTemplate += "</tr>";
    }

    // 🎯 ၃။ ဇယားကိုယ်ထည်ပိုင်း (Tbody)
    let tbody = table.querySelector("tbody");
    if(tbody) {
        for (let row of tbody.rows) {
            let isTotalRow = row.classList.contains("table-light") || row.innerText.includes("စုစုပေါင်း");
            excelTemplate += "<tr>";
            
            if (isTotalRow) {
                // 💡 (က) စုစုပေါင်း Row အတွက် ညာဘက် ၃ ကွက်အား Align Right ပြုလုပ်ခြင်း
                excelTemplate += `<td colspan="2" style="text-align:center; font-weight:bold; background-color:#f8f9fa; border:1px solid #dee2e6;">စုစုပေါင်း</td>`;
                
                for (let k = 1; k < row.cells.length; k++) {
                    let cellText = row.cells[k].innerText.replace(/,/g, '').trim();
                    
                    // နောက်ဆုံး ကော်လံ ၃ ခု (Index: 5, 6, 7 ဖြစ်မည့် ဆဲလ်များ) ကို ညာဘက်ကပ်ပြီး Space ချန်ခြင်း
                    if (k >= 4) { 
                        excelTemplate += `<td style="text-align:right; font-weight:bold; background-color:#f8f9fa; border:1px solid #dee2e6; mso-number-format:'\\#\\,\\#\\#၀';">${cellText}&nbsp;&nbsp;</td>`;
                    } else {
                        excelTemplate += `<td style="text-align:center; font-weight:bold; background-color:#f8f9fa; border:1px solid #dee2e6;">${cellText}</td>`;
                    }
                }
            } else {
                // 💡 (ခ) သာမန် လုပ်ငန်းအမျိုးအစား Row များအတွက် ညာဘက် ၃ ကွက်အား Align Right ပြုလုပ်ခြင်း
                let cellIndex = 0;
                for (let cell of row.cells) {
                    let cellText = cell.innerText.replace(/,/g, '').trim();
                    let cellStyle = "text-align:center;";
                    
                    if (cellIndex === 1) {
                        // လုပ်ငန်းအမျိုးအစားကို ဘယ်ကပ်မည်
                        cellStyle = "text-align:left;";
                    } else if (cellIndex >= 5) {
                        // 🎯 ညာဘက်အစွန်ဆုံး ငွေကြေးကော်လံ ၃ ခုကို ညာကပ်ပြီး Space ချန်မည်၊ ကော်မာ Format သတ်မှတ်မည်
                        cellStyle = "text-align:right; mso-number-format:'\\#\\,\\#\\#၀';";
                        cellText = cellText + "&nbsp;&nbsp;";
                    }
                    
                    excelTemplate += `<td style="${cellStyle} border:1px solid #dee2e6;">${cellText}</td>`;
                    cellIndex++;
                }
            }
            excelTemplate += "</tr>";
        }
    }
    
    excelTemplate += "</table>";

    // 🎯 ၄။ Excel ဖိုင်အဖြစ် ဒေါင်းလုဒ် ပြုလုပ်ခြင်း
    let excelBlob = new Blob(["\uFEFF" + excelTemplate], { type: "application/vnd.ms-excel;charset=utf-8;" });
    let link = document.createElement("a");
    
    if (link.download !== undefined) {
        let url = URL.createObjectURL(excelBlob);
        link.setAttribute("href", url);
        link.setAttribute("download", "Tax_Collection_Report_<?php echo $tax_year; ?>.xls");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}
</script>
</script>

</body>
</html>