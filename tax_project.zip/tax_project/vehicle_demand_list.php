<?php
// 🎯 PHP Warning တွေကြောင့် JS အလုပ်မလုပ်တော့တဲ့ ပြဿနာကို အပြီးတိုင် ပိတ်ပစ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) session_start();

include_once 'db_config.php'; 
$conn->set_charset("utf8mb4");

// ၁။ Session မှ တန်ဖိုးများယူခြင်း
$user_state    = $_SESSION['user_state'] ?? ($_SESSION['state_name'] ?? '-');
$user_township = $_SESSION['user_township'] ?? ($_SESSION['township_name'] ?? '-');
$user_region   = $_SESSION['user_region'] ?? ($_SESSION['region'] ?? 'နယ်မြေ');
$rank          = $_SESSION['rank_'] ?? ($_SESSION['user_rank'] ?? 'အခွန်ဦးစီးမှူး');

// ၂။ Search နှင့် Filter စနစ်ဆိုင်ရာ Variable များ ဖမ်းယူခြင်း
$search_query = isset($_GET['search']) ? trim($conn->real_escape_string($_GET['search'])) : '';
$from_num     = isset($_GET['from_num']) ? intval($_GET['from_num']) : 0;
$to_num       = isset($_GET['to_num']) ? intval($_GET['to_num']) : 0;

// ၃။ Filter WHERE Clause ကို တည်ဆောက်ခြင်း
$where_conditions = [];

// Session Data ရှိမှသာ Filter လုပ်ပါ (စစ်ဆေးချက် မှန်ကန်ပါသည်)
//if ($user_state !== '-' && $user_township !== '-') {
 //   $where_conditions[] = "s.state_name = '$user_state' AND s.township_name = '$user_township'";
//}

if (!empty($search_query)) {
    $where_conditions[] = "(s.case_number LIKE '%$search_query%' OR s.taxpayer_name LIKE '%$search_query%' OR s.nrc_no LIKE '%$search_query%')";
}

if ($from_num > 0) $where_conditions[] = "CAST(SUBSTRING_INDEX(s.case_number, '/', 1) AS UNSIGNED) >= $from_num";
if ($to_num > 0) $where_conditions[] = "CAST(SUBSTRING_INDEX(s.case_number, '/', 1) AS UNSIGNED) <= $to_num";

$where_clause = count($where_conditions) > 0 ? " WHERE " . implode(" AND ", $where_conditions) : "";

// ၄။ Sum Query တွက်ချက်ခြင်း (🎯 ပြင်ဆင်ချက် - FROM vehicledata ဘေးတွင် s ထည့်ပေးထားပါသည်)
$sum_query = "SELECT 
                SUM(CAST(REPLACE(s.total_tax, ',', '') AS UNSIGNED)) as total_demand_tax,
                SUM(CAST(REPLACE(s.paid_amount, ',', '') AS UNSIGNED)) as total_paid_tax,
                COUNT(s.id) as total_cases,
                SUM(CASE WHEN (s.paid_amount IS NOT NULL AND s.paid_amount != '' AND CAST(REPLACE(s.paid_amount, ',', '') AS UNSIGNED) > 0) THEN 1 ELSE 0 END) as paid_cases,
                SUM(CASE WHEN (CAST(REPLACE(s.total_tax, ',', '') AS UNSIGNED) > CAST(REPLACE(s.paid_amount, ',', '') AS UNSIGNED)) THEN 1 ELSE 0 END) as remain_cases
              FROM vehicledata s" . $where_clause;

$sum_result = $conn->query($sum_query);
$sum_data = $sum_result ? $sum_result->fetch_assoc() : [];

// Variable များကို သတ်မှတ်ပေးခြင်း
$total_valuation = $sum_data['total_demand_tax'] ?? 0;
$total_paid      = $sum_data['total_paid_tax'] ?? 0;
$total_remain    = $total_valuation - $total_paid;

$total_cases_count  = $sum_data['total_cases'] ?? 0;
$paid_cases_count   = $sum_data['paid_cases'] ?? 0;
$remain_cases_count = $sum_data['remain_cases'] ?? 0;

$limit = 16;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

// 🎯 ပြင်ဆင်ချက် - FROM vehicledata ဘေးတွင် s ထည့်ပေးထားပါသည်
$total_query = "SELECT COUNT(*) AS total FROM vehicledata s" . $where_clause;
$total_result = $conn->query($total_query);
$total_rows = $total_result ? ($total_result->fetch_assoc()['total'] ?? 0) : 0;
$total_pages = ceil($total_rows / $limit);

// 🎯 ပြင်ဆင်ချက် - Data ဆွဲထုတ်မည့် Query ကို စနစ်တကျ ပြန်လည်ပြင်ဆင်ခြင်း
$sql = "SELECT s.*, '' AS officer_rank FROM vehicledata s" . $where_clause . " ORDER BY s.id DESC LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);

// 🎯 ဒေတာဘေ့စ် Query မှာ အမှားရှိရင် စခရင်ပေါ်မှာ အဖြေထုတ်ပြခိုင်းမည့်ကုဒ်
if (!$result) {
    die("SQL Error တက်နေပါသည်- " . $conn->error . "<br>ယခုအလုပ်လုပ်နေသော Query မှာ: " . $sql);
}

// ဒဿမ .00 များကို ဖျက်ပြီး Comma ခံရန်အတွက် Function
function formatMyanmarNumber($value) {
    if (empty($value) || $value == '-' || $value == '0') return '0';
    $clean_value = floatval(str_replace(',', '', $value));
    return number_format($clean_value, 0, '.', ',');
}

// URL ထဲတွင် ရှိနေသမျှ Parameter များကို သိမ်းဆည်းပေးသည့်စနစ်
$queryString = $_GET;
unset($queryString['page']); 
$keepFilters = http_build_query($queryString); 
$keepFilters = $keepFilters ? '&' . $keepFilters : ''; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ဝင်ငွေခွန် စည်းကြပ်မှုမှတ်တမ်းပုံစံ</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css">
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/custom_style.css">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>
    body {
        background-color: #f8f9fa;
        font-family: 'Pyidaungsu', 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        font-size: 14px;
    }
    .header-bar {
        background-color: #0b5ed7;
        color: white;
        padding: 10px 20px;
        font-weight: bold;
        font-size: 18px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .summary-badge {
        font-size: 15px;
        font-weight: bold;
        padding: 8px 12px;
        border-radius: 10px;
        color: white;
        display: inline-block;
        min-width: 200px;
    }
    .bg-demand { background-color: #1e45a9; }
    .bg-paid { background-color: #198754; }
    .bg-remain { background-color: #b02a37; }
    
    .case-count-text {
        font-size: 13px;
        font-weight: bold;
        background-color: rgba(255, 255, 255, 0.25);
        color: #ffffff !important;
        padding: 2px 10px;
        border-radius: 20px;
        margin-left: 6px;
        display: inline-block;
    }
    
    .table thead tr.table-custom-header th,
    .table-custom-header {
        background-color: #fad157 !important;
        color: #000000 !important;
        font-weight: bold;
        text-align: center !important;
        vertical-align: middle !important;
        font-size: 13px;
        height: 35px;
    }
    
    .table-responsive {
        background: white;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0px 4px 10px rgba(9, 8, 8, 0.05);
        margin-top: 15px;
        position: relative;
        overflow-x: auto;
    }
    
    .table th, .table td {
        vertical-align: middle !important;

        white-space: nowrap;
    }

    .table {
        table-layout: auto !important;
        width: 100% !important;
    }
    

    .address-col {
    max-width: 170px !important;
    min-width: 170px !important;
    width: 170px !important;
    white-space: nowrap !important;
    overflow: hidden !important;
    text-overflow: ellipsis !important;
    
    /* ❌ display: inline-block; ကို ဖျက်လိုက်ပါသည် */
    
    /* 🎯 ဇယားကွက် မပျက်ဘဲ အလယ်ကွက်တိ ဖြစ်စေရန် Table-cell အတိုင်း ထားပါသည် */
    display: table-cell !important; 
    vertical-align: middle !important;
    text-align: start !important;
}

    .sticky-action-col {
        position: sticky !important;
        right: 0 !important;
        background-color: #eff3af !important;
        box-shadow: -4px 0px 8px rgba(0, 0, 0, 0.1);
        z-index: 5;
        min-width: 150px !important;
        max-width: 150px !important;
    }
    
    th.sticky-action-col {
        background-color: #ffd966 !important;
        z-index: 6;
    }
    
    .table-hover tbody tr:hover td.sticky-action-col {
        background-color: #5f5fda !important;
    }


    .pagination .page-link {
        color: #007bff;
        background-color: #fff;
        border: 1px solid #dee2e6;
        font-weight: bold;
        border-radius: 4px;
    }

    .pagination .page-item.active .page-link {
        z-index: 3;
        color: #fff;
        background-color: #007bff;
        border-color: #007bff;
    }

    .pagination .page-item.disabled .page-link {
        color: #6c757d;
        pointer-events: none;
        background-color: #fff;
        border-color: #dee2e6;
    }


    /* အဆိုပြုလွှာဇယားအတွက် အဓိကပြင်ဆင်ချက် */
#proposalTable { 
        width: 100%; 
        border-collapse: collapse; 
        table-layout: fixed; /* အရေးကြီး: ကော်လံအကျယ် Fix လုပ်ပေးသည် */
    }
    #proposalTable th, #proposalTable td {
        border: 0.5pt solid black !important;
        padding: 5px !important;
        vertical-align: top !important;
        word-wrap: break-word !important; /* စာသားအပြင်မထွက်အောင် */
        white-space: normal !important;   /* စာသားအောက်ဆင်းအောင် */
    }

    /* Row height ကို အတင်းမြင့်ပေးခြင်း */
    #proposalTable tbody tr {
        height: 50px !important;           /* ဤနေရာတွင် လိုသလို တိုး/လျှော့ လုပ်ပါ */
    }
    .address-col { word-break: break-all; }




/*အမှုတွဲပုံစံများ*/
   
.btn-grid {        
    display: block;        
    width: 100%;        
    height: 90%;        
    padding: .5rem;        
    font-size: 1rem;        
    line-height: 1.6;        
    text-align: left;        
    vertical-align: middle;        
    border: 2px solid;        
    border-radius: 0.5rem;        
    transition: all 0.3s ease;    
}    
.btn-grid:hover {        
    background-color: transparent;        
    transform: translateY(-5px);    
}

@media print {
    @page {
        size: legal landscape; /* Legal Paper Landscape */
        margin: 0.5in;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        font-family: 'Pyidaungsu', sans-serif;
    }
    th, td {
        border: 1px solid black !important; /* ဘောင်ခတ်ခြင်း */
        padding: 5px;
        text-align: center;
    }
    .header-info {
        text-align: center;
        font-weight: bold;
        font-size: 14pt;
        margin-bottom: 20px;
    }
    .2nd-row{border: none !important;}
    #printableTable tr:nth-child(1) td,
    #printableTable tr:nth-child(2) td,
    table tr.print-no-border td {
        border: none !important;
        border-top: none !important;
        border-bottom: none !important;
        border-left: none !important;
        border-right: none !important;
    }
}
</style>
</head>
<body>

<div class="header-bar">
    <div>| ဝင်ငွေခွန် စည်းကြပ်မှုမှတ်တမ်းပုံစံ</div>
    <div>မော်တော်ယာဉ်/ရေယာဉ်</div>
    <div style="font-size: 15px;"><i class="fa-solid fa-location-dot text-danger"></i> 
    <?= htmlspecialchars($user_township ?: $user_state ?: 'All Regions') ?>အခွန်ဦးစီးဌာနမှူးရုံး</div>
</div>

<!--<div class="container-fluid mt-3">-->
<div class="container-fluid mt-4" id="mainDemandList">
    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="summary-badge bg-demand w-100 shadow-sm d-flex justify-content-between align-items-center">
                <div>
                    <span>စည်းကြပ်တောင်းခံ-</span> 
                    <span class="case-count-text">( <?php echo number_format($total_cases_count); ?> ) မူ</span>
                </div>
                <span class="fw-bold"><?php echo number_format($total_valuation); ?></span>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-badge bg-paid w-100 shadow-sm d-flex justify-content-between align-items-center">
                <div>
                    <span>ပေးသွင်းငွေ-</span> 
                    <span class="case-count-text">( <?php echo number_format($paid_cases_count); ?> ) မူ</span>
                </div>
                <span class="fw-bold"><?php echo number_format($total_paid); ?></span>
            </div>
        </div>
        <div class="col-md-4">
            <div class="summary-badge bg-remain w-100 shadow-sm d-flex justify-content-between align-items-center">
                <div>
                    <span>ပေးသွင်းရန်ကျန်-</span> 
                    <span class="case-count-text">( <?php echo number_format($remain_cases_count); ?> ) မူ</span>
                </div>
                <span class="fw-bold"><?php echo number_format($total_remain); ?></span>
            </div>
        </div>
    </div>

    <div class="card p-3 shadow-sm mb-3">
    <form method="GET" action="vehicle_demand_list.php" class="row g-3 align-items-center">
        <div class="col-xl-1 col-lg-1 col-md-1">
            <input type="number" name="from_num" id="minCase" class="form-control form-control-sm" value="<?php echo $from_num > 0 ? $from_num : ''; ?>" placeholder="မှ">
        </div>

        <div class="col-xl-1 col-lg-1 col-md-1">
            <input type="number" name="to_num" id="maxCase" class="form-control form-control-sm" value="<?php echo $to_num > 0 ? $to_num : ''; ?>" placeholder="ထိ">
        </div>
        
        <div class="col-xl-1 col-lg-2 col-md-2 d-flex gap-1">
            <button type="submit" class="btn btn-sm btn-outline-secondary w-100"><i class="fa-solid fa-filter"></i> Filter</button>
            <a href="vehicle_demand_list.php" class="btn btn-sm btn-outline-danger" title="Filter များအားလုံးကို ဖျက်၍ မူလအတိုင်းပြန်ပြရန်">
                <i class="fa-solid fa-rotate-right"></i>
            </a>
        </div>
         <div class="col-xl-1 col-lg-1 col-md-1">
            <button type="button" class="btn btn-outline-primary btn-sm" onclick="openProposalFromUI()">
                <i class="bi bi-file-earmark-plus"></i> အဆိုပြုလွှာ
            </button>
        </div>
   

        <div class="col-xl-3 col-lg-3 col-md-3">
            <div class="input-group input-group-sm">
                <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
                <input type="text" id="search_box" name="search" class="form-control" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="အမှုတွဲ၊ အမည်၊ နိုင်ကတ် ဖြင့်ရှာရန်...">
                
                <?php if(!empty($search_query)): ?>
                    <a href="vehicle_demand_list.php" class="btn btn-outline-secondary d-flex align-items-center bg-white border-start-0 text-muted" style="border-color: #dee2e6;">
                        <i class="fa-solid fa-xmark"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="col-xl-5 col-lg-5 col-md-5 text-end">
            <div class="d-inline-flex gap-1 flex-wrap justify-content-end">
                <button type="submit" class="btn btn-sm btn-primary px-2"><i class="fa-solid fa-search"></i> ရှာဖွေရန်</button>
                <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#formsModal3">
                    အမှုတွဲ(ပုံစံ)များ
                </button>
                <button type="button" class="btn btn-sm btn-dark px-2" onclick="window.location.href='dashboard.php'"><i class="fa-solid fa-gauge"></i> Dashboard</button>
                <button class="btn btn-success btn-sm" onclick="exportVehicleDemandToExcelds()">
                    <i class="bi bi-file-earmark-excel-fill"></i> Excel
                </button>
                <button type="button" class="btn btn-sm btn-success px-2" onclick="window.location.href='vehicle_form.php'"><i class="fa-solid fa-plus"></i> စည်းကြပ်မှုအသစ်</button>
                
            </div>
        </div>
    </form>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover table-sm m-0">
            <thead>
                
            <tr class="table-custom-header">

                <th>စဉ်</th>
                <th>အမှုတွဲ အမှတ်</th>
                <th>စည်းကြပ်မှုအမှတ်</th>
                <th>စည်းကြပ် သည့်နေ့</th>
                <th>စည်းကြပ်နှစ်</th>
                <th class="text-start">အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</th> 
                <th class="text-start">အခွန်ထမ်းအမည်</th> 
                <th class="text-start">လုပ်ငန်း အမျိုးအစား</th> 
                <th class="address-col text-start">လုပ်ငန်းလိပ်စာ</th> 
                <th>သတ်မှတ်တန်ဖိုး</th>
                <th>ခွင့်ပြုငွေ</th>
                <th>သတ်မှတ်ဝင်ငွေ</th>
                <th>ကျသင့်အခွန်</th>
                <th>ကြိုတင်ခွန်</th>
                <th>တောင်းခံရန်</th>
                <th>ဒဏ်ငွေ</th>
                <th>ပေးဆောင်ရန် အခွန်</th>
                <th>ပေးသွင်းငွေ</th>
                <th>ချလန်အမှတ်</th>
                <th>ချလန်ရက်စွဲ</th>
                <th class="text-danger">ပေးသွင်းရန်ကျန်</th>
                <th class="sticky-action-col">လုပ်ဆောင်ချက်</th>
            </tr>
        </thead>
 
<tbody>
        <?php
        if ($result && $result->num_rows > 0) {
            $i = $offset + 1; 
            
            // ၁။ HTML ထဲထည့်ရန် Helper Function (while loop အပြင်ဘက်မှာ တစ်ကြိမ်ပဲ ကြေညာထားတာ ပိုကောင်းပါတယ်)
            if (!function_exists('clean_for_html')) {
                function clean_for_html($value) {
                    if ($value === null) return '';
                    $clean = preg_replace("/\r|\n/", " ", $value); // Enter (Line Break) ရှင်းထုတ်ခြင်း
                    $clean = trim($clean);
                    return htmlspecialchars($clean, ENT_QUOTES, 'UTF-8');
                }
            }
            
            while ($row = $result->fetch_assoc()) {
    
                $case_number   = htmlspecialchars($row['case_number'] ?? '');
                $taxpayer_name = htmlspecialchars($row['taxpayer_name'] ?? '');
                $township_name = htmlspecialchars($row['township_name'] ?? '');
                $business_type = htmlspecialchars($row['business_type'] ?? '');
                $address       = htmlspecialchars($row['address'] ?? '');
                $address       = str_replace(array("\r", "\n"), ' ', $address); 
                $tax_year      = htmlspecialchars($row['tax_year'] ?? '');
                $officer_name  = htmlspecialchars($row['officer_name'] ?? '');
                $officer_rank  = htmlspecialchars($row['officer_rank'] ?? 'အခွန်ဦးစီးမှူး');

                // Gir No ပြင်ဆင်ခြင်း
                $gir_type = !empty($row['gir_type']) ? trim($row['gir_type']) : '';
                $gir_no   = !empty($row['gir_no']) ? trim($row['gir_no']) : '';
                $gir_display = (!empty($gir_type) && !empty($gir_no)) ? $gir_type . "/" . $gir_no : (!empty($gir_type) ? $gir_type : "-");

                // ၂။ ဒေတာများကို ကွက်တိ Safety ဖြစ်အောင် Clean လုပ်ခြင်း
                $safe_taxpayer = clean_for_html($row['taxpayer_name']);
                $safe_township = clean_for_html($row['township_name']);
                $safe_business = clean_for_html($row['business_type']);
                $safe_officer  = clean_for_html($row['officer_name']);
                $safe_rank     = clean_for_html($row['officer_rank'] ?? 'အခွန်ဦးစီးမှူး');
                $safe_address  = clean_for_html($row['address']); // မူရင်း address အမဲအတိုင်း သုံးထားပါတယ်

                // ၃။ ကိန်းဂဏန်းနှင့် စာသားတိုများကို Clean လုပ်ခြင်း
                $safe_id          = htmlspecialchars($row['id'] ?? '', ENT_QUOTES, 'UTF-8');
                $safe_case_number = htmlspecialchars($row['case_number'] ?? '', ENT_QUOTES, 'UTF-8');
                $safe_tax_year    = htmlspecialchars($row['tax_year'] ?? '', ENT_QUOTES, 'UTF-8');
                $safe_gir_no      = htmlspecialchars($row['gir_no'] ?? '', ENT_QUOTES, 'UTF-8');
                
                // 🔥 [ဒီလိုင်းအသစ်] အဓိကလိုအပ်နေတဲ့ tax_to_pay ကို JavaScript ဘက်သို့ ပို့ရန် ပြင်ဆင်ခြင်း
                $safe_tax_to_pay  = htmlspecialchars($row['tax_to_pay'] ?? 0, ENT_QUOTES, 'UTF-8');

               // 🧹 Database ထဲက လိပ်စာ သို့မဟုတ် စာသားများတွင် Enter (Line break) ပါက ရှင်းလင်းပေးခြင်း
                $clean_address = preg_replace('/\s+/', ' ', $row['address']);
                $clean_name    = preg_replace('/\s+/', ' ', $row['taxpayer_name']);
                $clean_btype   = preg_replace('/\s+/', ' ', $row['business_type']);

                echo "<tr onclick='selectTableRow(this)' 
                    data-id='" . $row['id'] . "'
                    data-case_number='" . htmlspecialchars($row['case_number'] ?? '') . "'
                    data-tax_year='" . htmlspecialchars($row['tax_year'] ?? '') . "'
                    data-officer_name='" . htmlspecialchars($row['officer_name'] ?? '') . "'
                    data-officer_rank='" . htmlspecialchars($row['officer_rank'] ?? '') . "'
                    data-region='" . htmlspecialchars($row['region'] ?? '') . "'
                    data-state_name='" . htmlspecialchars($row['state_name'] ?? '') . "'
                    data-township_name='" . htmlspecialchars($row['township_name'] ?? '') . "'
                    
                    data-taxpayer_name='" . htmlspecialchars(str_replace(array("\r", "\n"), ' ', $row['taxpayer_name'] ?? '')) . "'
                    data-nrc_no='" . htmlspecialchars($row['nrc_no'] ?? '') . "'
                    data-gir_type='" . htmlspecialchars($row['gir_type'] ?? '') . "'
                    data-gir_no='" . htmlspecialchars($row['gir_no'] ?? '') . "'
                    data-address='" . htmlspecialchars(str_replace(array("\r", "\n"), ' ', $row['address'] ?? '')) . "'
                    data-business_type='" . htmlspecialchars(str_replace(array("\r", "\n"), ' ', $row['business_type'] ?? '')) . "'

                    data-plate_no='" . htmlspecialchars($row['plate_no'] ?? '') . "'
                    data-manufacture='" . htmlspecialchars($row['manufacture'] ?? '') . "'
                    data-brand_name='" . htmlspecialchars($row['brand_name'] ?? '') . "'
                    data-build_type='" . htmlspecialchars($row['build_type'] ?? '') . "'
                    data-chassi='" . htmlspecialchars($row['chassi'] ?? '') . "'
                    data-make_year='" . htmlspecialchars($row['make_year'] ?? '') . "'
                    data-sale_date='" . htmlspecialchars($row['sale_date'] ?? '') . "'

                    data-proposal_value='" . htmlspecialchars($row['proposal_value'] ?? '') . "'
                    data-valuation_value='" . htmlspecialchars($row['valuation_value'] ?? '') . "'
                    data-allowable_expenses='" . htmlspecialchars($row['allowable_expenses'] ?? '0') . "' 
                    data-taxable_income='" . htmlspecialchars($row['taxable_income'] ?? '0') . "' 
                    data-income_tax='" . htmlspecialchars($row['income_tax'] ?? '0') . "'
                    data-advance_tax='" . htmlspecialchars($row['advance_tax'] ?? '0') . "'
                    data-tax_to_pay='" . htmlspecialchars($row['tax_to_pay'] ?? '0') . "'
                    data-penalty_tax='" . htmlspecialchars($row['penalty_tax'] ?? '0') . "'
                    data-total_tax='" . htmlspecialchars($row['total_tax'] ?? '0') . "' 
                    data-paid_amount='" . htmlspecialchars($row['paid_amount'] ?? '0') . "' 
                    data-chalan_no='" . htmlspecialchars($row['chalan_no'] ?? '0') . "'
                    data-chalan_date='" . htmlspecialchars($row['chalan_date'] ?? '0') . "'   

                    data-notified_date='" . htmlspecialchars($row['notified_date'] ?? '') . "'
                    data-appointment_date='" . htmlspecialchars($row['appointment_date'] ?? '') . "'
                    data-appearance_date='" . htmlspecialchars($row['appearance_date'] ?? '') . "'

                    data-it_demand_no='" . htmlspecialchars($row['it_demand_no'] ?? '0') . "'
                    data-it_demand_date='" . htmlspecialchars($row['it_demand_date'] ?? '0') . "'

                    data-investigation_value='" . htmlspecialchars($row['investigation_value'] ?? '') . "'
                    data-source_of_income='" . htmlspecialchars($row['source_of_income'] ?? '') . "'
                    data-investigation='" . htmlspecialchars($row['investigation'] ?? '') . "'
                    style='cursor: pointer;'>"; // 👈 

                echo "<td>" . $i++ . "</td>";
                echo "<td><strong>" . $case_number . "</strong></td>";

                echo "<td class='text-center'>" . htmlspecialchars($row['it_demand_no'] ?? '-') . "</td>";
                echo "<td class='text-center'>" . htmlspecialchars($row['it_demand_date'] ?? '-') . "</td>";
                echo "<td class='text-center'>" . $tax_year . "</td>";
                
                echo "<td class='text-start'>" . htmlspecialchars($gir_display) . "</td>";
                echo "<td class='text-start'>" . $taxpayer_name . "</td>";
                echo "<td class='text-start'>" . $business_type . "</td>";
                echo '<td class="address-col text-start" title="' . $address . '">' . $address . '</td>';
                
                echo "<td class='text-end'>" . formatMyanmarNumber($row['valuation_value'] ?? 0) . "</td>";
                echo "<td class='text-end text-danger'>" . formatMyanmarNumber($row['allowable_expenses'] ?? 0) . "</td>";
                echo "<td class='text-end text-primary'>" . formatMyanmarNumber($row['taxable_income'] ?? 0) . "</td>";
                echo "<td class='text-end'>" . formatMyanmarNumber($row['income_tax'] ?? 0) . "</td>";
                echo "<td class='text-end text-danger'>" . formatMyanmarNumber($row['advance_tax'] ?? 0) . "</td>";
                echo "<td class='text-end'>" . formatMyanmarNumber($row['tax_to_pay'] ?? 0) . "</td>";
                echo "<td class='text-end text-danger'>" . formatMyanmarNumber($row['penalty_tax'] ?? 0) . "</td>";
                echo "<td class='text-end fw-bold text-success'>" . formatMyanmarNumber($row['total_tax'] ?? 0) . "</td>";
                echo "<td class='text-end fw-bold text-info'>" . formatMyanmarNumber($row['paid_amount'] ?? 0) . "</td>";

                echo "<td class='text-center'>" . htmlspecialchars($row['chalan_no'] ?? '-') . "</td>";
                echo "<td class='text-center'>" . htmlspecialchars($row['chalan_date'] ?? '-') . "</td>";
                
                
                
                $row_total_tax = intval(str_replace(',', '', $row['total_tax'] ?? 0));
                $row_paid_amount = intval(str_replace(',', '', $row['paid_amount'] ?? 0));
                $row_remain_amount = $row_total_tax - $row_paid_amount;
                
                $remain_text_class = $row_remain_amount > 0 ? 'text-danger fw-bold' : 'text-muted';
                echo "<td class='text-end {$remain_text_class}'>" . number_format($row_remain_amount) . "</td>";
                
                echo "<td class='sticky-action-col'>
                        <div class='d-flex justify-content-center align-items-center' style='gap: 4px;'>
                            <a href='vehicle_form.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm py-0 px-2' style='font-size: 12px;'>
                                <i class='fa-solid fa-pen-to-square'></i> Edit
                            </a>
                            <a href='javascript:void(0);' class='btn btn-danger btn-sm py-0 px-2' style='font-size: 12px;' onclick='openDeleteModal(" . intval($row['id']) . ");'>
                                    <i class='fa-solid fa-trash'></i> Delete
                            </a>
                        </div>
                    </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='20' class='text-center text-danger p-4'>သတ်မှတ်ချက်နှင့်ကိုက်ညီသော အချက်အလက်များ မရှိသေးပါ။</td></tr>";
        }
        ?>
</tbody>
        </table>
    </div>
</div>

<div id="formsModal3" class="modal fade"  tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title">အမှုတွဲပုံစံများ</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <div class="row row-cols-1 row-cols-md-2 g-3">
                    <div class="col">
                        <button type="button" class="btn btn-outline-primary w-100 text-start p-3" data-bs-dismiss="modal" onclick="openOrderSheetForm()">
                            ၁။ နေ့စဉ်လုပ်ငန်းမှတ်တမ်း <br>&ensp;&ensp;(Order Sheet)
                        </button>
                    </div>
                 
                    <div class="col">
                        <div class="col">
                        <button type="button" class="btn btn-outline-primary btn-grid" onclick="openForm0405()">
                            ၂။ ကြားနာစစ်ဆေးရန်<br>&ensp;&ensp;အကြောင်းကြားစာ<br> &ensp;&ensp;ပတခ(ဝင)-၀၄-၀၅
                        </button>
                    </div>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-primary btn-grid" onclick="openForm0406()">
                            ၃။ သတင်းအချက်အလက်များ<br>&ensp;&ensp;ပေးပို့ရန်အကြောင်းကြားစာ<br> &ensp;&ensp;ပတခ(ဝင)-၀၄-၀၆
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-primary btn-grid" onclick="openForm0407()">
                            ၄။ ဒဏ်ကြေးငွေစည်းကြပ်မှု<br>&ensp;&ensp;ဆုံးဖြတ်ချက်<br> &ensp;&ensp;ပတခ(ဝင)-၀၄-၀၇
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-primary btn-grid" onclick="openForm0408()">
                            ၅။ ဝင်ငွေခွန်စည်းကြပ်မှု <br>&ensp;&ensp;အကြောင်းကြားစာ <br> &ensp;&ensp;ပတခ(ဝင)-၀၄-၀၈
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-primary btn-grid" onclick="openFormgeneral2()">
                            ၆။ အကြောင်းကြားစာ ချအပ်<br> &ensp;&ensp;ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း <br>&ensp;&ensp;ပတခ(ထွေ)-၂
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-primary btn-grid" onclick="openForm0301()">
                            ၇။ ဝင်ငွေကြေညာလွှာ <br>&ensp;&ensp;ပတခ(ဝင)-၀၃-၀၁(ဂ)
                        </button>
                    </div>
                    <div class="col">
                        <button class="btn btn-outline-primary btn-grid" onclick="openForm0409()">
                            ၈။ တွက်ချက်မှုပုံစံ
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--//delete model-->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title" id="deleteModalLabel"><i class="fa-solid fa-exclamation-triangle"></i> အတည်ပြုရန် လိုအပ်ပါသည်</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center p-4">
                <h5 class="text-dark">ဤအချက်အလက်ကို မူရင်း <strong class="text-danger">sakalakahdata</strong> ထဲမှ အပြီးတိုင် ဖျက်သိမ်းရန် သေချာပါသလား?</h5>
                <p class="text-muted small mb-0">ဖျက်ပြီးပါက ပြန်လည်ရယူနိုင်တော့မည် မဟုတ်ပါ။</p>
            </div>
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-secondary px-4" data-bs-dismiss="modal">မဖျက်တော့ပါ</button>
                <button type="button" class="btn btn-danger px-4" onclick="confirmDelete()">သေချာသည် ဖျက်မည်</button>
            </div>
        </div>
    </div>
</div>

<!--အဆိုပြုလွှာပုံစံ-->
<div id="taxFormModal" class="modal" style="display:none; position:fixed; z-index:1000; left:0; top:0; width:100%; height:100%; overflow:auto; background-color:rgba(0,0,0,0.5);">
    <div class="modal-content" style="background-color:#fff; margin:2% auto; padding:20px; width:95%; border-radius:5px;">
        <div id="printableArea" class="form-container">
            
            <table id="proposalTable" class="table table-bordered" style="width:100%; border-collapse:collapse; font-size:0.8em; color:#333;">
                <thead>
                    <tr id="excel-row-1">
                        <td colspan="17" style="text-align: center; font-weight: bold; font-size: 12pt; color: #333; border: none !important; padding: 10px 0;">
                            ဝင်ငွေခွန်/ကုန်သွယ်လုပ်ငန်းခွန် စည်းကြပ်မှု အဆိုပြုလွှာ
                        </td>
                    </tr>
                    <tr id="excel-row-2">
                        <td colspan="4" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;">
                                <span>တိုင်းဒေသကြီး/ပြည်နယ်( <span id="display_state"></span> )</span>
                                
                            </div>
                        </td>
                        <td colspan="6" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;">
                                <span>မြို့နယ်( <span id="display_township"></span> )</span>
                               
                            </div>
                        </td>
                        <td colspan="4" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;">
                                <span>နယ်မြေ( <span id="display_region"></span> )</span>
                            </div>
                        </td>
                        <td colspan="3" style="border: none !important; padding-bottom: 15px; text-align: center;">
                            <div style="display: flex; justify-content: space-around; text-align:center; font-weight: bold; font-size: 10pt; color: #333; border: none !important;">
                               
                                <span>အတွဲ(........)</span0>
                            </div>
                        </td>
                       

                    </tr>

                    <tr style="background-color:#caf6d4;">
                        <th rowspan="2" style="width:45px; border: 0.5pt solid black; text-align:center; vertical-align:middle; background-color: #caf6d4; color: black;">အမှတ်<br>စဉ်</th>
                        <th rowspan="2" style="width:160px; border: 0.5pt solid black; text-align: center; vertical-align:middle; background-color: #caf6d4; color: black;">အခွန်ထမ်းမှတ်ပုံတင် <br>အမှတ်</th>
                        <th rowspan="2" style="width:200px; border: 0.5pt solid black; vertical-align:middle; text-align: center; background-color: #caf6d4; color: black;">အခွန်ထမ်းအမည်နှင့် လိပ်စာ</th>
                        <th rowspan="2" style="width:125px; border: 0.5pt solid black; vertical-align:middle; text-align: center; background-color: #caf6d4; color: black;">လုပ်ငန်းအမျိုးအစား</th>
                        <th colspan="5" style="border: 0.5pt solid black; text-align: center; background-color: #caf6d4; color: black;">နောက်ဆုံးသုံးနှစ်စည်းကြပ်မှု</th>
                        <th colspan="2" style="border: 0.5pt solid black; text-align: center; background-color: #caf6d4; color: black; font-size:0.6em;">အခွန်ထမ်းကြေညာ</th>
                        <th colspan="4" style="border: 0.5pt solid black; text-align: center; background-color: #caf6d4; color: black;">မြို့နယ်အခွန်ဦးစီးဌာနမှူးတင်ပြ</th>
                        <th rowspan="2" style="width:90px; border: 0.5pt solid black; text-align: center; vertical-align:middle; background-color: #caf6d4; color: black;">တိုင်းဦးစီးမှူး<br>သုံးသပ်ချက်</th>
                        <th rowspan="2" style="width:70px; border: 0.5pt solid black; vertical-align:middle; background-color: #caf6d4; color: black;">မှတ်ချက်</th>
                    </tr>
                    <tr>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black; ">စည်းကြပ်နှစ်</th>
                        <th style="width:75px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေ</th>
                        <th style="width:75px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေခွန်</th>
                        <th style="width:75px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ရောင်းရငွေ</th>
                        <th style="width:80px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ကုန်သွယ်ခွန်</th>
                        <th style="width:60px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black; font-size:0.6em;">ရောင်းရငွေ</th>
                        <th style="width:50px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black; font-size:0.6em;">ဝင်ငွေ</th>
                        <th style="width:90px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ရောင်းရငွေ</th>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ကုန်သွယ်ခွန်</th>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေ</th>
                        <th style="width:85px; text-align: center; border: 0.5pt solid black; background-color: #caf6d4; color: black;">ဝင်ငွေခွန်</th>
                    </tr>
                </thead>
                <tbody id="form_data_body"></tbody>
            </table>
        </div>
        <div class="text-end mt-3">
            <button onclick="exportProposalToExcel()" class="btn btn-success">Excel ထုတ်ယူမည်</button>
            <button onclick="printProposal()" class="btn btn-primary">Print ထုတ်မည်</button>
            <button onclick="closeModal()" class="btn btn-danger">ပိတ်မည်</button>
        </div>
    </div>
</div>

<script>
    // ၂။ Excel Export IT Demand List လုပ်ဆောင်ချက်
function exportVehicleDemandToExcelds() {
    // မျက်နှာပြင်မှာ မြင်ရတဲ့ ၂၁ Column အတိုင်း ခေါင်းစဉ် (Header) တည်ဆောက်ခြင်း
    var excelHtml = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <meta charset="UTF-8">
            <style>
                table { border-collapse: collapse; }
                /* 🎯 ခေါင်းစည်းအတွက် Border လုံးဝမပါစေဘဲ အလယ်ဗဟိုညှိသည့် Style */
                .excel-main-title { 
                    font-family: "Pyidaungsu", "Segoe UI"; 
                    font-size: 12pt; 
                    font-weight: bold; 
                    text-align: center; 
                    height: 45px; 
                    vertical-align: middle; 
                    border: none !important; 
                }
                .empty-row-cell {
                    border: none !important;
                }
                th { background-color: #caf6d4 !important; font-family: "Pyidaungsu", "Segoe UI"; font-size: 10pt; border: 0.5pt solid #000; padding: 5px; text-align: center; color: black; font-weight: bold; vertical-align: middle; }
                td { font-family: "Pyidaungsu", "Segoe UI"; font-size: 9pt; border: 0.5pt solid #000; padding: 5px; vertical-align: middle; }
            </style>
        </head>
        <body>
            <table>
                <thead>
                    <tr>
                        <td colspan="21" class="excel-main-title" style="border:none;">ဝင်ငွေခွန် စည်းကြပ်ခြင်း၊ တောင်းခံခြင်းနှင့် ကောက်ခံရရှိမှုမှတ်ပုံတင်</td>
                    </tr>
                   
                    
                    <tr>
                        <th width="45">စဉ်</th>
                        <th width="100">အမှုတွဲအမှတ်</th>
                        <th width="80">စည်းကြပ်မှု<br>အမှတ်</th>
                        <th width="90">စည်းကြပ်<br>သည့်နေ့</th>
                        <th width="85">စည်းကြပ်နှစ်</th>
                        <th width="175">အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</th>
                        <th width="130">အခွန်ထမ်းအမည်</th>
                        <th width="130">လုပ်ငန်းအမျိုးအစား</th>
                        <th width="230">လုပ်ငန်းလိပ်စာ</th> 
                        <th width="110">သတ်မှတ်တန်ဖိုး</th>
                        <th width="90">ခွင့်ပြုငွေ</th>
                        <th width="100">သတ်မှတ်ဝင်ငွေ</th>
                        <th width="100">ကျသင့်အခွန်</th>
                        <th width="90">ကြိုတင်ခွန်</th>
                        <th width="100">တောင်းခံရန်<br>အခွန်</th>
                        <th width="90">ဒဏ်ငွေ</th>
                        <th width="100">အခွန်ဒဏ်ပေါင်း</th>
                        <th width="100">ပေးသွင်းငွေ</th>
                        <th width="70">ချလန်<br>နံပါတ်</th>
                        <th width="90">ချလန်ရက်စွဲ</th>
                        <th width="100">ပေးသွင်း<br>ရန်ကျန်</th>
                    </tr>
                </thead>
                <tbody>
    `;

    // ဇယားထဲက ဒေတာ Rows များကို ဆွဲထုတ်ခြင်း (Action Column ကို ချန်လှပ်၍ ၂၁ ခုစီ ထည့်သွင်းခြင်း)
    var rows = document.querySelectorAll("table tbody tr");
    rows.forEach(function(row) {
        // 'သတ်မှတ်ချက်နှင့်ကိုက်ညီသော အချက်အလက်များ မရှိသေးပါ' ဆိုသော Row ဖြစ်ပါက ကျော်ရန်
        if (row.cells.length < 21) return; 

        excelHtml += "<tr>";
        excelHtml += "<td style='text-align:center;'>" + row.cells[0].innerText + "</td>"; // စဉ်
        excelHtml += "<td style='text-align:center;'>" + row.cells[1].innerText + "</td>"; // အမှုတွဲ အမှတ်
        excelHtml += "<td style='text-align:center;'>" + row.cells[2].innerText + "</td>"; // စည်းကြပ်မှုအမှတ်
        excelHtml += "<td style='text-align:center;'>" + row.cells[3].innerText + "</td>"; // စည်းကြပ် သည့်နေ့
        excelHtml += "<td style='text-align:center;'>" + row.cells[4].innerText + "</td>"; // စည်းကြပ်နှစ်
        excelHtml += "<td class='text-start'>"  + row.cells[5].innerText + "</td>"; // အခွန်ထမ်းမှတ်ပုံတင်အမှတ်
        excelHtml += "<td class='text-start'>"  + row.cells[6].innerText + "</td>"; // အခွန်ထမ်းအမည်
        excelHtml += "<td class='text-start'>"  + row.cells[7].innerText + "</td>"; // လုပ်ငန်း အမျိုးအစား
        excelHtml += "<td class='text-start'>"  + row.cells[8].innerText + "</td>"; // လုပ်ငန်းလိပ်စာ
        excelHtml += "<td class='text-end'>"    + row.cells[9].innerText + "</td>"; // သတ်မှတ်တန်ဖိုး
        excelHtml += "<td class='text-end'>"    + row.cells[10].innerText + "</td>"; // ခွင့်ပြုငွေ
        excelHtml += "<td class='text-end'>"    + row.cells[11].innerText + "</td>"; // သတ်မှတ်ဝင်ငွေ
        excelHtml += "<td class='text-end'>"    + row.cells[12].innerText + "</td>"; // ကျသင့်အခွန်
        excelHtml += "<td class='text-end'>"    + row.cells[13].innerText + "</td>"; // ကြိုတင်ခွန်
        excelHtml += "<td class='text-end'>"    + row.cells[14].innerText + "</td>"; // တောင်းခံရန်
        excelHtml += "<td class='text-end'>"    + row.cells[15].innerText + "</td>"; // ဒဏ်ငွေ
        excelHtml += "<td class='text-end'>"    + row.cells[16].innerText + "</td>"; // ပေးဆောင်ရန် အခွန်
        excelHtml += "<td class='text-end'>"    + row.cells[17].innerText + "</td>"; // ပေးသွင်းငွေ
        excelHtml += "<td class='text-center'>" + row.cells[18].innerText + "</td>"; // ချလန်အမှတ်
        excelHtml += "<td class='text-center'>" + row.cells[19].innerText + "</td>"; // ချလန်ရက်စွဲ
        excelHtml += "<td class='text-end' style='color:red; font-weight:bold;'>" + row.cells[20].innerText + "</td>"; // ပေးသွင်းရန်ကျန်
        excelHtml += "</tr>";
    });

    excelHtml += `
            </tbody>
        </table>
    </body>
    </html>`;

    // Excel File အဖြစ် Download ပြုလုပ်စေခြင်း
    var blob = new Blob([excelHtml], { type: "application/vnd.ms-excel;charset=utf-8;" });
    var link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "vehicle_demand.xls";
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// 🌟 ဒေါင်းလုဒ်လုပ်ရန် သေချာပေါက် အလုပ်လုပ်မည့် နည်းလမ်းအသစ်
function exportProposalToExcel() {
    // 🎯 [ဖြည့်စွက်ချက်] HTML ထဲက မြို့နယ်အမည်ကို လှမ်းဖတ်ပြီး Variable ထဲထည့်ခြင်း
    var township = document.getElementById("display_township").innerText.trim() || "Tax_List";

    // ၁။ Excel မထုတ်ခင် Row 1 နဲ့ 2 ရဲ့ td ဘောင်လိုင်းတွေကို အကုန်လုံး ပျောက်သွားအောင် ယာယီသတ်မှတ်ခြင်း
    const row1_tds = document.querySelectorAll('#excel-row-1 td');
    const row2_tds = document.querySelectorAll('#excel-row-2 td');
    
    row1_tds.forEach(td => td.style.setProperty('border', 'none', 'important'));
    row2_tds.forEach(td => td.style.setProperty('border', 'none', 'important'));

    // ၂။ Table တစ်ခုလုံးရဲ့ HTML ကို ဖမ်းယူခြင်း
    var table = document.getElementById("proposalTable");
    var html = table.outerHTML;

    // Excel ထဲတွင် မြန်မာစာလုံးများ မှန်ကန်စွာ ပေါ်စေရန်နှင့် Gridline စနစ်ထည့်သွင်းခြင်း
    var excelTemplate = `
        <html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
        <head>
            <meta charset="UTF-8">
            <style>
                table { border-collapse: collapse; }
                th, td { font-family: "Pyidaungsu", "Segoe UI", Arial; }
                #excel-row-1 td, #excel-row-2 td { border: none !important; }
            </style>
        </head>
        <body>
            ${html}
        </body>
        </html>
    `;

    // ၃။ Blob Object တည်ဆောက်ပြီး ဒေါင်းလုဒ်ပြုလုပ်ခြင်း
    var blob = new Blob([excelTemplate], { type: "application/vnd.ms-excel;charset=utf-8" });
    var url = URL.createObjectURL(blob);
    
    var a = document.createElement("a");
    a.href = url;
    
    // 🎯 🌟 အစ်ကိုကြီး လိုချင်တဲ့အတိုင်း မြို့နယ်အမည်ဖြင့် ဖိုင်အမည် သိမ်းဆည်းခြင်း
    a.download = "Proposal_" + township + ".xls"; 
    
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    // ၄။ Screen ပေါ်တွင် မူလအတိုင်း ပြန်ဖြစ်အောင် လိုင်းပြန်ဖော်ပေးခြင်း
    setTimeout(() => {
        row1_tds.forEach(td => td.style.border = 'none');
        row2_tds.forEach(td => td.style.border = 'none');
    }, 300);
}

// ပုံမှန် စာရွက် Print ထုတ်ပေးသည့် Function
function printProposal() {
    var printContents = document.getElementById("printableArea").innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    window.location.reload(); // Page ကို ပြန်တင်ပေးခြင်း
}

function closeModal() {
    document.getElementById('taxFormModal').style.display = 'none';
}
</script>





<?php if ($total_pages > 1): ?>
<div class="d-flex justify-content-center align-items-center my-4">
    <nav aria-label="Page navigation">
        <ul class="pagination pagination-sm m-0 gap-1">
            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                <a class="page-link px-2" href="?page=1<?php echo $keepFilters; ?>">&laquo;&laquo;</a>
            </li>
            <li class="page-item <?php echo ($page <= 1) ? 'disabled' : ''; ?>">
                <a class="page-link px-2" href="?page=<?php echo $page - 1; ?><?php echo $keepFilters; ?>">&laquo;</a>
            </li>
            <?php 
            $range = 3;
            for ($i = 1; $i <= $total_pages; $i++): 
                if ($i == 1 || $i == $total_pages || ($i >= $page - $range && $i <= $page + $range)):
            ?>
                <li class="page-item <?php echo ($page == $i) ? 'active' : ''; ?>">
                    <a class="page-link px-3" href="?page=<?php echo $i; ?><?php echo $keepFilters; ?>"><?php echo $i; ?></a>
                </li>
            <?php 
                endif;
            endfor; 
            ?>
            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                <a class="page-link px-2" href="?page=<?php echo $page + 1; ?><?php echo $keepFilters; ?>">&raquo;</a>
            </li>
            <li class="page-item <?php echo ($page >= $total_pages) ? 'disabled' : ''; ?>">
                <a class="page-link px-2" href="?page=<?php echo $total_pages; ?><?php echo $keepFilters; ?>">&raquo;&raquo;</a>
            </li>
        </ul>
    </nav>
</div>
<?php endif; ?>

<script>
// ၁။ အချက်အလက်များ သတ်မှတ်ခြင်း
const loginUserInfo = {
    'state_name': `<?php echo str_replace(array("\r", "\n"), '', $user_state ?? ''); ?>`.trim(),
    'township_name': `<?php echo str_replace(array("\r", "\n"), '', $user_township ?? ''); ?>`.trim(),
    'region': `<?php echo str_replace(array("\r", "\n"), '', $user_region ?? ''); ?>`.trim()
};

// Global Variable အဖြစ် ကြေညာထားခြင်း
let selectedRowData = null;

// Modal ထဲက ခလုတ်နှိပ်ရင် လက်ရှိ Highlight ဖြစ်နေတဲ့ row data ကို သုံးခြင်း
function openOrderSheetFromModal2() {
    if (!selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြအောင် နှိပ်ပါ)။");
        return;
    }
    var formsModalEl = document.getElementById('formsModal3');
    if (formsModalEl) {
        var formsModal = bootstrap.Modal.getInstance(formsModalEl);
        if (formsModal) formsModal.hide();
    }
    
    // 🎯 openformsModal3(); အစား အောက်ပါအတိုင်း တိုက်ရိုက်ခေါ်ခိုင်းလိုက်ပါ
    openFormordersheet(selectedRowData); 
    
    // ပြီးရင် Order Sheet Modal ကို လှမ်းပြပါ
    var orderModalEl = document.getElementById('orderSheetModal');
    if (orderModalEl) {
        var myModal = bootstrap.Modal.getInstance(orderModalEl) || new bootstrap.Modal(orderModalEl);
        myModal.show();
    }
}
$(document).ready(function() {
    // ၁။ Header ပြသခြင်း (မူရင်းအတိုင်း)
    if(document.getElementById("display_state")) document.getElementById("display_state").innerText = loginUserInfo.state_name;
    if(document.getElementById("display_township")) document.getElementById("display_township").innerText = loginUserInfo.township_name;
    if(document.getElementById("display_region")) document.getElementById("display_region").innerText = loginUserInfo.region;

    // ၂။ 🎯 Enter ခေါက်မှသာ ရှာဖွေစေရန် ပြောင်းလဲခြင်း (မူရင်းအတိုင်း)
    $('#search_box').on('keypress', function(e) {
        if (e.which === 13) { 
            e.preventDefault(); 
            let searchVal = $(this).val();
            let url = new URL(window.location.href);
            
            if (searchVal.trim() !== "") {
                url.searchParams.set('search', searchVal);
            } else {
                url.searchParams.delete('search'); 
            }
            window.location.href = url.toString();
        }
    });

    // ၃။ 🎯 အမိန့်စာချပ်စာမျက်နှာမှ ပိတ်မည်နှိပ်၍ ပြန်လာပါက formsModal3 အား အလိုအလျောက် ဖွင့်ပေးမည့်စနစ် (အသစ်ပေါင်းထည့်ခြင်း)
    const urlParams = new URLSearchParams(window.location.search);
    const modalId = urlParams.get('openModal');
    
    if (modalId === 'formsModal3') {
        // Bootstrap 5 စနစ်ဖြင့် formsModal3 မိုဒယ်အား လှမ်းဖွင့်ခြင်း
        var myModal = new bootstrap.Modal(document.getElementById('formsModal3'));
        myModal.show();
        
        // URL လိပ်စာတန်းကို သန့်ရှင်းရေးပြန်လုပ်ရန် (Refresh ပြန်လုပ်လျှင် Modal ထပ်မပွင့်စေရန်)
        window.history.replaceState({}, document.title, window.location.pathname);
    }
});

// ၂။ Table ရေးဆွဲခြင်း
function renderProposalTable(dataList) {
    const tableBody = document.querySelector("#form_data_body");
    if (!tableBody) return;
    tableBody.innerHTML = ""; 
    
    let subTotals = { valuation: 0, taxable: 0, income_tax: 0 };
    const commonStyle = "vertical-align: top !important; border: 0.5pt solid black !important; padding: 5px;";
    
    dataList.forEach((row, index) => {
        subTotals.valuation += parseFloat(row.valuation_value || 0);
        subTotals.taxable += parseFloat(row.taxable_income || 0);
        subTotals.income_tax += parseFloat(row.income_tax || 0);

        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td style="${commonStyle} text-align: center;">${index + 1}</td>
            <td style="${commonStyle}">${row.gir_no || ''}/${row.gir_type|| ''}</td>
            <td style="${commonStyle} text-align: left;">${row.taxpayer_name || ''}<br>${row.address || ''}</td>
            <td style="${commonStyle}">${row.business_type || ''}</td>
            <td style="${commonStyle} text-align: center;">${row.tax_year || ''}</td>
            <td colspan="4" style="${commonStyle} text-align: left;">${row.plate_no || '-'}၊ ${row.manufacture || '-'}၊ 
                ${row.brand_name || '-'}၊ ${row.build_type || '-'}၊ 
                ${row.chassi || '-'}၊ ${row.make_year || '-'}
            </td>
            <td style="${commonStyle}"></td>
            <td style="${commonStyle}"></td>
            <td style="${commonStyle} text-align: right;">${formatNumber(row.valuation_value)}</td>
            <td style="${commonStyle}"></td>
            <td style="${commonStyle} text-align: right;">${formatNumber(row.taxable_income)}</td>
            <td style="${commonStyle} text-align: right;">${formatNumber(row.income_tax)}</td>
            <td style="${commonStyle}"></td>
            <td style="${commonStyle}"></td>
        `;
        tableBody.appendChild(tr);
    });

    const totalTr = document.createElement('tr');
    totalTr.style.fontWeight = "bold";
    totalTr.innerHTML = `
        <td colspan="5" style="${commonStyle} text-align:center;">စုစုပေါင်း</td>
        <td colspan="4" style="${commonStyle}"></td>
        <td style="${commonStyle}"></td>
        <td style="${commonStyle}"></td>
        <td style="${commonStyle} vertical-align: top !important; text-align:right;">${formatNumber(subTotals.valuation)}</td>
        <td style="${commonStyle}"></td>
        <td style="${commonStyle} vertical-align: top !important; text-align:right;">${formatNumber(subTotals.taxable)}</td>
        <td style="${commonStyle} vertical-align: top !important; text-align:right;">${formatNumber(subTotals.income_tax)}</td>
        <td style="${commonStyle}"></td>
        <td style="${commonStyle}"></td>
    `;
    tableBody.appendChild(totalTr);
}

// ၃။ Helper Functions
function formatNumber(num) { return parseFloat(num || 0).toLocaleString('en-US', {minimumFractionDigits: 0}); }

function openProposalFromUI() {
    let minV = document.getElementById('minCase').value;
    let maxV = document.getElementById('maxCase').value;
    if(!minV || !maxV) return alert("အမှုတွဲနံပါတ် အကွာအဝေး ရိုက်ထည့်ပါ");
    
    document.getElementById('taxFormModal').style.display = "block";
    fetch(`get_case_details_vehicle.php?min_case=${minV}&max_case=${maxV}`)
        .then(res => res.json())
        .then(data => renderProposalTable(data))
        .catch(err => alert("ဒေတာရယူရာတွင် အမှားဖြစ်နေသည်"));
}

function closeModal() { document.getElementById('taxFormModal').style.display = "none"; }

// ၄။ Export & Print


function printProposal() {
    var content = document.getElementById("printableArea").innerHTML;
    var win = window.open('', '_blank');
    win.document.write('<html><head><style>body{font-family:Pyidaungsu;} table{width:100%; border-collapse:collapse;} td,th{border:0.5pt solid black; padding:5px; vertical-align:top;}</style></head><body>'+content+'</body></html>');
    win.print();
}

// ----------------------------------------------------------------------
// (၁) Table Row (လိုင်း) ကို နှိပ်လိုက်သည့်အချိန်တွင် အလုပ်လုပ်မည့် Function
// ----------------------------------------------------------------------
// 🎯 [ပြင်ဆင်ချက်] function စာလုံး ကျန်ခဲ့သည်ကို ဖြည့်စွက်ပေးထားပါသည်
function selectTableRow(rowElement) {
    var rows = rowElement.parentNode.getElementsByTagName('tr');
    for (var i = 0; i < rows.length; i++) { rows[i].classList.remove('table-active'); }
    rowElement.classList.add('table-active');

    selectedRowData = {
        id: rowElement.getAttribute('data-id'),
        case_number: rowElement.getAttribute('data-case_number'),
        tax_year: rowElement.getAttribute('data-tax_year'),
        officer_name: rowElement.getAttribute('data-officer_name'),
        officer_rank: rowElement.getAttribute('data-officer_rank'),
        region: rowElement.getAttribute('data-region'),
        state_name: rowElement.getAttribute('data-state_name'),
        township_name: rowElement.getAttribute('data-township_name'),
        taxpayer_name: rowElement.getAttribute('data-taxpayer_name'),
        nrc_no: rowElement.getAttribute('data-nrc_no'),
        gir_type: rowElement.getAttribute('data-gir_type'),
        gir_no: rowElement.getAttribute('data-gir_no'),
        address: rowElement.getAttribute('data-address'),
        business_type: rowElement.getAttribute('data-business_type'),
        plate_no: rowElement.getAttribute('data-plate_no'),
        manufacture: rowElement.getAttribute('data-manufacture'),
        brand_name: rowElement.getAttribute('data-brand_name'),
        build_type: rowElement.getAttribute('data-build_type'),
        chassi: rowElement.getAttribute('data-chassi'),
        make_year: rowElement.getAttribute('data-make_year'),
        sale_date: rowElement.getAttribute('data-sale_date'),
        proposal_value: rowElement.getAttribute('data-proposal_value'),
        valuation_value: rowElement.getAttribute('data-valuation_value'),
        allowable_expenses: rowElement.getAttribute('data-allowable_expenses'),
        taxable_income: rowElement.getAttribute('data-taxable_income'),
        income_tax: rowElement.getAttribute('data-income_tax'),
        advance_tax: rowElement.getAttribute('data-advance_tax'),
        tax_to_pay: rowElement.getAttribute('data-tax_to_pay'),
        penalty_tax: rowElement.getAttribute('data-penalty_tax'),
        total_tax: rowElement.getAttribute('data-total_tax'),
        paid_amount: rowElement.getAttribute('data-paid_amount'),
        chalan_no: rowElement.getAttribute('data-chalan_no'),
        chalan_date: rowElement.getAttribute('data-chalan_date'),
        notified_date: rowElement.getAttribute('data-notified_date'),
        appointment_date: rowElement.getAttribute('data-appointment_date'),
        appearance_date: rowElement.getAttribute('data-appearance_date'),
        it_demand_no: rowElement.getAttribute('data-it_demand_no'),
        it_demand_date: rowElement.getAttribute('data-it_demand_date'),
        investigation_value: rowElement.getAttribute('data-investigation_value'),
        source_of_income: rowElement.getAttribute('data-source_of_income'),
        investigation: rowElement.getAttribute('data-investigation'),    
    };
    console.log("Data selected and stored!");
}

// 2️⃣ ခလုတ်နှိပ်မှသာ ဒေတာပို့ပြီး Modal ကို ဖွင့်မည်
function openformsModal3() {
    if (!selectedRowData) {
        alert("⚠️ ကျေးဇူးပြု၍ Table ထဲမှ အမှုတွဲ Row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (လိုင်းပေါ်တွင် နှိပ်ပါ)။");
        return;
    }

    if (typeof openFormordersheet === 'function') {
        openFormordersheet(selectedRowData); 
    }

    var orderModalEl = document.getElementById('orderSheetModal');
    if (orderModalEl) {
        var myModal = bootstrap.Modal.getInstance(orderModalEl) || new bootstrap.Modal(orderModalEl);
        myModal.show();
    }
}

// ✅ vehicle_demand_list.php ထဲက openOrderSheetForm ကို ဤကဲ့သို့ အရှင်းဆုံး ပုံစံပြောင်းလိုက်ပါ
function openOrderSheetForm() {
    if (!selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြအောင် နှိပ်ပါ)။");
        return;
    }
    
    // လမ်းကြောင်းမှန်အတိုင်း တိုက်ရိုက် စာမျက်နှာအသစ်သို့ ကူးပြောင်းမည်
    window.location.href = `forms_vehicle/form_vehicle_order_sheet.php?id=${selectedRowData.id}`;
}

// -----------------------------------------------------------------
// 📂 MODAL ထဲမှ ဖောင်တစ်ခုချင်းစီကို ဒေတာဖြင့် လှမ်းဖွင့်ပေးမည့် Functions များ
// -----------------------------------------------------------------
function openForm0405() {
    if (!selectedRowData) return;
    
    // openFormgeneral2 အလုပ်လုပ်ပုံအတိုင်း တထပ်တည်း ပြောင်းလဲခြင်း
    bootstrap.Modal.getInstance(document.getElementById('formsModal3')).hide();
    window.location.href = `forms_vehicle/form_vehicle_04_05.php?id=${selectedRowData.id}`;
}

function openForm0406() {
    if (!selectedRowData) return;
    bootstrap.Modal.getInstance(document.getElementById('formsModal3')).hide();
    window.location.href = `forms_vehicle/form_vehicle_04_06.php?id=${selectedRowData.id}`;
}

function openForm0407() {
    if (!selectedRowData) return;
    bootstrap.Modal.getInstance(document.getElementById('formsModal3')).hide();
    window.location.href = `forms_vehicle/form_vehicle_04_07.php?id=${selectedRowData.id}`;
}

function openForm0408() {
    if (!selectedRowData) return;
    bootstrap.Modal.getInstance(document.getElementById('formsModal3')).hide();
    window.location.href = `forms_vehicle/form_vehicle_04_08.php?id=${selectedRowData.id}`;
}

function openFormgeneral2() {
    if (!selectedRowData) return;
    bootstrap.Modal.getInstance(document.getElementById('formsModal3')).hide();
    window.location.href = `forms_vehicle/form_vehicle_general2.php?id=${selectedRowData.id}`;
}

function openForm0301() {
    if (!selectedRowData) return;
    bootstrap.Modal.getInstance(document.getElementById('formsModal3')).hide();
    window.location.href = `forms_vehicle/form_vehicle_wanga1.php?id=${selectedRowData.id}`;
}

function openForm0409() {
    if (!selectedRowData) return;
    bootstrap.Modal.getInstance(document.getElementById('formsModal3')).hide();
    window.location.href = `forms_vehicle/calculation_vehicle_form.php?id=${selectedRowData.id}`;
}

// -----------------------------------------------------------------
// 📄 အမိန့်စာချုပ်ဖောင်ထဲသို့ Data ဖြည့်သွင်းပေးသည့် ပင်မစနစ်
// -----------------------------------------------------------------
function openFormordersheet(data) {
    if (!data) return;

    var userRank = "<?php echo @$rank ? str_replace(array("\r", "\n"), '', $rank) : 'အခွန်ဦးစီးမှူး'; ?>";

    const cleanText = (val) => {
        if (typeof val !== 'string') return val;
        let clean = val;
        if (clean.startsWith('"') && clean.endsWith('"')) {
            try { clean = JSON.parse(clean); } catch(e) {}
        } else if (clean.includes('\\u')) {
            try { clean = JSON.parse('"' + clean + '"'); } catch(e) {}
        }
        return clean.replace(/\r?\n|\r/g, " ").trim(); 
    };

    // 🎯 ID တစ်ခုတည်းတင်မကဘဲ စာမျက်နှာတစ်ခုလုံးမှာရှိတဲ့ ID တူသမျှ Element အားလုံးထဲ ဒေတာလိုက်ထည့်ပေးမည့် စမတ်စနစ်
    const updateText = (id, value) => {
        const elements = document.querySelectorAll('[id="' + id + '"], .' + id);
        elements.forEach(el => {
            el.innerText = cleanText(value) || '-/-/-';
        });
    };

    updateText('os_township', data.township_name);
    updateText('os_name', data.taxpayer_name);
    updateText('os_address', data.address);
    updateText('os_biz', data.business_type); 
    updateText('os_year', data.tax_year);
    updateText('os_officer', data.officer_name);
    updateText('os_rank', userRank); 
    updateText('os_gir', (cleanText(data.gir_no) || '') + " / " + (cleanText(data.gir_type) || ''));

    const fn = (val) => typeof formatNumber === 'function' ? formatNumber(val) : val;

    let profitVal  = data.profit || data.taxable_income || 0;
    let taxVal     = data.income_tax || 0;
    let advVal     = data.advance || data.advance_tax || 0;
    let penaltyVal = data.penalty || data.penalty_tax || 0;
    let totalVal   = data.total_all || data.total_tax || 0;

    let taxInt = parseInt(String(taxVal).replace(/,/g, '')) || 0;
    let advInt = parseInt(String(advVal).replace(/,/g, '')) || 0;

    let balInt = taxInt - advInt; 
    if (balInt < 0) balInt = 0;

    if (typeof parseToNumber === 'function' && data.tax_to_pay) {
        balInt = parseToNumber(data.tax_to_pay);
    }

    updateText('os_profit', fn(profitVal));
    updateText('os_income_tax', fn(taxVal));
    updateText('os_advance', fn(advVal));    
    updateText('os_advance1', fn(advVal));   
    updateText('os_total_all', fn(totalVal)); 

    updateText('os_balance', fn(balInt));    
    updateText('os_penalty', fn(penaltyVal)); 
    updateText('os_balance1', fn(balInt));   
    updateText('os_penalty1', fn(penaltyVal)); 

    updateText('os_itDemandNo', data.it_demand_no_ || data.it_demand_no || '---');
    updateText('os_itDemandDate', data.it_demand_date || '---');
    updateText('os_notified_date', data.notified_date || '---');
    updateText('os_appointment_date', data.appointment_date || '---');
    updateText('os_appearance_date', data.appearance_date || '---');

    updateText('os_land_type', data.land_type);
    updateText('os_block_no', data.block_no);
    updateText('os_holding_no', data.holding_no);
    updateText('os_city', data.city);
    updateText('os_road', data.road);
    updateText('os_area', data.area);

    updateText('os_building_type', data.building_type);
    updateText('os_building_height', data.building_height);
    updateText('os_municipal_no', data.municipal_no);
    updateText('os_permit_date', data.permit_date);
    
   // 🎯 ကုဒ်သစ် - Object ထဲက လာတဲ့ ရက်စွဲတင်မကဘဲ Table Row ထဲက တန်ဖိုးကိုပါ လှမ်းရှာပြီး အတင်းထည့်ခိုင်းတဲ့ စနစ်
const parentRow = document.querySelector(`tr[data-id="${data.id}"]`);
const rowDateVal = parentRow ? parentRow.getAttribute('data-purchase_date') : '';
const finalDate = data.purchase_date || rowDateVal || '-/-/-';

updateText('vehicle_purchase_date', finalDate);
    
    updateText('os_assessment_submit_date', data.assessment_submit_date);
    updateText('os_tasapha_no', data.tasapha_no);
    updateText('os_ttasapha_date', data.tasapha_date);
    updateText('os_declared_value', fn(data.declared_value || 0));
    updateText('os_valuation_value', fn(data.valuation_value || 0));

    if (data.it_demand_date && data.it_demand_date !== '0000-00-00') {
        const d = new Date(data.it_demand_date);
        if (!isNaN(d.getTime())) {
            d.setDate(d.getDate() + 14); 
            const dd = String(d.getDate()).padStart(2, '0');
            const mm = String(d.getMonth() + 1).padStart(2, '0');
            const yyyy = d.getFullYear();
            
            const targetEl = document.getElementById('rq_date1');
            if (targetEl) targetEl.innerText = dd + "-" + mm + "-" + yyyy;
        }
    }
}

function parseToNumber(val) {
    if (!val) return 0;
    let cleanVal = String(val).replace(/,/g, ''); 
    return parseInt(cleanVal) || 0;
}

// 🎯 ခလုတ်နှိပ်လိုက်သည့် ID ကို မှတ်သားပြီး Modal (Pop-up) ကို ဖွင့်ပေးမည့် Function
let currentDeleteId = null;

function openDeleteModal(id) {
    currentDeleteId = id; // ဖျက်မည့် ID ကို Variables ထဲမှတ်သားသည်
    
    // Bootstrap Modal အား ID အမည်ဖြင့် ဖမ်းယူ၍ ပွင့်ခိုင်းခြင်း
    let deleteBtnModal = new bootstrap.Modal(document.getElementById('deleteModal'));
    deleteBtnModal.show();
}

// 🎯 Modal ထဲက "သေချာသည် ဖျက်မည်" ခလုတ်နှိပ်လျှင် အလုပ်လုပ်မည့် စနစ်
function confirmDelete() {
    if (currentDeleteId) {
        // မူရင်း sakalakahdata Table ထဲက id အတိုင်း သွားဖျက်ရန် delete_vehicle.php ထံ ပို့ပေးခြင်း
        window.location.href = 'delete_vehicle.php?id=' + currentDeleteId;
    }
}
</script>

<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/tableToExcel.js"></script>
<script src="js/xlsx.full.min.js"></script>

<?php 
    // ဖိုင်တွေကို တိုက်ရိုက် include မလုပ်ဘဲ Version ပြောင်းလဲပြီး ခေါ်တဲ့စနစ် (Cache အမြစ်ပြတ်စေရမည်)
    include 'forms_vehicle/form_vehicle_order_sheet.php'; 
    include_once 'forms_vehicle/form_vehicle_04_05.php';
    include 'forms_vehicle/form_vehicle_04_06.php'; 
    //include 'forms_vehicle/form_vehicle_04_07.php'; 
    //include 'forms_vehicle/form_vehicle_04_08.php'; 
    include 'forms_vehicle/form_vehicle_general2.php'; 
    //include 'forms_vehicle/calculation_form.php'; 
?>
</div>
</body>
</html>
<?php
$conn->close();
?>