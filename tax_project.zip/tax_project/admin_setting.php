<?php
session_start();

if (!isset($_SESSION['user_name'])) {
    header('Location: login.php');
    exit;
}
if (($_SESSION['user_role'] ?? '') !== 'admin') {
    header('Location: dashboard.php');
    exit;
}

include 'db_config.php';
$conn->set_charset('utf8mb4');

function adm_h($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
function adm_sel($current, $value) {
    return trim((string) $current) === trim((string) $value) ? 'selected' : '';
}

$blank = [
    'id' => '', 'state_name' => '', 'township_name' => '', 'md_no' => '', 'bank_township' => '',
    'state_office' => '', 'state_city' => '', 'township_code' => '', 'officer_name' => '',
    'rank_' => '', 'region' => '', 'user_name' => '', 'role' => 'user', 'other' => '',
];
$data = $blank;
$is_edit = false;
$search = trim($_GET['q'] ?? '');
$self_id = (int) ($_SESSION['user_id'] ?? 0);

if (isset($_GET['edit_id']) && $_GET['edit_id'] !== '') {
    $edit_id = (int) $_GET['edit_id'];
    $stmt = $conn->prepare('SELECT * FROM user_register WHERE id = ?');
    $stmt->bind_param('i', $edit_id);
    $stmt->execute();
    $found = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($found) {
        $data = array_merge($blank, $found);
        $is_edit = true;
    }
}

$list_sql = 'SELECT id, user_name, officer_name, rank_, state_name, township_name, role FROM user_register';
if ($search !== '') {
    $like = '%' . $search . '%';
    $list_sql .= ' WHERE user_name LIKE ? OR officer_name LIKE ? OR state_name LIKE ? OR township_name LIKE ? OR role LIKE ? OR rank_ LIKE ?';
}
$list_sql .= ' ORDER BY id DESC';
$list_stmt = $conn->prepare($list_sql);
if ($search !== '') {
    $list_stmt->bind_param('ssssss', $like, $like, $like, $like, $like, $like);
}
$list_stmt->execute();
$list_result = $list_stmt->get_result();
$rows = [];
while ($row = $list_result->fetch_assoc()) {
    $rows[] = $row;
}
$list_stmt->close();

$states = ['ကချင်ပြည်နယ်','ကယားပြည်နယ်','ကရင်ပြည်နယ်','ချင်းပြည်နယ်','စစ်ကိုင်းတိုင်းဒေသကြီး','တနင်္သာရီတိုင်းဒေသကြီး','ပဲခူးတိုင်းဒေသကြီး','မကွေးတိုင်းဒေသကြီး','မန္တလေးတိုင်းဒေသကြီး','မွန်ပြည်နယ်','ရခိုင်ပြည်နယ်','ရှမ်းပြည်နယ်','ရန်ကုန်တိုင်းဒေသကြီး','ပြည်ထောင်စုနယ်မြေ'];
$offices = [];
foreach ($states as $state) {
    $offices[] = $state . 'အခွန်ဦးစီးဌာနမှူးရုံး';
}
$ranks = ['လက်ထောက်ညွှန်ကြားရေးမှူး','ဦးစီးအရာရှိ','ဒုတိယဦးစီးမှူး'];
$saved_places = [
    'township' => $data['township_name'],
    'bank' => $data['bank_township'],
    'city' => $data['state_city'],
];
?>
<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <title>စနစ်အသုံးပြုသူ စီမံခန့်ခွဲမှု</title>
    <style>
        html, body { height: 100%; }
        body { font-family: 'Pyidaungsu', sans-serif; background: #f4f6f9; margin: 0; overflow: hidden; display: flex; flex-direction: column; }
        .page-title-bar { position: relative; flex: 0 0 auto; background: #0b3d91; }
        .page-title { margin: 0; color: #fff; text-align: center; padding: 12px 64px; font-size: 1.35rem; font-weight: bold; line-height: 1.4; }
        .page-close { position: absolute; top: 50%; right: 14px; transform: translateY(-50%); width: 36px; height: 36px; background: #dc3545; color: #fff; border: none; border-radius: 4px; font-size: 24px; font-weight: bold; line-height: 1; cursor: pointer; }
        .page-close:hover { background: #bd2130; }
        .page-split { display: flex; gap: 12px; flex: 1 1 auto; min-height: 0; padding: 10px; box-sizing: border-box; }
        .form-container { flex: 0 0 560px; width: 560px; background: #fff; padding: 12px 14px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,.1); overflow-y: auto; box-sizing: border-box; }
        .form-header { background: #007bff; color: #fff; text-align: center; padding: 8px 10px; border-radius: 6px; margin-bottom: 10px; font-size: 1.05rem; }
        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px 10px; }
        .full-width { grid-column: 1 / -1; }
        label { display: block; margin-bottom: 3px; font-weight: bold; font-size: 13px; color: #333; }
        input, select { width: 100%; padding: 7px 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .login-box { background: #e9ecef; padding: 10px; border-radius: 5px; display: grid; gap: 8px; }
        .save-btn, .cancel-btn { width: 100%; padding: 9px; border: none; border-radius: 4px; color: #fff; cursor: pointer; font-size: 1rem; margin-top: 10px; text-align: center; text-decoration: none; display: block; box-sizing: border-box; }
        .save-btn { background: #28a745; }
        .save-btn:hover { background: #218838; }
        .cancel-btn { background: #6c757d; }
        .list-wrap { flex: 1 1 auto; min-width: 0; background: #fff; padding: 12px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,.1); display: flex; flex-direction: column; overflow: hidden; }
        .list-head { display: flex; justify-content: space-between; align-items: center; gap: 10px; margin-bottom: 10px; flex-wrap: wrap; }
        .list-head h2 { margin: 0; font-size: 1.1rem; color: #1f3b73; }
        .search-form { display: flex; gap: 8px; }
        .search-form input { width: 180px; }
        .search-form button, .search-form a { padding: 7px 12px; border: none; border-radius: 4px; text-decoration: none; cursor: pointer; }
        .search-form button { background: #007bff; color: #fff; }
        .search-form a { background: #e9ecef; color: #333; }
        .table-scroll { flex: 1 1 auto; min-height: 0; overflow: auto; }
        table { width: 100%; border-collapse: separate; border-spacing: 0; font-size: 14px; }
        th, td { border-right: 1px solid #d7dce3; border-bottom: 1px solid #d7dce3; padding: 6px 8px; white-space: nowrap; text-align: left; }
        th { position: sticky; top: 0; z-index: 1; background: #007bff; color: #fff; text-align: center; font-weight: bold; padding: 12px 8px; }
        th:first-child, td:first-child { border-left: 1px solid #d7dce3; }
        tr.data-row { cursor: pointer; }
        tr.data-row:hover { background: #eef5ff; }
        tr.selected { background: #d9f2e3; }
        .row-actions { display: flex; gap: 6px; }
        .btn-edit { background: #ffc107; border: none; border-radius: 4px; padding: 4px 8px; font-weight: bold; cursor: pointer; }
        .btn-delete { background: #dc3545; color: #fff; border: none; border-radius: 4px; padding: 4px 8px; font-weight: bold; cursor: pointer; }
        .btn-delete:disabled { background: #e8a0a8; cursor: not-allowed; }
        .hint { font-weight: normal; color: #555; }
    </style>
</head>
<body>
<div class="page-title-bar">
    <h1 class="page-title">စနစ်အသုံးပြုသူ အချက်အလက်များ</h1>
    <button type="button" class="page-close" title="ပိတ်မည်" onclick="window.location.href='dashboard.php'">×</button>
</div>
<div class="page-split">
    <div class="form-container" id="user-form">
        <div class="form-header"><?php echo $is_edit ? 'အသုံးပြုသူအချက်အလက် ပြင်ဆင်ရန်' : 'အသုံးပြုသူအသစ် ထည့်သွင်းရန်'; ?></div>
        <form action="process_register.php" method="POST">
            <input type="hidden" name="id" value="<?php echo adm_h($data['id']); ?>">
            <input type="hidden" name="q" value="<?php echo adm_h($search); ?>">
            <div class="form-grid">
                <div>
                    <label>တိုင်းဒေသကြီး/ပြည်နယ်</label>
                    <select name="state_name" id="stateSelect" onchange="fetchTownships()" required>
                        <option value="">-- တိုင်းဒေသကြီး ရွေးပါ --</option>
                        <?php foreach ($states as $state): ?>
                            <option value="<?php echo adm_h($state); ?>" <?php echo adm_sel($data['state_name'], $state); ?>><?php echo adm_h($state); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>မြို့နယ်အခွန်ဦးစီးဌာနမှူးရုံးအမည်</label>
                    <select id="township_select" name="township_name" onchange="fetchTownshipCode()" required>
                        <option value="">-- ရွေးချယ်ပါ --</option>
                    </select>
                </div>
                <div>
                    <label>MD နံပါတ်</label>
                    <input type="text" name="md_no" value="<?php echo adm_h($data['md_no']); ?>">
                </div>
                <div>
                    <label>ဘဏ်ခွဲ (မြို့နယ်)</label>
                    <select name="bank_township" id="bankSelect" required>
                        <option value="">-- ဘဏ်ခွဲ ရွေးပါ --</option>
                    </select>
                </div>
                <div>
                    <label>တိုင်းဒေသကြီး/ပြည်နယ်ရုံးအမည်</label>
                    <select name="state_office">
                        <option value="">-- တိုင်း/ပြည်နယ်ရုံး ရွေးပါ --</option>
                        <?php foreach ($offices as $office): ?>
                            <option value="<?php echo adm_h($office); ?>" <?php echo adm_sel($data['state_office'], $office); ?>><?php echo adm_h($office); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>တိုင်းဒေသကြီး/ပြည်နယ် (ရုံးစိုက်ရာမြို့)</label>
                    <select name="state_city" id="citySelect" required>
                        <option value="">-- ရုံးစိုက်ရာမြို့ ရွေးပါ --</option>
                    </select>
                </div>
                <div>
                    <label>မြို့နယ် ကုဒ်</label>
                    <input type="text" id="short_code" name="township_code" value="<?php echo adm_h($data['township_code']); ?>" readonly>
                </div>
                <div>
                    <label>အခွန်မှူးအမည်</label>
                    <input type="text" name="officer_name" value="<?php echo adm_h($data['officer_name']); ?>" required>
                </div>
                <div>
                    <label>အခွန်မှူးရာထူး</label>
                    <select name="rank_" required>
                        <option value="">-- ရာထူးရွေးချယ်ပါ --</option>
                        <?php foreach ($ranks as $rank): ?>
                            <option value="<?php echo adm_h($rank); ?>" <?php echo adm_sel($data['rank_'], $rank); ?>><?php echo adm_h($rank); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>နယ်မြေ (Region)</label>
                    <input type="text" name="region" value="<?php echo adm_h($data['region']); ?>">
                </div>
                <div>
                    <label>Short Code</label>
                    <input type="text" name="other" value="<?php echo adm_h($data['other']); ?>" required>
                </div>
                <div>
                    <label>အသုံးပြုသူအဆင့်</label>
                    <select name="role" required>
                        <option value="user" <?php echo adm_sel($data['role'], 'user'); ?>>user</option>
                        <option value="admin" <?php echo adm_sel($data['role'], 'admin'); ?>>admin</option>
                    </select>
                </div>
                <div class="full-width login-box">
                    <div>
                        <label>User Name (Login အတွက်)</label>
                        <input type="text" name="user_name" value="<?php echo adm_h($data['user_name']); ?>" required>
                    </div>
                    <div>
                        <label>Password <?php if ($is_edit): ?><span class="hint">(မပြောင်းလျှင် ကွက်လပ်ထားပါ)</span><?php endif; ?></label>
                        <div style="position: relative;">
                            <input type="password" name="password" id="passwordField" <?php echo $is_edit ? '' : 'required'; ?> style="padding-right: 40px;">
                            <span id="togglePassword" style="position: absolute; right: 10px; top: 50%; transform: translateY(-50%); cursor: pointer;">👁️</span>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" name="btn_save" class="save-btn"><?php echo $is_edit ? 'အချက်အလက်များ ပြင်ဆင်မည်' : 'အသုံးပြုသူအသစ် သိမ်းဆည်းမည်'; ?></button>
            <?php if ($is_edit): ?>
                <a class="cancel-btn" href="admin_setting.php<?php echo $search !== '' ? '?q=' . urlencode($search) : ''; ?>">ပယ်ဖျက်မည်</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="list-wrap">
        <div class="list-head">
            <h2>သိမ်းထားသော အသုံးပြုသူစာရင်း (<?php echo count($rows); ?>)</h2>
            <form class="search-form" method="GET" action="admin_setting.php">
                <?php if ($is_edit): ?><input type="hidden" name="edit_id" value="<?php echo adm_h($data['id']); ?>"><?php endif; ?>
                <input type="text" name="q" value="<?php echo adm_h($search); ?>" placeholder="အမည် / User ရှာရန်">
                <button type="submit">ရှာမည်</button>
                <?php if ($search !== ''): ?><a href="admin_setting.php<?php echo $is_edit ? '?edit_id=' . urlencode($data['id']) : ''; ?>">အားလုံး</a><?php endif; ?>
            </form>
        </div>
        <div class="table-scroll">
            <table>
                <thead>
                    <tr>
                        <th>စဉ်</th>
                        <th>User Name</th>
                        <th>အမည်</th>
                        <th>ရာထူး</th>
                        <th>တိုင်း/ပြည်နယ်</th>
                        <th>မြို့နယ်</th>
                        <th>အဆင့်</th>
                        <th>လုပ်ဆောင်ချက်</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (count($rows) === 0): ?>
                    <tr><td colspan="8" style="text-align:center;">ပြရန် အချက်အလက် မရှိပါ။</td></tr>
                <?php else: ?>
                    <?php foreach ($rows as $index => $row): ?>
                        <?php
                            $selected = $is_edit && (string) $row['id'] === (string) $data['id'];
                            $edit_url = 'admin_setting.php?edit_id=' . urlencode($row['id']);
                            if ($search !== '') $edit_url .= '&q=' . urlencode($search);
                            $own = (int) $row['id'] === $self_id;
                        ?>
                        <tr class="data-row<?php echo $selected ? ' selected' : ''; ?>" onclick="window.location.href='<?php echo adm_h($edit_url); ?>'">
                            <td><?php echo $index + 1; ?></td>
                            <td><?php echo adm_h($row['user_name']); ?></td>
                            <td><?php echo adm_h($row['officer_name']); ?></td>
                            <td><?php echo adm_h($row['rank_']); ?></td>
                            <td><?php echo adm_h($row['state_name']); ?></td>
                            <td><?php echo adm_h($row['township_name']); ?></td>
                            <td><?php echo adm_h($row['role']); ?></td>
                            <td>
                                <div class="row-actions">
                                    <button type="button" class="btn-edit" onclick="event.stopPropagation(); window.location.href='<?php echo adm_h($edit_url); ?>'"><?php echo $selected ? 'ရွေးထားသည်' : 'ပြင်ဆင်မည်'; ?></button>
                                    <form method="POST" action="process_register.php" onsubmit="return confirm('ဤအသုံးပြုသူကို ဖျက်ရန် သေချာပါသလား။');">
                                        <input type="hidden" name="id" value="<?php echo adm_h($row['id']); ?>">
                                        <input type="hidden" name="q" value="<?php echo adm_h($search); ?>">
                                        <button type="submit" name="btn_delete" class="btn-delete" onclick="event.stopPropagation();" <?php echo $own ? 'disabled title="မိမိအကောင့်ကို ဖျက်၍မရပါ"' : ''; ?>>ဖျက်မည်</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<script>
const savedPlaces = <?php echo json_encode($saved_places, JSON_UNESCAPED_UNICODE); ?>;

function chooseSaved(select, value) {
    if (!value) return;
    const exists = Array.from(select.options).some(function (opt) { return opt.value === value; });
    if (!exists) select.add(new Option(value, value));
    select.value = value;
}

function fetchTownships() {
    const state = document.getElementById('stateSelect').value;
    const townshipSelect = document.getElementById('township_select');
    const bankSelect = document.getElementById('bankSelect');
    const citySelect = document.getElementById('citySelect');
    if (!state) return;

    const loadingText = '<option value="">-- ခေတ္တစောင့်ပါ --</option>';
    townshipSelect.innerHTML = loadingText;
    bankSelect.innerHTML = loadingText;
    citySelect.innerHTML = loadingText;

    fetch('get_townships.php?state=' + encodeURIComponent(state))
        .then(function (response) { return response.json(); })
        .then(function (data) {
            townshipSelect.innerHTML = '<option value="">-- မြို့နယ် ရွေးပါ --</option>';
            bankSelect.innerHTML = '<option value="">-- ဘဏ်ခွဲ ရွေးပါ --</option>';
            citySelect.innerHTML = '<option value="">-- ရုံးစိုက်ရာမြို့ ရွေးပါ --</option>';
            if (Array.isArray(data)) {
                data.forEach(function (item) {
                    if (item.township) {
                        townshipSelect.add(new Option(item.township, item.township));
                        bankSelect.add(new Option(item.township, item.township));
                    }
                    if (item.city) citySelect.add(new Option(item.city, item.city));
                });
            }
            chooseSaved(townshipSelect, savedPlaces.township);
            chooseSaved(bankSelect, savedPlaces.bank);
            chooseSaved(citySelect, savedPlaces.city);
            if (townshipSelect.value) fetchTownshipCode();
        })
        .catch(function () {
            townshipSelect.innerHTML = '<option value="">Error ဖြစ်သွားပါသည်</option>';
        });
}

function fetchTownshipCode() {
    const townshipName = document.getElementById('township_select').value;
    const shortCodeInput = document.getElementById('short_code');
    if (townshipName === '') {
        shortCodeInput.value = '';
        return;
    }
    fetch('get_township_code.php?township_name=' + encodeURIComponent(townshipName))
        .then(function (response) { return response.text(); })
        .then(function (code) {
            shortCodeInput.value = code.trim() !== '' ? code.trim() : 'မရှိပါ';
        });
}

document.getElementById('togglePassword').addEventListener('click', function () {
    const field = document.getElementById('passwordField');
    const show = field.getAttribute('type') === 'password';
    field.setAttribute('type', show ? 'text' : 'password');
    this.textContent = show ? '🙈' : '👁️';
});

if (document.getElementById('stateSelect').value) fetchTownships();
</script>
</body>
</html>
