<?php
// ၁။ Session စတင်ခြင်း
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ DB Config ချိတ်ဆက်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}

// ၃။ Session ထဲက User ID ကိုယူခြင်း
$u_id = $_SESSION['user_id'] ?? 0;
$user_other_info = ""; // default value

// ၄။ Database မှ data ဆွဲထုတ်ခြင်း
if ($u_id > 0) {
    $user_query = "SELECT other FROM user_register WHERE id = '$u_id'";
    $user_result = mysqli_query($conn, $user_query);

    if ($user_result && $user_row = mysqli_fetch_assoc($user_result)) {
        $user_other_info = str_replace(array("\r", "\n", "'", '"'), '', $user_row['other']);
    }
}
?>

<script>
function openForm0405() {
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြအောင် နှိပ်ပါ)။");
        return; 
    }
    
    console.log("Selected Row Data:", selectedRowData);

    // ၂။ Helper Functions
    const toMyanmarDigit = (num) => {
        if (!num) return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    const mmMonths = ['ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ'];

    // ၃။ Login User ရဲ့ Other Data
    const loginUserOther = "<?php echo $user_other_info; ?>"; 
    console.log("ရရှိလာသော Other Data:", loginUserOther);
    setText('m0405_other_data', loginUserOther || '......');

    // ၄။ အခြေခံအချက်အလက်များ (🎯 ပင်မ Table နှင့် ကိုက်ညီအောင် Variable နာမည်များ ညှိလိုက်ပါပြီ)
    setText('m0405_name', selectedRowData.taxpayer_name);
    setText('m0405_address', selectedRowData.address);
    setText('m0405_biz', selectedRowData.business_type || selectedRowData.businessType1);
    setText('m0405_biz_detail', selectedRowData.business_type || selectedRowData.businessType1);
    setText('m0405_township', selectedRowData.township_name || selectedRowData.state_name);
    
    let yearVal = selectedRowData.tax_year || selectedRowData.taxYear || '';
    setText('m0405_year', toMyanmarDigit(yearVal));

    // ၅။ ရက်စွဲပိုင်းဆိုင်ရာ Process လုပ်ခြင်း
    const processDate = (dateStr, prefix) => {
        if (dateStr && dateStr.includes('-')) {
            const parts = dateStr.split('-');
            const yyyy = parts[0]; 
            const mm = parts[1];   
            const dd = parts[2].split(' ')[0];

            setText(prefix + '_year', toMyanmarDigit(yyyy));
            setText(prefix + '_month', mmMonths[parseInt(mm) - 1]);
            setText(prefix + '_day', toMyanmarDigit(dd));
            
            if (prefix === 'orDate') {
                setText('orDate_year_short', toMyanmarDigit(yyyy.slice(-2)));
                setText('m0405_orDate', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            } else if (prefix === 'appDate') {
                setText('m0405_appDate', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            }
        } else {
            setText(prefix + '_year', '....');
            setText(prefix + '_month', '....');
            setText(prefix + '_day', '....');
        }
    };

    // 🎯 ပင်မ Table Row မှ လာသော ရက်စွဲစာလုံးပေါင်းများနှင့် ကွက်တိညှိခြင်း
    let orderD = selectedRowData.order_date || selectedRowData.orderDate || selectedRowData.it_demand_date;
    let appD = selectedRowData.appointment_date || selectedRowData.appointmentDate;

    processDate(orderD, 'orDate');
    processDate(appD, 'appDate');

    // ၆။ Modal ကို ဖွင့်ခြင်း (🎯 HTML ID နှင့် ကိုက်ညီအောင် 'formsModal0405' ဟု ပြင်ဆင်လိုက်ပါပြီ)
    var modalElem = document.getElementById('formsModal0405');
    if (modalElem) {
        var myModal = new bootstrap.Modal(modalElem);
        myModal.show();
    } else {
        console.error("Modal element 'formsModal0405' ကို ရှာမတွေ့ပါဗျာ။");
    }
}
</script>

<style>
 #formsModal0405 .print-container { 
        padding-top: 10mm !important; 
        padding-bottom: 10mm !important; 
        padding-left: 20mm !important; 
        padding-right: 10mm !important; 
        border: none !important; 
        margin: 0 !important;
        line-height: 1.8 !important;
    }

@media print {
    .modal-footer, .no-print, .btn, .btn-close, .modal-header { display: none !important; }
    .modal-content, .modal-body { border: none !important; box-shadow: none !important; }

    body * { visibility: hidden; }
    #formsModal0405, #formsModal0405 * { visibility: visible !important; }
    #formsModal0405 { position: absolute; left: 0; top: 0; width: 100%; margin: 0; padding: 0; }

    #formsModal0405 .print-container { 
        padding-top: 10mm !important; 
        padding-bottom: 10mm !important; 
        padding-left: 24mm !important; 
        padding-right: 10mm !important; 
        border: none !important; 
        margin: 0 !important;
        line-height: 1.8 !important;
    }

    #formsModal0405 .print-container p,
    #formsModal0405 .print-container div,
    #formsModal0405 .print-container td,
    #formsModal0405 .print-container span {
        line-height: 1.8 !important;
    }

    table, tr, td { 
        border: none !important; 
    }
    
    .print-container table:first-child {
        border: none !important;
    }

    .modal-content, .modal-header, .modal-footer {
        border: none !important;
        box-shadow: none !important;
    }

    hr { display: none !important; }
    .modal-body { border: none !important; }
}

#formsModal0405 .modal-dialog {
    max-width: 800px; 
    margin: 20px auto;
}

#formsModal0405 .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}

#formsModal0405 .print-container {
    padding-left: 70px;
    padding-right: 10px;
    margin-left: 0;
    box-sizing: border-box;
}
</style>

<div class="modal fade" id="formsModal0405" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: none;">
                <h5 class="modal-title">၀၄-၀၅ ကြားနာစစ်ဆေးရန်အကြောင်းကြားစာ ထုတ်ယူရန်</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <table style="border: 1.5px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:25px">
                        <tr>
                            <td style='border: 0px solid black; padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px; padding:5px'>ပตခ(ဝင)-၀၄-၀၅</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၆၊ ပုဒ်မခွဲ(က)၊ ပုဒ်မခွဲငယ်(၂)အရ<br>
                        စာရင်းအထောက်အထားများတင်ပြစေရန် သို့မဟုတ် ကြားနာစစ်ဆေးရန်အကြောင်းကြားစာ
                    </div>

                    <table style='width:100%; font-size:15px; border:none !important;'>
                        <tr>
                            <td style='text-align:right; width:60%'>စာအမှတ်၊ ပတခ/<span id="m0405_other_data"></span>/ဝငခ/၂၀<span id="orDate_year_short"></span>(&emsp;&emsp;&emsp;)</td>
                        </tr>
                        <tr>
                            <td style='text-align:right;'>ရက်&ensp;&ensp;စွဲ၊ 
                                <strong>
                                    <span id="orDate_year"></span> ခုနှစ်၊ &ensp;
                                    <span id="orDate_month"></span> &ensp; လ &ensp;
                                    <span id="orDate_day"></span> &ensp;ရက်
                                </strong> 
                            </td>
                        </tr>
                    </table>

                    <div style="margin-left: 0px; text-align:left; margin-top:10px;">
                        သို့<br>
                        <span style='padding-left:70px;'></span><span id="m0405_name" style="border-bottom:1px dotted; font-weight:bold;"></span><br>
                        <span style='padding-left:70px;'></span><span id="m0405_address" style="border-bottom:1px dotted; font-weight:bold;"></span><br>
                        <span style='padding-left:70px;'></span><span id="m0405_biz" style="border-bottom:1px dotted; font-weight:bold;"></span>
                    </div>

                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၁။<span style='padding-left:46px;'></span>လူကြီးမင်း၏ <strong><span id="m0405_biz_detail"></span></strong> အပေါ် ( <strong><span id="m0405_year"></span></strong> )ဘဏ္ဍာနှစ်အတွက် 
                        ဝင်ငွေခွန်စည်းကြပ်ရန် အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၂၂ နှင့် ဝင်ငွေခွန်ဥပဒေပုဒ်မခွဲ( ၁၇ )အရ ပေးပို့ထားသော ဝင်ငွေကြေညာလွှာကို မှန်/မမှန် စိစစ်နိုင်ရန် လိုအပ်သဖြင့်  
                        လူကြီးမင်းကိုယ်တိုင်ဖြစ်စေ သို့တည်းမဟုတ် စာဖြင့် တာဝန်လွှဲအပ်ထားသည့် ကိုယ်စားလှယ်ဖြစ်စေ ( <strong><span id="m0405_appDate"></span></strong> )နေ့ရက်၊ ( ၁၀:၀၀ )နာရီ အချိန်တွင် ဤရုံးသို့ 
                        လာရောက်၍ အထောက်အထားများ၊ စာရင်းစာအုပ်၊ စာရွက်စာတမ်းများကို တင်ပြရန် အကြောင်းကြားသည်။ 
                    </div>
                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၂။<span style='padding-left:46px;'></span>ဤအကြောင်းကြားစာအတိုင်း လိုက်နာဆောင်ရွက်ရန် ပျက်ကွက်ပါက အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေ ပုဒ်မ ၂၇(ဂ)အရ ရနိုင်သမျှ အထောက်အထားများကို အခြေပြု၍ 
                        အခွန်စည်းကြပ်ခြင်း၊ အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၇၀ / ၇၃ တို့အရ ဒဏ်ငွေတပ်ရိုက်ခြင်း၊  ပုဒ်မ ၇၈ အရ အရေးယူခြင်းတို့ကို ခံရဖွယ်ရှိကြောင်း အသိ‌ပေးအပ်ပါသည်။ 
                    </div>
                     <p style='border:0px solid; text-align:center;font-size:15px;line-height:24px'><span style='padding-left:44px'><strong> ပေးပို့ရန် သတင်းအချက်အလက်အထောက်အထား စာရွက်စာတမ်းများ</strong></span></p>

                    <p style='border:0px solid; text-align:left;font-size:15px;line-height:24px'>
                    <span style='padding-left:70px;'></span> (က) <span style='padding-left:30px;'> မှတ်ပုံတင်မူရင်း/မိတ္တူ </span><br/>
                    <span style='padding-left:70px;'></span> ( ခ ) <span style='padding-left:30px;'> အိမ်ထောင်စုဇယားမူရင်း/မိတ္တူ </span><br/>
                    <span style='padding-left:70px;'></span> ( ဂ ) <span style='padding-left:30px;'> မြေပုံမြေရာဇဝင်မူရင်း/မိတ္တူ </span><br/>
                    <span style='padding-left:70px;'></span> (ဃ) <span style='padding-left:30px;'> မြေငှားဂရန်မူရင်း/မိတ္တူ</span><br/>
                    <span style='padding-left:70px;'></span> ( င ) <span style='padding-left:30px;'> အရောင်းအဝယ်စာချုပ်မူရင်း/မိတ္တူ </span><br/>
                    <span style='padding-left:70px;'></span> ( စ ) <span style='padding-left:30px;'> Bank Transection </span><br/>
                    <span style='padding-left:70px;'></span> (ဆ) <span style='padding-left:30px;'> ဝင်ငွေရလမ်း/မူလတန်ဖိုးအတွက် တင်ပြလိုသည့် အထောက်အထားများ </span><br/></p>  
                    <br>
                    <table style='width:100%; margin-top:20px; border:none !important;'>
                        <tr>
                            <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်<br><br><br></td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br><span id="m0405_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး<br><br><br>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>
