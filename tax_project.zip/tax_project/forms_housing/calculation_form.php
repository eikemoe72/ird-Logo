<?php
// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    // အစ်ကို့ရဲ့ ပင်မ Table နာမည် 'sakalakahdata' ထဲမှ ဆွဲထုတ်ခြင်း
    $query = "SELECT * FROM sakalakahdata WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း
$os_case_number  = htmlspecialchars($db_data['case_number'] ?? '-');
$os_township  = htmlspecialchars($db_data['township_name'] ?? '-');
$os_year      = htmlspecialchars($db_data['tax_year'] ?? '-');
$os_name      = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_gir       = htmlspecialchars($db_data['gir_no'] ?? '-');
$os_gir_type  = htmlspecialchars($db_data['gir_type'] ?? '-');
$os_address   = htmlspecialchars($db_data['address'] ?? '-');
$os_officer   = htmlspecialchars($db_data['officer_name'] ?? '-');
$os_officer_rank      = htmlspecialchars($db_data['officer_rank'] ?? 'အခွန်ဦးစီးမှူး');
$os_biz       = htmlspecialchars($db_data['business_type'] ?? '-');



   // (၄) မြေနှင့် အဆောက်အဦးဆိုင်ရာ အချက်အလက်များ
$os_land_type   = htmlspecialchars($db_data['land_type'] ?? '-');
$os_block_no    = htmlspecialchars($db_data['block_no'] ?? '-');
$os_holding_no  = htmlspecialchars($db_data['holding_no'] ?? '-');
$os_city        = htmlspecialchars($db_data['city'] ?? '-');
$os_road        = htmlspecialchars($db_data['road'] ?? '-');
$os_area        = htmlspecialchars($db_data['area'] ?? '-');
$os_building_type        = htmlspecialchars($db_data['building_type'] ?? '-');
$os_building_height      = htmlspecialchars($db_data['building_height'] ?? '-');


$os_itDemandNo  = htmlspecialchars($db_data['it_demand_no'] ?? '......');
$os_itDemandDate  = htmlspecialchars($db_data['it_demand_date'] ?? '............');

$os_chalan_no  = htmlspecialchars($db_data['chalan_no'] ?? '......');
$os_chalan_date  = htmlspecialchars($db_data['chalan_date'] ?? '............');

$os_tasapha_no  = htmlspecialchars($db_data['tasapha_no'] ?? '......');
$os_tasapha_date  = htmlspecialchars($db_data['tasapha_date'] ?? '............');

$os_municipal_no  = htmlspecialchars($db_data['it_municipal_no'] ?? '......');
$os_permit_date  = htmlspecialchars($db_data['permit_date'] ?? '............');

$os_notified_date  = htmlspecialchars($db_data['notified_date'] ?? '............');
$os_appointment_date  = htmlspecialchars($db_data['appointment_date'] ?? '............');
$os_appearance_date  = htmlspecialchars($db_data['appearance_date'] ?? '............');
$os_notified  = htmlspecialchars($db_data['notified_date'] ?? '............');

$os_purchase_date = '-/-/-';
if (!empty($db_data['purchase_date']) && $db_data['purchase_date'] !== '0000-00-00') {
    $os_purchase_date = date('d-m-Y', strtotime($db_data['purchase_date']));
}

$os_assessment_submit_date   = htmlspecialchars($db_data['assessment_submit_date'] ?? '0');

$os_terget_date = '............'; // Default စာသား
if (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') {
    try {
        $date = new DateTime($db_data['it_demand_date']);
        $date->modify('+14 days'); // ရက်ပေါင်း ၁၄ ရက် တိုးလိုက်ခြင်း
        $os_terget_date = $date->format('d-m-Y'); // dd-mm-yyyy ပုံစံဖြင့် ထုတ်ယူခြင်း
    } catch (Exception $e) {
        $os_terget_date = '............';
    }
}


//ကိန်းဂဏန်းများ 
$os_declared_value     = number_format(floatval($db_data['declared_value'] ?? 0), 0, '.', ',');
$os_valuation_value    = number_format(floatval($db_data['valuation_value'] ?? 0), 0, '.', ',');
$os_allowable_expenses = number_format(floatval($db_data['allowable_expenses'] ?? 0), 0, '.', ',');

$os_taxable_income     = number_format(floatval($db_data['taxable_income'] ?? 0), 0, '.', ',');
$os_income_tax         = number_format(floatval($db_data['income_tax'] ?? 0), 0, '.', ',');
$os_advance_tax        = number_format(floatval($db_data['advance_tax'] ?? 0), 0, '.', ',');

$os_tax_to_pay         = number_format(floatval($db_data['tax_to_pay'] ?? 0), 0, '.', ',');
$os_penalty_tax        = number_format(floatval($db_data['penalty_tax'] ?? 0), 0, '.', ',');
$os_total_tax          = number_format(floatval($db_data['total_tax'] ?? 0), 0, '.', ',');
$os_source_of_income  = htmlspecialchars($db_data['source_of_income'] ?? '........................................................................');
$os_investigation = htmlspecialchars($db_data['investigation'] ?? '........................................................................');

?>


<script>
function openForcal() {
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြအောင် နှိပ်ပါ)။");
        return; 
    }
    
    console.log("Selected Row Data:", selectedRowData);

    // ၂။ Helper Functions
    const toMyanmarDigit = (num) => {
        if (!num) return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    const mmMonths = ['ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ'];

    // ၃။ Login User ရဲ့ Other Data
    const loginUserOther = "<?php echo $user_other_info; ?>"; 
    console.log("ရရှိလာသော Other Data:", loginUserOther);
    setText('cal_other_data', loginUserOther || '......');

    // ၄။ အခြေခံအချက်အလက်များ (🎯 ပင်မ Table နှင့် ကိုက်ညီအောင် Variable နာမည်များ ညှိလိုက်ပါပြီ)
    setText('cal_name', selectedRowData.taxpayer_name);
    setText('cal_address', selectedRowData.address);
    setText('cal_biz', selectedRowData.business_type || selectedRowData.businessType1);
    setText('cal_biz_detail', selectedRowData.business_type || selectedRowData.businessType1);
    setText('cal_township', selectedRowData.township_name || selectedRowData.state_name);
    
    let yearVal = selectedRowData.tax_year || selectedRowData.taxYear || '';
    setText('cal_year', toMyanmarDigit(yearVal));

    // ၅။ ရက်စွဲပိုင်းဆိုင်ရာ Process လုပ်ခြင်း
    const processDate = (dateStr, prefix) => {
        if (dateStr && dateStr.includes('-')) {
            const parts = dateStr.split('-');
            const yyyy = parts[0]; 
            const mm = parts[1];   
            const dd = parts[2].split(' ')[0];

            setText(prefix + '_year', toMyanmarDigit(yyyy));
            setText(prefix + '_month', mmMonths[parseInt(mm) - 1]);
            setText(prefix + '_day', toMyanmarDigit(dd));
            
            if (prefix === 'orDate') {
                setText('orDate_year_short', toMyanmarDigit(yyyy.slice(-2)));
                setText('cal_orDate', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            } else if (prefix === 'appDate') {
                setText('cal_appDate', `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`);
            }
        } else {
            setText(prefix + '_year', '....');
            setText(prefix + '_month', '....');
            setText(prefix + '_day', '....');
        }
    };

    // 🎯 ပင်မ Table Row မှ လာသော ရက်စွဲစာလုံးပေါင်းများနှင့် ကွက်တိညှိခြင်း
    let orderD = selectedRowData.order_date || selectedRowData.orderDate || selectedRowData.it_demand_date;
    let appD = selectedRowData.appointment_date || selectedRowData.appointmentDate;

    processDate(orderD, 'orDate');
    processDate(appD, 'appDate');

    // ၆။ Modal ကို ဖွင့်ခြင်း (🎯 HTML ID နှင့် ကိုက်ညီအောင် 'calculateModal' ဟု ပြင်ဆင်လိုက်ပါပြီ)
    var modalElem = document.getElementById('calculateModal');
    if (modalElem) {
        var myModal = new bootstrap.Modal(modalElem);
        myModal.show();
    } else {
        console.error("Modal element 'calculateModal' ကို ရှာမတွေ့ပါဗျာ။");
    }
}
</script>

<style>
/* ==========================================================================
   🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် တကယ့် A4 ကဲ့သို့ ဗဟိုကျကျပေါ်စေရန်)
   ========================================================================== */
#calculateModal .modal-dialog {
    max-width: 795px !important; 
    width: 95% !important;
    margin: 20px auto !important;
    position: relative; /* 🎯 Close Button ကို ပုံသေနေရာချရန် အရေးကြီးပါသည် */
}

#calculateModal .modal-content {
    background-color: #9ecaeb !important; /* အစ်ကိုကြီး ရွေးချယ်ထားသော အပြာနုရောင်နောက်ခံ */
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 30px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}

#calculateModal .modal-body {
    padding: 20px !important; 
    overflow-x: auto !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
    justify-content: center !important;
}

/* 🎯 ညာဘက်ထိပ်တွင် အနီရောင် X ခလုတ် ပေါ်စေရန် စတိုင် */
.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 36px !important;
    background-color: #dc3545 !important; /* အနီရောင် */
    color: #ffffff !important; /* အဖြူရောင် X */
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 36px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; /* မိုဒယ်စာမျက်နှာထက် အပေါ်စီးတွင် ရှိနေစေရန် */
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}

.custom-close-btn:hover {
    background-color: #bd2130 !important; /* Hover လုပ်လျှင် အနီရောင် ပိုရင့်သွားစေရန် */
}

/* 🎯 ကွန်ပျူတာပေါ်တွင် မြင်ရမည့် A4 စာရွက်ပုံစံအစစ် */
.print-container { 
    background: #ffffff !important;
    width: 210mm !important; 
    min-height: 297mm !important; 
    padding: 5mm 10mm 5mm 15mm !important; 
    margin: 0 auto 20px auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}

/* ဇယားများ ညာဘက်လုံးဝမကျွံစေရန် ထိန်းချုပ်မှု */
table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}

table, tr, td { 
    box-sizing: border-box !important;
}

/* ခလုတ်များရှိသော နေရာကို စာရွက်အထက်တွင် လှပစွာ ဗဟိုညှိပေးခြင်း */
#calculateModal .no-print-buttons {
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    gap: 16px !important;
    width: 100% !important;
    margin: 0 !important;
    padding: 14px 16px 16px 16px !important;
    background-color: #9ecaeb !important;
    box-sizing: border-box !important;
}

/* 🎯 ခေါင်းစီးစာသားကို ဆိုက်ကြီးပြီး ညာဘက်သို့ လှပစွာ တွန်းရွှေ့ပေးခြင်း */
.custom-modal-title {
    font-size: 20px !important; /* စာလုံးအရွယ်အစားကို ပိုကြီးအောင် ပြင်ဆင်ခြင်း */
    font-weight: bold !important; /* စာလုံးအထူ ထားခြင်း */
    color: #1a4d80 !important; /* စာသားအရောင်ကို ပိုမိုတောက်ပသော အပြာရင့်ရောင် ပြောင်းခြင်း */
    padding-left: 25px !important; /* 🎯 ဘယ်ဘက်မှ ၂၅ ပစ်ဇယ် စာသားကို ညာဘက်သို့ တွန်းချလိုက်ခြင်း */
    display: inline-block !important;
    line-height: 40px !important; /* စာသား၏ အထက်အောက် အကွာအဝေး မျှတစေရန် */
}

/* 🎯 အောက်ခြေခလုတ်များကို ဆိုက်ချဲ့ပြီး စာရွက်နှင့် ပိုမိုနီးကပ်စေရန် အပေါ်သို့ ကပ်ပေးခြင်း */
#calculateModal .no-print-buttons .btn {
    font-size: 16px !important;
    font-weight: bold !important;
    padding: 10px 24px !important;
    min-width: 140px !important;
    border-radius: 5px !important;
    color: #ffffff !important;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important;
    transition: all 0.2s ease-in-out !important;
}

#calculateModal .no-print-buttons .btn-print {
    background-color: #0b5ed7 !important;
    border: 1px solid #0a58ca !important;
}

#calculateModal .no-print-buttons .btn-close-form {
    background-color: #dc3545 !important;
    border: 1px solid #b02a37 !important;
}

#calculateModal .no-print-buttons .btn-print:hover {
    background-color: #0a58ca !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}

#calculateModal .no-print-buttons .btn-close-form:hover {
    background-color: #bb2d3b !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}
/* ==========================================================================
   🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် မြင်ရမည့်ပုံစံ)
   ========================================================================== */
#calculateModal .modal-dialog {
max-width: 900px; 
margin: 5px auto;
}

#calculateModal .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}
/* 🖨️ PRINT ထုတ်လျှင် X ခလုတ်ကိုပါ အလိုအလျောက် ဖျောက်ရန် */
@media print {
    .custom-close-btn { display: none !important; }
}

/* ==========================================================================
   🖨️ PRINT ထုတ်ယူသည့်အခါ စတိုင် (ညာဘက်မကျွံဘဲ အနားသတ်ကွက်တိဖြစ်စေမည့်စနစ်)
   ========================================================================== */
@media print {
    html, body {
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    #calculateModal .modal-footer,
    #calculateModal .no-print,
    #calculateModal .no-print-buttons,
    #calculateModal .btn,
    #calculateModal .btn-close,
    #calculateModal .modal-header,
    #calculateModal .custom-close-btn {
        display: none !important;
    }

    body:has(#calculateModal.show) > *:not(#calculateModal) {
        display: none !important;
    }

    #calculateModal {
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: visible !important;
    }

    .modal-dialog, .modal-content, .modal-body {
        margin: 0 !important;
        padding: 0 !important;
        max-width: 100% !important;
        width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        border: none !important;
        box-shadow: none !important;
        background: transparent !important;
        overflow: visible !important;
    }

    .print-container {
        width: 100% !important;
        max-width: 100% !important;
        min-height: 0 !important;
        height: auto !important;
        padding: 8mm 8mm 6mm 16mm !important;
        margin: 0 !important;
        border: none !important;
        box-shadow: none !important;
        display: block !important;
        box-sizing: border-box !important;
        page-break-after: avoid !important;
        page-break-inside: avoid !important;
    }

    table, .main-content-table, .main-content-table2, .order-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important;
    }

    table, tr, td {
        border: none !important;
        box-sizing: border-box !important;
    }

    hr { display: none !important; }

    @page {
        size: A4 portrait;
        margin: 0 !important;
    }
}


</style>

<script>
function closeAndReturnToDemandList() {
    // 1️⃣ လက်ရှိဖွင့်ထားသော #calculateModal ကို ပိတ်ခြင်း
    try {
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var myModalEl = document.getElementById('calculateModal');
            var modal = bootstrap.Modal.getInstance(myModalEl) || new bootstrap.Modal(myModalEl);
            modal.hide();
        }
        
        if (typeof jQuery !== 'undefined') {
            jQuery('#calculateModal').modal('hide');
            jQuery('.modal-backdrop').remove();
            jQuery('body').removeClass('modal-open').css('overflow', 'auto');
        }
    } catch (e) {
        console.log("Modal ပိတ်ရာတွင် အမှားရှိသည်: ", e);
    }
    
    // 2️⃣ မိခင်စာမျက်နှာ (capital_demand_list.php) ထဲက formsModal2 ကို လမ်းကြောင်းမှန်ဖြင့် ပြန်လှမ်းဖွင့်ခြင်း
    setTimeout(function() {
        if (window.opener && !window.opener.closed) {
            // အကယ်၍ Window အသစ် (Pop-up) ဖြင့် ပွင့်နေပါက
            try {
                if (window.opener.jQuery && window.opener.jQuery('#formsModal2').length) {
                    window.opener.jQuery('#formsModal2').modal('show');
                } else if (window.opener.bootstrap && window.opener.bootstrap.Modal) {
                    var parentModal = new window.opener.bootstrap.Modal(window.opener.document.getElementById('formsModal2'));
                    parentModal.show();
                }
            } catch (err) {
                console.log("Parent modal ဖွင့်မရပါ: ", err);
            }
            window.close(); 
        } else {
            /* 🎯 ဤနေရာတွင် လမ်းကြောင်းကို အစ်ကိုကြီးပြောသည့်အတိုင်း အပြင် main folder သို့ ထွက်ရန် ../ ဖြင့် ပြင်ဆင်ထားပါသည် */
            if (typeof jQuery !== 'undefined' && jQuery('#formsModal2').length) {
                jQuery('#formsModal2').modal('show');
            } else {
                // forms_housing folder ထဲမှ အပြင်သို့တစ်ဆင့်ထွက်ပြီး capital_demand_list.php သို့ သွားခြင်း
                window.location.href = '../capital_demand_list.php?openModal=formsModal2';
            }
        }
    }, 300); 
}
</script>

<div class="modal fade" id="calculateModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="custom-modal-title">အခွန်တွက်ချက်မှုပုံစံ ထုတ်ယူရန်</h5>

                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            <div class="modal-body" style="padding: 0px !important;">

            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <div style="text-align: center; margin-bottom: 10px;">
                        <h6 style="font-weight: bold; font-size: 15px; margin-bottom: 5px;">အခွန်တွက်ချက်မှုပုံစံ</h6>
                    </div>

                    <table class="main-content-table2" style="line-height:21px; font-size:14px;">
                        <tr>
                            <td style="width:54%"><b>အမှုတွဲအမှတ်စဉ်( <span id="os_case_number"><?php echo $os_case_number; ?></span> )</b></td>
                            <td style="width:22%; text-align:right;"><b>စည်းကြပ်နှစ် ၊</b></td>
                            <td style="width:24%; border-bottom: 1.5px dashed #000 !important; text-align:center;"> <span id="os_year"><?php echo $os_year; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>GIR-No ၊</b></td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:center;"> <span id="os_gir"><?php echo $os_gir; ?></span>/<span id="os_gir_type"><?php echo $os_gir_type; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>အခွန်မှူး ၊</b></td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:center;"> <span id="os_officer"><?php echo $os_officer; ?></span></td>
                        </tr>
                        <tr>
                            <td></td>
                            <td style="text-align:right;"><b>ရာထူး ၊</b></td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:center;"> <span id="os_officer_rank "><?php echo $os_officer_rank ; ?></span></td>
                        </tr>
                    </table>

                     <table class="main-content-table2" style="line-height:21px; font-size:14px;">
                        <tr>
                            <td style="width:5%; text-align:left;">၁။</td>
                            <td style="width:36%; text-align:left; font-weight: bold;">အခွန်ထမ်းအမည်</td>
                            <td style="width:4%; text-align:center;">-</td>
                            <td style="width:55%; border-bottom: 1.5px dashed #000 !important; text-align:left;"> <span id="os_name"><?php echo $os_name; ?></span></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၂။</td>
                            <td style="text-align:left; font-weight: bold;">အခွန်ထမ်းလိပ်စာ</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> <span id="os_address"><?php echo $os_address; ?></span></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၃။</td>
                            <td style="text-align:left; font-weight: bold;">လုပ်ငန်းအမျိုးအစား</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> <span id="os_biz"><?php echo $os_biz; ?></span></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၄။</td>
                            <td style="text-align:left; font-weight: bold;">အခြေပစ္စည်းလိပ်စာ</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;">
                                အကွက်( <span id="os_block_no"><?php echo $os_block_no; ?></span> )၊ 
                                ဦးပိုင်( <span id="os_holding_no"><?php echo $os_holding_no; ?></span> )၊ 
                                ဧရီယာ( <span id="os_area "><?php echo $os_area ; ?></span> )၊ 
                              </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;"></td>
                            <td style="text-align:left; font-weight: bold;"></td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;">
                                ( <span id="os_road "><?php echo $os_road ; ?></span> )၊ 
                                ( <span id="os_city"><?php echo $os_city; ?></span> ) </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၅။</td>
                            <td style="text-align:left; font-weight: bold;">မြေနှင့်အတူပါအိမ်အမျိုးအစား</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> <span id="os_building_type"><?php echo $os_building_type; ?></span>၊ </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၆။</td>
                            <td style="text-align:left; font-weight: bold;">အဆောက်ဦအတိုင်းအတာ</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> ( <span id="os_building_height"><?php echo $os_building_height; ?></span> )</td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၇။</td>
                            <td style="text-align:left; font-weight: bold;">အခြေပစ္စည်းဝယ်ယူရောင်းချသည့်နေ့</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left; "> 
                                ( <span id="cal_purchase_date"><?php echo !empty($os_purchase_date) ? $os_purchase_date : '-/-/-'; ?> )</span>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၈။</td>
                            <td style="text-align:left; font-weight: bold;">မြေအမျိုးအစား</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> <span id="os_land_type"><?php echo $os_land_type; ?></span></td>
                        </tr>
                        
                    <?php 
                    // 🌟 🌟 🌟 [၁။ ပထမဆုံးအဆင့် - "အခြေ" ဖြစ်/မဖြစ် စစ်ဆေးခြင်း] 🌟 🌟 🌟
                    if ($os_gir_type === 'အခြေ(အိမ်မြေ)' || $os_biz === 'အခြေ(အိမ်မြေ)') { 
                    ?>
                        <tr>
                            <td style="text-align:left;">၉။</td>
                            <td style="text-align:left; font-weight: bold;">အခွန်ထမ်းတင်ပြသည့်အရောင်းတန်ဖိုး</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> 
                                <span id="os_declared_value"><?php echo $os_declared_value; ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၁၀။</td>
                            <td style="text-align:left; font-weight: bold;">အစားထိုးသတ်မှတ်သည့်အရောင်းတန်ဖိုး</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> 
                                <span id="os_valuation_value"><?php echo $os_valuation_value; ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၁၁။</td>
                            <td colspan='3' style="text-align:left; font-weight: bold;">အစားထိုးခန့်မှန်းသတ်မှတ်သည့် အရောင်းတန်ဖိုးနှင့်ပတ်သက်၍ ရှင်းလင်းချက်</td>
                        </tr>

                        <tr>
                            <td style="text-align:left;"></td>
                            <td colspan='3' style="text-align:justify;">&emsp;&emsp;<span id="os_township"><?php echo $os_township; ?></span>၊
                                အိမ်ခြံမြေကာလတန်ဖိုးစိစစ်သတ်မှတ်ရေးအဖွဲ့၏ ( <span style="color:red;" id="os_tasapha_date"><?php echo $os_tasapha_date; ?></span> )ရက်စွဲပါ  
                                တစဖ အမှတ်စဉ် ( <span style="color:red;" id="os_tasapha_no"><?php echo $os_tasapha_no; ?></span> )အရ အခြေပစ္စည်း၏ ကာလတန်ဖိုးအား အစားထိုးသတ်မှတ်ပါသည်။   
                            </td>
                        </tr>

                        <tr>
                            <td style="text-align:left; vertical-align:top;">၁၂။</td>
                            <td colspan='3' style="text-align:left; "><b>အခွန်ထမ်းတင်ပြသော မူလတန်ဖိုးနှင့်ဖြည့်စွက်စရိတ်များ</b></td>
                        </tr>
                        <tr>
                            <td style="text-align:left; vertical-align:top;"></td>
                            <td colspan='3' style="text-align:left; ">&emsp;&emsp;<span style="text-align:justify; line-height:21px" id="os_source_of_income"><?php echo $os_source_of_income; ?></span></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;vertical-align:top;">၁၃။</td>
                            <td colspan='3' style="text-align:left;"><b>အခွန်ထမ်းတင်ပြသည့် မူလတန်ဖိုးနှင့်ဖြည့်စွက်စရိတ်အပေါ် စိစစ်ခွင့်ပြုမှုနှင့်ပတ်သက်၍ ရှင်းလင်းတင်ပြချက်</b></td>
                        </tr>
                        <tr>
                            <td style="text-align:left; vertical-align:top;"></td>
                            <td colspan='3' style="text-align:left; ">&emsp;&emsp;<span style="text-align:justify; line-height:21px" id="os_investigation"><?php echo $os_investigation; ?></span></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၁၄။</td>
                            <td colspan='3' style="text-align:left; font-weight: bold;">အခြေပစ္စည်းမှမြတ်စွန်းငွေအတွက် ဝင်ငွေခွန်တွက်ချက်မှု</td>
                        </tr>
                    </table> <table style="width:100%; border:none !important; line-height:21px; font-size:15px; margin-top:10px;">
                        <tr>
                            <td style="border:none !important; width:55%; text-align:right;">အခြေပစ္စည်းသတ်မှတ်အရောင်းတန်ဖိုး</td>
                            <td style="border:none !important; width:5%; text-align:center;">=</td>
                            <td style="border:none !important; width:20%; border-bottom: 1.5px dashed #000 !important; text-align:right; font-weight: bold; padding-right:15px;"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></span></td>
                            <td style="border:none !important; width:20%;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; width:55%; text-align:right;">(နုတ်)မူလတန်ဖိုးနှင့်ခွင့်ပြုစရိတ်</td>
                            <td style="border:none !important; width:5%; text-align:center;">=</td>
                            <td style="border:none !important; width:20%; border-bottom: 1.5px dashed #000 !important; text-align:right; font-weight: bold; color:red; padding-right:15px;"><span id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></span></td>
                            <td style="border:none !important; width:20%;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; width:55%; text-align:right;">အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                            <td style="border:none !important; width:5%; text-align:center;">=</td>
                            <td style="border:none !important; width:20%; border-bottom: 1.5px solid #000 !important; text-align:right; font-weight: bold; padding-right:15px;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            <td style="border:none !important; width:20%;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; text-align:right;">၁၀ % ဖြင့်ကျသင့်ဝင်ငွေခွန်</td>
                            <td style="border:none !important; text-align:center;">=</td>
                            <td style="border:none !important; border-bottom: 1.5px dashed #000 !important; text-align:right; font-weight: bold; padding-right:15px;"><span id="os_income_tax"><?php echo $os_income_tax; ?></span></td>
                            <td style="border:none !important;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; width:55%; text-align:right;">ဒဏ်ကြေး</td>
                            <td style="border:none !important; width:5%; text-align:center;">=</td>
                            <td style="border:none !important; width:20%; border-bottom: 1.5px solid #000 !important; text-align:right; font-weight: bold; padding-right:15px;"><span id="os_penalty_tax"><?php echo $os_penalty_tax; ?></span></td>
                            <td style="border:none !important; width:20%;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; text-align:right;">ပေးဆောင်ရမည့် အခွန်+ဒဏ်</td>
                            <td style="border:none !important; text-align:center;">=</td>
                            <td style="border:none !important; border-bottom: 1.5px solid #000 !important; text-align:right; font-weight: bold; padding-right:15px;"><span id="os_total_tax"><?php echo $os_total_tax; ?></span></td>
                            <td style="border:none !important;"></td>
                        </tr>
                    </table>

                    <br><br>
                    <table style='width:100%; margin-top:16px; border:none !important;font-size:15px;'>
                        <tr>
                            <td style='width:50%; padding-left:100px'></td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br><span id="os_township"><?php echo $os_township; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>

                    <?php 
                    } else { 
                    ?>
                        <tr>
                            <td style="text-align:left;">၉။</td>
                            <td style="text-align:left; font-weight: bold;">အခွန်ထမ်းတင်ပြသည့်အဝယ်တန်ဖိုး</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> 
                                <span id="os_declared_value"><?php echo $os_declared_value; ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၁၀။</td>
                            <td style="text-align:left; font-weight: bold;">အစားထိုးသတ်မှတ်သည့်အဝယ်တန်ဖိုး</td>
                            <td style="text-align:center;">-</td>
                            <td style="border-bottom: 1.5px dashed #000 !important; text-align:left;"> 
                                <span id="os_valuation_value"><?php echo $os_valuation_value; ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၁၁။</td>
                            <td colspan='3' style="text-align:left; font-weight: bold;">အစားထိုးခန့်မှန်းသတ်မှတ်သည့် အဝယ်တန်ဖိုးနှင့်ပတ်သက်၍ ရှင်းလင်းချက်</td>
                        </tr>
                        <?php 
                        // 🌟 [ထပ်ဆင့် Condition စစ်ဆေးခြင်း] လယ်ယာမြေ သို့မဟုတ် ဥယျဉ်မြေ ဖြစ်လျှင်
                        if ($os_land_type === 'လယ်ယာမြေ' || $land_type === 'ဥယျဉ်မြေ') { 
                        ?>
                            <tr>
                                <td style="text-align:left;"></td>
                                <td colspan='3' style="text-align:justify;">&emsp;&emsp;<span id="os_township"><?php echo $os_township; ?></span>၊
                                    လယ်ယာမြေစီမံခန့်ခွဲရေးအဖွဲ့၏ ( <span style="color:red;" id="os_tasapha_date"><?php echo $os_tasapha_date; ?></span> )ရက်စွဲပါ  
                                    စာအမှတ် ( <span style="color:red;" id="os_tasapha_no"><?php echo $os_tasapha_no; ?></span> )အရ အခြေပစ္စည်း၏ ကာလတန်ဖိုးအား အစားထိုးသတ်မှတ်ပါသည်။   
                                </td>
                            </tr>
                        <?php 
                        } else { 
                        ?>
                            <tr>
                                <td style="text-align:left;"></td>
                                <td colspan='3' style="text-align:justify;">&emsp;&emsp;<span id="os_township"><?php echo $os_township; ?></span>၊
                                    အိမ်ခြံမြေကာလတန်ဖိုးစိစစ်သတ်မှတ်ရေးအဖွဲ့၏ ( <span style="color:red;" id="os_tasapha_date"><?php echo $os_tasapha_date; ?></span> )ရက်စွဲပါ  
                                    တစဖ အမှတ်စဉ် ( <span style="color:red;" id="os_tasapha_no"><?php echo $os_tasapha_no; ?></span> )အရ အခြေပစ္စည်း၏ ကာလတန်ဖိုးအား အစားထိုးသတ်မှတ်ပါသည်။   
                                </td>
                            </tr>
                        <?php 
                        } // မြေအမျိုးအစား if-else အပိတ် 
                        ?>
                        
                        <tr>
                            <td style="text-align:left; vertical-align:top;">၁၂။</td>
                            <td colspan='3' style="text-align:left; "><b>အခွန်ထမ်းတင်ပြသော ဝင်ငွေရလမ်းများ</b></td>
                        </tr>
                        <tr>
                            <td style="text-align:left; vertical-align:top;"></td>
                            <td colspan='3' style="text-align:left; ">&emsp;&emsp;<span style="text-align:justify; line-height:21px" id="os_source_of_income"><?php echo $os_source_of_income; ?></span></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;vertical-align:top;">၁၃။</td>
                            <td colspan='3' style="text-align:left;"><b>အခွန်ထမ်းတင်ပြသော ဝင်ငွေရလမ်းအပေါ် စိစစ်ခွင့်ပြုမှုနှင့်ပတ်သက်၍ ရှင်းလင်းတင်ပြချက်</b></td>
                        </tr>
                        <tr>
                            <td style="text-align:left; vertical-align:top;"></td>
                            <td colspan='3' style="text-align:left; ">&emsp;&emsp;<span style="text-align:justify; line-height:21px" id="os_investigation"><?php echo $os_investigation; ?></span></td>
                        </tr>
                        <tr>
                            <td style="text-align:left;">၁၄။</td>
                            <td colspan='3' style="text-align:left; font-weight: bold;">စည်းကြပ်မှုမှလွှတ်ကင်းနေသောဝင်ငွေအတွက် ဝင်ငွေခွန်တွက်ချက်မှု</td>
                        </tr>
                    </table>

                    <table style="width:100%; border:none !important; line-height:21px; font-size:14px;">
                        <tr>
                            <td style="border:none !important; width:55%; text-align:right;">အခြေပစ္စည်း သတ်မှတ်အဝယ်တန်ဖိုး</td>
                            <td style="border:none !important; width:5%; text-align:center;">=</td>
                            <td style="border:none !important; width:20%; border-bottom: 1.5px dashed #000 !important; text-align:right; font-weight: bold; padding-right:15px;" id="cal_valuation_value"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></span></td>
                            <td style="border:none !important; width:20%;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; width:55%; text-align:right;">(နုတ်)ခွင့်ပြုဝင်ငွေရလမ်း</td>
                            <td style="border:none !important; width:5%; text-align:center;">=</td>
                            <td style="border:none !important; width:20%; border-bottom: 1.5px dashed #000 !important; text-align:right; font-weight: bold; color:red; padding-right:15px;" id="cal_allowable_expenses"><span id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></span></td>
                            <td style="border:none !important; width:20%;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; width:55%; text-align:right;">စည်းကြပ်မှမှလွှတ်ကင်းနေသောဝင်ငွေ</td>
                            <td style="border:none !important; width:5%; text-align:center;">=</td>
                            <td style="border:none !important; width:20%; border-bottom: 1.5px solid #000 !important; text-align:right; font-weight: bold; padding-right:15px;" id="cal_profit"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            <td style="border:none !important; width:20%;"></td>
                        </tr>
                        <tr>
                            <td style="border:none !important; text-align:right;">ကျသင့်ဝင်ငွေခွန်</td>
                            <td style="border:none !important; text-align:center;">=</td>
                            <td style="border:none !important; border-bottom: 1.5px solid #000 !important; text-align:right; font-weight: bold; padding-right:15px;" id="cal_income_tax"><span id="os_income_tax"><?php echo $os_income_tax; ?></span></td>
                            <td style="border:none !important;"></td>
                        </tr>
                        </table>

                        <br><br><br><br>
                        <table style='width:100%; margin-top:16px; border:none !important;font-size:15px;'>
                            <tr>
                                <td style='width:50%; padding-left:100px'></td>
                                <td style='text-align:center;'>
                                    တာဝန်ခံအရာရှိ<br><span id="os_township"><?php echo $os_township; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                                </td>
                            </tr>
                        </table>
                        <br><br><br><br>
                    <?php 
                    } // if-else အပိတ်
                    ?>
               

                   
                </div>
            </div>
            <div class="no-print-buttons no-print">
                <button type="button" class="btn btn-print" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary btn-close-form" onclick="closeAndReturnToDemandList()">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>


