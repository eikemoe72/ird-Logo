<?php

// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    // အစ်ကို့ရဲ့ ပင်မ Table နာမည် 'sakalakahdata' ထဲမှ ဆွဲထုတ်ခြင်း
    $query = "SELECT * FROM sakalakahdata WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း
$os_case_number  = htmlspecialchars($db_data['case_number'] ?? '-');
$os_township  = htmlspecialchars($db_data['township_name'] ?? '-');
$os_year      = htmlspecialchars($db_data['tax_year'] ?? '-');
$os_name      = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_gir       = htmlspecialchars($db_data['gir_no'] ?? '-');
$os_gir_type  = htmlspecialchars($db_data['gir_type'] ?? '-');
$os_address   = htmlspecialchars($db_data['address'] ?? '-');
$os_officer   = htmlspecialchars($db_data['officer_name'] ?? '-');
$os_officer_rank      = htmlspecialchars($db_data['officer_rank'] ?? 'အခွန်ဦးစီးမှူး');
$os_biz       = htmlspecialchars($db_data['business_type'] ?? '-');



   // (၄) မြေနှင့် အဆောက်အဦးဆိုင်ရာ အချက်အလက်များ
$os_land_type   = htmlspecialchars($db_data['land_type'] ?? '-');
$os_block_no    = htmlspecialchars($db_data['block_no'] ?? '-');
$os_holding_no  = htmlspecialchars($db_data['holding_no'] ?? '-');
$os_city        = htmlspecialchars($db_data['city'] ?? '-');
$os_road        = htmlspecialchars($db_data['road'] ?? '-');
$os_area        = htmlspecialchars($db_data['area'] ?? '-');
$os_building_type        = htmlspecialchars($db_data['building_type'] ?? '-');
$os_building_height      = htmlspecialchars($db_data['building_height'] ?? '-');


$os_itDemandNo  = htmlspecialchars($db_data['it_demand_no'] ?? '......');
$os_itDemandDate  = htmlspecialchars($db_data['it_demand_date'] ?? '............');

$os_chalan_no  = htmlspecialchars($db_data['chalan_no'] ?? '......');
$os_chalan_date  = htmlspecialchars($db_data['chalan_date'] ?? '............');

$os_tasapha_no  = htmlspecialchars($db_data['tasapha_no'] ?? '......');
$os_tasapha_date  = htmlspecialchars($db_data['tasapha_date'] ?? '............');

$os_municipal_no  = htmlspecialchars($db_data['it_municipal_no'] ?? '......');
$os_permit_date  = htmlspecialchars($db_data['permit_date'] ?? '............');

$os_notified_date  = htmlspecialchars($db_data['notified_date'] ?? '............');
$os_appointment_date  = htmlspecialchars($db_data['appointment_date'] ?? '............');
$os_appearance_date  = htmlspecialchars($db_data['appearance_date'] ?? '............');
$os_notified  = htmlspecialchars($db_data['notified_date'] ?? '............');

$os_purchase_date = '-/-/-';
if (!empty($db_data['purchase_date']) && $db_data['purchase_date'] !== '0000-00-00') {
    $os_purchase_date = date('d-m-Y', strtotime($db_data['purchase_date']));
}

$os_assessment_submit_date   = htmlspecialchars($db_data['assessment_submit_date'] ?? '0');

$os_terget_date = '............'; // Default စာသား
if (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') {
    try {
        $date = new DateTime($db_data['it_demand_date']);
        $date->modify('+14 days'); // ရက်ပေါင်း ၁၄ ရက် တိုးလိုက်ခြင်း
        $os_terget_date = $date->format('d-m-Y'); // dd-mm-yyyy ပုံစံဖြင့် ထုတ်ယူခြင်း
    } catch (Exception $e) {
        $os_terget_date = '............';
    }
}

//ကိန်းဂဏန်းများ 
$os_declared_value  = htmlspecialchars($db_data['declared_value'] ?? '0');
$os_valuation_value  = htmlspecialchars($db_data['valuation_value'] ?? '0');
$os_allowable_expenses  = htmlspecialchars($db_data['allowable_expenses'] ?? '0');
$os_taxable_income  = htmlspecialchars($db_data['taxable_income'] ?? '0');
$os_income_tax   = htmlspecialchars($db_data['income_tax'] ?? '0');
$os_advance_tax   = htmlspecialchars($db_data['advance_tax'] ?? '0');
$os_tax_to_pay   = htmlspecialchars($db_data['tax_to_pay'] ?? '0');
$os_penalty_tax   = htmlspecialchars($db_data['penalty_tax'] ?? '0');
$os_total_tax   = htmlspecialchars($db_data['total_tax'] ?? '0');

$os_source_of_income  = htmlspecialchars($db_data['source_of_income'] ?? '........................................................................');
$os_investigation  = htmlspecialchars($db_data['investigation'] ?? '........................................................................');

?>


<style>
#form0406Modal .modal-dialog {
    max-width: 210mm;
    width: calc(100vw - 32px);
    margin: 16px auto;
}

#form0406Modal .modal-content {
    overflow: hidden;
}

#form0406Modal .modal-body {
    padding: 0 !important;
    overflow-x: hidden;
}

/* A4 အကျယ်အတင်းက မော်ဒယ်နောက်ခံထက် ညာဘက်ကျွံမထွက်စေရန် */
#form0406Modal .print-container {
    width: 100% !important;
    max-width: 100% !important;
    min-height: 0 !important;
    box-sizing: border-box !important;
    margin: 0 auto !important;
    padding: 10mm 12mm 10mm 18mm !important;
    line-height: 1.9 !important;
    font-size: 15px !important;
    background: #fff;
}

#form0406Modal .print-container p,
#form0406Modal .print-container div,
#form0406Modal .print-container td,
#form0406Modal .print-container th,
#form0406Modal .print-container span,
#form0406Modal .print-container strong {
    line-height: 1.9 !important;
    font-size: 15px !important;
}

#form0406Modal .print-container table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed;
}

.underline { border-bottom: 1px dotted solid; width: 250px; }

@media print {
    .modal-footer, .no-print, .btn, .btn-close, .modal-header { display: none !important; }
    .modal-content, .modal-body { border: none !important; box-shadow: none !important; }

    body * { visibility: hidden; }
    #form0406Modal, #form0406Modal * { visibility: visible !important; }
    #form0406Modal {
        position: absolute;
        left: 0 !important;
        top: 0;
        width: 100%;
        margin: 0 !important;
        padding: 0 !important;
    }

    #form0406Modal .print-container {
        width: 100% !important;
        max-width: 100% !important;
        padding: 10mm 12mm 10mm 20mm !important;
        border: none !important;
        margin: 0 !important;
        line-height: 1.9 !important;
        font-size: 15px !important;
    }

    .modal-dialog {
        margin: 0 !important;
        max-width: 100% !important;
        width: 100% !important;
    }

    .modal-content, .modal-body {
        border: none !important;
        padding: 0 !important;
    }

    #form0406Modal table,
    #form0406Modal tr,
    #form0406Modal td {
        border: none !important;
    }

    #form0406Modal .print-container table:first-child {
        border: 1.5px solid #000 !important;
    }

    .modal-header, .modal-footer {
        border: none !important;
        border-bottom: none !important;
        border-top: none !important;
        box-shadow: none !important;
    }

    hr { display: none !important; }
}
</style>

<div class="modal fade" id="form0406Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: none;">
                <h5 class="modal-title">၀၄-၀၆ သတင်းအချက်အလက်များပေးပို့ရန်အကြောင်းကြားစာ ထုတ်ယူရန်</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:25px">
                        <tr>
                            <td style='border: 0px solid black; padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px; padding:5px'>ပတခ(ဝင)-၀၄-၀၆</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၆၊ ပုဒ်မခွဲ(က)၊ ပုဒ်မခွဲငယ်(၁)အရ <br>
                        သတင်းအချက်အလက်များပေးပို့ရန်အကြောင်းကြားစာ 
                    </div>
                    <table style='width: 100%; font-size: 15px; margin-top: 10px;'>
                        <tr>
                            <td style='text-align: right; width: 100%; letter-spacing: 0.5px;'>
                                စာအမှတ်၊ ပတခ/<span id="m0406_other_data"></span>/ဝငခ/၂၀<span id="m0406_year_short_letter"></span>(&emsp;&emsp;&emsp;)
                            </td>
                        </tr>
                        <tr>
                            <td style='text-align: right;'>
                                ရက်&ensp;&ensp;စွဲ၊ 
                                <strong>
                                    ၂၀<span id="m0406_year_short"></span> ခုနှစ်၊ &ensp;
                                    <span id="m0406_month"></span> &ensp;&ensp;လ &ensp;
                                    <span id="m0406_day"></span>&ensp;&ensp;ရက်
                                </strong> 
                            </td>
                        </tr>
                    </table>

                    
                    <div style="margin-left: 0px; text-align:left; margin-top:10px;">
                        သို့<br>
                        <span style = 'padding-left:70px;'></span><span id="m0406_name" style="border-bottom:1.5px dotted; font-weight:bold;" ></span><br>
                        <span style = 'padding-left:70px;'></span><span id="m0406_address" style="border-bottom:1.5px dotted; font-weight:bold;"></span><br>
                        <span style = 'padding-left:70px;'></span><span id="m0406_biz" style="border-bottom:1.5px dotted; font-weight:bold;"></span>
                    </div>

                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၁။<span style = 'padding-left:46px;'><strong><span id="m0406_biz_detail"></span></strong> လုပ်ငန်းအပေါ်တွင် ဝင်ငွေခွန်စည်းကြပ်သည့် 
                        ကိစ္စနှင့်ပတ်သက်၍ လူကြီးမင်းထံမှ သတင်းအချက်အလက်များကို ရရှိစစ်ဆေးရန် လိုအပ်ပါသဖြင့် ( <strong><span id="m0406_appearance_date">....-....-....</span></strong> )
                        ရက်နေ့၊ (၁၀:၀၀) နာရီအချိန် သို့မဟုတ် ယင်းကာလမတိုင်မီတွင် အောက်တွင်ဖော်ပြထားသည်တို့ကို ဤရုံးသို့ ပေးပို့ရန် အကြောင်းကြားပါသည်။ 
                    </div>
                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၂။<span style = 'padding-left:46px;'></span>ဤအကြောင်းကြားစာအတိုင်း လိုက်နာဆောင်ရွက်ရန် ပျက်ကွက်ပါက  အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေ 
                        ပုဒ်မ ၇၀/၇၃ တို့အရ ဒဏ်ငွေတပ်ရိုက်ခြင်း၊  ပုဒ်မ ၇၈ အရ အရေးယူခြင်းတို့ကိုခံရဖွယ်ရှိကြောင်း အသိပေးအပ်ပါသည်။
                    </div>
                     <p style = 'border:0px solid; text-align:center;font-size:15px;line-height:24px'><span style = 'padding-left:44px'><strong> ပေးပို့ရန် သတင်းအချက်အလက်အထောက်အထား စာရွက်စာတမ်းများ</strong ></span></p >

                    <p style = 'border:0px solid; text-align:left;font-size:15px;line-height:24px'>
                    <span style = 'padding-left:70px;'></span> (က) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span> ( ခ ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span> ( ဂ ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span > (ဃ) <span style = 'padding-left:30px;'> ........................................</span><br/>
                    
                    <span style = 'padding-left:70px;'></span> ( င ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span > ( စ ) <span style = 'padding-left:30px;'> ........................................ </span><br/></p>  

                    <table style='width:100%; margin-top:30px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center;'>
                                တာဝန်ခံအရာရှိ<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br><span id="m0406_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div class="modal-footer no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>


<script>
function openForm0406() {
    console.log("Selected Row Data:", selectedRowData);

    // ၁။ Row ရွေးထားခြင်း ရှိမရှိ စစ်ဆေးခြင်း
    if (typeof selectedRowData === 'undefined' || !selectedRowData) {
        alert("ကျေးဇူးပြု၍ Table ထဲမှ row တစ်ခုကို အရင်ရွေးချယ်ပေးပါ (Highlight ပြာသွားအောင် နှိပ်ပါ)။");
        return;
    }

    // ၂။ Helper Functions (မြန်မာဂဏန်းပြောင်းခြင်းနှင့် စာသားထည့်ခြင်း)
    const toMyanmarDigit = (num) => {
        if (!num) return '';
        const mDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
        return num.toString().replace(/\d/g, d => mDigits[d]);
    };

    const setText = (id, val) => {
        const el = document.getElementById(id);
        if (el) el.innerText = val || '';
    };

    // 📅 အင်္ဂလိပ်ရက်စွဲပုံစံ (YYYY-MM-DD) ကို မြန်မာရက်စွဲပုံစံ (DD-MM-YYYY) သို့ ပြောင်းပေးသော Function
    const formatToMyanmarDate = (dateStr) => {
        if (!dateStr || !dateStr.includes('-')) return '............';
        const parts = dateStr.split('-');
        const yyyy = parts[0];
        const mm = parts[1];
        const dd = parts[2].split(' ')[0];
        return `${toMyanmarDigit(dd)}-${toMyanmarDigit(mm)}-${toMyanmarDigit(yyyy)}`;
    };

    const mmMonths = ['ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ'];

      // ၃။ Login User ရဲ့ Other Data
    const loginUserOther = "<?php echo $user_other_info; ?>"; 
    console.log("ရရှိလာသော Other Data:", loginUserOther);
    setText('m0406_other_data', loginUserOther || '......');


    // ၄။ အခြေခံအချက်အလက်များ ထည့်သွင်းခြင်း
    setText('m0406_name', selectedRowData.taxpayer_name);
    setText('m0406_address', selectedRowData.address);
    setText('m0406_biz', selectedRowData.business_type || selectedRowData.businessType1);
    setText('m0406_biz_detail', selectedRowData.business_type || selectedRowData.businessType1);
    setText('m0406_township', selectedRowData.township_name || selectedRowData.state_name);
    setText('m0406_remark2', selectedRowData.remark2 || selectedRowData.remark2);

    let noticeDate = selectedRowData.notified_date || selectedRowData.it_demand_date || selectedRowData.orderDate || selectedRowData.entry_date;
    
    if (noticeDate && noticeDate.includes('-')) {
        const parts = noticeDate.split('-');
        const yyyy = parts[0]; 
        const mm = parts[1];   
        const dd = parts[2].split(' ')[0];

        const shortYear = toMyanmarDigit(yyyy.slice(-2)); // နှစ် (နောက်ဆုံး ၂ လုံး) ကို variable တစ်ခုထဲ အရင်သိမ်း

        // ID နှစ်ခုလုံးထဲကို တန်ဖိုး ထည့်ပေးလိုက်ပါတယ်
        setText('m0406_year_short_letter', shortYear); // စာအမှတ်နေရာအတွက်
        setText('m0406_year_short', shortYear);        // ရက်စွဲနေရာအတွက်
        
        setText('m0406_month', mmMonths[parseInt(mm) - 1]);         // မြန်မာလနာမည်
        setText('m0406_day', toMyanmarDigit(parseInt(dd)));         // ရက်စွဲဂဏန်း
    } else {
        setText('m0406_year_short_letter', '....');
        setText('m0406_year_short', '....');
        setText('m0406_month', '....');
        setText('m0406_day', '....');
    }

    // ၆။ 🎯 အနီပြ (ဒုတိယနေရာ) - ရုံးသို့ လာရောက်ရမည့်ရက် (appearance_date သို့မဟုတ် appointmentDate)
    let appearanceDate = selectedRowData.appearance_date || selectedRowData.appointment_date || selectedRowData.appointmentDate;
    if (appearanceDate) {
        setText('m0406_appearance_date', formatToMyanmarDate(appearanceDate));
    } else {
        setText('m0406_appearance_date', '....-....-....');
    }

    // ၇။ Modal ကို ဖွင့်ခြင်း
    var modalElem = document.getElementById('form0406Modal');
    if (modalElem) {
        var myModal = bootstrap.Modal.getInstance(modalElem) || new bootstrap.Modal(modalElem);
        myModal.show();
    }
}
</script>