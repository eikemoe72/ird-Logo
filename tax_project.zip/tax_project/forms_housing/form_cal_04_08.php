<?php
// ၁။ Session စတင်ခြင်း နှင့် Error အားလုံးကို Browser တွင် ပေါ်အောင် ဖွင့်ပေးခြင်း
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ db_config.php ချိတ်ဆက်မှုကို စစ်ဆေးခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}

if (!isset($conn)) {
    die("Database Connection Error: \$conn variable is not defined.");
}
$conn->set_charset("utf8mb4");

// ၃။ Login User ၏ အချက်အလက်များ ဆွဲထုတ်ခြင်း
$os_md_no = '............'; 
$os_bank_township = '............'; 
$session_user = $_SESSION['user_id'] ?? $_SESSION['username'] ?? '';

if (!empty($session_user)) {
    $user_stmt = $conn->prepare("SELECT md_no, bank_township FROM user_register WHERE id = ? LIMIT 1");
    if ($user_stmt) {
        $user_stmt->bind_param("s", $session_user);
        $user_stmt->execute();
        $user_res = $user_stmt->get_result();
        if ($user_res && $user_res->num_rows > 0) {
            $user_row = $user_res->fetch_assoc();
            if (!empty($user_row['md_no'])) $os_md_no = htmlspecialchars($user_row['md_no']);
            if (!empty($user_row['bank_township'])) $os_bank_township = htmlspecialchars($user_row['bank_township']);
        }
        $user_stmt->close();
    }
}

// ၄။ URL ID မှ ဒေတာဆွဲထုတ်ခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    $query = "SELECT * FROM sakalakahdata WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၅။ String ကိန်းရှင်များ သတ်မှတ်ခြင်း
$os_case_number  = htmlspecialchars($db_data['case_number'] ?? '-');
$os_township     = htmlspecialchars($db_data['township_name'] ?? '-');
$os_year         = htmlspecialchars($db_data['tax_year'] ?? '-');
$os_name         = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_nrc_no       = htmlspecialchars($db_data['nrc_no'] ?? '-');
$os_gir          = htmlspecialchars($db_data['gir_no'] ?? '-');
$os_gir_type     = htmlspecialchars($db_data['gir_type'] ?? '-');
$os_address      = htmlspecialchars($db_data['address'] ?? '-');
$os_officer      = htmlspecialchars($db_data['officer_name'] ?? '-');
$os_officer_rank = htmlspecialchars($db_data['officer_rank'] ?? 'အခွန်ဦးစီးမှူး');
$os_biz          = htmlspecialchars($db_data['business_type'] ?? '-');

$os_land_type        = htmlspecialchars($db_data['land_type'] ?? '-');
$os_block_no         = htmlspecialchars($db_data['block_no'] ?? '-');
$os_holding_no       = htmlspecialchars($db_data['holding_no'] ?? '-');
$os_city             = htmlspecialchars($db_data['city'] ?? '-');
$os_road             = htmlspecialchars($db_data['road'] ?? '-');
$os_area             = htmlspecialchars($db_data['area'] ?? '-');
$os_building_type    = htmlspecialchars($db_data['building_type'] ?? '-');
$os_building_height  = htmlspecialchars($db_data['building_height'] ?? '-');

$os_itDemandNo     = htmlspecialchars($db_data['it_demand_no'] ?? '......');
$os_itDemandDate   = htmlspecialchars($db_data['it_demand_date'] ?? '............');
$os_chalan_no      = htmlspecialchars($db_data['chalan_no'] ?? '......');
$os_chalan_date    = htmlspecialchars($db_data['chalan_date'] ?? '............');
$os_tasapha_no     = htmlspecialchars($db_data['tasapha_no'] ?? '......');
$os_tasapha_date   = htmlspecialchars($db_data['tasapha_date'] ?? '............');
$os_municipal_no   = htmlspecialchars($db_data['it_municipal_no'] ?? '......');
$os_permit_date    = htmlspecialchars($db_data['permit_date'] ?? '............');
$os_notified_date  = htmlspecialchars($db_data['notified_date'] ?? '............');
$os_appointment_date = htmlspecialchars($db_data['appointment_date'] ?? '............');
$os_appearance_date  = htmlspecialchars($db_data['appearance_date'] ?? '............');

$os_purchase_date = '-/-/-';
if (!empty($db_data['purchase_date']) && $db_data['purchase_date'] !== '0000-00-00') {
    $os_purchase_date = date('d-m-Y', strtotime($db_data['purchase_date']));
}

$os_assessment_submit_date = htmlspecialchars($db_data['assessment_submit_date'] ?? '0');
$os_terget_date = '............';
if (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00' && strtotime($db_data['it_demand_date'])) {
    $os_terget_date = date('d-m-Y', strtotime($db_data['it_demand_date'] . ' + 14 days'));
}

// ကိန်းဂဏန်းများ
$os_declared_value     = htmlspecialchars($db_data['declared_value'] ?? '0');
$os_valuation_value    = htmlspecialchars($db_data['valuation_value'] ?? '0');
$os_allowable_expenses = htmlspecialchars($db_data['allowable_expenses'] ?? '0');
$os_taxable_income     = htmlspecialchars($db_data['taxable_income'] ?? '0');
$os_income_tax         = htmlspecialchars($db_data['income_tax'] ?? '0');
$os_advance_tax        = htmlspecialchars($db_data['advance_tax'] ?? '0');
$os_tax_to_pay         = htmlspecialchars($db_data['tax_to_pay'] ?? '0');
$os_penalty_tax        = htmlspecialchars($db_data['penalty_tax'] ?? '0');
$os_total_tax          = htmlspecialchars($db_data['total_tax'] ?? '0');

$os_source_of_income = htmlspecialchars($db_data['source_of_income'] ?? '........................................................................');
$os_investigation    = htmlspecialchars($db_data['investigation'] ?? '........................................................................');

// ဘတ်ဂျက်နှစ်အလိုက် ရက်စွဲဆွဲထုတ်ခြင်း
$start_date2 = '';
$end_date2 = '';
$start_year = '';
$end_year = '';
$current_tax_year = $db_data['tax_year'] ?? ''; 

if (!empty($current_tax_year)) {
    $by_query = "SELECT start_date2, end_date2 FROM budget_year WHERE budget_year = '" . $conn->real_escape_string($current_tax_year) . "'";
    $by_result = $conn->query($by_query);
    if ($by_result && $by_result->num_rows > 0) {
        $by_data = $by_result->fetch_assoc();
        
        // မူလ Database ထဲက ရက်စွဲများ
        $orig_start = $by_data['start_date2'];
        $orig_end = $by_data['end_date2'];

        // 'အခြေ' ဖြစ်ရင် မူလရက်စွဲထဲက ၁ နှစ် နှုတ်ပါမည်။
        if ($os_gir_type === 'အခြေ' && !empty($orig_start) && !empty($orig_end)) {
            $start_date2 = date('Y-m-d', strtotime($orig_start . ' -1 year'));
            $end_date2 = date('Y-m-d', strtotime($orig_end . ' -1 year'));
        } else {
            // 'အခြေ' မဟုတ်ရင် (စကလက/အိမ်မြေ စသည်) မူလအတိုင်း ထားပါမည်။
            $start_date2 = $orig_start;
            $end_date2 = $orig_end;
        }

        // HTML ထဲမှာ (၂၀၂၅ မှ ၂၀၂၆) စာသားအဖြစ် လွယ်လွယ်ကူကူ သုံးနိုင်ရန် ခုနှစ်ကို သီးသန့် ဖြတ်ယူခြင်း
        if (!empty($start_date2)) {
            $start_year = date('Y', strtotime($start_date2));
        }
        if (!empty($end_date2)) {
            $end_year = date('Y', strtotime($end_date2));
        }
    }
}
?>

<style>
#form0408Modal .modal-dialog {
    max-width: 795px !important; 
    width: 95% !important;
    margin: 20px auto !important;
    position: relative;
}

#form0408Modal .modal-content {
    background-color: #9ecaeb !important; 
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 20px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}

#form0408Modal .modal-body {
    padding: 20px !important; 
    overflow-x: auto !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
    justify-content: center !important;
}

.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 34px !important;
    background-color: #dc3545 !important; 
    color: #ffffff !important; 
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 34px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; 
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}

.custom-close-btn:hover {
    background-color: #bd2130 !important; 
}

.print-container { 
    background: #ffffff !important;
    width: 210mm !important; 
    min-height: 297mm !important; 
    padding: 5mm 5mm 5mm 10mm !important; 
    margin: 0 auto 20px auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}

table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}

table, tr, td { 
    box-sizing: border-box !important;
}

.custom-modal-title {
    font-size: 20px !important; 
    font-weight: bold !important; 
    color: #1a4d80 !important; 
    padding-left: 25px !important; 
    display: inline-block !important;
    line-height: 40px !important; 
}

#form0408Modal .no-print-bottoms {
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    gap: 16px !important;
    width: 100% !important;
    margin: 0 !important;
    padding: 14px 16px 16px 16px !important;
    background-color: #9ecaeb !important;
    box-sizing: border-box !important;
}

#form0408Modal .no-print-bottoms .btn {
    font-size: 16px !important;
    font-weight: bold !important;
    padding: 10px 24px !important;
    min-width: 140px !important;
    border-radius: 5px !important;
    color: #ffffff !important;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important;
    transition: all 0.2s ease-in-out !important;
}

#form0408Modal .no-print-bottoms .btn-print {
    background-color: #0b5ed7 !important;
    border: 1px solid #0a58ca !important;
}

#form0408Modal .no-print-bottoms .btn-close-form {
    background-color: #dc3545 !important;
    border: 1px solid #b02a37 !important;
}

#form0408Modal .no-print-bottoms .btn-print:hover {
    background-color: #0a58ca !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}

#form0408Modal .no-print-bottoms .btn-close-form:hover {
    background-color: #bb2d3b !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}

@media print {
    .custom-close-btn { display: none !important; }
}

@media print {
    .modal-footer, .no-print, .btn, .btn-close, .modal-header,.modal-title { 
        display: none !important; 
    }
    
    body * { 
        visibility: hidden !important; 
    }
    
    #form0408Modal, #form0408Modal * { 
        visibility: visible !important; 
    }
    
    #form0408Modal { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .modal-dialog, .modal-content, .modal-body { 
        margin: 0 !important;
        padding: 0 !important;
        max-width: 100% !important; 
        width: 100% !important;
        border: none !important; 
        box-shadow: none !important;
        background: transparent !important;
    }

    .print-container { 
        width: 100% !important;
        max-width: 100% !important;
        padding: 5mm 5mm 5mm 5mm !important; 
        margin: 0 !important;
        display: block !important;
        box-sizing: border-box !important; 
    }

    table, .main-content-table, .main-content-table2, .order-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important; 
    }
    
    table, tr, td { 
        border: none !important; 
        box-sizing: border-box !important;
    }
    
    .print-container table:first-child {
        border: none !important;
    }

    hr { display: none !important; }
    
    @page {
        size: A4 portrait;
        margin: 0mm !important; 
    }
}

#form0408Modal .modal-dialog {
    max-width: 900px; 
    margin: 5px auto;
}

#form0408Modal .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}

.underline{border-bottom: 1px dotted black; width:250px;}
.dashed-line{border-bottom:1.5px dotted black !important;}
.solid-line{border-bottom: 1.5px solid #0d0d0d !important; min-width:150px; display: inline-block; text-align: left; padding-left:5px;}
.under-line { border-bottom: 1.5px dashed #0d0d0d !important; min-width:150px; display: inline-block; text-align: left; padding-left:5px; padding-top:15px;}
.under-line2 { border-bottom: 1.5px dashed #0d0d0d !important; min-width:150px; display: inline-block; text-align: left; padding-left:5px; }
</style>

<div class="modal fade" id="form0408Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="custom-modal-title">၀၄-၀၈ စည်းကြပ်မှုအကြောင်းကြားစာ  ထုတ်ယူရန်</h5>
                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            <div class="modal-body" style="padding: 0px !important;">
                <div class="modal-body" id="printableSheet">
                    <div class="print-container" style="padding-left: 70px !important; padding-right: 30px !important; margin-left: 0px !important;">
                        <table style="border: 1.5px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:22px; margin-bottom: 5px;">
                            <tr>
                                <td style='padding:2px; font-size:14px;'>
                                    ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                                </td>
                            </tr>
                        </table>
                        <div style="text-align:right; font-weight:bold;  margin-bottom:20px; line-height:22px; font-size:14px;">ပတခ(ဝင)-၀၄-၀၈</div>
                        <div style="text-align:center; font-weight:bold;  margin-bottom:20px; line-height:22px; font-size:14px;">
                            <b>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၁ နှင့် ၆၄ တို့အရ ဝင်ငွေခွန်စည်းကြပ်မှု၊ ဒဏ်ကြေးငွေစည်းကြပ်မှု </b> <br>
                            <b>အကြောင်းကြားစာ </b> 
                        </div>

                        <table style='width:100%; font-size:15px; line-height:22px; font-size:14px;'>
                            <tr>
                                <td style='width:50%'></td>
                                <td style='width:20%; text-align:right;'>အခွန်တောင်းခံလွှာအမှတ်</td>
                                <td style='width:10%; text-align:right; border-bottom:1.5px dotted black !important;'>DN-<span id="m0408_tit_demand_no"></span></td>
                            </tr>
                            <tr>
                                <td style='width:50%'></td>
                                <td style='width:20%; text-align:right;'>ရက်&ensp;စွဲ၊ </td>
                                <td style='width:10%; text-align:right; border-bottom:1.5px dotted black !important;'><span id="m0408_demandDate"></span></td>
                            </tr>
                        </table>

                        <table style='width:100%; font-size:15px; line-height:22px; font-size:14px;'>
                            <tr>
                                <td style='width:10%'>သို့</td>
                                <td style='width:27%'>အခွန်ထမ်းအမည်၊</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_name"></span></td>
                            </tr>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:27%'>နိုင်ငံသားစိစစ်ရေးကတ်/TIN၊</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_gir"></span>/<span id="m0408_gir_type"></span> (<span id="m0408_nrc_no"></span>)</td>
                            </tr>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:27%'>အခွန်ထမ်းလိပ်စာ၊</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_address"></span></td>
                            </tr>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:27%'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_tax_period_txt"></span></td>
                            </tr>
                        </table>
                        <div style="margin-top:15px; padding:3px; text-align:justify; line-height:22px; font-size:14px;">
                            ၁။<span style='padding-left:48px;'></span>( <strong><span id="m0408_year"></span></strong> )စည်းကြပ်နှစ်အတွက် 
                            ကျောဖက်ပါပုံစံတွင် အသေးစိပ်ဖော်ပြထားချက်အရ ပေးဆောင်ရန် တာဝန်ရှိသည့် အခွန်နှင့်စပ်လျဉ်း၍ အောက်ပါအတိုင်း ပေးဆောင်ရန် အကြောင်းကြားပါသည် -
                        </div>

                        <table style='width:90%; font-size:15px; line-height:22px; font-size:14px;'>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:5%'>(က)</td>
                                <td style='width:55%'>ဝင်ငွေခွန်</td>
                                <td style='width:8%; text-align:left;'>ကျပ်</td>
                                <td style='width:30%; text-align:right; padding-right:30px;' class="under-line2"> <span id="m0408_tax_to_pay"></span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ခ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၅ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဂ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၆ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>(ဃ)</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၇ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( င )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၈ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( စ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၉ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>(ဆ)</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၀ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဇ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၁ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဈ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၂ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>(ည)</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၃ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဋ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၄ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td style='text-align:right; padding-right:30px; ' class="solid-line"><span id="m0408_penalty_tax"></span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td><b>စုစုပေါင်းပေးဆောင်ရမည့်အခွန်ပမာဏ</b></td>
                                <td>ကျပ်</td>
                                <td style='text-align:right; padding-right:30px; ' class="solid-line"><b><span id="m0408_total_tax"></span></b></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td colspan="5" style='padding-top: 5px; text-align:left;  '>
                                   <strong> စာသားဖြင့် ( <span id="m0408_taxTextMM"></span> ) ကျပ်တိတိ၊</strong>
                                </td>     
                            </tr>
                        </table>
                        <div style="margin-top:15px; padding:3px; text-align:justify; line-height:22px; font-size:14px;">
                             ၂။<span style='padding-left:48px;'></span>အထက်ပါပေးဆောင်ရမည့် အခွန်ငွေပမာဏကို 
                                ( <span id="m0408_bank_township">............</span> ) ရှိ မြန်မာ့စီးပွားရေးဘဏ်၊ 
                                ဘဏ်စာရင်းအမှတ် ( <span id="m0408_bank_acc">............</span> ) သို့ ပူးတွဲပါ ငွေသွင်းချလန်ဖြင့်
                                ( <span id="m0408_demandDate_2"></span> )ရက်နေ့ နောက်ဆုံးထား၍ ပေးသွင်းပြီး လက်ခံဖြတ်ပိုင်းကို
                                ရယူစေလိုပါသည်။ (Online Paymentဖြင့် ပေးသွင်း၍ရပါက ပေးသွင်းစေလိုပါသည်။) သတ်မှတ်ရက်အတွင်း အခွန်ပေးသွင်းရန် ပျက်ကွက်ပါက 
                                အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေ ပုဒ်မ ၇၄ ၊ ပုဒ်မခွဲ(က)အရ ဒဏ်ငွေ ထပ်မံတပ်ရိုက်ခြင်း ခံရဖွယ်ရှိပါ၍ မပျက်မကွက် ပေးဆောင်စေလိုပါသည်။<br>
                            ၃။<span style='padding-left:48px;'></span>စည်းကြပ်မှု သို့မဟုတ် ဒဏ်ကြေးငွေတပ်ရိုက်မှုအတွက်ဆုံးဖြတ်ချက်ကို ကျေနပ်မှုမရှိပါက
                             အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၄ ပါ စီမံအုပ်ချုပ်မှုနည်းလမ်းအရ ပြန်လည်သုံးသပ်ပေးရန် ညွှန်ကြားရေးမှူးချုပ်၊ ပြည်တွင်းအခွန်များဦးစီးဌာန၊ 
                             ရုံးအမှတ်(၄6)၊ နေပြည်တော်သို့ အကြောင်းကြားစာလက်ခံရရှိသည့်နေ့မှ ရက်ပေါင်း(၃၀)အတွင်း လျှောက်ထားနိုင်ပါသည်။
                        </div>
                        <table style='width:100%; margin-top:30px;line-height:22px; font-size:14px;'>
                            <tr>
                                <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                                <td style='text-align:center;'>
                                    တာဝန်ခံအရာရှိ<br><span id="m0408_township">............</span>အခွန်ဦးစီးဌာနမှူးရုံး
                                </td>
                            </tr>
                        </table>
                            <br><br><br>
                        <p style='text-align:right; font-size:15px; padding:3px; line-height: 24px;font-size:14px;'>ပတခ(ဝင)-၀၄-၀၈(အဆက်)</p>

                        <div style="text-align:center; font-weight:bold; margin-bottom:10px; font-size:14px;">
                            ဝင်ငွေအမျိုးအစားအလိုက် သတ်မှတ်မှု 
                        </div>
                        
                        <table style="width: 100%; line-height:23px; border-collapse: collapse; font-size:14px; table-layout: fixed;">
                            <tr style="border: 1.5px solid #0a0a0a !important;">
                                <th colspan="2" style="width: 76%; text-align: center; border-right: 1.5px solid #0b0b0b !important; padding:2px;">ဝင်ငွေရလမ်း</th>
                                <th style="width: 22%; text-align: center; padding:2px;">သတ်မှတ်ဝင်ငွေ (ကျပ်)</th>
                            </tr>
                            
                            <tr style="border-right: 1.5px solid #0b0b0b !important;">
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၁။ &ensp;လစာ</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                            
                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၂။ &ensp;အသက်မွေးဝမ်းကျောင်းပညာလုပ်ငန်း</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၃။ &ensp;စီးပွားရေးလုပ်ငန်း</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"> </td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၄။ &ensp;ပစ္စည်း</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၅။ &ensp;အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                                <td style="width: 70%; text-align: center; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"><b> <span id="m0408_biz_slot5"></span> </b></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="m0408_profit_income"></span></td>
                            </tr>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၆။ &ensp;စည်းကြပ်မှုမှလွတ်ကင်းသွားသောဝင်ငွေ</td>
                                <td style="width: 70%; text-align: center; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"><b> <span id="m0408_biz"></span> </b></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="m0408_taxable_income"></span></td>
                            </tr>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၇။ &ensp;အခြားရလမ်းများမှဝင်ငွေ</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                            
                            <tr style="height:20px;">
                                <td colspan="2" style="border-left: 1.5px solid #0a0a0a !important; border-right: 1.5px solid #0a0a0a !important; color:red; text-align: right; padding-right: 30px;">
                                    အကွက်( <span id="m0408_block_no"></span> )၊ ဦးပိုင်( <span id="m0408_holding_no"></span> )၊ ဧရိယာ( <span id="m0408_area"></span> )ဧက၊ <span id="m0408_building_type"></span>
                                </td>
                                 <td style="border-right: 1.5px solid #0a0a0a !important; border-bottom: 0px solid #0a0a0a !important;"></td>
                            </tr>
                            <tr style="height:20px;">
                                <td style="border-left: 1.5px solid #0a0a0a !important; border-bottom: 1.5px solid #0a0a0a !important;"></td>
                                <td style="border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px solid #0a0a0a !important;"></td>
                                <td style="border-right: 1.5px solid #0a0a0a !important; border-bottom: 1.5px solid #0a0a0a !important;"></td>
                            </tr>
                        
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; font-weight:bold; padding:2px;">စုစုပေါင်း</td>
                                <td style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="m0408_taxable_income2"></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; padding:2px;">*သက်သာခွင့်များ</td>
                                <td style="text-align: right; padding-right:30px; border-bottom: 1.5px solid #121212 !important; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; font-weight:bold; padding:2px;">အခွန်စည်းကြပ်ရန်အသားတင်ဝင်ငွေ</td>
                                <td style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="m0408_taxable_income3"></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; padding:2px;">ကျသင့်ဝင်ငွေခွန်</td>
                                <td style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="m0408_income_tax"></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; color: red; padding:2px;">နုတ်-ပုဒ်မ ၁၆ အရ ပေးဆောင်ပြီးအခွန်</td>
                                <td style="text-align: right; padding-right:30px; color: red; border-bottom: 1.5px solid #121212 !important; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="m0408_advance"></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; border-bottom: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-bottom: 1.5px solid #0a0a0a !important; border-right: 1.5px solid #0a0a0a !important; font-weight:bold; padding:2px;">ပေးဆောင်ရန်ကျန် / ပြန်အမ်းရန်အခွန်</td>
                                <td style="text-align: right; border-bottom: 1.5px solid #0a0a0a !important; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="m0408_tax_to_pay2"></span></td>
                            </tr>
                        </table>
                        <div style="text-align:center; font-weight:bold; margin-bottom:10px; font-size:14px; color:red;"><br>
                            <span id="m0408_township2">............</span> အိမ်ခြံမြေကာလတန်ဖိုးစိစစ်သတ်မှတ်ရေးအဖွဲ့၏( <span id="m0408_tasapha_date">-/-/-</span>  )ရက်စွဲပါ တစဖအမှတ် ( <span id="m0408_tasapha_no">--</span>  ) အရ အခြေပစ္စည်း၏ ကာလတန်ဖိုးမှာ ( <span id="m0408_valuation_value"></span>  )ကျပ် ဖြစ်ပါသည်။
                        </div>
                        <br><br>

                        <table style="width: 100%; font-size:14px; line-height:23px;">
                            <tr>
                                <th style="width: 17%;"></th>
                                <th style="width: 5%;"></th>
                                <th style="width: 46%; text-align: left;"><b>*သက်သာခွင့်များ</b></th>
                                <th style="width: 12%;"></th>
                                <th style="width: 20%; padding-top:0px;"></th>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၁။</td>
                                <td>အခြေခံသက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၂။</td>
                                <td>အတူနေမိဘအတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၃။</td>
                                <td>အိမ်ထောင်ဖက်အတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၄။</td>
                                <td>သားသမီးများအတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၅။</td>
                                <td style="font-size: 13px;">အခွန်ထမ်းနှင့်အိမ်ထောင်ဖက်၏အသက်အာမခံအတွက်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၆။</td>
                                <td>စုဆောင်းငွေအတွက် သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၇။</td>
                                <td>လှူဒါန်းငွေအတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px solid #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td><b>စုစုပေါင်း</b></td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px solid #0d0d0d !important;">&ensp;</td>
                            </tr>
                        </table>
                        <br><br><br><br><br><br><br><br>
                    </div>
                </div>
            </div>
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn btn-print" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-close-form" onclick="closeAndReturnToDemandList()">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
// ဒေတာထည့်သွင်းသည့် ပင်မ Function အား သီးသန့်ထုတ်၍ DOM ပုံစံမျိုးစုံတွင် အလုပ်လုပ်စေရန် ပြင်ဆင်ခြင်း
function DB_Data_Binding_0408() {
    
    // ၁။ English ဂဏန်းပုံစံ (Comma ပါဝင်ပြီး) ပြောင်းလဲပေးသည့် Helper Function
    const formatNumberToEnglish = (numStr) => {
        if (numStr === null || numStr === undefined || numStr == '') return '0';
        let cleanNum = numStr.toString().replace(/,/g, '');
        let num = parseFloat(cleanNum);
        if (isNaN(num)) return '0';
        if (num === 0) return '0'; 
        return Math.round(num).toLocaleString('en-US');
    };

    // ရက်စွဲပုံစံပြောင်းရန် function (YYYY-MM-DD -> DD-MM-YYYY English လို)
    const formatDateToEnglish = (dateStr) => {
        if (!dateStr || dateStr === '0000-00-00' || dateStr.includes('...')) return '............';
        if (dateStr.includes('-')) {
            const parts = dateStr.split('-');
            if (parts.length >= 3) {
                const yyyy = parts[0];
                const mm = parseInt(parts[1]); 
                const dd = parseInt(parts[2].split(' ')[0]);
                if (isNaN(mm) || isNaN(dd)) return '............';
                return `${dd}-${mm}-${yyyy}`;
            }
        }
        return dateStr;
    };

    // ၂။ ဂဏန်းမှ မြန်မာစာသားသို့ ပြောင်းလဲခြင်း Function
    const numberToMyanmarText = (number) => {
        if (number === 0 || !number) return "သုည";
        const digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
        const units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
        let numStr = Math.floor(number).toString();
        let result = "";
        let len = numStr.length;
        for (let i = 0; i < len; i++) {
            let digit = parseInt(numStr[i]);
            let unitIndex = len - i - 1;
            if (digit !== 0) {
                result += digits[digit] + units[unitIndex];
            }
        }
        return result;
    };

    try {
        if(document.getElementById('m0408_name')) document.getElementById('m0408_name').innerText = <?php echo json_encode($os_name); ?>;
        if(document.getElementById('m0408_address')) document.getElementById('m0408_address').innerText = <?php echo json_encode($os_address); ?>;

        if(document.getElementById('m0408_gir')) document.getElementById('m0408_gir').innerText = <?php echo json_encode($os_gir); ?>;
        if(document.getElementById('m0408_gir_type')) document.getElementById('m0408_gir_type').innerText = <?php echo json_encode($os_gir_type); ?>;

        // ✨ PHP string အား ကာကွယ်ရေးသားခြင်း
        const tName = <?php echo json_encode($os_township); ?> || "............";
        if(document.getElementById('m0408_township')) document.getElementById('m0408_township').innerText = tName;
        if(document.getElementById('m0408_township2')) document.getElementById('m0408_township2').innerText = tName;
        
        if(document.getElementById('m0408_nrc_no')) document.getElementById('m0408_nrc_no').innerText = <?php echo json_encode($os_nrc_no); ?>;
        if(document.getElementById('m0408_year')) document.getElementById('m0408_year').innerText = <?php echo json_encode($os_year); ?>;

        // 📅 budget_year Table မှ ရလာသော ရက်စွဲများကို ချိတ်ဆက်ခြင်း
        const startDate2 = formatDateToEnglish(<?php echo json_encode($start_date2); ?>);
        const endDate2 = formatDateToEnglish(<?php echo json_encode($end_date2); ?>);
        
        let taxPeriodText = "............ မှ ............ ထိ";
        if(startDate2 !== '............' && endDate2 !== '............') {
            const startParts = startDate2.split('-');
            const endParts = endDate2.split('-');
            if (startParts.length >= 3 && endParts.length >= 3) {
                taxPeriodText = `(01-04-${startParts[2]}) မှ (31-03-${endParts[2]}) ထိ`;
            }
        }
        if(document.getElementById('m0408_tax_period_txt')) document.getElementById('m0408_tax_period_txt').innerText = taxPeriodText;

        if(document.getElementById('m0408_tit_demand_no')) document.getElementById('m0408_tit_demand_no').innerText = <?php echo json_encode($os_itDemandNo); ?>;
        
        const demandDateStr = formatDateToEnglish(<?php echo json_encode($os_itDemandDate); ?>);
        if(document.getElementById('m0408_demandDate')) document.getElementById('m0408_demandDate').innerText = demandDateStr;
        if(document.getElementById('m0408_demandDate_2')) document.getElementById('m0408_demandDate_2').innerText = demandDateStr;

        // မြေအချက်အလက်
        if(document.getElementById('m0408_block_no')) document.getElementById('m0408_block_no').innerText = <?php echo json_encode($os_block_no); ?>;
        if(document.getElementById('m0408_holding_no')) document.getElementById('m0408_holding_no').innerText = <?php echo json_encode($os_holding_no); ?>;
        if(document.getElementById('m0408_area')) document.getElementById('m0408_area').innerText = <?php echo json_encode($os_area); ?>;
        if(document.getElementById('m0408_road')) document.getElementById('m0408_road').innerText = <?php echo json_encode($os_road); ?>;
        if(document.getElementById('m0408_city')) document.getElementById('m0408_city').innerText = <?php echo json_encode($os_city); ?>;
        
        // ဆောက်ဦးအချက်အလက်
        if(document.getElementById('m0408_building_type')) document.getElementById('m0408_building_type').innerText = <?php echo json_encode($os_building_type); ?>;

        // တဆဖ နံပါတ်နှင့် ရက်စွဲ
        if(document.getElementById('m0408_tasapha_no')) document.getElementById('m0408_tasapha_no').innerText = <?php echo json_encode($os_tasapha_no); ?>;
        if(document.getElementById('m0408_tasapha_date')) document.getElementById('m0408_tasapha_date').innerText = <?php echo json_encode($os_tasapha_date); ?>;

        // 🎯 Business_type ပါဝင်မှုအလိုက် နေရာပြောင်းလဲချိတ်ဆက်ခြင်း Logic
        const bizType = <?php echo json_encode($os_biz); ?> || "";
        const incomeValue = formatNumberToEnglish(<?php echo json_encode($os_taxable_income); ?>);

        const slot5_BizText  = document.getElementById('m0408_biz_slot5');     
        const slot5_Income   = document.getElementById('m0408_profit_income');  
        const slot6_BizText  = document.getElementById('m0408_biz');            
        const slot6_Income   = document.getElementById('m0408_taxable_income');  

        if (bizType.includes("ဝယ်ယူခြင်း")) {
            if(slot6_BizText) slot6_BizText.innerText = bizType;
            if(slot6_Income)  slot6_Income.innerText  = incomeValue;
            if(slot5_BizText) slot5_BizText.innerText = "";
            if(slot5_Income)  slot5_Income.innerText  = "";
        } else {
            if(slot5_BizText) slot5_BizText.innerText = bizType;
            if(slot5_Income)  slot5_Income.innerText  = incomeValue;
            if(slot6_BizText) slot6_BizText.innerText = "";
            if(slot6_Income)  slot6_Income.innerText  = "";
        }

        // 🎯 Login User ၏ md_no နှင့် bank_township အား ဖောင်တွင် ချိတ်ဆက်ခြင်း
        if(document.getElementById('m0408_bank_acc')) {
            document.getElementById('m0408_bank_acc').innerText = <?php echo json_encode($os_md_no); ?>;
        }
        if(document.getElementById('m0408_bank_township')) {
            document.getElementById('m0408_bank_township').innerText = <?php echo json_encode($os_bank_township); ?>.replace(/နယ်/g, '');
        }

        // ဇယားကွက်အတွင်းပိုင်း ကိန်းဂဏန်းဒေတာများ ဆက်လက်ချိတ်ဆက်ခြင်း
        if(document.getElementById('m0408_valuation_value')) document.getElementById('m0408_valuation_value').innerText = formatNumberToEnglish(<?php echo json_encode($os_valuation_value); ?>);
        if(document.getElementById('m0408_taxable_income2')) document.getElementById('m0408_taxable_income2').innerText = incomeValue;
        if(document.getElementById('m0408_taxable_income3')) document.getElementById('m0408_taxable_income3').innerText = incomeValue;
        if(document.getElementById('m0408_income_tax')) document.getElementById('m0408_income_tax').innerText = formatNumberToEnglish(<?php echo json_encode($os_income_tax); ?>);
        if(document.getElementById('m0408_advance')) document.getElementById('m0408_advance').innerText = formatNumberToEnglish(<?php echo json_encode($os_advance_tax); ?>);
        if(document.getElementById('m0408_tax_to_pay')) document.getElementById('m0408_tax_to_pay').innerText = formatNumberToEnglish(<?php echo json_encode($os_tax_to_pay); ?>);
        if(document.getElementById('m0408_tax_to_pay2')) document.getElementById('m0408_tax_to_pay2').innerText = formatNumberToEnglish(<?php echo json_encode($os_tax_to_pay); ?>);
        if(document.getElementById('m0408_penalty_tax')) document.getElementById('m0408_penalty_tax').innerText = formatNumberToEnglish(<?php echo json_encode($os_penalty_tax); ?>);
        if(document.getElementById('m0408_total_tax')) document.getElementById('m0408_total_tax').innerText = formatNumberToEnglish(<?php echo json_encode($os_total_tax); ?>);

        if(document.getElementById('m0408_taxTextMM')) {
            document.getElementById('m0408_taxTextMM').innerText = numberToMyanmarText(<?php echo json_encode($os_total_tax); ?>);
        }
    } catch (err) {
        console.error("Data Binding Error: ", err);
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', DB_Data_Binding_0408);
} else {
    DB_Data_Binding_0408();
}

function closeAndReturnToDemandList() {
    try {
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var myModalEl = document.getElementById('form0408Modal');
            var modal = bootstrap.Modal.getInstance(myModalEl) || new bootstrap.Modal(myModalEl);
            modal.hide();
        }
        if (typeof jQuery !== 'undefined') {
            jQuery('#form0408Modal').modal('hide');
            jQuery('.modal-backdrop').remove();
            jQuery('body').removeClass('modal-open').css('overflow', 'auto');
        }
    } catch (e) {
        console.log("Modal ပိတ်ရာတွင် အမှားရှိသည်: ", e);
    }
    
    setTimeout(function() {
        if (window.opener && !window.opener.closed) {
            try {
                if (window.opener.jQuery && window.opener.jQuery('#formsModal2').length) {
                    window.opener.jQuery('#formsModal2').modal('show');
                } else if (window.opener.bootstrap && window.opener.bootstrap.Modal) {
                    var parentModal = new window.opener.bootstrap.Modal(window.opener.document.getElementById('formsModal2'));
                    parentModal.show();
                }
            } catch (err) {
                console.log("Parent modal ဖွင့်မရပါ: ", err);
            }
            window.close(); 
        } else {
            if (typeof jQuery !== 'undefined' && jQuery('#formsModal2').length) {
                jQuery('#formsModal2').modal('show');
            } else {
                window.location.href = '../capital_demand_list.php?openModal=formsModal2';
            }
        }
    }, 300); 
}
</script>