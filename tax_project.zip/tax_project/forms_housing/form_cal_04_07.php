<?php

// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    // အစ်ကို့ရဲ့ ပင်မ Table နာမည် 'sakalakahdata' ထဲမှ ဆွဲထုတ်ခြင်း
    $query = "SELECT * FROM sakalakahdata WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း
$os_case_number  = htmlspecialchars($db_data['case_number'] ?? '-');
$os_township  = htmlspecialchars($db_data['township_name'] ?? '-');
$os_year      = htmlspecialchars($db_data['tax_year'] ?? '-');
$os_name      = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_gir       = htmlspecialchars($db_data['gir_no'] ?? '-');
$os_gir_type  = htmlspecialchars($db_data['gir_type'] ?? '-');
$os_address   = htmlspecialchars($db_data['address'] ?? '-');
$os_officer   = htmlspecialchars($db_data['officer_name'] ?? '-');
$os_officer_rank      = htmlspecialchars($db_data['officer_rank'] ?? 'အခွန်ဦးစီးမှူး');
$os_biz       = htmlspecialchars($db_data['business_type'] ?? '-');

// (၄) မြေနှင့် အဆောက်အဦးဆိုင်ရာ အချက်အလက်များ
$os_land_type   = htmlspecialchars($db_data['land_type'] ?? '-');
$os_block_no    = htmlspecialchars($db_data['block_no'] ?? '-');
$os_holding_no  = htmlspecialchars($db_data['holding_no'] ?? '-');
$os_city        = htmlspecialchars($db_data['city'] ?? '-');
$os_road        = htmlspecialchars($db_data['road'] ?? '-');
$os_area        = htmlspecialchars($db_data['area'] ?? '-');
$os_building_type        = htmlspecialchars($db_data['building_type'] ?? '-');
$os_building_height      = htmlspecialchars($db_data['building_height'] ?? '-');

$os_itDemandNo  = htmlspecialchars($db_data['it_demand_no'] ?? '......');
$os_itDemandDate  = htmlspecialchars($db_data['it_demand_date'] ?? '............');

$os_chalan_no  = htmlspecialchars($db_data['chalan_no'] ?? '......');
$os_chalan_date  = htmlspecialchars($db_data['chalan_date'] ?? '............');

$os_tasapha_no  = htmlspecialchars($db_data['tasapha_no'] ?? '......');
$os_tasapha_date  = htmlspecialchars($db_data['tasapha_date'] ?? '............');

$os_municipal_no  = htmlspecialchars($db_data['it_municipal_no'] ?? '......');
$os_permit_date  = htmlspecialchars($db_data['permit_date'] ?? '............');

$os_notified_date  = htmlspecialchars($db_data['notified_date'] ?? '............');
$os_appointment_date  = htmlspecialchars($db_data['appointment_date'] ?? '............');
$os_appearance_date  = htmlspecialchars($db_data['appearance_date'] ?? '............');
$os_notified  = htmlspecialchars($db_data['notified_date'] ?? '............');

$os_purchase_date = '-/-/-';
if (!empty($db_data['purchase_date']) && $db_data['purchase_date'] !== '0000-00-00') {
    $os_purchase_date = date('d-m-Y', strtotime($db_data['purchase_date']));
}

$os_assessment_submit_date   = htmlspecialchars($db_data['assessment_submit_date'] ?? '0');

$os_terget_date = '............'; // Default စာသား
if (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') {
    try {
        $date = new DateTime($db_data['it_demand_date']);
        $date->modify('+14 days'); // ရက်ပေါင်း ၁၄ ရက် တိုးလိုက်ခြင်း
        $os_terget_date = $date->format('d-m-Y'); // dd-mm-yyyy ပုံစံဖြင့် ထုတ်ယူခြင်း
    } catch (Exception $e) {
        $os_terget_date = '............';
    }
}

//ကိန်းဂဏန်းများ 
$os_declared_value  = htmlspecialchars($db_data['declared_value'] ?? '0');
$os_valuation_value  = htmlspecialchars($db_data['valuation_value'] ?? '0');
$os_allowable_expenses  = htmlspecialchars($db_data['allowable_expenses'] ?? '0');
$os_taxable_income  = htmlspecialchars($db_data['taxable_income'] ?? '0');
$os_income_tax   = htmlspecialchars($db_data['income_tax'] ?? '0');
$os_advance_tax   = htmlspecialchars($db_data['advance_tax'] ?? '0');
$os_tax_to_pay   = htmlspecialchars($db_data['tax_to_pay'] ?? '0');
$os_penalty_tax   = htmlspecialchars($db_data['penalty_tax'] ?? '0');
$os_total_tax   = htmlspecialchars($db_data['total_tax'] ?? '0');

$os_source_of_income  = htmlspecialchars($db_data['source_of_income'] ?? '........................................................................');
$os_investigation  = htmlspecialchars($db_data['investigation'] ?? '........................................................................');

// 🛑 ဘတ်ဂျက်နှစ်အလိုက် Start Date နှင့် End Date ကို budget_year Table မှ ဆွဲထုတ်ခြင်း
$start_date2 = '';
$end_date2 = '';
$current_tax_year = $db_data['tax_year'] ?? ''; 

if (!empty($current_tax_year)) {
    // budget_year table ထဲတွင် budget_year column ဖြင့် တိုက်စစ်သည်
    $by_query = "SELECT start_date2, end_date2 FROM budget_year WHERE budget_year = '" . $conn->real_escape_string($current_tax_year) . "'";
    $by_result = $conn->query($by_query);
    if ($by_result && $by_result->num_rows > 0) {
        $by_data = $by_result->fetch_assoc();
        $start_date2 = $by_data['start_date2'];
        $end_date2 = $by_data['end_date2'];
    }
}
?>

<style>
#form0407Modal .modal-dialog {
    max-width: 795px !important; 
    width: 95% !important;
    margin: 20px auto !important;
    position: relative;
}

#form0407Modal .modal-content {
    background-color: #9ecaeb !important; 
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 20px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}

#form0407Modal .modal-body {
    padding: 20px !important; 
    overflow-x: auto !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
    justify-content: center !important;
}

.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 34px !important;
    background-color: #dc3545 !important; 
    color: #ffffff !important; 
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 34px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; 
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}

.custom-close-btn:hover {
    background-color: #bd2130 !important; 
}

.print-container { 
    background: #ffffff !important;
    width: 210mm !important; 
    min-height: 297mm !important; 
    padding: 5mm 5mm 5mm 15mm !important; 
    margin: 0 auto 20px auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}

table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}

table, tr, td { 
    box-sizing: border-box !important;
}



#form0407Modal .no-print-bottoms {
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    gap: 16px !important;
    width: 100% !important;
    margin: 0 !important;
    padding: 14px 16px 16px 16px !important;
    background-color: #9ecaeb !important;
    box-sizing: border-box !important;
}

#form0407Modal .no-print-bottoms .btn {
    font-size: 16px !important;
    font-weight: bold !important;
    padding: 10px 24px !important;
    min-width: 140px !important;
    border-radius: 5px !important;
    color: #ffffff !important;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important;
    transition: all 0.2s ease-in-out !important;
}

#form0407Modal .no-print-bottoms .btn-print {
    background-color: #0b5ed7 !important;
    border: 1px solid #0a58ca !important;
}

#form0407Modal .no-print-bottoms .btn-close-form {
    background-color: #dc3545 !important;
    border: 1px solid #b02a37 !important;
}

#form0407Modal .no-print-bottoms .btn-print:hover {
    background-color: #0a58ca !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}

#form0407Modal .no-print-bottoms .btn-close-form:hover {
    background-color: #bb2d3b !important;
    transform: translateY(-2px) !important;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}

@media print {
    .custom-close-btn { display: none !important; }
}

@media print {
    .modal-footer, .no-print, .btn, .btn-close, .modal-header { 
        display: none !important; 
    }
    
    body * { 
        visibility: hidden !important; 
    }
    
    #form0407Modal, #form0407Modal * { 
        visibility: visible !important; 
    }
    
    #form0407Modal { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .modal-dialog, .modal-content, .modal-body { 
        margin: 0 !important;
        padding: 0 !important;
        max-width: 100% !important; 
        width: 100% !important;
        border: none !important; 
        box-shadow: none !important;
        background: transparent !important;
    }

    .print-container { 
        width: 100% !important;
        max-width: 100% !important;
        padding: 10mm 5mm 5mm 10mm !important; 
        margin: 0 !important;
        display: block !important;
        box-sizing: border-box !important; 
    }

    table, .main-content-table, .main-content-table2, .order-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important; 
    }
    
    table, tr, td { 
        border: none !important; 
        box-sizing: border-box !important;
    }
    
    .print-container table:first-child {
        border: none !important;
    }

    hr { display: none !important; }
    
    @page {
        size: A4 portrait;
        margin: 0mm !important; 
    }
}

#form0407Modal .modal-dialog {
    max-width: 900px; 
    margin: 5px auto;
}

#form0407Modal .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}

.underline{border-bottom: 1px dotted solid; width:250px;}
.dashed-line{border-bottom:1.5px dotted black !important;}
.solid-line{border-bottom:1.5px solid black !important;}
.under-line { border-bottom: 1.5px dashed #0d0d0d !important; min-width:400px; display: inline-block; text-align: left; padding-left:5px;}
</style>

<div class="modal fade" id="form0407Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 0px 20px; border-bottom: none;">
                <h4 class="custom-modal-title">အခွန်တွက်ချက်မှုပုံစံ ထုတ်ယူရန်</h4>

                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            <div class="modal-body" style="padding: 0px !important;">
            <div class="modal-body" id="printableSheet">
                <div class="print-container" style="padding-left: 80px !important; padding-right: 30px !important; margin-left: 0px !important;">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:1.9; margin-bottom: 5px;">
                        <tr>
                            <td style='padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇</p>

                    <div style="text-align:center; font-weight:bold; line-height: 1.9; margin-bottom:20px;">
                        <b>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃၀ နှင့် ၆၄ တို့အရ ဝင်ငွေခွန်စည်းကြပ်မှုနှင့်</b> <br>
                        <b>ဒဏ်ကြေးငွေစည်းကြပ်မှု ဆုံးဖြတ်ချက်</b> 
                    </div>
                    <div style="text-align:center;  line-height: 1.9; margin-bottom:20px;">
                        ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                        (<span id="m0407_township"></span>အခွန်ဦးစီးဌာနမှူးရုံး)
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:50%'></td>
                            <td style='width:20%; text-align:right;'>ရက်စွဲ၊ </td>
                            <td style='width:10%; text-align:right; border-bottom:1.5px dotted black !important;'><span id="m0407_demandDate">............</span></td>
                        </tr>
                        <tr>
                            <td> </td>
                            <td style='text-align:right;'>စည်းကြပ်နှစ်၊ </td>
                            <td style='text-align:right; border-bottom:1.5px dotted black !important;'><span id="m0407_taxYear">............</span></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:15px; line-height: 1.8;'>
                        <tr>
                            <td style='width:6%'>၁။</td>
                            <td style='width:28%; font-weight:bold;'>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</td>
                            <td style='width:3%; text-align:center;'>၊</td>
                            <td style='width:63%; text-align: left; border-bottom:1.5px dotted black !important;;'> <span id="m0407_gir"></span>/<span id="m0407_gir_type"></span></td>
                        </tr>
                        <tr>
                            <td >၂။</td>
                            <td style=' font-weight:bold;'>အခွန်ထမ်းအမည်နှင့်လိပ်စာ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="m0407_name" ></span></td>
                        </tr>
                        <tr>
                            <td ></td>
                            <td style='width:38%'></td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="m0407_address" ></span></td>
                        </tr>
                        <tr>
                            <td >၃။</td>
                            <td style=' font-weight:bold;'>အခွန်ထမ်းအမျိုးအစား</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> ပုဂ္ဂလိက</td>
                        </tr>
                        <tr>
                            <td >၄။</td>
                            <td style=' font-weight:bold;'>လုပ်ငန်းအမျိုးအစား</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="m0407_biz"></span></td>
                        </tr>
                        <tr>
                            <td >၅။</td>
                            <td style=' font-weight:bold;'>လုပ်ငန်းခွဲများ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> အကွက်(<span id="m0407_block_no2"></span>)၊ 
                                ဦးပိုင်( <span id="m0407_holding_no2"></span> )၊  <span id="m0407_road2"></span> လမ်း၊  <span id="m0407_city2"></span> ၊ ဧရိယာ( <span id="m0407_area2"></span> )ဧက၊ </td>
                        </tr>
                        <tr>
                            <td >၆။</td>
                            <td style=' font-weight:bold;'>(က)ပုဂ္ဂိုလ်စုဝင်များ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'>  
                                    ( <span id="m0407_building_type2"></span> )၊ ( <span id="m0407_building_height2"></span> )၊ </td>
                        </tr>
                        <tr>
                            <td ></td>
                            <td style=' font-weight:bold;'>( ခ ) အစုများ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span>-</span></td>
                        </tr>
                        <tr>
                            <td >၇။</td>
                            <td style='width:150px; font-weight:bold;'>ကြေညာသည့်ဝင်ငွေ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="m0407_declared_value">၀</span> ကျပ်</td>
                        </tr>
                        <tr>
                            <td >၈။</td>
                            <td style=' font-weight:bold;'>တင်ပြသောစာရင်းများ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span>-</span></td>
                        </tr>
                        <tr>
                            <td >၉။</td>
                            <td style=' font-weight:bold;'>စည်းကြပ်သည့်ပုဒ်မ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊၂၈၊၃၀ နှင့် ၆၄ တို့အရ </td>
                        </tr>
                        <tr>
                            <td >၁၁။</td>
                            <td style=' font-weight:bold;'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="m0407_tax_period_txt"></span></td>
                        </tr>
                    </table>

                    <?php if ($os_gir_type == 'အခြေ(အိမ်မြေ)') { ?> 
                    <p style='text-align:center; font-weight:bold; margin-top:20px;'>
                        <b>ဝင်ငွေခွန်စည်းကြပ်မှုနှင့် ဒဏ်ကြေးငွေ စည်းကြပ်မှု ဆုံးဖြတ်ချက်</b>
                    </p>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းသည်( <span id="m0407_taxYear_txt">...</span> )ဝင်ငွေနှစ်အတွင်း <span id="m0407_road">....</span>၊ <span id="m0407_city">...</span> ရှိ အကွက်အမှတ်
                        ( <span id="m0407_block_no">---</span>  )၊ဦးပိုင်( <span id="m0407_holding_no">---</span>  )၊ ဧရိယာ( <span id="m0407_area">၀</span>  )ဧက၊
                        <span id="m0407_building_type">...</span> အဆောက်အဦးအတိုင်းအတာ အလျား/ အနံ/အမြင့်
                        ( <span id="m0407_building_height">...</span>  ) ရှိ၊ အခြေပစ္စည်းကို( <span id="m0407_purchase_date">-/-/-</span>  )ရက်နေ့တွင် 
                            ရောင်းချခဲ့ကြောင်း တိုင်း/မြို့နယ်အိမ်ခြံမြေကာလတန်ဖိုးစိစစ်သတ်မှတ်ရေးအဖွဲ့၏ ( <span class="m0407_tasapha_date">-/-/-</span> )ရက်နေ့တွင် 
                            ကာလတန်ဖိုး( <span class="m0407_valuation_class">---</span>  )သတ်မှတ်ချက်အရ ပေါ်ပေါက်ပါသည်။
                    </div>
                    <br><br><br><br><br><br>
                    <p style="text-align:right; font-size:14px;">ပတခ(ဝင)-၀၄-၀၇(အဆက်)</p>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                          ရောင်းချသော အခြေပစ္စည်းနှင့်ပတ်သက်၍ အခွန်ထမ်းတင်ပြသည့် မူလတန်ဖိုးနှင့်ဖြည့်ဆွက်စရိတ်များအပေါ် စိစစ်ပြီး မြို့နယ်အိမ်ခြံမြေကာလတန်ဖိုးစိစစ်သတ်မှတ်ရေးအဖွဲ့၏
                        (<span class="m0407_tasapha_date">-/-/-</span>) ရက်စွဲပါ တစဖအမှတ် ( <span id="m0407_tasapha_no">၀</span>  ) အရ ကာလတန်ဖိုး စိစစ်သတ်မှတ်ချက်အပေါ် 
                         အရောင်းတန်ဖိုးသတ်မှတ်ပြီး  ပြည်ထောင်စု၏အခွန်အကောက်ဥပဒေ ပုဒ်မ ၂၇ (ခ) နှင့်အရ
                         အခြေပစ္စည်းမှမြတ်စွန်းငွေအပေါ် စည်းကြပ်မှုဆုံးဖြတ်ချက်အမိန့်အား အောက်ပါအတိုင်း ချမှတ်လိုက်သည်-
                    </div>

                    <table class="order-table" style="width:70%; margin-left:auto; border:none !important;">
                        <tr style="border:none !important;">
                            <td style="width:67%; text-align:right; padding:3px; border:none !important;">အခြေပစ္စည်း အရောင်းသတ်မှတ်တန်ဖိုး</td>
                            <td style="width:5%; text-align:center; padding:3px; border:none !important;">=</td>
                            <td class="m0407_valuation_class" style="width:15%; text-align:right; padding:3px; font-weight:bold; border-bottom:0px dotted black !important;">၀</td>
                            <td style="width:13%;"></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">(နုတ်)မူလစရိတ်နှင့်ဖြည့်ဆွက်စရိတ်</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_allowable" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important;">၀</td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_taxable_income" style="text-align:right; padding:3px; font-weight:bold; border-bottom:px dotted black !important;">၀</td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ကျသင့်ဝင်ငွေခွန် </td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_income_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:px dotted black !important;">၀</td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ကျသင့်ဒဏ်ငွေ</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_penalty_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important;">၀</td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ကျသင့်အခွန်နင့်ဒဏ်ငွေပေါင်း</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_total_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:0px solid black !important;">၀</td>
                            <td></td>
                        </tr>
                    </table>
                    <br><br><br><br><br>

                    <?php } else { ?> 

                    <p style='text-align:center; font-weight:bold; margin-top:20px;'>
                        <b>ဝင်ငွေခွန်စည်းကြပ်မှုနှင့် ဒဏ်ကြေးငွေ စည်းကြပ်မှု ဆုံးဖြတ်ချက်</b>
                    </p>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းသည်( <span id="m0407_taxYear_txt">...</span> )ဝင်ငွေနှစ်အတွင်း <span id="m0407_road">....</span>၊ <span id="m0407_city">...</span> ရှိ အကွက်အမှတ်
                        ( <span id="m0407_block_no">---</span>  )၊ဦးပိုင်( <span id="m0407_holding_no">---</span>  )၊ ဧရိယာ( <span id="m0407_area">၀</span>  )ဧက၊
                        <span id="m0407_building_type">...</span> အဆောက်အဦးအတိုင်းအတာ အလျား/ အနံ/အမြင့်
                        ( <span id="m0407_building_height">...</span>  ) ရှိ၊ အခြေပစ္စည်းကို( <span id="m0407_purchase_date">-/-/-</span>  )ရက်နေ့တွင် 
                            ဝယ်ယူခဲ့သည့်အတွက် ကာလတန်ဖိုးသတ်မှတ်ပေးရန် တင်ပြလာမှုအပေါ် တိုင်း/မြို့နယ်အိမ်ခြံမြေကာလတန်ဖိုးစိစစ်သတ်မှတ်ရေးအဖွဲ့မှ ( <span class="m0407_tasapha_date">-/-/-</span> )ရက်နေ့တွင် 
                            ကာလတန်ဖိုး( <span class="m0407_valuation_class">---</span>  )သတ်မှတ်ခဲ့ပါသည်။
                    </div>
                    <br><br><br><br><br><br>
                    <p style="text-align:right; font-size:14px;">ပတခ(ဝင)-၀၄-၀၇(အဆက်)</p>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                         အခွန်ထမ်းသည် အိမ်မြေဝယ်ယူခြင်းနှင့်ပတ်သက်၍ အသုံးပြုခဲ့သည့် အသုံးစရိတ်များနှင့်ပတ်သက်၍ ဝင်ငွေရလမ်း
                         အထောက်အထားတစ်စုံတစ်ရာ တင်ပြနိုင်ခြင်းမရှိပါသဖြင့် စည်းကြပ်မှုမှလွှတ်ကင်းနေသော ဝင်ငွေအား မြို့နယ်အိမ်ခြံမြေကာလတန်ဖိုးစိစစ်သတ်မှတ်ရေးအဖွဲ့၏
                        (<span class="m0407_tasapha_date">-/-/-</span>) ရက်စွဲပါ တစဖအမှတ် ( <span id="m0407_tasapha_no">၀</span>  ) အရ ကာလတန်ဖိုး စိစစ်သတ်မှတ်ချက်အပေါ် 
                         အဝယ်တန်ဖိုးသတ်မှတ်ပြီး  ပြည်ထောင်စု၏အခွန်အကောက်ဥပဒေ ပုဒ်မ ၂၅ (က) နှင့်အညီ 
                         စည်းကြပ်မှုဆုံးဖြတ်ချက်အမိန့်အား အောက်ပါအတိုင်း ချမှတ်လိုက်သည်-
                    </div>

                    <table class="order-table" style="width:70%; margin-left:auto; border:none !important;">
                        <tr style="border:none !important;">
                            <td style="width:67%; text-align:right; padding:3px; border:none !important;">အခြေပစ္စည်း အဝယ်သတ်မှတ်တန်ဖိုး</td>
                            <td style="width:5%; text-align:center; padding:3px; border:none !important;">=</td>
                            <td class="m0407_valuation_class" style="width:15%; text-align:right; padding:3px; font-weight:bold; border-bottom:0px dotted black !important;">၀</td>
                            <td style="width:13%;"></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">(နုတ်) ခွင့်ပြုဝင်ငွေလမ်း</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_allowable" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important;">၀</td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">စည်းကြပ်မှုမှ လွှတ်ကင်းနေသောဝင်ငွေ</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_taxable_income" style="text-align:right; padding:3px; font-weight:bold; border-bottom:0px dotted black !important;">၀</td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ကျသင့်ဝင်ငွေခွန် </td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="m0407_income_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:0px dotted black !important;">၀</td>
                            <td></td>
                        </tr>
                 
                    </table>
                    <br><br><br><br><br><br><br><br>

                    <?php } ?>

                    <table style='width:100%; margin-top:40px;'>
                        <tr>
                            <td style='width:30%; text-align:center;'>ရုံးတံဆိပ်</td>
                            <td style='width:20%; text-align:center;'></td>
                            <td style='width:50%; text-align:center; line-height: 1.8;'>
                                တာဝန်ခံအရာရှိ<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                (<span id="m0407_township_footer"></span>အခွန်ဦးစီးဌာနမှူးရုံး)
                            </td>
                        </tr>
                    </table>
                    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                </div>
            </div>
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn btn-print" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-close-form" onclick="closeAndReturnToDemandList()">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
window.addEventListener('DOMContentLoaded', (event) => {
    
    // ၁။ English ဂဏန်းပုံစံ (Comma ပါဝင်ပြီး) ပြောင်းလဲပေးသည့် Helper Function
    const formatNumberToEnglish = (numStr) => {
        if (numStr === null || numStr === undefined || numStr == '0' || numStr == '') return '0';
        let cleanNum = numStr.toString().replace(/,/g, '');
        let num = parseFloat(cleanNum);
        if (isNaN(num)) return '0';
        return Math.round(num).toLocaleString('en-US');
    };

    // ရက်စွဲပုံစံပြောင်းရန် function (YYYY-MM-DD -> DD-MM-YYYY English လို)
    const formatDateToEnglish = (dateStr) => {
        if (!dateStr || dateStr === '0000-00-00' || dateStr.includes('...')) return '............';
        if (dateStr.includes('-')) {
            const parts = dateStr.split('-');
            if (parts.length >= 3) {
                const yyyy = parts[0];
                const mm = parseInt(parts[1]); // ရှေ့က 0 ပါရင် ဖြုတ်ရန်
                const dd = parseInt(parts[2].split(' ')[0]);
                return `${dd}-${mm}-${yyyy}`;
            }
        }
        return dateStr;
    };

    // ၂။ HTML ID များထဲသို့ ဒေတာ တိုက်ရိုက်ထည့်သွင်းခြင်း
    document.getElementById('m0407_name').innerText = "<?php echo $os_name; ?>";
    document.getElementById('m0407_address').innerText = "<?php echo $os_address; ?>";
    
    const tName = "<?php echo $os_township; ?>";
    document.getElementById('m0407_township').innerText = tName;
    document.getElementById('m0407_township_footer').innerText = tName;
    
    // English ဂဏန်းဖြင့်သာ ပြသရန်
    document.getElementById('m0407_gir').innerText = "<?php echo $os_gir; ?>";
    document.getElementById('m0407_gir_type').innerText = "<?php echo $os_gir_type; ?>";
    document.getElementById('m0407_taxYear').innerText = "<?php echo $os_year; ?>";
    document.getElementById('m0407_biz').innerText = "<?php echo $os_biz; ?>";

    // 📅 budget_year Table မှ ရလာသော ရက်စွဲများကို ချိတ်ဆက်ခြင်း
    const startDate2 = formatDateToEnglish("<?php echo $start_date2; ?>");
    const endDate2 = formatDateToEnglish("<?php echo $end_date2; ?>");
    
    let taxPeriodText = "............ မှ ............ ထိ";
    if(startDate2 !== '............' && endDate2 !== '............') {
        taxPeriodText = `${startDate2} မှ ${endDate2} ထိ`;
    }
    
    // အခွန်ကာလစာသား ထည့်သွင်းခြင်း
    document.getElementById('m0407_tax_period_txt').innerText = taxPeriodText;
    
    document.getElementById('m0407_demandDate').innerText = formatDateToEnglish("<?php echo $db_data['it_demand_date'] ?? ''; ?>");
    document.getElementById('m0407_taxYear_txt').innerText = "<?php echo $os_year; ?>";

    //မြေအချက်အလက်
    document.getElementById('m0407_block_no').innerText = "<?php echo $os_block_no; ?>";
    document.getElementById('m0407_holding_no').innerText = "<?php echo $os_holding_no; ?>";
    document.getElementById('m0407_area').innerText = "<?php echo $os_area; ?>";
    document.getElementById('m0407_road').innerText = "<?php echo $os_road; ?>";
    document.getElementById('m0407_city').innerText = "<?php echo $os_city; ?>";

    document.getElementById('m0407_block_no2').innerText = "<?php echo $os_block_no; ?>";
    document.getElementById('m0407_holding_no2').innerText = "<?php echo $os_holding_no; ?>";
    document.getElementById('m0407_area2').innerText = "<?php echo $os_area; ?>";
    document.getElementById('m0407_road2').innerText = "<?php echo $os_road; ?>";
    document.getElementById('m0407_city2').innerText = "<?php echo $os_city; ?>";
    
    //ဆောက်ဦအချက်အလက်
    document.getElementById('m0407_building_type').innerText = "<?php echo $os_building_type; ?>";
    document.getElementById('m0407_building_height').innerText = "<?php echo $os_building_height; ?>";
    document.getElementById('m0407_building_type2').innerText = "<?php echo $os_building_type; ?>";
    document.getElementById('m0407_building_height2').innerText = "<?php echo $os_building_height; ?>";
    document.getElementById('m0407_purchase_date').innerText = "<?php echo $os_purchase_date; ?>";

    document.getElementById('m0407_tasapha_no').innerText = "<?php echo $os_tasapha_no; ?>";
    (() => {
        const raw = "<?php echo $os_tasapha_date; ?>";
        let formatted = '-/-/-';
        if (raw && raw !== '0' && raw !== '0000-00-00' && !raw.includes('...')) {
            const parts = raw.split('-');
            if (parts.length >= 3 && parts[0].length === 4) {
                const dd = parts[2].split(' ')[0].padStart(2, '0');
                const mm = parts[1].padStart(2, '0');
                formatted = `${dd}-${mm}-${parts[0]}`;
            } else {
                formatted = raw;
            }
        }
        document.querySelectorAll('.m0407_tasapha_date').forEach(el => {
            el.innerText = formatted;
        });
    })();

    // 🎯 ဇယားကွက်အတွင်းပိုင်း ကိန်းဂဏန်းဒေတာများ (English Format)
    document.getElementById('m0407_declared_value').innerText = formatNumberToEnglish("<?php echo $os_declared_value; ?>");
    
    // 🛑 နှစ်ခါချိတ်ရမည့် Valuation (ဇယားထဲရော စာပိုဒ်ထဲရော) အတွက် Class သုံးပြီး Loop ပတ်ထည့်ပေးခြင်း
    const formattedValuation = formatNumberToEnglish("<?php echo $os_valuation_value; ?>");
    document.querySelectorAll('.m0407_valuation_class').forEach(el => {
        el.innerText = formattedValuation;
    });

    const fillAmount = (id, value) => {
        const el = document.getElementById(id);
        if (el) el.innerText = value;
    };
    fillAmount('m0407_allowable', formatNumberToEnglish("<?php echo $os_allowable_expenses; ?>"));
    fillAmount('m0407_taxable_income', formatNumberToEnglish("<?php echo $os_taxable_income; ?>"));
    fillAmount('m0407_income_tax', formatNumberToEnglish("<?php echo $os_income_tax; ?>"));
    fillAmount('m0407_advance', formatNumberToEnglish("<?php echo $os_advance_tax; ?>"));
    fillAmount('m0407_tax_to_pay', formatNumberToEnglish("<?php echo $os_tax_to_pay; ?>"));
    fillAmount('m0407_penalty_tax', formatNumberToEnglish("<?php echo $os_penalty_tax; ?>"));
    fillAmount('m0407_total_tax', formatNumberToEnglish("<?php echo $os_total_tax; ?>"));
});


function closeAndReturnToDemandList() {
    // 1️⃣ လက်ရှိဖွင့်ထားသော #calculateModal ကို ပိတ်ခြင်း
    try {
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var myModalEl = document.getElementById('form0407Modal');
            var modal = bootstrap.Modal.getInstance(myModalEl) || new bootstrap.Modal(myModalEl);
            modal.hide();
        }
        
        if (typeof jQuery !== 'undefined') {
            jQuery('#form0407Modal').modal('hide');
            jQuery('.modal-backdrop').remove();
            jQuery('body').removeClass('modal-open').css('overflow', 'auto');
        }
    } catch (e) {
        console.log("Modal ပိတ်ရာတွင် အမှားရှိသည်: ", e);
    }
    
    // 2️⃣ မိခင်စာမျက်နှာ (capital_demand_list.php) ထဲက formsModal2 ကို လမ်းကြောင်းမှန်ဖြင့် ပြန်လှမ်းဖွင့်ခြင်း
    setTimeout(function() {
        if (window.opener && !window.opener.closed) {
            // အကယ်၍ Window အသစ် (Pop-up) ဖြင့် ပွင့်နေပါက
            try {
                if (window.opener.jQuery && window.opener.jQuery('#formsModal2').length) {
                    window.opener.jQuery('#formsModal2').modal('show');
                } else if (window.opener.bootstrap && window.opener.bootstrap.Modal) {
                    var parentModal = new window.opener.bootstrap.Modal(window.opener.document.getElementById('formsModal2'));
                    parentModal.show();
                }
            } catch (err) {
                console.log("Parent modal ဖွင့်မရပါ: ", err);
            }
            window.close(); 
        } else {
            /* 🎯 ဤနေရာတွင် လမ်းကြောင်းကို အစ်ကိုကြီးပြောသည့်အတိုင်း အပြင် main folder သို့ ထွက်ရန် ../ ဖြင့် ပြင်ဆင်ထားပါသည် */
            if (typeof jQuery !== 'undefined' && jQuery('#formsModal2').length) {
                jQuery('#formsModal2').modal('show');
            } else {
                // forms_housing folder ထဲမှ အပြင်သို့တစ်ဆင့်ထွက်ပြီး capital_demand_list.php သို့ သွားခြင်း
                window.location.href = '../capital_demand_list.php?openModal=formsModal2';
            }
        }
    }, 300); 
}
</script>
