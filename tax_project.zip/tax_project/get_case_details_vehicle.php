<?php
header('Content-Type: application/json');
include 'db_config.php';

// ကိန်းဂဏန်းသီးသန့်ဖြစ်အောင် စစ်ထုတ်ခြင်း
$min = intval($_GET['min_case'] ?? 0);
$max = intval($_GET['max_case'] ?? 0);

// 🎯 ပြင်ဆင်ချက် - Table အမည်အား မူရင်း မော်တော်ယာဉ်ဇယား 'vehicledata' သို့ ပြောင်းလဲထားပါသည်
$sql = "SELECT * FROM vehicledata 
        WHERE CAST(SUBSTRING_INDEX(case_number, '/', 1) AS UNSIGNED) BETWEEN $min AND $max 
        ORDER BY id DESC";

$result = $conn->query($sql);
$data = [];

if ($result) {
    while($row = $result->fetch_assoc()) {
        // JavaScript ဘက်က မျှော်လင့်ထားတဲ့ Key တွေနဲ့ ကိုက်အောင် အဓိက field တွေကို စုစည်းပါ
        $data[] = [
            'case_number' => $row['case_number'],
            'tax_year' => $row['tax_year'],
            'officer_name' => $row['officer_name'],
            'officer_rank' => $row['officer_rank'] ?? '', // 🎯 ထည့်သွင်းပေးထားပါသည်
            'region' => $row['region'],
            'state_name' => $row['state_name'],
            'township_name' => $row['township_name'],
            'taxpayer_name' => $row['taxpayer_name'],
            'nrc_no' => $row['nrc_no'],
            'gir_type' => $row['gir_type'],
            'gir_no' => $row['gir_no'],
            'address' => $row['address'],
            'business_type' => $row['business_type'],
            'plate_no' => $row['plate_no'],
            'manufacture' => $row['manufacture'],
            'brand_name' => $row['brand_name'],
            'build_type' => $row['build_type'],
            'chassi' => $row['chassi'],     
            'make_year' => $row['make_year'],
            'sale_date' => $row['sale_date'],
            
            'proposal_value' => $row['proposal_value'],
            'valuation_value' => $row['valuation_value'],
            'allowable_expenses' => $row['allowable_expenses'], 
            'taxable_income' => $row['taxable_income'],
            'income_tax' => $row['income_tax'],
            'advance_tax' => $row['advance_tax'],
            'tax_to_pay' => $row['tax_to_pay'],
            'penalty_tax' => $row['penalty_tax'],
            'total_tax' => $row['total_tax'], // 🎯 ဤနေရာတွင် Comma (,) ထည့်ပေးလိုက်ပါသည်
            'paid_amount' => $row['paid_amount']
        ];
    }
}

// ဂျေဆန် Format စစ်စစ် အဖြစ် ပြောင်းလဲထုတ်ပေးခြင်း
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>