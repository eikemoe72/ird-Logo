<?php
// Session စတင်ခြင်း
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Connection ချက်ဆက်ခြင်း
include_once 'db_config.php'; 
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

$state_code  = $data['state_code'] ?? '';
$letter_code = $data['letter_code'] ?? '';
$nrc_type    = $data['nrc_type'] ?? '';
$nrc_text    = $data['nrc_text'] ?? '';
$nrc_no      = $data['nrc_no'] ?? '';

// 🎯 ✅ ပြင်ဆင်ချက် - ဒေတာဆွဲမထုတ်မီ Session ထံမှ user_id ကို ကနဦး ကြိုတင်ဖမ်းယူထားရပါမည်
$current_user_id = $_SESSION['user_id'] ?? 0;

// ကနဦး ဒေတာများကို Default Blank ပေးခြင်း
$state_name = "";
$township_name = "";
$officer_rank = ""; 
$region = "";

// 🎯 user_register table မှ တိုင်းဒေသကြီးနှင့် မြို့နယ်ကို Database တွင် တိုက်ရိုက် ရှာဖွေဆွဲထုတ်ခြင်း
if ($current_user_id > 0) {
    // 💡 user_register table ထဲတွင် ရာထူး column အမည်သည် rank_ ဖြစ်ပါက -
    $user_query = "SELECT state_name, township_name, rank_ FROM user_register WHERE id = $current_user_id LIMIT 1";
    $user_result = $conn->query($user_query);
    if ($user_result && $user_result->num_rows > 0) {
        $user_row = $user_result->fetch_assoc();
        $state_name = $user_row['state_name'] ?? "";
        $township_name = $user_row['township_name'] ?? "";
        
        // 🎯 ရရှိလာသော rank_ တန်ဖိုးကို HTML က သုံးမည့် $officer_rank ထဲသို့ ထည့်ပေးလိုက်ပါ
        $officer_rank = $user_row['rank_'] ?? ""; 
    }
}

// URL က id ကို တိတိကျကျ စစ်ဆေးပြီး ဖမ်းယူခြင်း (အလွတ်ဖြစ်နေလျှင် 0 ဟု သတ်မှတ်မည်)
$id = (isset($_GET['id']) && trim($_GET['id']) !== '') ? intval($_GET['id']) : 0;

if ($id <= 0) {
    $id = 0;
    unset($_SESSION['edit_id']); 
    unset($_POST['id']);
}

// ကနဦး Variable အားလုံးကို အပေါ်ဆုံးမှာ Default Blank/0 သတ်မှတ်ပေးခြင်းဖြင့် Undefined Error ကို ကာကွယ်ပါမည်။
$case_number = "";
$tax_year = "";
$officer_name = "";
$region = "";
$state_name = "";
$township_name = "";
$taxpayer_name = "";
$nrc_no = "";
$gir_type = "";
$gir_no = "";
$address = "";
$business_type = "";
$plate_no = "";
$manufacture = "";
$brand_name = "";
$build_type = "";
$chassi = "";
$make_year = "";
$sale_date = "";
$proposal_value = "";
$valuation_value = "";
$allowable_expenses = "";
$taxable_income = "";
$income_tax = "";
$advance_tax = "";
$tax_to_pay = "";
$penalty_tax = "";
$total_tax = "";
$paid_amount = "";
$chalan_no = "";
$chalan_date = "";
$notified_date = "";
$appointment_date = "";
$appearance_date = "";
$it_demand_no = "";
$it_demand_date = "";

$investigation_value = "";
$source_of_income = "";
$investigation = "";


// -------------------------------------------------------------
// ၂။ မုဒ်ခွဲခြားခြင်း (EDIT MODE သို့မဟုတ် NEW ENTRY MODE)
// -------------------------------------------------------------
if ($id > 0) {
    // =========================================================
    // 📝 EDIT MODE (ပြင်ဆင်ခြင်း မုဒ်)
    // =========================================================
    $_SESSION['edit_id'] = $id; 
    $is_edit_mode = true;
    
    $query = "SELECT * FROM vehicledata WHERE id = $id LIMIT 1";
    $result = $conn->query($query);
    
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // 🎯 ✅ ပြင်ဆင်ချက် - ဒေတာဟောင်း ပြင်ဆင်သည့်မုဒ်ဖြစ်ပါက vehicledata Table ထဲတွင် သိမ်းထားခဲ့သော ဒေတာဟောင်းကို ပြန်လည်ဆွဲယူဖော်ပြမည်
        $state_name      = !empty($row['state_name']) ? $row['state_name'] : $state_name;
        $township_name   = !empty($row['township_name']) ? $row['township_name'] : $township_name;

        $case_number     = $row['case_number'] ?? '';
        $tax_year        = $row['tax_year'] ?? ''; 
        $officer_name    = $row['officer_name'] ?? ''; 
        $officer_rank    = $row['officer_rank'] ?? '';
        $region          = $row['region'] ?? '';
        $state_name      = !empty($row['state_name']) ? $row['state_name'] : $state_name;
        $township_name   = !empty($row['township_name']) ? $row['township_name'] : $township_name;
        $taxpayer_name   = $row['taxpayer_name'] ?? '';
        $nrc_no = $row['nrc_no'] ?? '';
        if (!empty($nrc_no)) {
            if (preg_match('/^([^\/]+)\/([^\(]+)(\([^\)]+\))(.*)$/u', $nrc_no, $matches)) {
                $state_code  = trim($matches[1]);
                $letter_code = trim($matches[2]);
                $nrc_type    = trim($matches[3]);
                $nrc_text    = trim($matches[4]);
            }
        }
        $gir_type           = $row['gir_type'] ?? '';
        $gir_no             = isset($row['gir_no']) ? strval($row['gir_no']) : ''; 
        $address            = $row['address'] ?? '';
        $business_type      = $row['business_type'] ?? ''; 
        $plate_no           = $row['plate_no'] ?? '';
        $manufacture        = $row['manufacture'] ?? '';
        $brand_name         = $row['brand_name'] ?? '';
        $build_type         = $row['build_type'] ?? '';
        $chassi             = $row['chassi'] ?? '';
        $make_year          = isset($row['make_year']) ? floatval(str_replace(',', '', $row['make_year'])) : 0;
        $sale_date          = $row['sale_date'] ?? '';
        $proposal_value     = isset($row['proposal_value']) ? floatval(str_replace(',', '', $row['proposal_value'])) : 0;
        $valuation_value    = isset($row['valuation_value']) ? floatval(str_replace(',', '', $row['valuation_value'])) : 0;
        $allowable_expenses = isset($row['allowable_expenses']) ? floatval(str_replace(',', '', $row['allowable_expenses'])) : 0;
        $taxable_income     = isset($row['taxable_income']) ? floatval(str_replace(',', '', $row['taxable_income'])) : 0;
        $income_tax         = isset($row['income_tax']) ? floatval(str_replace(',', '', $row['income_tax'])) : 0;
        $advance_tax        = isset($row['advance_tax']) ? floatval(str_replace(',', '', $row['advance_tax'])) : 0;
        $penalty_tax        = isset($row['penalty_tax']) ? floatval(str_replace(',', '', $row['penalty_tax'])) : 0;
        $tax_to_pay         = isset($row['tax_to_pay']) ? floatval(str_replace(',', '', $row['tax_to_pay'])) : 0;
        $total_tax          = isset($row['total_tax']) ? floatval(str_replace(',', '', $row['total_tax'])) : 0;
        $paid_amount        = isset($row['paid_amount']) ? floatval(str_replace(',', '', $row['paid_amount'])) : 0;
        $chalan_no          = $row['chalan_no'] ?? '';
        $chalan_date        = $row['chalan_date'] ?? '';

        $notified_date      = $row['notified_date'] ?? '';
        $appointment_date   = $row['appointment_date'] ?? '';
        $appearance_date    = $row['appearance_date'] ?? '';

        $it_demand_no       = $row['it_demand_no'] ?? '';
        $it_demand_date     = $row['it_demand_date'] ?? '';

        $investigation_value    = $row['investigation_value'] ?? '';
        $source_of_income       = $row['source_of_income'] ?? '';
        $investigation          = $row['investigation'] ?? '';
       
    }
} else {
    // =========================================================
    // ✨ NEW ENTRY MODE (အသစ်ထည့်ခြင်း မုဒ်)
    // =========================================================
    unset($_SESSION['edit_id']);
    unset($_POST['id']);

    // 🎯 ✅ ပြင်ဆင်ချက် - $current_user_id ကို အပေါ်ဆုံးတွင် ကြိုတင်သတ်မှတ်ထားပြီး ဖြစ်ပါသည်
    $officer_name    = $_SESSION['officer_name'] ?? '';
    $region          = $_SESSION['region'] ?? '';

    // Budget Year တွက်ချက်ခြင်း
    $current_date = date('Y-m-d');
    $budget_query = "SELECT budget_year FROM budget_year WHERE '$current_date' BETWEEN start_date2 AND end_date2 LIMIT 1";
    $budget_result = $conn->query($budget_query);

    $budget_year = "";
    if ($budget_result && $budget_result->num_rows > 0) {
        $budget_row = $budget_result->fetch_assoc();
        $budget_year = $budget_row['budget_year'];
    } else {
        $fallback_query = "SELECT budget_year FROM budget_year ORDER BY id DESC LIMIT 1";
        $fallback_result = $conn->query($fallback_query);
        if ($fallback_result && $fallback_result->num_rows > 0) {
            $fallback_row = $fallback_result->fetch_assoc();
            $budget_year = $fallback_row['budget_year'];
        }
    }
    $tax_year = $budget_year;

    // အမှုတွဲအမှတ် အသစ်စစ်စစ် ထုတ်ပေးခြင်း
    if ($current_user_id > 0) {
        $case_query = "SELECT MAX(CAST(SUBSTRING_INDEX(case_number, '/', 1) AS UNSIGNED)) as max_no 
                       FROM vehicledata 
                       WHERE tax_year = '$budget_year'";
        
        $case_result = $conn->query($case_query);
        $next_count = 1; 

        if ($case_result) {
            $case_row = $case_result->fetch_assoc();
            if (!is_null($case_row['max_no'])) {
                $next_count = intval($case_row['max_no']) + 1;
            }
        }
        
        $padded_count = str_pad($next_count, 3, "0", STR_PAD_LEFT);
        $case_number = $padded_count . "/" . $budget_year;
    } else {
        $case_number = "";
    }
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tax Calculation System - Form 2</title>
    <style>
        body { font-family: 'Pyidaungsu', sans-serif; background-color: #f0f0f0; margin: 0; padding: 10px; }
        .container { width: 100%; max-width: 1400px; margin: auto; background: white; border: 1px solid #000; }
        header { background: #0056b3; color: white; display: flex; justify-content: space-between; padding: 8px; font-weight: bold; font-size: 16px; }
        .main-content { display: flex; gap: 10px; padding: 15px; }
        .section { flex: 1; border: 1px solid #ccc; padding: 10px; }
        .section-title { background: yellow; text-align: center; padding: 6px; margin-bottom: 10px; font-weight: bold; border: 1px solid #000; }
        .sub-title { background: #0056b3; color:white; text-align: center; padding: 2px; margin: 10px 0; font-size: 14px; font-weight: bold; }
        .calc-grid { display: grid; grid-template-columns: 1fr 1.3fr 1fr 1fr 1fr 1fr; gap: 4px 10px; align-items: center; }
        label { font-size: 14px; display: flex; align-items: center; height: 28px; }
        input, select { height: 28px; padding: 2px 5px; border: 1px solid #777; width: 100%; box-sizing: border-box; text-align: right; font-size: 14px; }
        input[readOnly] { background-color: #e9e9e9; font-weight: normal; }
        .button-group { display: flex; flex-direction: column; gap: 8px; margin-top: 20px; }
        .btn { height: 30px; border: none; color: white; font-weight: bold; cursor: pointer; border-radius: 15px; }
        .save { background: green; } .clear { background: gray; } .exit { background: red; }
        .back-btn { background: #5d46e2; width: 120px; margin-top: 10px; }
        .link { color: white; text-decoration: none; display: block; width: 100%; height: 100%; line-height: 30px; }
        .chalantext { width: 26.8%; text-align: left; }
        .date { width: 71%; }
        .GIR { width: 76%; }
        .nrc1 { width: 20%; }
        .nrc2 { width: 28%; }
        .nrc3 { width: 23%; }
        .nrc_no { width: 24%; text-align: left; }
        .region{ width: 49%; }
        .flex-row { display: flex; align-items: stretch; gap: 5px; }
        .flex-row select, .flex-row input { height: 30px; margin: 0; padding: 2px 5px; box-sizing: border-box; vertical-align: top; }
        textarea { text-align: left; font-family: 'Pyidaungsu', sans-serif; padding: 5px; }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>

<div class="container">

    

    <form action="vehicle_save.php" method="POST" autocomplete="off">
        <input type="hidden" name="id" value="<?php echo ($id > 0) ? $id : ''; ?>">

        <header>
            <div class="header-left">
                <span id="state_name_text"><?php echo htmlspecialchars($state_name); ?></span>
                <input type="hidden" name="state_name" value="<?php echo htmlspecialchars($state_name); ?>">
            </div>
            <div class="header-center">Tax Calculation And Case Printing System</div>
            <div class="header-right">
                <span id="township_name_text"><?php echo htmlspecialchars($township_name); ?></span>
                <input type="hidden" name="township_name" value="<?php echo htmlspecialchars($township_name); ?>">
            </div>
    </header>

        <div class="main-content">
            <div class="section">
                <div class="section-title">မော်တော်ယာ/ရေယာဉ် တွက်ချက်မှု</div>
                <div class="calc-grid">

                    <div class="sub-title" style="grid-column: span 2; margin:0;">အမှုတွဲဆိုင်ရာအခက်အလက်များ</div>
                    <div class="sub-title" style="grid-column: span 2; margin:0;">ယာဉ်ဆိုင်ရာအချက်အလက်များ</div>
                    <div class="sub-title" style="grid-column: span 2; margin:0;">အကြောင်းကြားစာချုပ်အပ်ခြင်းဆိုင်ရာအချက်အလက်များ</div>

                    <label>အမှုတွဲအမှတ်</label>
                    <input type="text" id="case_number" name="case_number" value="<?php echo htmlspecialchars($case_number); ?>" style="text-align: center;">
                    <label id="lbl_sale_date">မော်တော်ယာဉ်ဝယ်ယူသည့်နေ့</label>
                        <input type="date" id="sale_date" name="sale_date" value="<?php echo htmlspecialchars($sale_date); ?>" >
                    <label>အကြောင်းကြားစာချသည့်ရက်</label>
                    <input type="date" id="notified_date" name="notified_date" value="<?php echo htmlspecialchars($notified_date); ?>">
                     
                    <label>စည်းကြပ်နှစ်</label>
                    <input type="text" id="tax_year" name="tax_year" value="<?php echo htmlspecialchars($tax_year); ?>" readonly style="text-align: center;">
                    <label id="lbl_proposal_value">အခွန်ထမ်းတင်ပြသည့်အဝယ်တန်ဖိုး</label>
                    <input type="text" id="proposal_value" name="proposal_value" value="<?php echo htmlspecialchars($proposal_value); ?>" style="text-align: right;">
                    <label>ချိန်းဆိုသည့်ရက်</label>
                    <input type="date" id="appointment_date" name="appointment_date" value="<?php echo htmlspecialchars($appointment_date); ?>">
                    
                    <label>အခွန်မှူးအမည်</label>
                    <input type="text" id="officer_name" name="officer_name" value="<?php echo htmlspecialchars($officer_name); ?>" style="text-align: center;">
                    <label id="lbl_valuation_value">သတ်မှတ်အရောင်း/အဝယ်တန်ဖိုး</label>
                    <input type="text" id="valuation_value" name="valuation_value" oninput="calculateTax()"value="<?php echo htmlspecialchars($valuation_value); ?>" style="text-align: right;">
                    <label>လာရောက်သည့်ရက်</label>
                        <input type="date" id="appearance_date" name="appearance_date" value="<?php echo htmlspecialchars($appearance_date); ?>">

                    <label>ရာထူး/နယ်မြေ</label>
                        <div>
                            <input type="text" id="officer_rank" name="officer_rank" value="<?php echo htmlspecialchars($officer_rank); ?>" style="text-align: center;" class="region">
                            <input type="text" id="region" name="region" value="<?php echo htmlspecialchars($region); ?>" style="text-align: center;" class="region">
                        </div>
                    <label style="color:red;">မူလတန်ဖိုး/ခွင့်ပြုဝင်ငွေရလမ်း</label>
                    <input type="text" name="allowable_expenses" style="color:red;" id="allowable_expenses" oninput="calculateTax()"  value="<?php echo ($allowable_expenses > 0) ? number_format($allowable_expenses) : 0; ?>">
                    <div class="sub-title" style="grid-column: span 2; margin:0;">အခွန်စည်းကြပ်မှုမှတ်တမ်း</div>

                    <div class="sub-title" style="grid-column: span 2; margin:0;">အခွန်ထမ်းဆိုင်ရာအချက်အလက်များ</div>
                    <label>စည်းကြပ်မှုမှလွတ်ကင်းနေသောဝင်ငွေ</label>
                    <input type="text" name="taxable_income" id="taxable_income" value="<?php echo ($taxable_income > 0) ? number_format($taxable_income) : 0; ?>" readonly>
                    <label>IT Demand No.</label>
                    <div>
                        <input type="text" id="it_demand_no" name="it_demand_no" value="<?php echo htmlspecialchars($it_demand_no); ?>" class="chalantext">
                        <input type="date" id="it_demand_date" name="it_demand_date" value="<?php echo htmlspecialchars($it_demand_date); ?>" class="date">
                    </div>

                    <label>အခွန်ထမ်းအမည်</label>
                    <input type="text" id="taxpayer_name" name="taxpayer_name" value="<?php echo htmlspecialchars($taxpayer_name); ?>" style="text-align: left;">
                    <label>ကျသင့်ဝင်ငွေခွန်</label>
                    <input type="text" name="income_tax" id="income_tax" value="<?php echo ($income_tax > 0) ? number_format($income_tax) : 0; ?>" readonly>
                    <div class="sub-title" style="grid-column: span 2; margin:0;">အစားထိုးသတ်မှတ်သည့်တန်ဖိုးနှင့်ပတ်သက်၍ ရှငိးလင်းချက်</div>

                    <label>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</label>
                    <div class="flex-row">
                        <select id="gir_select" name="gir_type" class="GIR">
                            <option value="">ရွေးချယ်ပါ</option>
                            <option value="စကလက(ယာဉ်)" <?php echo ($gir_type == 'စကလက(ယာဉ်)') ? 'selected' : ''; ?>>စကလက(ယာဉ်)</option>
                            <option value="အခြေ(ယာဉ်)" <?php echo ($gir_type == 'အခြေ(ယာဉ်)') ? 'selected' : ''; ?>>အခြေ(ယာဉ်)</option>
                            <option value="စကလက(ရေယာဉ်)" <?php echo ($gir_type == 'စကလက(ရေယာဉ်)') ? 'selected' : ''; ?>>စကလက(ရေယာဉ်)</option>
                            <option value="အခြေ(ရေယာဉ်)" <?php echo ($gir_type == 'အခြေ(ရေယာဉ်)') ? 'selected' : ''; ?>>အခြေ(ရေယာဉ်)</option>
                        </select>
                        <input type="text" id="gir_no" name="gir_no" value="<?php echo htmlspecialchars($gir_no); ?>" class="nrc_no">
                    </div>
                    <label style="color:red;">ကြိုတင်ခွန်</label>
                    <input type="text" name="advance_tax" style="color:red;" id="advance_tax" oninput="calculateTax()"  value="<?php echo ($advance_tax > 0) ? number_format($advance_tax) : 0; ?>">
                    <textarea id="investigation_value" name="investigation_value" style="grid-column: span 2; grid-row: span 3; margin: 0; height: 100%; min-height: 30px;"><?php echo htmlspecialchars($investigation_value); ?></textarea>

                    

                    <label>နိုင်ငံသားစိစစ်ရေးကတ်ပြားအမှတ်</label>
                    <div class="flex-row">
                       <select id="state_code" name="state_code" class="nrc1">
                            <option value="">ရွေးချယ်ရန်</option>
                            <?php 
                            for($i=1; $i<=14; $i++) {
                                $val = str_pad($i, 2, "0", STR_PAD_LEFT);
                                $selected = (intval($state_code) == $i) ? 'selected' : '';
                                echo "<option value='$val' $selected>$i</option>";
                            }
                            ?>
                        </select>

                        <select id="letter_code" name="letter_code" class="nrc2">
                            <option value="">ရွေးချယ်ရန်</option>
                            <?php if(!empty($letter_code)): ?>
                                <option value="<?php echo $letter_code; ?>" selected><?php echo $letter_code; ?></option>
                            <?php endif; ?>
                        </select>
                        <select name="nrc_type" id="nrc_type" class="nrc3" onchange="combineNRC();">
                            <option value="">ရွေးချယ်ပါ</option>
                            <option value="(နိုင်)" <?php echo ($nrc_type == '(နိုင်)' || $nrc_type == 'နိုင်') ? 'selected' : ''; ?>>(နိုင်)</option>
                            <option value="(ဧည့်)" <?php echo ($nrc_type == '(ဧည့်)' || $nrc_type == 'ဧည့်') ? 'selected' : ''; ?>>(ဧည့်)</option>
                            <option value="(ပြု)" <?php echo ($nrc_type == '(ပြု)' || $nrc_type == 'ပြု') ? 'selected' : ''; ?>>(ပြု)</option>
                            <option value="(သာ)" <?php echo ($nrc_type == '(သာ)' || $nrc_type == 'သာ') ? 'selected' : ''; ?>>(သာ)</option>
                            <option value="(သီ)" <?php echo ($nrc_type == '(သီ)' || $nrc_type == 'သီ') ? 'selected' : ''; ?>>(သီ)</option>
                        </select>
                                                                                
                        <input type="text" name="nrc_text" id="nrc_text" class="nrc_no" value="<?php echo htmlspecialchars($nrc_text); ?>" oninput="combineNRC()">
                        <input type="hidden" name="nrc_no" id="nrc_no_hidden" value="<?php echo htmlspecialchars($nrc_no); ?>">
                    </div>
                    <label>ပေးဆောင်ရမည့်အခွန်</label>
                    <input type="text" name="tax_to_pay" id="tax_to_pay" value="<?php echo ($tax_to_pay > 0) ? number_format($tax_to_pay) : 0; ?>" readonly>
                    
                    <label>အခွန်ထမ်းလိပ်စာ</label>
                    <textarea id="address" name="address" style=" grid-row: span 2; margin: 0; height: 100%; min-height: 30px;"><?php echo htmlspecialchars($address); ?></textarea>
                    <label style="color:red;">ဒဏ်ငွေ</label>
                    <input type="text" name="penalty_tax" style="color:red;" oninput="calculateTax()"  id="penalty_tax" value="<?php echo ($penalty_tax > 0) ? number_format($penalty_tax) : 0; ?>">           
                    <label></label>
                    <label>ပေးဆောင်ရမည့်အခွန်+ဒဏ်</label>
                    <input type="text" name="total_tax" id="total_tax" value="<?php echo ($total_tax > 0) ? number_format($total_tax) : 0; ?>" readonly> 
                    <div class="sub-title" style="grid-column: span 2; margin:0;">အခွန်ထမ်းတင်ပြသည့်ဝင်ငွေရလမ်း အကြောင်းအရာ ဖော်ပြချက်</div>
                    
                    
                    <div class="sub-title" style="grid-column: span 2; margin:0;">အခွန်စည်းကြပ်ခြင်းဆိုင်ရာအချက်အလက်များ</div>
                    <label style="color:blue;">ပေးသွင်းသည့်အခွန်</label>
                    <input type="text" style="color:blue;" id="paid_amount" name="paid_amount" value="<?php echo ($paid_amount > 0) ? number_format($paid_amount) : 0; ?>">
                    <textarea id="source_of_income" name="source_of_income" style="grid-column: span 2; grid-row: span 3; margin: 0; height: 100%; min-height: 30px;"><?php echo htmlspecialchars($source_of_income); ?></textarea>
                    
                    
                    <label>လုပ်ငန်းအမျိုးအစား</label>
                        <select id="business_type" name="business_type" oninput="calculateTax()">
                            <option value="">ရွေးချယ်ရန်</option>
                            <option value="မော်တော်ယာဉ်ဝယ်ယူခြင်း" <?php echo ($business_type == 'မော်တော်ယာဉ်ဝယ်ယူခြင်း') ? 'selected' : ''; ?>>မော်တော်ယာဉ်ဝယ်ယူခြင်း</option>
                            <option value="မော်တော်ယာဉ်ရောင်းချခြင်း" <?php echo ($business_type == 'မော်တော်ယာဉ်ရောင်းချခြင်း') ? 'selected' : ''; ?>>မော်တော်ယာဉ်ရောင်းချခြင်း</option>
                            <option value="ရေယာဉ်ဝယ်ယူခြင်း" <?php echo ($business_type == 'ရေယာဉ်ဝယ်ယူခြင်း') ? 'selected' : ''; ?>>ရေယာဉ်ဝယ်ယူခြင်း</option>
                            <option value="ရေယာဉ်ရောင်းချခြင်း" <?php echo ($business_type == 'ရေယာဉ်ရောင်းချခြင်း') ? 'selected' : ''; ?>>ရေယာဉ်ရောင်းချခြင်း</option>
                        </select>
                    <label><b>ချလန်အမှတ်/ရက်စွဲ</b></label>
                    <div>
                        <input type="text" id="chalan_no" name="chalan_no" value="<?php echo htmlspecialchars($chalan_no); ?>" class="chalantext">
                        <input type="date" id="chalan_date" name="chalan_date" value="<?php echo htmlspecialchars($chalan_date); ?>" class="date">
                    </div>
                   
                    
                    <label id="lbl_plate_no">ယာဉ်နံပါတ်</label>
                    <input type="text" id="plate_no" name="plate_no" value="<?php echo htmlspecialchars($plate_no); ?>"> 
                    <label></label><label></label>
                    
                    
                    <label id="lbl_manufacture">ယာဉ်အမျိုးအမည်(Manufacture)</label>
                    <input type="text" id="manufacture" name="manufacture" value="<?php echo htmlspecialchars($manufacture); ?>">
                    <label></label><label></label>
                     <div class="sub-title" style="grid-column: span 2; margin:0;">ဝင်ငွေရလမ်းအပေါ်  စိစစ်ခွင့်ပြုမှုနှင့်ပတ်သက်၍ ရှင်းလင်းချက်</div>


                    <label id="lbl_brand_name">ယာဉ်အမျိုးအစား(Brand Name)</label>
                    <input type="text" id="brand_name" name="brand_name" value="<?php echo htmlspecialchars($brand_name); ?>">
                    <button type="submit" class="btn save" style="grid-column: span 2; margin:0;">SAVE DATA</button>
                    <textarea id="investigation" name="investigation" style="grid-column: span 2; grid-row: span 3; margin: 0; height: 100%; min-height: 30px;"><?php echo htmlspecialchars($investigation); ?></textarea>

                    <label id="lbl_build_type">တည်ဆောက်ပုံ(build Type)</label>
                    <input type="text" id="build_type" name="build_type" value="<?php echo htmlspecialchars($build_type); ?>">
                    <button type="button" style="grid-column: span 2; margin:0;" class="btn exit" onclick="exitToList()">EXIT</button>
                    
                    

                    <label id="lbl_chassi">ဘောင်အမှတ်(Chassi)</label>
                    <input type="text" id="chassi" name="chassi" value="<?php echo htmlspecialchars($chassi); ?>">
                     <button type="button" style="grid-column: span 2; margin:0;" class="btn clear"><a href="dashboard.php" class="link">Home Page</a></button>

   
                    <label id="lbl_make_year">ထုတ်လုပ်သည့်ခုနှစ်(Make Year)</label>
                    <input type="text" id="make_year" name="make_year" value="<?php echo htmlspecialchars($make_year); ?>">
                    <label></label><label></label>
                    <label></label><label></label>
                   

                </div>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const stateCodeSelect = document.getElementById('state_code');
    const letterCodeSelect = document.getElementById('letter_code');

    if (stateCodeSelect && letterCodeSelect) {
        stateCodeSelect.addEventListener('change', function() {
            const selectedState = this.value;
            if (selectedState === "") {
                letterCodeSelect.innerHTML = '<option value="">ရွေးချယ်ပါ</option>';
                combineNRC();
                return;
            }
            fetch(`get_letters_by_state.php?state_code=${encodeURIComponent(selectedState)}`)
                .then(response => response.json())
                .then(res => {
                    if (res.status === 'success') {
                        letterCodeSelect.innerHTML = '<option value="">ရွေးချယ်ပါ</option>';
                        res.data.forEach(letter => {
                            const option = document.createElement('option');
                            option.value = letter;
                            option.textContent = letter;
                            letterCodeSelect.appendChild(option);
                        });
                        
                        const nrcNoEl = document.getElementById('nrc_no_hidden');
                        if (nrcNoEl && nrcNoEl.value.includes('/')) {
                            const parts = nrcNoEl.value.split('/');
                            if (parts.length > 1) {
                                const remain = parts[1];
                                const typeIndex = remain.indexOf('(');
                                if (typeIndex !== -1) {
                                    const savedLetter = remain.substring(0, typeIndex).trim();
                                    letterCodeSelect.value = savedLetter;
                                }
                            }
                        }
                        combineNRC(); 
                    }
                });
        });
        letterCodeSelect.addEventListener('change', combineNRC);
    }
});

function combineNRC() {
    var state = document.getElementById('state_code') ? document.getElementById('state_code').value : '';
    var township = document.getElementById('letter_code') ? document.getElementById('letter_code').value : '';
    var type = document.getElementById('nrc_type') ? document.getElementById('nrc_type').value : '';
    var text = document.getElementById('nrc_text') ? document.getElementById('nrc_text').value : '';
    var nrcNoField = document.getElementById('nrc_no_hidden');
    if(nrcNoField) {
        if(state && township && type && text) {
            nrcNoField.value = parseInt(state) + "/" + township + type + text;
        } else {
            nrcNoField.value = ""; 
        }
    }
}

const mmDigits = { '၀':'0', '၁':'1', '၂':'2', '၃':'3', '၄':'4', '၅':'5', '၆':'6', '၇':'7', '၈':'8', '၉':'9' };

function parseVal(id) {
    let el = document.getElementById(id);
    if (!el || !el.value) return 0;
    let valStr = el.value.toString().replace(/,/g, '').replace(/[၀-၉]/g, function(s) { return mmDigits[s]; });
    let cleanVal = valStr.replace(/[^0-9.]/g, ''); 
    return parseFloat(cleanVal) || 0;
}

function formatVal(id, num) {
    let el = document.getElementById(id);
    if (el) {
        if (num <= 0 || isNaN(num)) { el.value = "0"; } 
        else { el.value = Math.round(num).toLocaleString('en-US'); }
    }
}

function formatInputOnType(e) {
    let el = e.target;
    let cursorPosition = el.selectionStart;
    let originalLength = el.value.length;
    let val = el.value.replace(/,/g, '').replace(/[၀-၉]/g, function(s) { return mmDigits[s]; });
    let cleanVal = val.replace(/[^0-9.]/g, ''); 
    if (cleanVal === '') { el.value = ''; return; }
    let num = parseFloat(cleanVal) || 0;
    el.value = Math.round(num).toLocaleString('en-US');
    let newLength = el.value.length;
    let newCursorPos = cursorPosition + (newLength - originalLength);
    el.setSelectionRange(newCursorPos, newCursorPos);
}

window.addEventListener('DOMContentLoaded', () => {
                                // လုပ်ငန်းအမျိုးအစား ပြောင်းလဲမှုကိုပါ လှမ်းဖမ်းရန် တိုးပေးလိုက်သောကုဒ်
    const bizTypeEl = document.getElementById('business_type');
    if (bizTypeEl) {
        bizTypeEl.addEventListener('change', calculateTax);
    }
    
    const taxFields = ['proposal_value', 'valuation_value', 'allowable_expenses', 'advance_tax', 'penalty_tax', 'paid_amount'];
    taxFields.forEach(id => {
        const input = document.getElementById(id);
        if (input) { 
            input.addEventListener('input', (e) => {
                formatInputOnType(e); 
                calculateTax();       
            });
        }
    });
    calculateTax();
});


  
function calculateTax() {
    // 🎯 လုပ်ငန်းအမျိုးအစားကို ဖတ်ယူခြင်း
    let business_type_el = document.getElementById("business_type");
    let business_type = "";
    if (business_type_el) {
        business_type = business_type_el.value.trim();
    } else {
        business = "<?php echo isset($os_biz) ? trim($os_biz) : ''; ?>";
    }

    let advanceTaxInput = document.getElementById('advance_tax');
    let penaltyTaxInput = document.getElementById('penalty_tax');

    // 🎯 "ဝယ်ယူခြင်း" ပါဝင်ပါက Readonly ပိတ်ပြီး Value ကို 0 ပေးမည့်စနစ်
    if (business_type.includes('ဝယ်ယူခြင်း')) {
        if (advanceTaxInput) {
            advanceTaxInput.readOnly = true;
            advanceTaxInput.value = "0";
            advanceTaxInput.style.backgroundColor = "#e9ecef"; // Readonly ပုံစံ မီးခိုးရောင်ပြောင်းခြင်း
        }
        if (penaltyTaxInput) {
            penaltyTaxInput.readOnly = true;
            penaltyTaxInput.value = "0";
            penaltyTaxInput.style.backgroundColor = "#e9ecef";
        }
    } else {
        // "ရောင်းချခြင်း" သို့မဟုတ် အခြားအခြေအနေများတွင် ပြန်ဖွင့်ပေးခြင်း
        if (advanceTaxInput) {
            advanceTaxInput.readOnly = false;
            advanceTaxInput.style.backgroundColor = ""; // နဂိုအရောင်အတိုင်း ပြန်ပြောင်းခြင်း
        }
        if (penaltyTaxInput) {
            penaltyTaxInput.readOnly = false;
            penaltyTaxInput.style.backgroundColor = "";
        }
    }

    // ၁။ valuation_value ကို User ရိုက်ထားတဲ့အတိုင်း တိုက်ရိုက်ဆွဲယူပါမယ်
    let valuation_value    = parseVal("valuation_value");  
    let allowable_expenses = parseVal("allowable_expenses");   
    let advance_tax        = parseVal("advance_tax");          
    let penalty_tax        = parseVal("penalty_tax");  

    console.log("ယခုလုပ်ငန်းအမျိုးအစားမှာ: ", business_type);
    
    let taxable_income = valuation_value - allowable_expenses;
    if (taxable_income < 0) taxable_income = 0; 
    formatVal("taxable_income", taxable_income); 
                                
    let income_tax = 0; 
    let remainingIncome = taxable_income;

    // ၂။ 🎯 လုပ်ငန်းအမျိုးအစား တိုက်စစ်ခြင်း
    if (business_type.includes('ရောင်းချခြင်း')) {
        if (remainingIncome > 0) { 
            income_tax = remainingIncome * 0.10; 
        }
    } else {
        // အခြား စည်းကြပ်မှုမှ လွတ်ကင်းသော ဝင်ငွေ (ဝယ်ယူခြင်းများ) ဖြစ်ပါက Slab အလိုက် တွက်ချက်ခြင်း
        if (remainingIncome > 0) {
            let slabChunk = Math.min(remainingIncome, 300000000); 
            income_tax += slabChunk * 0.03; remainingIncome -= slabChunk;
        }
        if (remainingIncome > 0) {
            let slabChunk = Math.min(remainingIncome, 300000000); 
            income_tax += slabChunk * 0.05; remainingIncome -= slabChunk;
        }
        if (remainingIncome > 0) {
            let slabChunk = Math.min(remainingIncome, 400000000); 
            income_tax += slabChunk * 0.10; remainingIncome -= slabChunk;
        }
        if (remainingIncome > 0) {
            let slabChunk = Math.min(remainingIncome, 2000000000); 
            income_tax += slabChunk * 0.15; remainingIncome -= slabChunk;
        }
        if (remainingIncome > 0) { 
            income_tax += remainingIncome * 0.30; 
        }
    }

    formatVal("income_tax", income_tax);
    let tax_to_pay = income_tax - advance_tax;
    if (tax_to_pay < 0) tax_to_pay = 0;
    formatVal("tax_to_pay", tax_to_pay); 

    let total_tax = tax_to_pay + penalty_tax;
    formatVal("total_tax", total_tax); 
}

// 🛑 [အရေးကြီးဆုံးပြင်ဆင်ချက်] ကနဦး Form ဖွင့်ချိန်တွင် ဒေတာဟောင်းများကို Clear လုပ်ခြင်း
window.onload = function() {
    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.has('id');
    
    if (!isEditMode) { 
        // အသစ်ဝင်ခြင်းဖြစ်ပါက LocalStorage အဟောင်းများကို ချက်ချင်းဖျက်ပစ်ပါမည်။
        localStorage.removeItem('TaxSystem_Data_Share'); 
    } else {
        const savedData = localStorage.getItem('TaxSystem_Data_Share');
        if (savedData) { 
            const formData = JSON.parse(savedData);
            Object.keys(formData).forEach(id => {
                const element = document.getElementById(id);
                if (element && element.value === "") { element.value = formData[id]; }
            });
            if (typeof calculateTax === "function") calculateTax(); 
        }
    }
};

document.addEventListener('input', () => {
    var urlParams = new URLSearchParams(window.location.search);
    var isEditMode = urlParams.has('id');
    if (isEditMode) {
        let formData = JSON.parse(localStorage.getItem('TaxSystem_Data_Share')) || {};
        document.querySelectorAll('input, select, textarea').forEach(input => {
            if (input.id) { formData[input.id] = input.value; }
        });
        localStorage.setItem('TaxSystem_Data_Share', JSON.stringify(formData));
    }
});

// 🎯 ၁။ တိုင်းဒေသကြီးအလိုက် စာလုံးအက္ခရာများ ဆွဲယူပေးသည့် အစ်ကို့မူရင်း Function (အပြည့်အစုံ ပြန်ထည့်ပေးထားပါသည်)
function loadLetterCodes(stateCode, selectedLetterCode = '') {
    if (!stateCode) {
        $('#letter_code').html('<option value="">ရွေးချယ်ရန်</option>');
        return;
    }
    $.ajax({
        type: 'GET',
        url: 'get_letters_by_state.php',
        data: { state_code: stateCode },
        dataType: 'json',
        success: function(response) {
            $('#letter_code').html('<option value="">ရွေးချယ်ရန်</option>');
            if (response.status === 'success' && response.data.length > 0) {
                $.each(response.data, function(index, value) {
                    var isSelected = (value.trim() === selectedLetterCode.trim()) ? 'selected' : '';
                    $('#letter_code').append('<option value="' + value + '" ' + isSelected + '>' + value + '</option>');
                });
            }
        }
    });
}

$(document).ready(function() {
    // 🎯 ၂။ User Login Session မှ State နှင့် Township အချက်အလက်များအား အလိုအလျောက် ဖြည့်သွင်းခြင်း (New Mode အတွက်)
    <?php if ($id <= 0): ?>
        var sessionState = "<?php echo isset($_SESSION['state_name']) ? $_SESSION['state_name'] : ''; ?>";
        var sessionTownship = "<?php echo isset($_SESSION['township_name']) ? $_SESSION['township_name'] : ''; ?>";
        var sessionoRank = "<?php echo isset($_SESSION['officer_rank']) ? $_SESSION['officer_rank'] : ''; ?>";
        
        if(document.getElementById("display_state") && sessionState !== "") {
            document.getElementById("display_state").value = sessionState; 
        }
        if(document.getElementById("display_township") && sessionTownship !== "") {
            document.getElementById("display_township").value = sessionTownship;
        }
         if(document.getElementById("display_rank") && sessionoRank !== "") {
            document.getElementById("display_rank").value = sessionoRank;
        }
    <?php endif; ?>

    // 🎯 ၃။ တိုင်းဒေသကြီး ကုဒ်ပြောင်းလဲမှုစနစ်နှင့် မူရင်းချိတ်ဆက်မှုများ
    $('#state_code').on('change', function() {
        loadLetterCodes($(this).val(), '');
    });

    var existingState = $('#state_code').val();
    var existingLetter = "<?php echo isset($letter_code) ? $letter_code : ''; ?>"; 
    if (existingState && existingLetter) {
        loadLetterCodes(existingState, existingLetter);
    }
});

function exitToList() { 
    if (confirm("ပင်မစာမျက်နာသို့ သွားရန်သေချာပါသလား?")) { 
        window.location.href = "dashboard.php"; 
    } 
}
</script>



<?php if ($id <= 0): ?>
<script>
// ✨ New Entry Mode တွင် <header> ၏ hidden inputs များအပါအဝင် ဒေတာများ လုံးဝမပျောက်ပျက်စေမည့် စနစ်အသစ်
document.addEventListener("DOMContentLoaded", function() {
    // PHP ထံမှ တန်ဖိုးများကို JavaScript Variable အဖြစ် ဖမ်းယူခြင်း
    var phpState = "<?php echo htmlspecialchars($state_name); ?>";
    var phpTownship = "<?php echo htmlspecialchars($township_name); ?>";
    var phpRank = "<?php echo htmlspecialchars($officer_rank ?? $rank_ ?? ''); ?>";

    //  ფუნქရှင်ငယ် - hidden input နှင့် စာသားပြ span နှစ်ခုလုံးသို့ တန်ဖိုးထည့်ပေးရန်
    function assignHeaderData() {
        // ၁။ တိုင်းဒေသကြီးအတွက် (Hidden Input တွန်းထည့်ခြင်း နှင့် Span စာသားပြောင်းခြင်း)
        var stateInput = document.getElementsByName("state_name")[0];
        if(stateInput) stateInput.value = phpState;
        var stateSpan = document.getElementById("state_name_text") || document.getElementById("state_name");
        if(stateSpan) stateSpan.innerText = phpState;

        // ၂။ မြို့နယ်အတွက် (Hidden Input တွန်းထည့်ခြင်း နှင့် Span စာသားပြောင်းခြင်း)
        var townshipInput = document.getElementsByName("township_name")[0];
        if(townshipInput) townshipInput.value = phpTownship;
        var townshipSpan = document.getElementById("township_name_text") || document.getElementById("township_name");
        if(townshipSpan) townshipSpan.innerText = phpTownship;

        // ၃။ အရာရှိရာထူးအတွက် (မူလ ID အကွက်ရှိလျှင် ထည့်ရန်)
        if(document.getElementById("display_rank")) document.getElementById("display_rank").value = phpRank;
        var rankInput = document.getElementsByName("officer_rank")[0] || document.getElementsByName("rank_")[0];
        if(rankInput) rankInput.value = phpRank;
    }

    // 🎬 (က) ပထမအကြိမ် စာမျက်နှာပွင့်လျှင်ပွင့်ချင်း ချက်ချင်း တန်ဖိုးထည့်သွင်းခြင်း
    assignHeaderData();

    // 🎬 (ခ) ဒုတိယအကြိမ် Autofill ရှင်းလင်းရေးစနစ် အလုပ်လုပ်ပြီးနောက် ကာကွယ်ရေးအနေဖြင့် ထပ်မံထည့်သွင်းခြင်း
    setTimeout(function() {
        // state_name နှင့် township_name input များကို ကွင်းစနစ်ဖြင့် Autofill ဖျက်ခြင်းမှ ကာကွယ်ထားပါသည်
        document.querySelectorAll('input:not([id="case_number"]):not([id="tax_year"]):not([id="officer_name"]):not([id="region"]):not([name="state_name"]):not([name="township_name"]):not([name="officer_rank"]):not([name="rank_"])').forEach(input => {
            if(input.type === 'date') {
                input.value = '';
            } else if(input.type === 'text') {
                input.value = (input.name.includes('value') || input.name.includes('tax') || input.id === 'taxable_income' || input.id === 'income_tax' || input.id === 'tax_to_pay' || input.id === 'total_tax') ? '0' : '';
            }
        });
        
        // 🎯 ရှင်းလင်းရေး အားလုံးပြီးဆုံးသွားချိန်တွင် Header ဒေတာများကို အမိန့်ပေး၍ အပြီးသတ် ပြန်လည်ရိုက်ထည့်ခြင်း
        assignHeaderData();
        
    }, 150); // 150ms စောင့်ပြီး အလုပ်လုပ်ပါသည်
});
</script>
<script>
document.getElementById('business_type').addEventListener('change', function() {
    var businessType = this.value;
    
    // Label tag များကို လှမ်းယူခြင်း
    var lblPlateNo = document.getElementById('lbl_plate_no');
    var lblManufacture = document.getElementById('lbl_manufacture');
    var lblBrandName = document.getElementById('lbl_brand_name');
    var lblChassi = document.getElementById('lbl_chassi');
    var lblBuild_type = document.getElementById('lbl_build_type');
    var lblMakeYear = document.getElementById('lbl_make_year');
    var lblProposal_value = document.getElementById('lbl_proposal_value');
    var lblValuation_valuer = document.getElementById('lbl_valuation_value');
    var lblSale_date = document.getElementById('lbl_sale_date');

    if (businessType === 'ရေယာဉ်ဝယ်ယူခြင်း') {
        // ၁။ ရေယာဉ် ဝယ်ယူခြင်း အတွက်
        lblPlateNo.innerText = 'ရေယာဉ်မှတ်ပုံတင်အမှတ်';
        lblManufacture.innerText = 'ရေယာဉ်အမည်';
        lblBrandName.innerText = 'အတိုင်းအတာ(အလျားxအနံxအနက်)';
        lblChassi.innerText = 'စက်အမျိုးအစား(Engine Power)';
        lblBuild_type.innerText = 'သံခွံ/သစ်သားခွံ';
        lblMakeYear.innerText = 'စုစုပေါင်းတန်ချိန်/ကုန်တင်တန်ချိန်';
        lblSale_date.innerText = 'ရေယာဉ်ဝယ်ယူ/တည်ဆောက်သည့်နေ့';
        lblProposal_value.innerText = 'တင်ပြရေယာဉ်အဝယ်တန်ဖိုး';
        lblValuation_valuer.innerText = 'သတ်မှတ်ရေယာဉ်အဝယ်တန်ဖိုး';

    } else if (businessType === 'ရေယာဉ်ရောင်းချခြင်း') {
        // ၂။ ရေယာဉ် ရောင်းချခြင်း အတွက်
        lblPlateNo.innerText = 'ရေယာဉ်မှတ်ပုံတင်အမှတ်';
        lblManufacture.innerText = 'ရေယာဉ်အမည်';
        lblBrandName.innerText = 'အတိုင်းအတာ(အလျားxအနံxအနက်)';
        lblChassi.innerText = 'စက်အမျိုးအစား(Engine Power)';
        lblBuild_type.innerText = 'သံခွံ/သစ်သားခွံ';
        lblMakeYear.innerText = 'စုစုပေါင်းတန်ချိန်/ကုန်တင်တန်ချိန်';
        lblSale_date.innerText = 'ရေယာဉ်ဝယ်ယူ/တည်ဆောက်သည့်နေ့';
        lblProposal_value.innerText = 'တင်ပြရေယာဉ်အရောင်းတန်ဖိုး';
        lblValuation_valuer.innerText = 'သတ်မှတ်ရေယာဉ်အရောင်းတန်ဖိုး';

    } else if (businessType === 'မော်တော်ယာဉ်ရောင်းချခြင်း') {
        // ၃။ မော်တော်ယာဉ် ရောင်းချခြင်း အတွက်
        lblPlateNo.innerText = 'ယာဉ်နံပါတ်';
        lblManufacture.innerText = 'ယာဉ်အမျိုးအမည်(Manufacture)';
        lblBrandName.innerText = 'ယာဉ်အမျိုးအစား(Brand Name)';
        lblChassi.innerText = 'ဘောင်အမှတ်(Chassi)';
        lblBuild_type.innerText = 'တည်ဆောက်ပုံ(Build Type)';
        lblMakeYear.innerText = 'ထုတ်လုပ်သည့်ခုနှစ်(Make Year)';
        lblSale_date.innerText =  'မော်တော်ယာဉ်ဝယ်ယူသည့်နေ့';
        lblProposal_value.innerText = 'တင်ပြသည့်ယာဉ်အရောင်းတန်ဖိုး';
        lblValuation_valuer.innerText = 'သတ်မှတ်ယာဉ်အရောင်းတန်ဖိုး';

    } else {
        // ၄။ မော်တော်ယာဉ် ဝယ်ယူခြင်း (သို့မဟုတ် အခြား default အခြေအနေ) အတွက်
        lblPlateNo.innerText = 'ယာဉ်နံပါတ်';
        lblManufacture.innerText = 'ယာဉ်အမျိုးအမည်(Manufacture)';
        lblBrandName.innerText = 'ယာဉ်အမျိုးအစား(Brand Name)';
        lblChassi.innerText = 'ဘောင်အမှတ်(Chassi)';
        lblBuild_type.innerText = 'တည်ဆောက်ပုံ(Build Type)';
        lblMakeYear.innerText = 'ထုတ်လုပ်သည့်ခုနှစ်(Make Year)';
        lblSale_date.innerText = 'မော်တော်ယာဉ်ဝယ်ယူသည့်နေ့';
        lblProposal_value.innerText = 'တင်ပြသည့်ယာဉ်အဝယ်တန်ဖိုး';
        lblValuation_valuer.innerText = 'သတ်မှတ်ယာဉ်အဝယ်တန်ဖိုး';
    }
});

// စာမျက်နှာ စဖွင့်ချိန် (Page Load) တွင်လည်း သတ်မှတ်ချက်အတိုင်း ကိုက်ညီစေရန် တစ်ကြိမ် Run ပေးခြင်း
document.getElementById('business_type').dispatchEvent(new Event('change'));
</script>
<?php endif; ?>

</body>
</html>