<?php
$servername = "127.0.0.1"; // localhost အစား ဒါကို သုံးကြည့်ပါ
$username = "root";
$password = "Kyawaungmoe1972@"; // အကယ်၍ password ရှိရင် ဒီမှာ ထည့်ပါ
$dbname = "tax_system";

// Connection တည်ဆောက်ခြင်း
$conn = new mysqli($servername, $username, $password, $dbname);

// Error စစ်ဆေးခြင်း
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");
?>