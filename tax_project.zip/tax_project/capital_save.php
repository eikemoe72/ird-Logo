<?php
include 'db_config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start(); 
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // ၄။ HTML Form က ပို့လိုက်သော name="id" ကို ကျိန်းသေဖမ်းယူခြင်း
    $edit_id = !empty($_POST['id']) ? intval($_POST['id']) : null;

    // စာသားအချက်အလက်များ
    $case_number   = mysqli_real_escape_string($conn, $_POST['case_number'] ?? '');
    $tax_year      = mysqli_real_escape_string($conn, $_POST['tax_year'] ?? '');
    $officer_name  = mysqli_real_escape_string($conn, $_POST['officer_name'] ?? '');
    $region        = mysqli_real_escape_string($conn, $_POST['region'] ?? '');
    
    // 🎯 ✅ ပြင်ဆင်ချက် - $_SESSION အစား housing_form.php က ပို့လိုက်သော Form $_POST ဒေတာများဖြင့် တိုက်ရိုက်ပြောင်းလဲဖမ်းယူခြင်း
    $state_name    = mysqli_real_escape_string($conn, $_POST['state_name'] ?? ''); 
    $township_name = mysqli_real_escape_string($conn, $_POST['township_name'] ?? ''); 
    
    // $_POST ကလာတဲ့ တန်ဖိုးတွေကို အကာအကွယ်ဖြင့် သေချက်ဖမ်းယူခြင်း
    $officer_rank = mysqli_real_escape_string($conn, $_POST['officer_rank'] ?? $_POST['rank_'] ?? '');

    // 💡 (ပြီးခဲ့တဲ့အဆင့်က တက်ခဲ့တဲ့ Data too long Error ကို ကာကွယ်ရန် စာလုံးရေ ၃၀ သာ အမြင့်ဆုံး ဖြတ်သိမ်းမည့်စနစ်)
    $officer_rank = mb_substr(trim($officer_rank), 0, 30, 'UTF-8');

    $taxpayer_name = mysqli_real_escape_string($conn, $_POST['taxpayer_name'] ?? '');
    $nrc_no        = mysqli_real_escape_string($conn, $_POST['nrc_no'] ?? ''); 
    $gir_type      = mysqli_real_escape_string($conn, $_POST['gir_type'] ?? '');
    $gir_no        = mysqli_real_escape_string($conn, $_POST['gir_no'] ?? '');
    $address       = mysqli_real_escape_string($conn, $_POST['address'] ?? '');
    $business_type = mysqli_real_escape_string($conn, $_POST['business_type'] ?? '');
    $land_type     = mysqli_real_escape_string($conn, $_POST['land_type'] ?? '');
    $block_no      = mysqli_real_escape_string($conn, $_POST['block_no'] ?? '');
    $holding_no    = mysqli_real_escape_string($conn, $_POST['holding_no'] ?? '');
    $city          = mysqli_real_escape_string($conn, $_POST['city'] ?? '');
    $road          = mysqli_real_escape_string($conn, $_POST['road'] ?? '');
    $area          = mysqli_real_escape_string($conn, $_POST['area'] ?? '');
    $building_type = mysqli_real_escape_string($conn, $_POST['building_type'] ?? '');
    $building_height = mysqli_real_escape_string($conn, $_POST['building_height'] ?? '');
    $municipal_no  = mysqli_real_escape_string($conn, $_POST['municipal_no'] ?? '');
    $tasapha_no    = mysqli_real_escape_string($conn, $_POST['tasapha_no'] ?? '');
    $chalan_no     = mysqli_real_escape_string($conn, $_POST['chalan_no'] ?? '');
    $it_demand_no  = mysqli_real_escape_string($conn, $_POST['it_demand_no'] ?? '');
    $remark        = mysqli_real_escape_string($conn, $_POST['remark'] ?? '');
    
    // 🌟 🌟 🌟 [ပြင်ဆင်ချက်] remark2 အား User Login ဆွဲပြီး user_register Table ထဲမှ သိမ်းဆည်းခြင်း Logic 🌟 🌟 🌟
    $remark2 = ''; // Default အလွတ်သတ်မှတ်ချက်
    $session_user = $_SESSION['user_id'] ?? $_SESSION['username'] ?? '';

    if (!empty($session_user)) {
        // 💡 အစ်ကိုကြီး စိတ်ကြိုက်ပြောင်းလဲနိုင်ရန် ဆွဲထုတ်မည့် ဥပမာ Column များကို ရေးပေးထားပါတယ်ဗျာ။
        // (ဥပမာ - name သို့မဟုတ် rank သို့မဟုတ် အစ်ကိုကြီး သိမ်းချင်တဲ့ Column တစ်ခုခုကို ပြောင်းထည့်နိုင်ပါတယ်)
        $user_stmt = $conn->prepare("SELECT other, md_no FROM user_register WHERE id = ? LIMIT 1");
        if ($user_stmt) {
            $user_stmt->bind_param("s", $session_user);
            $user_stmt->execute();
            $user_res = $user_stmt->get_result();
            if ($user_res && $user_res->num_rows > 0) {
                $user_row = $user_res->fetch_assoc();
                
                // 🎯 ဤနေရာတွင် အစ်ကိုကြီး သိမ်းချင်သော Column အချက်အလက်ကို remark2 ထဲသို့ ထည့်သွင်းပါမည်။
                // လက်ရှိ ဥပမာတွင် user ရဲ့ 'name' (အမည်) ကို သိမ်းခိုင်းထားပါတယ် အစ်ကိုကြီး။
                if (!empty($user_row['other'])) {
                    $remark2 = mysqli_real_escape_string($conn, $user_row['other']);
                }
            }
            $user_stmt->close();
        }
    }
    // Form က ပို့လာတဲ့ remark2 ရှိနေပြီး Login ထဲကဟာ မရခဲ့ရင် Form ဟာပဲ သုံးဖို့ Back up ခံထားခြင်း
    if (empty($remark2)) {
        $remark2 = mysqli_real_escape_string($conn, $_POST['remark2'] ?? '');
    }

    $source_of_income = mysqli_real_escape_string($conn, $_POST['source_of_income'] ?? '');
    $investigation = mysqli_real_escape_string($conn, $_POST['investigation'] ?? '');

    // 🎯 ရက်စွဲများအတွက် ပိုမိုစိတ်ချရသော Helper Function (Quote ပါတစ်ခါတည်း ရှင်းပေးမည့်စနစ်)
    function formatDateForSQL($conn, $value) {
        $trimmed = trim($value);
        if (empty($trimmed) || $trimmed === '-/-/-' || $trimmed === '0000-00-00') {
            return "NULL";
        }
        return "'" . mysqli_real_escape_string($conn, $trimmed) . "'";
    }

    $permit_date            = formatDateForSQL($conn, $_POST['permit_date'] ?? '');
    $purchase_date          = formatDateForSQL($conn, $_POST['purchase_date'] ?? '');
    $assessment_submit_date = formatDateForSQL($conn, $_POST['assessment_submit_date'] ?? '');
    $tasapha_date           = formatDateForSQL($conn, $_POST['tasapha_date'] ?? ''); 
    $chalan_date            = formatDateForSQL($conn, $_POST['chalan_date'] ?? '');
    $notified_date          = formatDateForSQL($conn, $_POST['notified_date'] ?? '');
    $appointment_date       = formatDateForSQL($conn, $_POST['appointment_date'] ?? '');
    $appearance_date        = formatDateForSQL($conn, $_POST['appearance_date'] ?? '');
    $it_demand_date         = formatDateForSQL($conn, $_POST['it_demand_date'] ?? '');

    // ကိန်းဂဏန်းများသန့်စင်ခြင်း
    function cleanNumber($val) {
        $clean = preg_replace('/[^\d.]/', '', $val);
        return (empty($clean)) ? 0 : floatval($clean);
    }

    $declared_value     = cleanNumber($_POST['declared_value'] ?? 0);
    $valuation_value    = cleanNumber($_POST['valuation_value'] ?? 0);
    $allowable_expenses = cleanNumber($_POST['allowable_expenses'] ?? 0);
    $taxable_income     = cleanNumber($_POST['taxable_income'] ?? 0);
    $income_tax         = cleanNumber($_POST['income_tax'] ?? 0);
    $advance_tax        = cleanNumber($_POST['advance_tax'] ?? 0);
    $tax_to_pay         = cleanNumber($_POST['tax_to_pay'] ?? 0);
    $penalty_tax        = cleanNumber($_POST['penalty_tax'] ?? 0);
    $total_tax          = cleanNumber($_POST['total_tax'] ?? 0);
    $paid_amount        = cleanNumber($_POST['paid_amount'] ?? 0);

    // ၅။ $edit_id ကိန်းဂဏန်းအခြေအနေအပေါ်မူတည်ပြီး ခွဲခြားခြင်း
    if ($edit_id === null || $edit_id <= 0) {
        // INSERT MODE
        $sql = "INSERT INTO sakalakahdata (
            case_number, tax_year, officer_name, region, state_name, township_name, taxpayer_name, nrc_no,
            gir_type, gir_no, address, business_type, land_type, block_no, holding_no, city, road, area,
            building_type, building_height, municipal_no, permit_date, purchase_date, assessment_submit_date, 
            tasapha_no, tasapha_date, declared_value, valuation_value, allowable_expenses, taxable_income, 
            income_tax, advance_tax, tax_to_pay, penalty_tax, total_tax, paid_amount, chalan_no, chalan_date, 
            notified_date, appointment_date, appearance_date, it_demand_no, it_demand_date, officer_rank, remark2, 
            source_of_income, investigation
        ) VALUES (
            '$case_number', '$tax_year', '$officer_name', '$region', '$state_name', '$township_name', '$taxpayer_name', '$nrc_no',
            '$gir_type', '$gir_no', '$address', '$business_type', '$land_type', '$block_no', '$holding_no', '$city', '$road', '$area',
            '$building_type', '$building_height', '$municipal_no', $permit_date, $purchase_date, $assessment_submit_date, 
            '$tasapha_no', $tasapha_date, '$declared_value', '$valuation_value', '$allowable_expenses', '$taxable_income', 
            '$income_tax', '$advance_tax', '$tax_to_pay', '$penalty_tax', '$total_tax', '$paid_amount', '$chalan_no', $chalan_date, 
            $notified_date, $appointment_date, $appearance_date, '$it_demand_no', $it_demand_date, '$officer_rank', '$remark2', 
            '$source_of_income', '$investigation'
        )";
        $msg = "အချက်အလက်အသစ်ကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ။";
    } else {
        // UPDATE MODE
        $sql = "UPDATE sakalakahdata SET 
                    case_number='$case_number', 
                    tax_year='$tax_year',  
                    officer_name='$officer_name', 
                    region='$region',  
                    state_name='$state_name',
                    township_name='$township_name', 
                    taxpayer_name='$taxpayer_name', 
                    nrc_no='$nrc_no',
                    gir_type='$gir_type',
                    gir_no='$gir_no', 
                    address='$address', 
                    business_type='$business_type', 
                    land_type='$land_type', 
                    block_no='$block_no', 
                    holding_no='$holding_no', 
                    city='$city',
                    road='$road', 
                    area='$area',
                    building_type='$building_type',
                    building_height='$building_height',
                    municipal_no='$municipal_no', 
                    permit_date=$permit_date, 
                    purchase_date=$purchase_date, 
                    assessment_submit_date=$assessment_submit_date,
                    tasapha_no='$tasapha_no',
                    tasapha_date=$tasapha_date,
                    declared_value='$declared_value', 
                    valuation_value='$valuation_value', 
                    allowable_expenses='$allowable_expenses',
                    taxable_income='$taxable_income',
                    income_tax='$income_tax',
                    advance_tax='$advance_tax', 
                    tax_to_pay='$tax_to_pay',
                    penalty_tax='$penalty_tax', 
                    total_tax='$total_tax', 
                    paid_amount='$paid_amount', 
                    chalan_no='$chalan_no', 
                    chalan_date=$chalan_date,
                    notified_date=$notified_date, 
                    appointment_date=$appointment_date,
                    appearance_date=$appearance_date, 
                    it_demand_no='$it_demand_no',
                    it_demand_date=$it_demand_date,
                    officer_rank='$officer_rank',
                    remark2='$remark2',
                    source_of_income='$source_of_income', 
                    investigation='$investigation'
                WHERE id = $edit_id";
        $msg = "အချက်အလက်များကို အောင်မြင်စွာ ပြင်ဆင်ပြီးပါပြီ။";
    }

    // Query ကို Run ခြင်း
    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('$msg');
                window.location.href = 'capital_demand_list.php'; 
              </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>