<?php
header('Content-Type: application/json');
include 'db_config.php';

$min = intval($_GET['min_case'] ?? 0);
$max = intval($_GET['max_case'] ?? 0);

$sql = "SELECT * FROM sakalakahdata 
        WHERE CAST(SUBSTRING_INDEX(case_number, '/', 1) AS UNSIGNED) BETWEEN $min AND $max";

$result = $conn->query($sql);
$data = [];

if ($result) {
    while($row = $result->fetch_assoc()) {
        // JavaScript ဘက်က မျှော်လင့်ထားတဲ့ Key တွေနဲ့ ကိုက်အောင် အဓိက field တွေကို စုစည်းပါ
        $data[] = [
            'case_number' => $row['case_number'],
            'tax_year' => $row['tax_year'],
            'officer_name' => $row['officer_name'],
            'region' => $row['region'],
            'state_name' => $row['state_name'],
            'township_name' => $row['township_name'],
            'taxpayer_name' => $row['taxpayer_name'],
            'nrc_no' => $row['nrc_no'],
            'gir_type' => $row['gir_type'],
            'gir_no' => $row['gir_no'],
            'address' => $row['address'],
            'business_type' => $row['business_type'],
            'land_type' => $row['land_type'],
            'block_no' => $row['block_no'],
            'holding_no' => $row['holding_no'],
            'city' => $row['city'],
            'road' => $row['road'],
            'area' => $row['area'],
            'building_type' => $row['building_type'],
          
            'valuation_value' => $row['valuation_value'],
            'allowable_expenses' => $row['allowable_expenses'], 
            'taxable_income' => $row['taxable_income'],
            'income_tax' => $row['income_tax'],
            'advance_tax' => $row['advance_tax'],
            'tax_to_pay' => $row['tax_to_pay'],
            'penalty_tax' => $row['penalty_tax'],
            'total_tax' => $row['total_tax']
         
        ];
    }
}
echo json_encode($data);
?>