<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ DB Config ချိတ်ဆက်ခြင်း (မူလအတိုင်း ထားရှိပါသည်)
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// ၁။ Database Connection ချိတ်ဆက်ခြင်း (ဒါ ကွက်တိ မှန်သွားပါပြီ)
//$conn = new mysqli("localhost", "root", "", "sakalakahdata");

// ၂။ URL ကနေ id ကို လှမ်းယူခြင်း
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$taxpayer_name = "";
$business_type = "";
$address = "";

if ($id > 0) {
    // 🎯 ၃။ ဇယားအမည်ကို 'taxpayers_table' အစား 'sakalakahdata' သို့ ပြောင်းလဲထားပါသည်
    $sql = "SELECT taxpayer_name, business_type, address FROM vehicledata WHERE id = $id";
    $result = $conn->query($sql);
    
    if ($result && $row = $result->fetch_assoc()) {
        $taxpayer_name = $row['taxpayer_name'];
        $business_type = $row['business_type'];
        $address = $row['address'];
    }
}
?>

<style>
    /* Modal Layout ပိုင်း သန့်စင်ခြင်း */
    #sharegeneral2Modal .modal-dialog {
        max-width: 820px !important; 
        width: 95% !important;
        margin: 20px auto !important;
    }

    #sharegeneral2Modal .modal-content {
        background-color: #9ecaeb !important; 
        border: 1.5px solid #404446 !important;
        border-radius: 6px !important;
        overflow: hidden !important;
    }

    #sharegeneral2Modal .modal-body {
        padding: 15px !important; 
        display: flex !important;
        flex-direction: column !important;
        align-items: center !important; 
    }

    /* 🎯 စာရွက်ပုံစံ Container (A4 Size အချိုးအစား ကွက်တိဖြစ်စေရန်) */
    .print-container { 
        background: #ffffff !important;
        width: 100% !important;
        max-width: 210mm !important; 
        min-height: 297mm !important; 
        padding: 10mm 15mm !important; 
        box-sizing: border-box !important; 
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
        display: flex !important;
        flex-direction: column !important;
        justify-content: space-between !important; 
    }

    /* 🎯 အပေါ်/အောက် ဖြတ်ပိုင်းတစ်ခုချင်းစီ၏ ဘောင်ခတ်မှု */
    .outer-border-box {
        border: 2px solid #000000 !important;
        padding: 15px 20px !important; 
        box-sizing: border-box !important;
        width: 100% !important;
        height: 132mm !important; 
        position: relative !important;
    }

    /* ဇယားများဆိုင်ရာ Style */
    .inner-data-table {
        width: 100% !important;
        border-collapse: collapse !important;
        font-family: "Pyidaungsu", "Segoe UI" !important;
        font-size: 14px !important;
    }

    .inner-data-table td {
        padding: 4px 3px !important;
        vertical-align: middle !important;
    }

    /* အောက်ခြေ လက်မှတ်ဇယားကွက် */
    .signature-table {
        width: 100% !important;
        border-collapse: collapse !important;
    }

    .signature-table td {
        padding: 3px !important;
    }

    /* 🎯 စာသားအောက်က အစက်လိုင်း (...) သတ်မှတ်ချက် */
    .under-line2 { 
        border-bottom: 1.5px dotted #121212 !important; 
        display: inline-block !important; 
        min-width: 100% !important;
        padding-left: 5px !important;
    }

    /* 🎯 Header ကို ဘယ်/ညာ ခွဲထုတ်ပစ်မည့် စနစ် */
    .modal-header {
        display: flex;
        justify-content: space-between; /* 👈 ခေါင်းစဉ်ကို ဘယ်ထားပြီး ခလုတ်ကို ညာဘက်အစွန်ဆုံး တွန်းထုတ်ပေးပါတယ် */
        align-items: center;            /* 👈 တစ်တန်းတည်း အလယ်ကွက်တိ ဖြစ်အောင် ညှိပေးပါတယ် */
        width: 100%;
        padding: 10px 15px;             /* ဘေးပတ်ပတ်လည် Space ချန်ခြင်း */
        box-sizing: border-box;
    }

    /* 🎯 Close Button (×) ဒီဇိုင်း ပြင်ဆင်ခြင်း */
    .custom-close-btn {
        background: none;
        border: none;
        font-size: 28px;               /* စာလုံးအရွယ်အစား */
        font-weight: bold;
        color: #555;                   /* အရောင် */
        cursor: pointer;               /* မောက်စ်တင်ရင် လက်ညှိုးပုံပြောင်းရန် */
        padding: 0 5px;
        line-height: 1;
        transition: color 0.2s ease;
    }

    /* မောက်စ်တင်လိုက်ရင် အရောင်အနီပြောင်းပေးမည့် Effect (မကြိုက်က ဖြုတ်နိုင်ပါတယ်) */
    .custom-close-btn:hover {
        color: #f44336; 
    }

    /* 🎯 အောက်ခြေ Footer ကို ညာဘက်အစွန်ဆုံး ကပ်မည့်စနစ် */
.modal-footer {
    display: block;               /* WeasyPrint/Standard Flow တွဲဖက်ညီစေရန် */
    text-align: right;            /* 👈 ခလုတ်များကို ညာဘက်အစွန်ဆုံးသို့ ကပ်ထုတ်ပေးခြင်း */
    padding: 15px 24px;           /* ဘေးပတ်ပတ်လည် Space အကွာအဝေး */
    background-color: #f8fafc;    /* Footer နောက်ခံကို အဝါနု/မီးခိုးနုရောင် သန့်သန့်လေးခံခြင်း */
    border-top: 1px solid #e2e8f0;/* အပေါ်ဘောင်လိုင်းတားခြင်း */
    width: 100%;
    box-sizing: border-box;
}

/* 🎯 ခလုတ်များ၏ အခြေခံဒီဇိုင်း (Common Styles) */
.btn-print-custom, .btn-close-custom {
    display: inline-block;
    padding: 10px 22px;
    font-size: 14px;
    font-weight: 500;
    font-family: inherit;
    border-radius: 6px;           /* ခလုတ်ဒေါင့်များကို အနည်းငယ်ဝိုင်းစေခြင်း */
    border: none;
    cursor: pointer;
    margin-left: 10px;            /* ခလုတ်နှစ်ခုကြား အကွာအဝေးချန်ခြင်း */
    box-shadow: 0 2px 4px rgba(0,0,0,0.05); /* အောက်ခြေ အရိပ်အနည်းငယ်ထည့်ခြင်း */
    transition: all 0.2s ease;
}

/* 🔵 "Print ထုတ်မည်" ခလုတ်ဒီဇိုင်း (Muted Deep Blue) */
.btn-print-custom {
    background-color: #1e3a8a;    /* အခွန်ဌာနသုံး သပ်ရပ်သော နက်ပြာရောင် */
    color: #ffffff;
}

/* မောက်စ်တင်လိုက်ရင် ပြောင်းလဲမည့် Effect */
.btn-print-custom:hover {
    background-color: #1d4ed8;    /* အပြာရောင် အနည်းငယ်လင်းစေခြင်း */
    box-shadow: 0 4px 6px rgba(29, 78, 216, 0.2);
}

/* ⚪ "ပိတ်မည်" ခလုတ်ဒီဇိုင်း (Elegant Warm Slate) */
.btn-close-custom {
    background-color: #64748b;    /* မျက်စိမနောက်စေမည့် Slate Gray အရောင် */
    color: #ffffff;
}

/* မောက်စ်တင်လိုက်ရင် ပြောင်းလဲမည့် Effect */
.btn-close-custom:hover {
    background-color: #475569;    /* ရင့်မှောင်သောအရောင်သို့ ပြောင်းလဲခြင်း */
    box-shadow: 0 4px 6px rgba(71, 85, 105, 0.2);
}


    /* ===== 🎯 ၂။ PRINT ထုတ်သည့်အခါ Layout အတိုင်း A4 Portrait ကွက်တိဖြစ်စေမည့် CSS ===== */
    @media print {
        @page {
            size: A4 portrait !important; 
            margin: 0 !important; /* Browser ရဲ့ default margin များကို သုညချသည် */
        }

        /* ပရင့်ထုတ်ချိန်တွင် Web Layout များနှင့် မသက်ဆိုင်သည်များကို ဖျောက်သည် */
        body {
            background: #ffffff !important;
            margin: 15 !important;
            padding-left: 30px !important;
            padding: 20px !important;
          
        }

        .modal-backdrop {
            display: none !important;
        }

        /* Modal Background နှင့် ဘောင်များကို ဖျောက်၍ Printable Container ကိုပဲ တင်မည် */
        #sharegeneral2Modal, #sharegeneral2Modal,
        .modal-dialog, .modal-content, .modal-body {
            position: static !important;
            width: 100% !important;
            max-width: 100% !important;
            height: auto !important;
            margin: 0 !important;
            padding: 0 !important;
            background: transparent !important;
            border: none !important;
            box-shadow: none !important;
            gap: 10px !important;
        }

        /* 🎯 Layout View အတိုင်း အပေါ်အောက် ကွက်တိ စာရွက်တစ်ရွက်တည်း ထွက်စေရန် */
        #sharePrintableSheet {
            position: absolute !important;
            left: 45mm !important;        /* 👈 စာရွက်၏ ဘယ်ဘက်မှ ကွက်တိ ကပ်ရန် */
            top: 15mm !important;         /* 👈 စာရွက်၏ အပေါ်ဘက်မှ စတင်ရန် */
            width: 165mm !important;       /* 👈 ဘရောက်ဆာရဲ့ scale ကြောင့် ဘေးကားမထွက်အောင် တင်းတင်းကျပ်ကျပ် ထိန်းသည် */
            height: 275mm !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
            box-sizing: border-box !important;
            display: flex !important;
            flex-direction: column !important;
            justify-content: space-between !important;
        }

        /* ပရင့်ထဲတွင် ဘောင်များ ကွက်တိပေါ်ပြီး စာရွက်မပြတ်စေရန် */
        .outer-border-box {
            height: 145mm !important;
            max-height: 135mm !important;
            border: 1.5px solid #000000 !important;
            page-break-inside: avoid !important;
        }

        .no-print, .modal-header, .modal-footer {
            display: none !important;
        }
    }
</style>

<div class="modal fade" id="sharegeneral2Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h3 class="modal-title">အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း ထုတ်ယူရန်</h3>
                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            
            <div class="modal-body">
                <div class="print-container" id="sharePrintableSheet">
                    
                    <div class="outer-border-box">
                        <div style="text-align: right; font-size: 14px; font-family: 'Pyidaungsu'; margin-bottom: 5px;">
                            ပတခ(ထွေ)-၂
                        </div>
                        <div style="text-align: center; font-weight: bold; font-size: 18px; font-family: 'Pyidaungsu'; margin-bottom: 20px;">
                            အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                        </div>
                        
                        <table class="inner-data-table">
                            <tr>
                                <td>အခွန်ထမ်းအမည်</td>
                                <td>-</td>
                                <td style="font-weight: bold;" class="under-line2"><?php echo htmlspecialchars($taxpayer_name); ?></td>
                            </tr>
                            <tr>
                                <td>လုပ်ငန်းအမျိုးအစား</td>
                                <td>-</td>
                                <td style="font-weight: bold;" class="under-line2"><?php echo htmlspecialchars($business_type); ?></td>
                            </tr>
                            <tr>
                                <td>အခွန်ထမ်းလိပ်စာ</td>
                                <td>-</td>
                                <td style="font-weight: bold;" class="under-line2"><?php echo htmlspecialchars($address); ?></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align: center; font-weight: bold; padding: 15px 0 !important; font-size: 14px;">
                                    လက်ခံရရှိပါသည်။
                                </td>
                            </tr>
                            <tr>
                                <td>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ကသခ)-၀၄-၀၈/ ပတခ(ကသခ)-၀၂-၀၁</span>
                                </td>
                            </tr>
                            <tr>
                                <td>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ဝင)-၀၄-၀၈ / ပတခ(ဝင)-၀၂-၀၁(ခ)</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အခြားအကြောင်းကြားစာများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">&ensp;</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td style="padding-top: 10px !important;">
                                    <table class="signature-table">
                                        <tr>
                                            <td style="width: 30%; text-align: right; padding-right: 15px;">လက်မှတ်</td>
                                            <td style="width: 70%; border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">အမည်</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">ရက်စွဲ</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                    <br><br>
                    <div class="outer-border-box">
                        <div style="text-align: right; font-size: 14px; font-family: 'Pyidaungsu'; margin-bottom: 5px;">
                            ပတခ(ထွေ)-၂
                        </div>
                        <div style="text-align: center; font-weight: bold; font-size: 18px; font-family: 'Pyidaungsu'; margin-bottom: 20px;">
                            အကြောင်းကြားစာ ချအပ်ခြင်းဆိုင်ရာ လက်ခံဖြတ်ပိုင်း
                        </div>
                        
                        <table class="inner-data-table">
                            <tr>
                                <td>အခွန်ထမ်းအမည်</td>
                                <td>-</td>
                                <td style="font-weight: bold;" class="under-line2"><?php echo htmlspecialchars($taxpayer_name); ?></td>
                            </tr>
                            <tr>
                                <td>လုပ်ငန်းအမျိုးအစား</td>
                                <td>-</td>
                                <td style="font-weight: bold;" class="under-line2"><?php echo htmlspecialchars($business_type); ?></td>
                            </tr>
                            <tr>
                                <td>အခွန်ထမ်းလိပ်စာ</td>
                                <td>-</td>
                                <td style="font-weight: bold;" class="under-line2"><?php echo htmlspecialchars($address); ?></td>
                            </tr>
                            <tr>
                                <td colspan="3" style="text-align: center; font-weight: bold; padding: 15px 0 !important; font-size: 14px;">
                                    လက်ခံရရှိပါသည်။
                                </td>
                            </tr>
                            <tr>
                                <td>ချအပ်သည့် ကုန်သွယ်လုပ်ငန်းခွန်/</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ကသခ)-၀၄-၀၈/ ပတခ(ကသခ)-၀၂-၀၁</span>
                                </td>
                            </tr>
                            <tr>
                                <td>ဝင်ငွေခွန်ဆိုင်ရာပုံစံများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">ပတခ(ဝင)-၀၄-၀၈ / ပတခ(ဝင)-၀၂-၀၁(ခ)</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အခြားအကြောင်းကြားစာများ</td>
                                <td style="text-align: center;">-</td>
                                <td>
                                    <span class="under-line2">&ensp;</span>
                                </td>
                            </tr>
                            <tr>
                                <td>အကြောင်းကြားစာ လက်ခံရရှိသူ</td>
                                <td style="text-align: center;">-</td>
                                <td><span class="under-line2">&ensp;</span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td style="padding-top: 10px !important;">
                                    <table class="signature-table">
                                        <tr>
                                            <td style="width: 30%; text-align: right; padding-right: 15px;">လက်မှတ်</td>
                                            <td style="width: 70%; border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">အမည်</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                        <tr>
                                            <td style="text-align: right; padding-right: 15px;">ရက်စွဲ</td>
                                            <td style="border-bottom: 1.5px dotted black;"></td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                    
                </div>
            </div>
            
            <div class="modal-footer no-print">
                <button type="button" class="btn-print-custom" onclick="printShareReceiptOnly()">Print ထုတ်မည်</button>
                <button type="button" class="btn-close-custom" onclick="closeAndReturnToDemandList()">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>


function printShareReceiptOnly() {
    const printContent = document.getElementById('sharePrintableSheet').innerHTML;
    const originalContent = document.body.innerHTML;
    
    document.body.innerHTML = printContent;
    
    window.print();
    
    document.body.innerHTML = originalContent;
    window.location.reload();
}
function closeAndReturnToDemandList() {
    // 🎯 ခလုတ်နှိပ်လိုက်တာနဲ့ မူလ ဇယားစာမျက်နှာကြီးဆီကို တိုက်ရိုက် ပြန်မောင်းနှင်ပေးမည့် ကုဒ်ဖြစ်ပါတယ်
    window.location.href = '../vehicle_demand_list.php';
}
</script>