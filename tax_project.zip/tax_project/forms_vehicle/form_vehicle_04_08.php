<?php
// ၁။ ⚠️ Error များကို Screen ပေါ်တွင် တိုက်ရိုက်ပြသရန် ဖွင့်လိုက်ပါသည် (Debug လုပ်ရန်)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    $query = "SELECT * FROM vehicledata WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း
$os_year      = htmlspecialchars($db_data['tax_year'] ?? '-');
$startYear = '-';
$endYear   = '-';
if (!empty($os_year) && strpos($os_year, '-') !== false) {
    $years_array = explode('-', $os_year);
    $startYear = trim($years_array[0]);
    $endYear   = trim($years_array[1]);
}
$os_officer   = htmlspecialchars($db_data['officer_name'] ?? '-');
$os_rank      = htmlspecialchars($db_data['officer_rank'] ?? '-');
$os_region    = htmlspecialchars($db_data['region'] ?? '');
$os_state_name  = htmlspecialchars($db_data['state_name'] ?? '-');
$os_township  = htmlspecialchars($db_data['township_name'] ?? '-');


$os_name      = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_nrc_no    = htmlspecialchars($db_data['nrc_no'] ?? '-');
$os_gir       = htmlspecialchars($db_data['gir_no'] ?? '-');
$os_gir_type  = htmlspecialchars($db_data['gir_type'] ?? '-');
$os_address   = htmlspecialchars($db_data['address'] ?? '-');

$os_biz       = htmlspecialchars($db_data['business_type'] ?? '-');

// (၄) မြေနှင့် အဆောက်အဦးဆိုင်ရာ အချက်အလက်များ
$os_plate_no        = htmlspecialchars($db_data['plate_no'] ?? '-');
$os_manufacture          = htmlspecialchars($db_data['manufacture'] ?? '-');
$os_brand_name        = htmlspecialchars($db_data['brand_name'] ?? '-');
$os_build_type          = htmlspecialchars($db_data['build_type'] ?? '-');
$os_chassi        = htmlspecialchars($db_data['chassi'] ?? '-');
$os_make_year          = htmlspecialchars($db_data['make_year'] ?? '-');

$os_sale_date = (!empty($db_data['sale_date']) && $db_data['sale_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['sale_date'])) 
    : '............';
$os_sale_date = htmlspecialchars($os_sale_date);

// ဒသမကိန်း .00 မပါဘဲ ကော်မာခတ်ပြီး ကိန်းပြည့်ထုတ်ရန်
$os_proposal_value    = number_format(floatval($db_data['proposal_value'] ?? 0), 0, '.', ',');
$os_valuation_value     = number_format(floatval($db_data['valuation_value'] ?? 0), 0, '.', ',');
$os_allowable_expenses  = number_format(floatval($db_data['allowable_expenses'] ?? 0), 0, '.', ',');
$os_taxable_income      = number_format(floatval($db_data['taxable_income'] ?? 0), 0, '.', ',');
$os_income_tax          = number_format(floatval($db_data['income_tax'] ?? 0), 0, '.', ',');
$os_advance_tax         = number_format(floatval($db_data['advance_tax'] ?? 0), 0, '.', ',');
$os_tax_to_pay          = number_format(floatval($db_data['tax_to_pay'] ?? 0), 0, '.', ',');
$os_penalty_tax         = number_format(floatval($db_data['penalty_tax'] ?? 0), 0, '.', ',');

// ဂဏန်းသက်သက် စာသားပြောင်းရာတွင် သုံးရန်အတွက် (ကော်မာ မပါသော ကိန်းပြည့်)
$raw_total_tax_int      = intval($db_data['total_tax'] ?? 0);
$os_total_tax           = number_format(floatval($db_data['total_tax'] ?? 0), 0, '.', ',');
$os_paid_amount         = number_format(floatval($db_data['paid_amount'] ?? 0), 0, '.', ',');

// ၅။ user_register table မှ Login user ၏ md_no ကို ရှာဖွေဆွဲထုတ်ခြင်း
$os_md_no = '............'; 
$login_user_key = $_SESSION['user_id'] ?? $_SESSION['username'] ?? ''; 

if (!empty($login_user_key)) {
    $login_user_key = $conn->real_escape_string($login_user_key);
    // username နေရာတွင် id တစ်ခုတည်းဖြင့်သာ စစ်ဆေးရန် ပြင်ဆင်ထားပါသည်
    $u_query = "SELECT md_no , bank_township FROM user_register WHERE id = '$login_user_key' LIMIT 1";
    $u_result = $conn->query($u_query);
    if ($u_result && $u_result->num_rows > 0) {
        $u_data = $u_result->fetch_assoc();
        $os_md_no = htmlspecialchars($u_data['md_no'] ?? '............');
        $os_bank_township = htmlspecialchars($u_data['bank_township'] ?? '............');
    }
}

$os_bank_township       = htmlspecialchars($db_data['bank_township'] ?? '............');
$os_chalan_no           = htmlspecialchars($db_data['chalan_no'] ?? '......');
$os_chalan_date         = htmlspecialchars($db_data['chalan_date'] ?? '............');
$os_notified_date       = htmlspecialchars($db_data['notified_date'] ?? '............');
$os_appointment_date    = htmlspecialchars($db_data['appointment_date'] ?? '............');
$os_appearance_date     = htmlspecialchars($db_data['appearance_date'] ?? '............');

$os_itDemandNo          = htmlspecialchars($db_data['it_demand_no'] ?? '......');
$os_itDemandDate        = htmlspecialchars($db_data['it_demand_date'] ?? '............');


$os_investigation_value = htmlspecialchars($db_data['investigation_value'] ?? '......');
$os_source_of_income    = htmlspecialchars($db_data['source_of_income'] ?? '............');
$os_investigation       = htmlspecialchars($db_data['investigation'] ?? '............');

$row_total_tax = floatval($db_data['total_tax'] ?? 0);
$row_paid_amount = floatval($db_data['paid_amount'] ?? 0);
$row_remain_amount = $row_total_tax - $row_paid_amount; 

$os_terget_date = '............'; 
if (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') {
    try {
        $date = new \DateTime($db_data['it_demand_date']);
        $date->modify('+14 days'); 
        $os_terget_date = $date->format('d-m-Y'); 
    } catch (\Exception $e) {
        $os_terget_date = '............';
    }
}

// ဘတ်ဂျက်နှစ်အလိုက် ရက်စွဲဆွဲထုတ်ခြင်း
$start_date2 = '';
$end_date2 = '';
$start_year = '';
$end_year = '';
$current_tax_year = $db_data['tax_year'] ?? ''; 

if (!empty($current_tax_year)) {
    $by_query = "SELECT start_date2, end_date2 FROM budget_year WHERE budget_year = '" . $conn->real_escape_string($current_tax_year) . "'";
    $by_result = $conn->query($by_query);
    if ($by_result && $by_result->num_rows > 0) {
        $by_data = $by_result->fetch_assoc();
        
        $orig_start = $by_data['start_date2'];
        $orig_end = $by_data['end_date2'];

        if ($os_gir_type === 'အခြေ' && !empty($orig_start) && !empty($orig_end)) {
            $start_date2 = date('Y-m-d', strtotime($orig_start . ' -1 year'));
            $end_date2 = date('Y-m-d', strtotime($orig_end . ' -1 year'));
        } else {
            $start_date2 = $orig_start;
            $end_date2 = $orig_end;
        }

        if (!empty($start_date2)) {
            $start_year = date('Y', strtotime($start_date2));
        }
        if (!empty($end_date2)) {
            $end_year = date('Y', strtotime($end_date2));
        }
    }
}

$u_id = $_SESSION['user_id'] ?? 0;
$user_other_info = ""; 
$user_bank_township = ""; // 💡 ဘဏ်မြို့နယ်အတွက် Variable အသစ် ကြေညာသည်

if ($u_id > 0) {
    // 🎯 QUERY ထဲတွင် bank_township ကိုပါ ထည့်သွင်းဆွဲထုတ်လိုက်ပါသည်
    $user_query = "SELECT other, bank_township FROM user_register WHERE id = '$u_id'";
    $user_result = mysqli_query($conn, $user_query);
    if ($user_result && $user_row = mysqli_fetch_assoc($user_result)) {
        $user_other_info = str_replace(array("\r", "\n", "'", '"'), '', $user_row['other']);
        
        // 🎯 ရလာတဲ့ တန်ဖိုးကို Variable ထဲသို့ သိမ်းဆည်းသည်
        $user_bank_township = $user_row['bank_township'] ?? ''; 
    }
}
?>

<style>
#form0408Modal .modal-dialog {
    max-width: 795px !important; 
    width: 95% !important;
    margin: 20px auto !important;
    position: relative;
}
#form0408Modal .modal-content {
    background-color: #9ecaeb !important; 
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 20px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}
#form0408Modal .modal-body {
    padding: 20px !important; 
    overflow-x: auto !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
    justify-content: center !important;
}
.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 34px !important;
    background-color: #dc3545 !important; 
    color: #ffffff !important; 
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 34px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; 
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}
.custom-close-btn:hover {
    background-color: #bd2130 !important; 
}
.print-container { 
    background: #ffffff !important;
    width: 210mm !important; 
    min-height: 297mm !important; 
    padding: 5mm 5mm 5mm 10mm !important; 
    margin: 0 auto 20px auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}
table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}
table, tr, td { 
    box-sizing: border-box !important;
}
.custom-modal-title {
    font-size: 20px !important; 
    font-weight: bold !important; 
    color: #1a4d80 !important; 
    padding-left: 25px !important; 
    display: inline-block !important;
    line-height: 40px !important; 
}
.no-print-bottoms {
    display: flex !important;
    justify-content: center !important;
    gap: 15px !important;
    margin-top: -10px !important;    
    margin-bottom: 25px !important;
    width: 100% !important;
}
.no-print-bottoms .btn {
    font-size: 16px !important;         
    font-weight: bold !important;     
    padding: 10px 24px !important;    
    border-radius: 5px !important;    
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important; 
    transition: all 0.2s ease-in-out !important;
}
.no-print-bottoms .btn:hover {
    transform: translateY(-2px) !important; 
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}
@media print {
    .custom-close-btn { display: none !important; }
    .modal-footer, .no-print, .btn, .btn-close, .modal-header { 
        display: none !important; 
    }
    body * { 
        visibility: hidden !important; 
    }
    #form0408Modal, #form0408Modal * { 
        visibility: visible !important; 
    }
    #form0408Modal { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }
    .modal-dialog, .modal-content, .modal-body { 
        margin: 0 !important;
        padding: 0 !important;
        max-width: 100% !important; 
        width: 100% !important;
        border: none !important; 
        box-shadow: none !important;
        background: transparent !important;
    }
    .print-container { 
        width: 100% !important;
        max-width: 100% !important;
        padding: 5mm 5mm 5mm 5mm !important; 
        margin: 0 !important;
        display: block !important;
        box-sizing: border-box !important; 
    }
    table, .main-content-table, .main-content-table2, .order-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important; 
    }
    table, tr, td { 
        border: none !important; 
        box-sizing: border-box !important;
    }
    hr { display: none !important; }
    @page {
        size: A4 portrait;
        margin: 0mm !important; 
    }
}
#form0408Modal .modal-dialog {
    max-width: 900px; 
    margin: 5px auto;
}
#form0408Modal .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}
.underline{border-bottom: 1px dotted black; width:250px;}
.dashed-line{border-bottom:1.5px dotted black !important;}
.solid-line{border-bottom: 1.5px solid #0d0d0d !important; min-width:150px; display: inline-block; text-align: left; padding-left:5px;}
.under-line { border-bottom: 1.5px dashed #0d0d0d !important; min-width:150px; display: inline-block; text-align: left; padding-left:5px; padding-top:15px;}
.under-line2 { border-bottom: 1.5px dashed #0d0d0d !important; min-width:150px; display: inline-block; text-align: left; padding-left:5px; }
</style>

<div class="modal fade" id="form0408Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="custom-modal-title">အခွန်တွက်ချက်မှုပုံစံ ထုတ်ယူရန်</h5>
                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            <div class="modal-body" style="padding: 0px !important;">
                <div class="modal-body" id="printableSheet">
                    <div class="print-container" style="padding-left: 70px !important; padding-right: 30px !important; margin-left: 0px !important;">
                        <table style="border: 1.5px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:22px; margin-bottom: 5px;">
                            <tr>
                                <td style='padding:2px; font-size:14px;'>
                                    ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                                </td>
                            </tr>
                        </table>
                        <div style="text-align:right; font-weight:bold;  margin-bottom:20px; line-height:22px; font-size:15px;">ပတခ(ဝင)-၀၄-၀၈</div>
                        <div style="text-align:center; font-weight:bold;  margin-bottom:20px; line-height:22px; font-size:14px;">
                            <b>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၁ နှင့် ၆၄ တို့အရ ဝင်ငွေခွန်စည်းကြပ်မှု၊ ဒဏ်ကြေးငွေစည်းကြပ်မှု </b> <br>
                            <b>အကြောင်းကြားစာ </b> 
                        </div>

                        <table style='width:100%; font-size:15px; line-height:22px;'>
                            <tr>
                                <td style='width:50%'></td>
                                <td style='width:20%; text-align:right;'>အခွန်တောင်းခံလွှာအမှတ်</td>
                                <td style='width:10%; text-align:right; border-bottom:1.5px dotted black !important;'>DN-<span id="m0408_it_demand_no"></span></td>
                            </tr>
                            <tr>
                                <td style='width:50%'></td>
                                <td style='width:20%; text-align:right;'>ရက်&ensp;စွဲ၊ </td>
                                <td style='width:10%; text-align:right; border-bottom:1.5px dotted black !important;'> <span id="m0408_demandDate"></span></td>
                            </tr>
                        </table>

                        <table style='width:100%; font-size:15px; line-height:22px;'>
                            <tr>
                                <td style='width:10%'>သို့</td>
                                <td style='width:27%'>အခွန်ထမ်းအမည်၊</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_name"></span>( <span id="os_biz"><?php echo $os_biz; ?></span> )</td>
                            </tr>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:27%'>နိုင်ငံသားစိစစ်ရေးကတ်/TIN၊</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_gir"></span>&ensp;/&ensp;<span id="m0408_gir_type"></span> (<span id="m0408_nrc_no"></span>)</td>
                            </tr>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:27%'>အခွန်ထမ်းလိပ်စာ၊</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_address"></span></td>
                            </tr>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:27%'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                                <td style='width:63%; border-bottom:1.5px dotted black !important;'>: <span id="m0408_tax_period_txt"></span></td>
                            </tr>
                        </table>
                        <div style="text-align:justify; margin-top:15px; padding:3px; line-height:22px; font-size:14px;">
                            ၁။<span style='padding-left:48px;'></span>( <strong><span id="m0408_year"></span></strong> )စည်းကြပ်နှစ်အတွက် 
                            ကျောဖက်ပါပုံစံတွင် အသေးစိပ်ဖော်ပြထားချက်အရ ပေးဆောင်ရန် တာဝန်ရှိသည့် အခွန်နှင့်စပ်လျဉ်း၍ အောက်ပါအတိုင်း ပေးဆောင်ရန် အကြောင်းကြားပါသည် -
                        </div>

                        <table style='width:90%; font-size:15px; line-height:22px;'>
                            <tr>
                                <td style='width:10%'></td>
                                <td style='width:5%'>(က)</td>
                                <td style='width:55%'>ဝင်ငွေခွန်</td>
                                <td style='width:8%; text-align:left;'>ကျပ်</td>
                                <td style='width:30%; text-align:right; padding-right:30px;' class="under-line2"> <span id="os_tax_to_pay"><?php echo $os_tax_to_pay; ?></span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ခ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၅ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဂ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၆ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>(ဃ)</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၇ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( င )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၈ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( စ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၆၉ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>(ဆ)</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၀ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဇ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၁ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဈ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၂ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>(ည)</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၃ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td class="under-line"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>( ဋ )</td>
                                <td>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေပုဒ်မ ၇၄ အရ ဒဏ်ကြေးငွေ</td>
                                <td>ကျပ်</td>
                                <td style='text-align:right; padding-right:30px; ' class="solid-line"><span id="os_penalty_tax"><?php echo $os_penalty_tax; ?></span></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td><b>စုစုပေါင်းပေးဆောင်ရမည့်အခွန်ပမာဏ</b></td>
                                <td>ကျပ်</td>
                                <td style='text-align:right; padding-right:30px; ' class="solid-line"><b><span id="os_total_tax"><?php echo $os_total_tax; ?></span></b></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td colspan="5" style='padding-top: 5px; text-align:left;'>
                                   <strong> စာသားဖြင့် ( <span id="m0408_taxTextMM"></span> ) ကျပ်တိတိ၊</strong>
                                </td>     
                            </tr>
                        </table>
                        <div style="text-align:justify; margin-top:15px; padding:3px; line-height:22px; font-size:14px;">
                            ၂။<span style='padding-left:48px;'></span>အထက်ပါပေးဆောင်ရမည့် အခွန်ငွေပမာဏကို 
                            ( <span id="user_bank_township"><?php echo !empty($user_bank_township) ? htmlspecialchars($user_bank_township) : '............'; ?></span> ) ရှိ မြန်မာ့စီးပွားရေးဘဏ်၊ 
                            ဘဏ်စာရင်းအမှတ် ( <span id="user_md_no">............</span> ) သို့ ပူးတွဲပါ ငွေသွင်းချလန်ဖြင့်
                            ( <span id="os_terget_date"><?php echo $os_terget_date; ?></span> )ရက်နေ့ နောက်ဆုံးထား၍ ပေးသွင်းပြီး လက်ခံဖြတ်ပိုင်းကို
                            ရယူစေလိုပါသည်။ (Online Paymentဖြင့် ပေးသွင်း၍ရပါက ပေးသွင်းစေလိုပါသည်။) သတ်မှတ်ရက်အတွင်း အခွန်ပေးသွင်းရန် ပျက်ကွက်ပါက 
                            အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေ ပုဒ်မ ၇၄ ၊ ပုဒ်မခွဲ(က)အရ ဒဏ်ငွေ ထပ်မံတပ်ရိုက်ခြင်း ခခံရဖွယ်ရှိပါ၍ မပျက်မကွက် ပေးဆောင်စေလိုပါသည်။<br>
                            ၃။<span style='padding-left:48px;'></span>စည်းကြပ်မှု သို့မဟုတ် ဒဏ်ကြေးငွေတပ်ရိုက်မှုအတွက်ဆုံးဖြတ်ချက်ကို ကျေနပ်မှုမရှိပါက
                            အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၃၄ ပါ စီမံအုပ်ချုပ်မှုနည်းလမ်းအရ ပြန်လည်သုံးသပ်ပေးရန် ညွှန်ကြားရေးမှူးချုပ်၊ ပြည်တွင်းအခွန်များဦးစီးဌာန၊ 
                            ရုံးအမှတ်(၄6)၊ နေပြည်တော်သို့ အကြောင်းကြားစာလက်ခံရရှိသည့်နေ့မှ ရက်ပေါင်း(၃၀)အတွင်း လျှောက်ထားနိုင်ပါသည်။
                        </div>

                        <table style='width:100%; margin-top:30px; line-height:22px;'>
                            <tr>
                                <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                                <td style='text-align:center;'>
                                    တာဝန်ခံအရာရှိ<br>
                                    <span id="os_township"><?php echo $os_township; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                                </td>
                            </tr>
                        </table>
                            <br><br><br>
                        <p style='text-align:right; font-size:15px; padding:3px; line-height: 24px;'>ပတခ(ဝင)-၀၄-၀၈(အဆက်)</p>

                        <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                            ဝင်ငွေအမျိုးအစားအလိုက် သတ်မှတ်မှု 
                        </div>
                        
                        <table style="width: 100%; line-height:23px; border-collapse: collapse; font-size:14px; table-layout: fixed;">
                            <tr style="border: 1.5px solid #0a0a0a !important;">
                                <th colspan="2" style="width: 76%; text-align: center; border-right: 1.5px solid #0b0b0b !important; padding:2px;">ဝင်ငွေရလမ်း</th>
                                <th style="width: 22%; text-align: center; padding:2px;">သတ်မှတ်ဝင်ငွေ (ကျပ်)</th>
                            </tr>
                            
                            <tr style="border-right: 1.5px solid #0b0b0b !important;">
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၁။ &ensp;လစာ</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                            
                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၂။ &ensp;အသက်မွေးဝမ်းကျောင်းပညာလုပ်ငန်း</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၃။ &ensp;စီးပွားရေးလုပ်ငန်း</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"> </td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၄။ &ensp;ပစ္စည်း</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                         <?php 
                        if (str_contains($db_data['business_type'] ?? '', 'ရောင်းချခြင်း')) {
                        ?>
                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၅။ &ensp;အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                                <td style="width: 70%; text-align: center; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"><b> ( <span id="os_biz"><?php echo $os_biz; ?></span> )</b></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            </tr>
                            
                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၆။ &ensp;စည်းကြပ်မှုမှလွတ်ကင်းသွားသောဝင်ငွေ</td>
                                <td style="width: 70%; text-align: center; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"><b> </b></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                         <?php 
                        } else { 
                        ?>
                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၅။ &ensp;အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                                <td style="width: 70%; text-align: center; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"><b> </b></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                            
                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၆။ &ensp;စည်းကြပ်မှုမှလွတ်ကင်းသွားသောဝင်ငွေ</td>
                                <td style="width: 70%; text-align: center; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"><b> ( <span id="os_biz"><?php echo $os_biz; ?></span> ) </b></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            </tr>
                        <?php 
                        }
                        ?>

                            <tr>
                                <td style="width: 8%; text-align: left; border-left: 1.5px solid #0a0a0a !important; padding:2px; padding-left:5px;">၇။ &ensp;အခြားရလမ်းများမှဝင်ငွေ</td>
                                <td style="width: 70%; text-align: left; border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px dotted #0b0b0b !important;"></td>
                                <td style="width: 22%; text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                            
                            <tr style="height:20px;">
                                <td colspan="2" style="border-left: 1.5px solid #0a0a0a !important; border-right: 1.5px solid #0a0a0a !important; color:red; text-align: right; padding-right: 30px;">
                                    <span id="os_plate_no"><?php echo $os_plate_no; ?></span>၊ 
                                    <span id="os_manufacture"><?php echo $os_manufacture; ?></span>၊ 
                                    <span id="os_brand_name"><?php echo $os_brand_name; ?></span>၊ 
                                    <span id="os_build_type"><?php echo $os_build_type; ?></span>၊ 
                                    <span id="os_chassi"><?php echo $os_chassi; ?></span>၊ 
                                    <span id="os_make_year"><?php echo $os_make_year; ?></span>၊ 
                                </td>
                                 <td style="border-right: 1.5px solid #0a0a0a !important;"></td>
                            </tr>
                            <tr style="height:20px;">
                                <td style="border-left: 1.5px solid #0a0a0a !important; border-bottom: 1.5px solid #0a0a0a !important;"></td>
                                <td style="border-right: 1.5px solid #0b0b0b !important; border-bottom: 1.5px solid #0a0a0a !important;"></td>
                                <td style="border-right: 1.5px solid #0a0a0a !important; border-bottom: 1.5px solid #0a0a0a !important;"></td>
                            </tr>
                        
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; font-weight:bold; padding:2px;">စုစုပေါင်း</td>
                                <td style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; padding:2px;">*သက်သာခွင့်များ</td>
                                <td style="text-align: right; padding-right:30px; border-bottom: 1.5px solid #121212 !important; border-right: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; font-weight:bold; padding:2px;">အခွန်စည်းကြပ်ရန်အသားတင်ဝင်ငွေ</td>
                                <td style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; padding:2px;">ကျသင့်ဝင်ငွေခွန်</td>
                                <td style="text-align: right; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="os_income_tax"><?php echo $os_income_tax; ?></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-right: 1.5px solid #0b0b0b !important; color: red; padding:2px;">နုတ်-ပုဒ်မ ၁၆ အရ ပေးဆောင်ပြီးအခွန်</td>
                                <td style="text-align: right; padding-right:30px; color: red; border-bottom: 1.5px solid #121212 !important; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="os_advance_tax"><?php echo $os_advance_tax; ?></span></td>
                            </tr>
                            <tr>
                                <td style="border-left: 1.5px solid #0a0a0a !important; border-bottom: 1.5px solid #0a0a0a !important; padding:2px;"></td>
                                <td style="text-align: right; border-bottom: 1.5px solid #0a0a0a !important; border-right: 1.5px solid #0a0a0a !important; font-weight:bold; padding:2px;">ပေးဆောင်ရန်ကျန် / ပြန်အမ်းရန်အခွန်</td>
                                <td style="text-align: right; border-bottom: 1.5px solid #0a0a0a !important; padding-right:30px; border-right: 1.5px solid #0a0a0a !important; padding:2px;"><span id="os_tax_to_pay"><?php echo $os_tax_to_pay; ?></span></td>
                            </tr>
                        </table>
                        <?php 
                         if (($db_data['business_type'] ?? '') === 'ရေယာဉ်ရောင်းချခြင်း') { 
                        ?>
                        <p style="text-align:center; color:red;">ရေယာဉ်အရောင်းသတ်မှတ်တန်ဖိုးမှာ( <span id="os_valuation_value"><?php echo $os_valuation_value; ?></span> )ကျပ် ဖြစ်ပါသည်။</p>
                        <?php 
                        } else if (($db_data['business_type'] ?? '') === 'ရေယာဉ်ဝယ်ယူခြင်း'){ 
                        ?>
                        <p style="text-align:center; color:red;">ရေယာဉ်အဝယ်သတ်မှတ်တန်ဖိုးမှာ( <span id="os_valuation_value"><?php echo $os_valuation_value; ?></span> )ကျပ် ဖြစ်ပါသည်။</p>
                        <?php 
                        } else if (($db_data['business_type'] ?? '') === 'မော်တော်ယာဉ်ရောင်းချခြင်း'){ 
                        ?>
                        <p style="text-align:center; color:red;">မော်တော်ယာဉ်အရောင်းသတ်မှတ်တန်ဖိုးမှာ( <span id="os_valuation_value"><?php echo $os_valuation_value; ?></span> )ကျပ် ဖြစ်ပါသည်။</p>
                        <?php 
                        } else if (($db_data['business_type'] ?? '') === 'မော်တော်ယာဉ်ဝယ်ယူခြင်း'){ 
                        ?>
                        <p style="text-align:center; color:red;">မော်တော်ယာဉ်အဝယ်သတ်မှတ်တန်ဖိုးမှာ( <span id="os_valuation_value"><?php echo $os_valuation_value; ?></span> )ကျပ် ဖြစ်ပါသည်။</p>
                        
                        <?php 
                        } 
                        ?>
                        <br><br>

                        <table style="width: 100%; font-size:14px; line-height:23px;">
                            <tr>
                                <th style="width: 17%;"></th>
                                <th style="width: 5%;"></th>
                                <th style="width: 46%; text-align: left;"><b>*သက်သာခွင့်များ</b></th>
                                <th style="width: 12%;"></th>
                                <th style="width: 20%; padding-top:0px;"></th>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၁။</td>
                                <td>အခြေခံသက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၂။</td>
                                <td>အတူနေမိဘအတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၃။</td>
                                <td>အိမ်ထောင်ဖက်အတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၄။</td>
                                <td>သားသမီးများအတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၅။</td>
                                <td style="font-size: 13px;">အခွန်ထမ်းနှင့်အိမ်ထောင်ဖက်၏အသက်အာမခံအတွက်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>6။</td>
                                <td>စုဆောင်းငွေအတွက် သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px dashed #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td>၇။</td>
                                <td>လှူဒါန်းငွေအတွက်သက်သာခွင့်</td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px solid #0d0d0d !important;">&ensp;</td>
                            </tr>
                            <tr>
                                <td></td>
                                <td></td>
                                <td><b>စုစုပေါင်း</b></td>
                                <td>........&ensp;ကျပ်</td>
                                <td style="text-align: right; padding-right:40px; border-bottom: 1.5px solid #0d0d0d !important;">&ensp;</td>
                            </tr>
                        </table>
                        <br><br><br><br><br><br><br><br><br>
                    </div>
                </div>
            </div>
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" onclick="closeAndReturnToDemandList()">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
function DB_Data_Binding_0408() {
    // ရက်စွဲ ပြောင်းလဲသည့် Helper Function
    const formatDateToEnglish = (dateStr) => {
        if (!dateStr || dateStr === '0000-00-00' || dateStr.includes('...')) return '............';
        if (dateStr.includes('-')) {
            const parts = dateStr.split('-');
            if (parts.length >= 3) {
                const yyyy = parts[0];
                const mm = parseInt(parts[1]); 
                const dd = parseInt(parts[2].split(' ')[0]);
                if (isNaN(mm) || isNaN(dd)) return '............';
                return `${dd}-${mm}-${yyyy}`;
            }
        }
        return dateStr;
    };

    // ဂဏန်းမှ မြန်မာစာသား ပြောင်းလဲသည့် Helper Function
    const numberToMyanmarText = (number) => {
        if (number === 0 || !number) return "သုည";
        const digits = ["", "တစ်", "နှစ်", "သုံး", "လေး", "ငါး", "ခြောက်", "ခုနစ်", "ရှစ်", "ကိုး"];
        const units = ["", "ဆယ်", "ရာ", "ထောင်", "သောင်း", "သိန်း", "သန်း", "ကုဋေ"];
        let numStr = Math.floor(number).toString();
        let result = "";
        let len = numStr.length;
        for (let i = 0; i < len; i++) {
            let digit = parseInt(numStr[i]);
            let unitIndex = len - i - 1;
            if (digit !== 0) {
                result += digits[digit] + units[unitIndex];
            }
        }
        return result;
    };

    // PHP မှ ဒေတာများကို သီးသန့် ကာကွယ်ပြီး Variable ဖမ်းယူခြင်း
    const osName = <?php echo json_encode($os_name); ?>;
    const osAddress = <?php echo json_encode($os_address); ?>;
    const osGir = <?php echo json_encode($os_gir); ?>;
    const osGirType = <?php echo json_encode($os_gir_type); ?>;
    const osNrc = <?php echo json_encode($os_nrc_no); ?>;
    const osYear = <?php echo json_encode($os_year); ?>;
    //const tName = <?php echo json_encode($os_township); ?> || "............";
    const bTownship = <?php echo json_encode($os_bank_township); ?> || "............";
    const mdNo = <?php echo json_encode($os_md_no); ?> || "............";
    const targetDate = <?php echo json_encode($os_terget_date); ?> || "............";
    const rawTaxInt = parseInt(<?php echo json_encode($raw_total_tax_int); ?>) || 0;

    // အောက်ပါ try-catch များသည် တစ်ခုချင်းစီ သီးသန့် အလုပ်လုပ်ပြီး တစ်ခုမှားလည်း ကျန်တာ ပုံမှန်အတိုင်း ချိတ်ပေးပါမည်။
    try { if(document.getElementById('m0408_name')) document.getElementById('m0408_name').innerText = osName; } catch(e){}
    try { if(document.getElementById('m0408_address')) document.getElementById('m0408_address').innerText = osAddress; } catch(e){}
    try { if(document.getElementById('m0408_gir')) document.getElementById('m0408_gir').innerText = osGir; } catch(e){}
    try { if(document.getElementById('m0408_gir_type')) document.getElementById('m0408_gir_type').innerText = osGirType; } catch(e){}
    try { if(document.getElementById('m0408_nrc_no')) document.getElementById('m0408_nrc_no').innerText = osNrc; } catch(e){}
    try { if(document.getElementById('m0408_year')) document.getElementById('m0408_year').innerText = osYear; } catch(e){}

    // ၁။ ဘဏ်တည်ရှိရာ မြို့နယ် ချိတ်ဆက်ခြင်း (os_bank_township)
    try {
        if(document.getElementById('os_bank_township')) {
            document.getElementById('os_bank_township').innerText = bTownship;
        }
    } catch(e){}

    // ၂။ အောက်ခြေ တာဝန်ခံအရာရှိရုံး မြို့နယ် ချိတ်ဆက်ခြင်း (m0408_township)
    //try {
       // if(document.getElementById('m0408_township')) {
           // document.getElementById('m0408_township').innerText = tName;
       // }
    //} catch(e){}

    // ၃။ ဘဏ်စာရင်းအမှတ် (user_md_no) ချိတ်ဆက်ခြင်း
    try {
        if(document.getElementById('user_md_no')) {
            document.getElementById('user_md_no').innerText = mdNo;
        }
    } catch(e){}

    // ၄။ နောက်ဆုံးပေးသွင်းရမည့်ရက် (os_terget_date) ကို တိုက်ရိုက် Binder လုပ်ခြင်း
    try {
        if(document.getElementById('os_terget_date')) {
            document.getElementById('os_terget_date').innerText = targetDate;
        }
    } catch(e){}

    // ၅။ အခွန်တောင်းခံလွှာရက်စွဲ နှင့် အမှတ်
    try {
        if(document.getElementById('m0408_it_demand_no')) document.getElementById('m0408_it_demand_no').innerText = <?php echo json_encode($os_itDemandNo); ?>;
        if(document.getElementById('m0408_demandDate')) {
            document.getElementById('m0408_demandDate').innerText = formatDateToEnglish(<?php echo json_encode($os_itDemandDate); ?>);
        }
    } catch(e){}

    // ၆။ ဘတ်ဂျက်နှစ် ကာလအပိုင်းအခြား တွက်ချက်ခြင်း
    try {
        const startDate2 = formatDateToEnglish(<?php echo json_encode($start_date2); ?>);
        const endDate2 = formatDateToEnglish(<?php echo json_encode($end_date2); ?>);
        let taxPeriodText = "............ မှ ............ ထိ";
        if(startDate2 !== '............' && endDate2 !== '............') {
            const startParts = startDate2.split('-');
            const endParts = endDate2.split('-');
            if (startParts.length >= 3 && endParts.length >= 3) {
                taxPeriodText = `(01-04-${startParts[2]}) မှ (31-03-${endParts[2]}) ထိ`;
            }
        }
        if(document.getElementById('m0408_tax_period_txt')) document.getElementById('m0408_tax_period_txt').innerText = taxPeriodText;
    } catch(e){}

    // ၇။ စာသားဖြင့် အခွန်ငွေဖြည့်စွက်ခြင်း (m0408_taxTextMM)
    try {
        if(document.getElementById('m0408_taxTextMM')) {
            document.getElementById('m0408_taxTextMM').innerText = numberToMyanmarText(rawTaxInt);
        }
    } catch(e){}
}

// ရလဒ်များကို စနစ်တကျ Render လုပ်ခြင်း
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', DB_Data_Binding_0408);
} else {
    DB_Data_Binding_0408();
}

function closeAndReturnToDemandList() {
    try {
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var myModalEl = document.getElementById('form0408Modal');
            var modal = bootstrap.Modal.getInstance(myModalEl) || new bootstrap.Modal(myModalEl);
            modal.hide();
        }
    } catch (e) {
        console.log("Modal ပိတ်ရာတွင် အမှားရှိသည်: ", e);
    }
    setTimeout(function() {
        if (window.opener && !window.opener.closed) {
            window.close(); 
        } else {
            window.location.href = '../vehicle_demand_list.php?openModal=formsModal3';
        }
    }, 300); 
}
</script>