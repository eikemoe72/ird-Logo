<?php
// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    // အစ်ကို့ရဲ့ ပင်မ Table နာမည် 'vehicledata' ထဲမှ ဆွဲထုတ်ခြင်း
    $query = "SELECT * FROM vehicledata WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း


$os_year      = htmlspecialchars($db_data['tax_year'] ?? '-');
$startYear = '-';
$endYear   = '-';
if (!empty($os_year) && strpos($os_year, '-') !== false) {
    $years_array = explode('-', $os_year);
    $startYear = trim($years_array[0]);
    $endYear   = trim($years_array[1]);
}
$os_officer   = htmlspecialchars($db_data['officer_name'] ?? '-');
$os_rank      = htmlspecialchars($db_data['officer_rank'] ?? '-');
$os_region      = htmlspecialchars($db_data['region'] ?? '');
$os_state_name  = htmlspecialchars($db_data['state_name'] ?? '-');
$os_township  = htmlspecialchars($db_data['township_name'] ?? '-');

$os_name      = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_nrc_no  = htmlspecialchars($db_data['nrc_no'] ?? '-');
$os_gir       = htmlspecialchars($db_data['gir_no'] ?? '-');
$os_gir_type  = htmlspecialchars($db_data['gir_type'] ?? '-');
$os_address   = htmlspecialchars($db_data['address'] ?? '-');

$os_biz       = htmlspecialchars($db_data['business_type'] ?? '-');



   // (၄) မြေနှင့် အဆောက်အဦးဆိုင်ရာ အချက်အလက်များ
$os_plate_no       = htmlspecialchars($db_data['plate_no'] ?? '-');
$os_manufacture          = htmlspecialchars($db_data['manufacture'] ?? '-');
$os_brand_name       = htmlspecialchars($db_data['brand_name'] ?? '-');
$os_build_type          = htmlspecialchars($db_data['build_type'] ?? '-');
$os_chassi       = htmlspecialchars($db_data['chassi'] ?? '-');
$os_make_year          = htmlspecialchars($db_data['make_year'] ?? '-');
$os_sale_date       = htmlspecialchars($db_data['sale_date'] ?? '-');
$os_manufacture          = htmlspecialchars($db_data['manufacture'] ?? '-');
// 🎯 ဒသမကိန်း .00 မပါဘဲ ကော်မာခတ်ပြီး ကိန်းပြည့်ထုတ်ရန် အောက်ပါအတိုင်း ပြင်ပါသည်
$os_proposal_value                = number_format(floatval($db_data['proposal_value'] ?? 0), 0, '.', ',');
$os_valuation_value     = number_format(floatval($db_data['valuation_value'] ?? 0), 0, '.', ',');
$os_allowable_expenses  = number_format(floatval($db_data['allowable_expenses'] ?? 0), 0, '.', ',');
$os_taxable_income      = number_format(floatval($db_data['taxable_income'] ?? 0), 0, '.', ',');
$os_income_tax          = number_format(floatval($db_data['income_tax'] ?? 0), 0, '.', ',');
$os_advance_tax         = number_format(floatval($db_data['advance_tax'] ?? 0), 0, '.', ',');
$os_tax_to_pay          = number_format(floatval($db_data['tax_to_pay'] ?? 0), 0, '.', ',');
$os_penalty_tax         = number_format(floatval($db_data['penalty_tax'] ?? 0), 0, '.', ',');
$os_total_tax           = number_format(floatval($db_data['total_tax'] ?? 0), 0, '.', ',');
$os_paid_amount         = number_format(floatval($db_data['paid_amount'] ?? 0), 0, '.', ',');



$os_chalan_no  = htmlspecialchars($db_data['chalan_no'] ?? '......');
$os_chalan_date = (!empty($db_data['chalan_date']) && $db_data['chalan_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['chalan_date'])) 
    : '............';
$os_chalan_date = htmlspecialchars($os_chalan_date);

$os_notified_date = (!empty($db_data['notified_date']) && $db_data['notified_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['notified_date'])) 
    : '............';
$os_notified_date = htmlspecialchars($os_notified_date);

$os_appointment_date = (!empty($db_data['appointment_date']) && $db_data['appointment_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['appointment_date'])) 
    : '............';
$os_appointment_date = htmlspecialchars($os_appointment_date);

$os_appearance_date = (!empty($db_data['appearance_date']) && $db_data['appearance_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['appearance_date'])) 
    : '............';
$os_appearance_date = htmlspecialchars($os_appearance_date);


$os_itDemandNo  = htmlspecialchars($db_data['it_demand_no'] ?? '......');
$os_itDemandDate = (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['it_demand_date'])) 
    : '............';
$os_itDemandDate = htmlspecialchars($os_itDemandDate);

$os_investigation_value  = htmlspecialchars($db_data['investigation_value'] ?? '......');
$os_source_of_income  = htmlspecialchars($db_data['source_of_income'] ?? '............');
$os_investigation  = htmlspecialchars($db_data['investigation'] ?? '............');

$row_remain_amount = $row_total_tax - $row_paid_amount; 
$os_terget_date = '............'; // Default စာသား
if (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') {
    try {
        $date = new DateTime($db_data['it_demand_date']);
        $date->modify('+14 days'); // ရက်ပေါင်း ၁၄ ရက် တိုးလိုက်ခြင်း
        $os_terget_date = $date->format('d-m-Y'); // dd-mm-yyyy ပုံစံဖြင့် ထုတ်ယူခြင်း
    } catch (Exception $e) {
        $os_terget_date = '............';
    }
}
?>

<style>
#formshareModal .modal-dialog {
    max-width: 795px !important; 
    width: 95% !important;
    margin: 20px auto !important;
    position: relative;
}

#formshareModal .modal-content {
    background-color: #9ecaeb !important; 
    border: 1px solid #404446 !important;
    box-shadow: 0 10px 20px rgba(0,0,0,0.5) !important;
    border-radius: 6px !important;
    overflow: hidden !important;
}

#formshareModal .modal-body {
    padding: 20px !important; 
    overflow-x: auto !important; 
    display: flex !important;
    flex-direction: column !important;
    align-items: center !important; 
    justify-content: center !important;
}

.custom-close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 34px !important;
    background-color: #dc3545 !important; 
    color: #ffffff !important; 
    border: none !important;
    border-radius: 4px !important;
    font-size: 20px !important;
    font-weight: bold !important;
    line-height: 34px !important;
    text-align: center !important;
    cursor: pointer !important;
    z-index: 1051 !important; 
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    box-shadow: 0 2px 5px rgba(0,0,0,0.3) !important;
    transition: background 0.2s ease-in-out !important;
}

.custom-close-btn:hover {
    background-color: #bd2130 !important; 
}

.print-container { 
    background: #ffffff !important;
    width: 210mm !important; 
    min-height: 297mm !important; 
    padding: 5mm 5mm 5mm 15mm !important; 
    margin: 0 auto 20px auto !important; 
    box-sizing: border-box !important; 
    box-shadow: 0 5px 20px rgba(0, 0, 0, 0.4) !important;
    border: 1px solid #d3d3d3 !important;
}

table, .main-content-table, .main-content-table2, .order-table {
    width: 100% !important;
    max-width: 100% !important;
    table-layout: fixed !important;
    box-sizing: border-box !important;
}

table, tr, td { 
    box-sizing: border-box !important;
}

.custom-modal-title {
    font-size: 20px !important; 
    font-weight: bold !important; 
    color: #1a4d80 !important; 
    padding-left: 25px !important; 
    display: inline-block !important;
    line-height: 40px !important; 
}

.no-print-bottoms {
    display: flex !important;
    justify-content: center !important;
    gap: 15px !important;
    margin-top: -10px !important;    
    margin-bottom: 25px !important;
    width: 100% !important;
}

.no-print-bottoms .btn {
    font-size: 16px !important;         
    font-weight: bold !important;     
    padding: 10px 24px !important;    
    border-radius: 5px !important;    
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.15) !important; 
    transition: all 0.2s ease-in-out !important;
}

.no-print-bottoms .btn:hover {
    transform: translateY(-2px) !important; 
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2) !important;
}

@media print {
    .custom-close-btn { display: none !important; }
}

@media print {
    .modal-footer, .no-print, .btn, .btn-close, .modal-header { 
        display: none !important; 
    }
    
    body * { 
        visibility: hidden !important; 
    }
    
    #formshareModal, #formshareModal * { 
        visibility: visible !important; 
    }
    
    #formshareModal { 
        position: absolute !important; 
        left: 0 !important; 
        top: 0 !important; 
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .modal-dialog, .modal-content, .modal-body { 
        margin: 0 !important;
        padding: 0 !important;
        max-width: 100% !important; 
        width: 100% !important;
        border: none !important; 
        box-shadow: none !important;
        background: transparent !important;
    }

    .print-container { 
        width: 100% !important;
        max-width: 100% !important;
        padding: 10mm 5mm 5mm 10mm !important; 
        margin: 0 !important;
        display: block !important;
        box-sizing: border-box !important; 
    }

    table, .main-content-table, .main-content-table2, .order-table {
        width: 100% !important;
        max-width: 100% !important;
        table-layout: fixed !important;
        border: none !important;
        box-sizing: border-box !important; 
    }
    
    table, tr, td { 
        border: none !important; 
        box-sizing: border-box !important;
    }
    
    .print-container table:first-child {
        border: none !important;
    }

    hr { display: none !important; }
    
    @page {
        size: A4 portrait;
        margin: 0mm !important; 
    }
}

#formshareModal .modal-dialog {
    max-width: 900px; 
    margin: 5px auto;
}

#formshareModal .modal-body {
    padding: 0px !important; 
    overflow-x: hidden; 
}

.underline{border-bottom: 1px dotted solid; width:250px;}
.dashed-line{border-bottom:1.5px dotted black !important;}
.solid-line{border-bottom:1.5px solid black !important;}
.under-line { border-bottom: 1.5px dashed #0d0d0d !important; min-width:400px; display: inline-block; text-align: left; padding-left:5px;}
</style>

<div class="modal fade" id="formshareModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header no-print">
                <h5 class="custom-modal-title">အခွန်တွက်ချက်မှုပုံစံ ထုတ်ယူရန်</h5>

                <button type="button" class="custom-close-btn no-print" onclick="closeAndReturnToDemandList()" title="ပိတ်မည်">×</button>
            </div>
            <div class="modal-body" style="padding: 0px !important;">
            <div class="modal-body" id="printableSheet">
                <div class="print-container" style="padding-left: 80px !important; padding-right: 30px !important; margin-left: 0px !important;">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:1.9; margin-bottom: 5px;">
                        <tr>
                            <td style='padding:5px'>
                                ၂00၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇</p>

                    <div style="text-align:center; font-weight:bold; line-height: 1.9; margin-bottom:20px;">
                        <b>အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊ ၂၈၊ ၃0 နှင့် ၆၄ တို့အရ ဝင်ငွေခွန်စည်းကြပ်မှုနှင့်</b> <br>
                        <b>ဒဏ်ကြေးငွေစည်းကြပ်မှု ဆုံးဖြတ်ချက်</b> 
                    </div>
                    <div style="text-align:center;  line-height: 1.9; margin-bottom:20px;">
                        ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                        ( <span id="os_township"><?php echo $os_township; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး )
                    </div>

                    <table style='width:100%; font-size:15px; margin-bottom: 15px;'>
                        <tr>
                            <td style='width:50%'></td>
                            <td style='width:20%; text-align:right;'>ရက်စွဲ၊ </td>
                            <td style='width:10%; text-align:right; border-bottom:1.5px dotted black !important;'><span id="os_itDemandDate"><?php echo $os_itDemandDate; ?></span></td>
                        </tr>
                        <tr>
                            <td> </td>
                            <td style='text-align:right;'>စည်းကြပ်နှစ်၊ </td>
                            <td style='text-align:right; border-bottom:1.5px dotted black !important;'><span id="os_year"><?php echo $os_year; ?></span></td>
                        </tr>
                    </table>

                    <table style='width:100%; font-size:15px; line-height: 1.8;'>
                        <tr>
                            <td style='width:6%'>၁။</td>
                            <td style='width:28%; font-weight:bold;'>အခွန်ထမ်းမှတ်ပုံတင်အမှတ်</td>
                            <td style='width:3%; text-align:center;'>၊</td>
                            <td style='width:63%; text-align: left; border-bottom:1.5px dotted black !important;;'> <span id="os_gir"><?php echo $os_gir; ?></span>/<span id="os_gir_type"><?php echo $os_gir_type; ?></span></td>
                        </tr>
                        <tr>
                            <td >၂။</td>
                            <td style=' font-weight:bold;'>အခွန်ထမ်းအမည်နှင့်လိပ်စာ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="os_name" ><?php echo $os_name; ?></span>&ensp;(  <span id="os_nrc_no" ><?php echo $os_nrc_no; ?></span>  )</td>
                        </tr>
                        <tr>
                            <td ></td>
                            <td style='width:38%'></td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="os_address" ><?php echo $os_address; ?></span></td>
                        </tr>
                        <tr>
                            <td >၃။</td>
                            <td style=' font-weight:bold;'>အခွန်ထမ်းအမျိုးအစား</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> ပုဂ္ဂလိက</td>
                        </tr>
                        <tr>
                            <td >၄။</td>
                            <td style=' font-weight:bold;'>လုပ်ငန်းအမျိုးအစား</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span id="os_biz"><?php echo $os_biz; ?></span></td>
                        </tr>
                        <tr>
                            <td >၅။</td>
                            <td style=' font-weight:bold;'>လုပ်ငန်းခွဲများ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> 
                                 <span id="os_plate_no"><?php echo $os_plate_no; ?></span>၊ 
                                  <span id="os_manufacture"><?php echo $os_manufacture; ?></span>၊ 
                                   <span id="os_brand_name"><?php echo $os_brand_name; ?></span>၊ 
                                    <span id="os_build_type"><?php echo $os_build_type; ?></span>၊ 
                                     <span id="os_chassi"><?php echo $os_chassi; ?></span>၊ 
                                      <span id="os_make_year"><?php echo $os_make_year; ?></span>
                            </td>
                        </tr>
                        <tr>
                            <td >၆။</td>
                            <td style=' font-weight:bold;'>(က)ပုဂ္ဂိုလ်စုဝင်များ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'></td>
                        </tr>
                        <tr>
                            <td ></td>
                            <td style=' font-weight:bold;'>( ခ ) အစုများ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> </td>
                        </tr>
                        <tr>
                            <td >၇။</td>
                            <td style='width:150px; font-weight:bold;'>ကြေညာသည့်ဝင်ငွေ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> ( <span id="os_proposal_value"><?php echo $os_proposal_value; ?></span> )ကျပ်</td>
                        </tr>
                        <tr>
                            <td >၈။</td>
                            <td style=' font-weight:bold;'>တင်ပြသောစာရင်းများ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> <span>-</span></td>
                        </tr>
                        <tr>
                            <td >၉။</td>
                            <td style=' font-weight:bold;'>စည်းကြပ်သည့်ပုဒ်မ</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၇၊၂၈၊၃0 နှင့် ၆၄ တို့အရ </td>
                        </tr>
                        <tr>
                            <td >၁၁။</td>
                            <td style=' font-weight:bold;'>ဝင်ငွေနှစ်(အခွန်ကာလ)</td>
                            <td style=' text-align:center;'>၊</td>
                            <td style=' text-align: left;border-bottom:1.5px dotted black !important;;'> ( 01-04-<span><?php echo $startYear; ?></span> ) မှ ( 31-03-<span><?php echo $endYear; ?></span> )ထိ ကာလ</td>
                        </tr>
                    </table>

                    <p style='text-align:center; font-weight:bold; margin-top:20px;'>
                        <b>ဝင်ငွေခွန်စည်းကြပ်မှုနှင့် ဒဏ်ကြေးငွေ စည်းကြပ်မှု ဆုံးဖြတ်ချက်</b>
                    </p>
                    
                    <?php 
                    if ($os_biz === 'ရေယာဉ်ရောင်းချခြင်း') { 
                    ?>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းဖြစ်သူ( <span style="color:red;" id="os_name"><?php echo $os_name; ?></span> )၏ 
                                <span id="os_plate_no"><?php echo $os_plate_no; ?></span>၊ 
                                  <span id="os_manufacture"><?php echo $os_manufacture; ?></span>၊ 
                                   <span id="os_brand_name"><?php echo $os_brand_name; ?></span>၊ 
                                    <span id="os_build_type"><?php echo $os_build_type; ?></span>၊ 
                                     <span id="os_chassi"><?php echo $os_chassi; ?></span>၊ 
                                      <span id="os_make_year"><?php echo $os_make_year; ?></span> ရောင်းချခြင်းနှင့်ပတ်သက်၍ အခွန်ထမ်းတင်ပြသော မူလတန်ဖိုးအပေါ်စိစစ်ပြီး
                        အခြေပစ္စည်းမှမြတ်စွန်းငွေအပေါ် ပြည်ထောင်စု၏အခွန်အကောက်ဥပဒေ ပုဒ်မ ၂၇ (ခ) နှင့်အညီ စည်းကြပ်မှုဆုံးဖြတ်ချက်အမိန့်အား တစ်ဖက်ပါအတိုင်း ချမှတ်လိုက်သည်-
                        <br><br><br><br><br><br><br>
                    </div>
                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇(အဆက်)</p>

                    <table class="order-table" style="width:70%; margin-left:auto; border:none !important;">
                        <tr style="border:none !important;">
                            <td style="width:70%; text-align:right; padding:3px; border:none !important;">ရေယာဉ်အရောင်းသတ်မှတ်တန်ဖိုး</td>
                            <td style="width:5%; text-align:center; padding:3px; border:none !important;">=</td>
                            <td class="share_valuation_class" style="width:15%; text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></span></td>
                            <td style="width:10%;"></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;color:red;">(နုတ်)ခွင့်ပြုမူလတန်ဖိုး</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_allowable" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important; color:red;"><span  id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_taxable_income" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ပြည်ထောင်စု၏အခွန်ကောက်ဥပဒေပုဒ်မ-၂၇(ခ) အရ ကျသင့်ဝင်ငွေခွန် </td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_income_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_income_tax"><?php echo $os_income_tax; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;color:red;">ပေးသွင်းထားသောကြိုတင်ခွန်</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_advance" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important;color:red;"><span id="os_advance_tax"><?php echo $os_advance_tax; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ထပ်မံပေးဆောင်ရမည့်ဝင်ငွေခွန်</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_tax_to_pay" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important;"><span id="os_tax_to_pay"><?php echo $os_tax_to_pay; ?></span></td>
                            <td></td>
                        </tr>
                    </table>
                    <br><br><br><br><br><br><br>

                    <?php 
                    } else if ($os_biz === 'ရေယာဉ်ဝယ်ယူခြင်း'){ 
                    ?>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းဖြစ်သူ( <span style="color:red;" id="os_name"><?php echo $os_name; ?></span> )၏
                                <span id="os_plate_no"><?php echo $os_plate_no; ?></span>၊ 
                                  <span id="os_manufacture"><?php echo $os_manufacture; ?></span>၊ 
                                   <span id="os_brand_name"><?php echo $os_brand_name; ?></span>၊ 
                                    <span id="os_build_type"><?php echo $os_build_type; ?></span>၊ 
                                     <span id="os_chassi"><?php echo $os_chassi; ?></span>၊ 
                                      <span id="os_make_year"><?php echo $os_make_year; ?></span> ဝယ်ယူခြင်းနှင့်ပတ်သက်၍ အခွန်ထမ်းတင်ပြသော အသုံးပြုသည့်ဝင်ငွေရလမ်းအပေါ်စိစစ်ပြီး
                        စည်းကြပ်မှုမှလွှတ်ကင်းနေသောအပေါ် ပြည်ထောင်စု၏အခွန်အကောက်ဥပဒေ ပုဒ်မ ၂၇ (ခ) နှင့်အညီ စည်းကြပ်မှုဆုံးဖြတ်ချက်အမိန့်အား တစ်ဖက်ပါအတိုင်း ချမှတ်လိုက်သည်-
                        <br><br><br><br><br><br><br>
                    </div>
                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇(အဆက်)</p>

                    <table class="order-table" style="width:70%; margin-left:auto; border:none !important;">
                        <tr style="border:none !important;">
                            <td style="width:70%; text-align:right; padding:3px; border:none !important;">ရေယာဉ်အဝယ်သတ်မှတ်တန်ဖိုး</td>
                            <td style="width:5%; text-align:center; padding:3px; border:none !important;">=</td>
                            <td class="share_valuation_class" style="width:15%; text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></span></td>
                            <td style="width:10%;"></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;color:red;">ခွင့်ပြုဝင်ငွေလမ်း</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_allowable" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important; color:red;"><span  id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">စည်းကြပ်မှုမှ လွှတ်ကင်းနေသောဝင်ငွေ</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_taxable_income" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ပြည်ထောင်စု၏အခွန်ကောက်ဥပဒေပုဒ်မ-၂၅ အရ ကျသင့်ဝင်ငွေခွန် </td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_income_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_income_tax"><?php echo $os_income_tax; ?></span></td>
                            <td></td>
                        </tr>
                        
                    </table>
                    <br><br><br><br><br><br><br><br><br><br><br>
                    <?php 
                    }if ($os_biz === 'မော်တော်ယာဉ်ရောင်းချခြင်း') { 
                    ?>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းဖြစ်သူ( <span style="color:red;" id="os_name"><?php echo $os_name; ?></span> )၏
                                <span id="os_plate_no"><?php echo $os_plate_no; ?></span>၊ 
                                  <span id="os_manufacture"><?php echo $os_manufacture; ?></span>၊ 
                                   <span id="os_brand_name"><?php echo $os_brand_name; ?></span>၊ 
                                    <span id="os_build_type"><?php echo $os_build_type; ?></span>၊ 
                                     <span id="os_chassi"><?php echo $os_chassi; ?></span>၊ 
                                      <span id="os_make_year"><?php echo $os_make_year; ?></span> မော်တော်ယာဉ်ရောင်းချခြင်းနှင့်ပတ်သက်၍ အခွန်ထမ်းတင်ပြသော မူလတန်ဖိုးအပေါ်စိစစ်ပြီး
                        အခြေပစ္စည်းမှမြတ်စွန်းငွေအပေါ် ပြည်ထောင်စု၏အခွန်အကောက်ဥပဒေ ပုဒ်မ ၂၇ (ခ) နှင့်အညီ စည်းကြပ်မှုဆုံးဖြတ်ချက်အမိန့်အား တစ်ဖက်ပါအတိုင်း ချမှတ်လိုက်သည်-
                        <br><br><br><br><br><br><br>
                    </div>
                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇(အဆက်)</p>

                    <table class="order-table" style="width:70%; margin-left:auto; border:none !important;">
                        <tr style="border:none !important;">
                            <td style="width:70%; text-align:right; padding:3px; border:none !important;">မော်တော်ယာဉ်အရောင်းသတ်မှတ်တန်ဖိုး</td>
                            <td style="width:5%; text-align:center; padding:3px; border:none !important;">=</td>
                            <td class="share_valuation_class" style="width:15%; text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></span></td>
                            <td style="width:10%;"></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;color:red;">(နုတ်)ခွင့်ပြုမူလတန်ဖိုး</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_allowable" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important; color:red;"><span  id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_taxable_income" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ပြည်ထောင်စု၏အခွန်ကောက်ဥပဒေပုဒ်မ-၂၇(ခ) အရ ကျသင့်ဝင်ငွေခွန် </td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_income_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_income_tax"><?php echo $os_income_tax; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;color:red;">ပေးသွင်းထားသောကြိုတင်ခွန်</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_advance" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important;color:red;"><span id="os_advance_tax"><?php echo $os_advance_tax; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ထပ်မံပေးဆောင်ရမည့်ဝင်ငွေခွန်</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_tax_to_pay" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important;"><span id="os_tax_to_pay"><?php echo $os_tax_to_pay; ?></span></td>
                            <td></td>
                        </tr>
                    </table>
                    <br><br><br><br><br><br><br>

                    <?php 
                    } else if ($os_biz === 'မော်တော်ယာဉ်ဝယ်ယူခြင်း'){ 
                    ?>
                    <div style="text-align:justify; line-height: 1.9; text-indent: 50px;">
                        အခွန်ထမ်းဖြစ်သူ( <span style="color:red;" id="os_name"><?php echo $os_name; ?></span> )၏
                                <span id="os_plate_no"><?php echo $os_plate_no; ?></span>၊ 
                                  <span id="os_manufacture"><?php echo $os_manufacture; ?></span>၊ 
                                   <span id="os_brand_name"><?php echo $os_brand_name; ?></span>၊ 
                                    <span id="os_build_type"><?php echo $os_build_type; ?></span>၊ 
                                     <span id="os_chassi"><?php echo $os_chassi; ?></span>၊ 
                                      <span id="os_make_year"><?php echo $os_make_year; ?></span> မော်တော်ယာဉ်ဝယ်ယူခြင်းနှင့်ပတ်သက်၍ အခွန်ထမ်းတင်ပြသော အသုံးပြုသည့်ဝင်ငွေရလမ်းအပေါ်စိစစ်ပြီး
                        စည်းကြပ်မှုမှလွှတ်ကင်းနေသောအပေါ် ပြည်ထောင်စု၏အခွန်အကောက်ဥပဒေ ပုဒ်မ ၂၇ (ခ) နှင့်အညီ စည်းကြပ်မှုဆုံးဖြတ်ချက်အမိန့်အား တစ်ဖက်ပါအတိုင်း ချမှတ်လိုက်သည်-
                        <br><br><br><br><br><br><br>
                    </div>
                    <p style='text-align:right; font-size:14px;'>ပတခ(ဝင)-၀၄-၀၇(အဆက်)</p>

                    <table class="order-table" style="width:70%; margin-left:auto; border:none !important;">
                        <tr style="border:none !important;">
                            <td style="width:70%; text-align:right; padding:3px; border:none !important;">မော်တော်ယာဉ်အဝယ်သတ်မှတ်တန်ဖိုး</td>
                            <td style="width:5%; text-align:center; padding:3px; border:none !important;">=</td>
                            <td class="share_valuation_class" style="width:15%; text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></span></td>
                            <td style="width:10%;"></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;color:red;">ခွင့်ပြုဝင်ငွေလမ်း</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_allowable" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px solid black !important; color:red;"><span  id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">စည်းကြပ်မှုမှ လွှတ်ကင်းနေသောဝင်ငွေ</td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_taxable_income" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></span></td>
                            <td></td>
                        </tr>
                        <tr style="border:none !important;">
                            <td style="text-align:right; padding:3px; border:none !important;">ပြည်ထောင်စု၏အခွန်ကောက်ဥပဒေပုဒ်မ-၂၅ အရ ကျသင့်ဝင်ငွေခွန် </td>
                            <td style="text-align:center; padding:3px; border:none !important;">=</td>
                            <td id="$os_income_tax" style="text-align:right; padding:3px; font-weight:bold; border-bottom:1.5px dotted black !important;"><span id="os_income_tax"><?php echo $os_income_tax; ?></span></td>
                            <td></td>
                        </tr>
                        
                    </table>
                    <br><br><br><br><br><br><br><br><br>
                    <?php 
                    } // if-else အပိတ်
                    ?>
                    <table style='width:100%; margin-top:40px;'>
                        <tr>
                            <td style='width:30%; text-align:center;'></td>
                            <td style='width:20%; text-align:center;'></td>
                            <td style='width:50%; text-align:center; line-height: 1.8;'>
                                တာဝန်ခံအရာရှိ<br>ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                <span id="os_township"><?php echo $os_township; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                    <br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                </div>
            </div>
            <div class="no-print-bottoms no-print">
                <button type="button" class="btn btn-primary" onclick="window.print()">Print ထုတ်မည်</button>
                <button type="button" class="btn btn-secondary" onclick="closeAndReturnToDemandList()">ပိတ်မည်</button>
            </div>
        </div>
    </div>
</div>

<script>
function openForm0407() {
    var myModalEl = document.getElementById('orderSheetModal'); 
    var modal = bootstrap.Modal.getInstance(myModalEl) || new bootstrap.Modal(myModalEl);
    // modal.show(); //


}

// အကယ်၍ string ဖြစ်နေပြီး ကော်မာများ ပါဝင်နေပါက ဖယ်ရှား၍ ကိန်းပြည့်ပြောင်းရန် Helper
function parseToNumber(val) {
    if (!val) return 0;
    let cleanVal = String(val).replace(/,/g, ''); 
    return parseInt(cleanVal) || 0;
}
function closeAndReturnToDemandList() {
    // 1️⃣ လက်ရှိဖွင့်ထားသော #calculateModal ကို ပိတ်ခြင်း
    try {
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var myModalEl = document.getElementById('formshareModal');
            var modal = bootstrap.Modal.getInstance(myModalEl) || new bootstrap.Modal(myModalEl);
            modal.hide();
        }
        
        if (typeof jQuery !== 'undefined') {
            jQuery('#formshareModal').modal('hide');
            jQuery('.modal-backdrop').remove();
            jQuery('body').removeClass('modal-open').css('overflow', 'auto');
        }
    } catch (e) {
        console.log("Modal ပိတ်ရာတွင် အမှားရှိသည်: ", e);
    }
    
    // 2️⃣ မိခင်စာမျက်နှာ (capital_demand_list.php) ထဲက formsModal2 ကို လမ်းကြောင်းမှန်ဖြင့် ပြန်လှမ်းဖွင့်ခြင်း
    setTimeout(function() {
        if (window.opener && !window.opener.closed) {
            // အကယ်၍ Window အသစ် (Pop-up) ဖြင့် ပွင့်နေပါက
            try {
                if (window.opener.jQuery && window.opener.jQuery('#formsModal3').length) {
                    window.opener.jQuery('#formsModal3').modal('show');
                } else if (window.opener.bootstrap && window.opener.bootstrap.Modal) {
                    var parentModal = new window.opener.bootstrap.Modal(window.opener.document.getElementById('formsModal3'));
                    parentModal.show();
                }
            } catch (err) {
                console.log("Parent modal ဖွင့်မရပါ: ", err);
            }
            window.close(); 
        } else {
            /* 🎯 ဤနေရာတွင် လမ်းကြောင်းကို အစ်ကိုကြီးပြောသည့်အတိုင်း အပြင် main folder သို့ ထွက်ရန် ../ ဖြင့် ပြင်ဆင်ထားပါသည် */
            if (typeof jQuery !== 'undefined' && jQuery('#formsModal3').length) {
                jQuery('#formsModal3').modal('show');
            } else {
                // forms_housing folder ထဲမှ အပြင်သို့တစ်ဆင့်ထွက်ပြီး capital_demand_list.php သို့ သွားခြင်း
                window.location.href = '../vehicle_demand_list.php?openModal=formsModal2';
            }
        }
    }, 300); 
}



</script>
