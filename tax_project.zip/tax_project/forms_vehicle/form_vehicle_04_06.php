<?php
// ၁။ Session စတင်ခြင်း
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၂။ DB Config ချိတ်ဆက်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}



// ၃။ Session ထဲက User ID ကိုယူပြီး user_register မှ other (စာအမှတ်အတွက်) ဆွဲထုတ်ခြင်း
$u_id = $_SESSION['user_id'] ?? 0;
$user_other_info = ""; 

if ($u_id > 0) {
    $user_query = "SELECT other FROM user_register WHERE id = '$u_id'";
    $user_result = mysqli_query($conn, $user_query);
    if ($user_result && $user_row = mysqli_fetch_assoc($user_result)) {
        $user_other_info = str_replace(array("\r", "\n", "'", '"'), '', $user_row['other']);
    }
}

// ၄။ URL မှ ပါလာသော ID ဖြင့် မော်တော်ယာဉ်ဒေတာ ဆွဲထုတ်ခြင်း
$vehicle_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$v_data = [];

if ($vehicle_id > 0) {
    // vehicledata ထဲမှ သက်ဆိုင်ရာ ID အလိုက် အချက်အလက်အားလုံး ဆွဲထုတ်ခြင်း
    $v_query = "SELECT * FROM vehicledata WHERE id = '$vehicle_id'";
    $v_result = mysqli_query($conn, $v_query);
    if ($v_result && mysqli_num_rows($v_result) > 0) {
        $v_data = mysqli_fetch_assoc($v_result);
    }
}

// ဂဏန်းများကို မြန်မာလိုပြောင်းပေးမည့် Function
function toMyanmarNumber($num) {
    if (empty($num)) return '';
    $en = array('0','1','2','3','4','5','6','7','8','9');
    $mm = array('၀','၁','၂','၃','၄','၅','၆','၇','၈','၉');
    return str_replace($en, $mm, $num);
}

// 🎯 ၅။ notify_date ကို ခုနှစ်၊ လ၊ ရက် ခွဲထုတ်ခြင်းစနစ်
$or_year = '....'; 
$or_year_short = '..'; 
$or_month = '..........'; 
$or_day = '....';

// ဒေတာဘေ့စ်ထဲရှိ notify_date အား စစ်ဆေးခြင်း
$target_date = $v_data['notified_date'] ?? ''; 

if (!empty($target_date) && $target_date != '0000-00-00') {
    $date_parts = explode('-', explode(' ', $target_date)[0]);
    if (count($date_parts) == 3) {
        $full_year = $date_parts[0]; // ဥပမာ - 2026
        $or_year = toMyanmarNumber($full_year);
        $or_year_short = toMyanmarNumber(substr($full_year, -2)); // နောက်ဆုံး ၂ လုံး (ဥပမာ - ၂၆)
        
        $mm_months = array('', 'ဇန်နဝါရီ', 'ဖေဖော်ဝါရီ', 'မတ်', 'ဧပြီ', 'မေ', 'ဇွန်', 'ဇူလိုင်', 'သြဂုတ်', 'စက်တင်ဘာ', 'အောက်တိုဘာ', 'နိုဝင်ဘာ', 'ဒီဇင်ဘာ');
        $or_month = $mm_months[intval($date_parts[1])];
        $or_day = toMyanmarNumber(intval($date_parts[2])); // သုညဆွဲဖြုတ်ပြီး မြန်မာမှုပြုခြင်း
    }
}

// ၂။ URL ကနေ id ကို လှမ်းယူခြင်း
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$taxpayer_name = "";
$business_type = "";
$address = "";
$township_name = "";

if ($id > 0) {
    // 🎯 ၃။ ဇယားအမည်ကို 'taxpayers_table' အစား 'sakalakahdata' သို့ ပြောင်းလဲထားပါသည်
    $sql = "SELECT taxpayer_name, business_type, township_name, address FROM vehicledata WHERE id = $id";
    $result = $conn->query($sql);
    
    if ($result && $row = $result->fetch_assoc()) {
        $taxpayer_name = $row['taxpayer_name'];
        $business_type = $row['business_type'];
        $address = $row['address'];
        $township_name = $row['township_name'];
    }
}
?>

<style>
/* 🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် စာရွက်အစစ်ကဲ့သို့ အလယ်တွင် မြင်ရစေရန်) */
#form0406Modal .modal-dialog {
    max-width: 210mm; 
    margin: 30px auto;
}

#form0406Modal .modal-content {   
    background-color: #525659; /* PDF Viewer ကဲ့သို့ နောက်ခံမီးခိုးရောင် */
    border: 1px solid rgba(0,0,0,0.2);
    box-shadow: 0 5px 15px rgba(0,0,0,0.5);
    border-radius: 6px;
}

#form0406Modal .modal-body {
    padding: 0px !important;
    overflow-x: hidden;
}

/* 📄 စာရွက် Background စတိုင် (Screen ပေါ်တွင် စာရွက်ဖြူဖြူလေး ပေါ်နေစေရန်) */
.print-container { 
    background: #ffffff;
    width: 210mm;
    min-height: 297mm;
    margin: 20px auto; /* အလယ်ကွက်တိ ချခြင်း */
    /* 🎯 Padding အစီအစဉ်: အပေါ် (20mm)၊ ညာ (15mm)၊ အောက် (20mm)၊ ဘယ် (30mm) 👈 ချဲ့လိုက်ပါပြီ */
    padding: 20mm 10mm 20mm 20mm !important; 
    box-sizing: border-box;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.3); /* စာရွက်ဘေးအရိပ် */
}

/* 📊 ဇယားကွက် ပုံစံများ */
.main-content-table2 {
    width: 100% !important;
    margin-bottom: 5px;
    border-collapse: collapse;
}

.main-content-table2 td {
    padding: 2px 4px !important;
    font-size: 15px;
    vertical-align: middle;
}

/* 🖨️ PRINT စနစ်အတွက် သီးသန့် CSS */
@media print {
    @page {
        size: A4 portrait;
        margin: 8mm 10mm 8mm 12mm;
    }

    html, body {
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #fff !important;
    }

    body:has(#form0406Modal.show) > *:not(#form0406Modal) {
        display: none !important;
    }

    #form0406Modal .modal-header,
    #form0406Modal .modal-footer,
    #form0406Modal .no-print,
    #form0406Modal .btn,
    #form0406Modal .btn-close {
        display: none !important;
    }

    #form0406Modal {
        position: static !important;
        left: auto !important;
        top: auto !important;
        width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: visible !important;
    }

    #form0406Modal .modal-dialog,
    #form0406Modal .modal-content,
    #form0406Modal .modal-body {
        width: 100% !important;
        max-width: 100% !important;
        height: auto !important;
        min-height: 0 !important;
        margin: 0 !important;
        padding: 0 !important;
        border: none !important;
        box-shadow: none !important;
        background: transparent !important;
        overflow: visible !important;
    }

    #form0406Modal .print-container {
        width: 100% !important;
        max-width: 100% !important;
        min-height: 0 !important;
        height: auto !important;
        margin: 0 !important;
        padding: 6mm 8mm 4mm 20mm !important;
        border: none !important;
        box-shadow: none !important;
        page-break-after: avoid !important;
        box-sizing: border-box !important;
    }
}
</style>

<div class="modal fade" id="form0406Modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
         
            <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: none;">
                    <h5 class="modal-title" style="font-size: 16px; font-weight: bold; margin: 0; color: white;">
                        ၀၄-၀၆ သတင်းအချက်အလက်များပေးပို့ရန်အကြောင်းကြားစာ ထုတ်ယူရန်
                    </h5>
                    <button type="button" class="close-modal-btn" onclick="window.location.href='../vehicle_demand_list.php';" style="background: none; border: none; color: #ff4d4d; font-size: 26px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                    </button>
            </div>
            <div class="modal-body" id="printableSheet">
                <div class="print-container">
                    <table style="border: 2px solid #000 !important; text-align:center; font-size:15px; width:100%; line-height:25px">
                        <tr>
                            <td style='border: 0px solid black; padding:5px'>
                                ၂၀၀၈ ခုနှစ်၊ ပြည်ထောင်စုသမ္မတမြန်မာနိုင်ငံတော် ဖွဲ့စည်းပုံအခြေခံဥပဒေပုဒ်မ ၃၈၉ အရ နိုင်ငံသားတိုင်းသည်<br>ဥပဒေအရ ပေးဆောင်ရမည့် အခွန်အကောက်များကိုပေးဆောင်ရန် တာဝန်ရှိသည်။
                            </td>
                        </tr>
                    </table>

                    <p style='text-align:right; font-size:15px; padding:5px'>ပတခ(ဝင)-၀၄-၀၆</p>

                    <div style="text-align:center; font-weight:bold; margin-bottom:10px;">
                        အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှု ဥပဒေပုဒ်မ ၂၆၊ ပုဒ်မခွဲ(က)၊ ပုဒ်မခွဲငယ်(၁)အရ <br>
                        သတင်းအချက်အလက်များပေးပို့ရန်အကြောင်းကြားစာ 
                    </div>
                    <table style='width: 100%; font-size: 15px; margin-top: 10px;'>
                        <tr>
                            <td style='text-align:right; width:60%'>
                                စာအမှတ်၊ ပတခ/<?php echo htmlspecialchars($user_other_info ?: '......'); ?>/ဝငခ/၂၀<?php echo $or_year_short; ?>(&emsp;&emsp;&emsp;)
                            </td>
                        </tr>
                        <tr>
                            <td style='text-align:right;'>ရက်&ensp;&ensp;စွဲ၊ 
                                <strong>
                                    <span><?php echo $or_year; ?></span> ခုနှစ်၊ &ensp;
                                    <span><?php echo $or_month; ?></span> &ensp; လ &ensp;
                                    <span><?php echo $or_day; ?></span> &ensp;ရက်
                                </strong> 
                            </td>
                        </tr>
                    </table>

                    
                    <div style="margin-left: 0px; text-align:left; margin-top:10px;">
                        သို့<br>
                        <span style='padding-left:70px;'></span><strong><span id="m0405_name"><?php echo htmlspecialchars($v_data['taxpayer_name'] ?? ''); ?></span></strong> <br>
                        <span style='padding-left:70px;'></span><strong><span id="m0405_address"><?php echo htmlspecialchars($v_data['address'] ?? ''); ?></span></strong> <br>
                        <span style='padding-left:70px;'></span><strong><span id="m0405_biz"><?php echo htmlspecialchars($v_data['business_type'] ?? ''); ?></span></strong> 
                    </div>

                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၁။<span style = 'padding-left:46px;'>လူကြီးမင်း၏ <strong><?php echo htmlspecialchars($v_data['business_type'] ?? ''); ?></strong> လုပ်ငန်းအပေါ်တွင် ဝင်ငွေခွန်စည်းကြပ်သည့် 
                        ကိစ္စနှင့်ပတ်သက်၍ လူကြီးမင်းထံမှ သတင်းအချက်အလက်များကို ရရှိစစ်ဆေးရန် လိုအပ်ပါသဖြင့် ( <span id="m0405_appDate"><?php echo htmlspecialchars($v_data['appointment_date'] ?? ''); ?></span></strong> )
                        ရက်နေ့၊ (၁၀:၀၀) နာရီအချိန် သို့မဟုတ် ယင်းကာလမတိုင်မီတွင် အောက်တွင်ဖော်ပြထားသည်တို့ကို ဤရုံးသို့ ပေးပို့ရန် အကြောင်းကြားပါသည်။ 
                    </div>
                    <div style="margin-top:15px; padding:5px; text-align:justify;">
                        ၂။<span style = 'padding-left:46px;'></span>ဤအကြောင်းကြားစာအတိုင်း လိုက်နာဆောင်ရွက်ရန် ပျက်ကွက်ပါက  အခွန်ဆိုင်ရာစီမံအုပ်ချုပ်မှုဥပဒေ 
                        ပုဒ်မ ၇၀/၇၃ တို့အရ ဒဏ်ငွေတပ်ရိုက်ခြင်း၊  ပုဒ်မ ၇၈ အရ အရေးယူခြင်းတို့ကိုခံရဖွယ်ရှိကြောင်း အသိပေးအပ်ပါသည်။
                    </div>
                     <p style = 'border:0px solid; text-align:center;font-size:15px;line-height:24px'><span style = 'padding-left:44px'><strong> ပေးပို့ရန် သတင်းအချက်အလက်အထောက်အထား စာရွက်စာတမ်းများ</strong ></span></p >

                    <p style = 'border:0px solid; text-align:left;font-size:15px;line-height:24px'>
                    <span style = 'padding-left:70px;'></span> (က) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span> ( ခ ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span> ( ဂ ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span > (ဃ) <span style = 'padding-left:30px;'> ........................................</span><br/>
                    
                    <span style = 'padding-left:70px;'></span> ( င ) <span style = 'padding-left:30px;'> ........................................ </span><br/>

                    <span style = 'padding-left:70px;'></span > ( စ ) <span style = 'padding-left:30px;'> ........................................ </span><br/></p>  

                    <table style='width:100%; margin-top:30px;'>
                        <tr>
                            <td style='width:50%; padding-left:50px'>ရုံးတံဆိပ်</td>
                            <td style='text-align:center; font-size: 16px; line-height: 1.8;'>
                                တာဝန်ခံအရာရှိ<br>
                                ပြည်တွင်းအခွန်များဦးစီးဌာန<br>
                                
                                    <span id="m0405_township_direct">
                                        <?php echo !empty($township_name) ? htmlspecialchars($township_name) : '............'; ?>
                                    </span>အခွန်ဦးစီးဌာနမှူးရုံး
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div style="padding-left:540px; padding-top:15px" class="modal-footer no-print d-flex justify-content-end align-items-center gap-2" style="width: 100%; border-top: 1px solid #dee2e6; padding: 15px; ">

                <button type="button" class="btn px-4" onclick="window.print()" 
                        style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                    <i class="fa fa-print"></i> Print ထုတ်မည်
                </button>
                <button type="button" class="btn px-4" 
                        onclick="window.location.href='../vehicle_demand_list.php?openModal=formsModal2';" 
                        style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                    ပိတ်မည်
                </button>
            </div>
        </div>
    </div>
</div>


