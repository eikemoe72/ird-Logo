<?php
include 'db_config.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start(); 
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 🔍 စမ်းသပ်ရန် Debug Code (Data ပါမလာပါက အဖြူရောင် Screen ဖြင့် ပြပေးပါလိမ့်မည်)
    if (!isset($_POST['investigation_value'])) {
        die("သတိပေးချက် - Form ထဲကနေ investigation_value ဆိုတဲ့ name နဲ့ data ပါမလာပါဗျာ။ HTML ဘက်က name ကို ပြန်စစ်ပေးပါ။");
    } else {
        // ပါလာတဲ့ တန်ဖိုးကို Screen ပေါ်မှာ ထုတ်ပြကြည့်ခြင်း
        // echo "ပါလာသော တန်ဖိုးမှာ: " . $_POST['investigation_value']; die();
    }

    // ၄။ HTML Form က ပို့လိုက်သော name="id" သို့မဟုတ် name="edit_id" ကို ကျိန်းသေဖမ်းယူခြင်း
    $edit_id = !empty($_POST['edit_id']) ? intval($_POST['edit_id']) : (!empty($_POST['id']) ? intval($_POST['id']) : null);

    // စာသားအချက်အလက်များ
    $case_number        = mysqli_real_escape_string($conn, $_POST['case_number'] ?? '');
    $tax_year           = mysqli_real_escape_string($conn, $_POST['tax_year'] ?? '');
    $officer_name       = mysqli_real_escape_string($conn, $_POST['officer_name'] ?? '');
    $officer_rank       = mysqli_real_escape_string($conn, $_POST['officer_rank'] ?? $_POST['rank_'] ?? '');
    $officer_rank       = mb_substr(trim($officer_rank), 0, 30, 'UTF-8');
    $region             = mysqli_real_escape_string($conn, $_POST['region'] ?? '');
    
    // 🎯 ✅ share_form.php က ပို့လိုက်သော Form $_POST ဒေတာများဖြင့် တိုက်ရိုက်ပြောင်းလဲဖမ်းယူခြင်း
    $state_name         = mysqli_real_escape_string($conn, $_POST['state_name'] ?? ''); 
    $township_name      = mysqli_real_escape_string($conn, $_POST['township_name'] ?? ''); 
    
    $taxpayer_name      = mysqli_real_escape_string($conn, $_POST['taxpayer_name'] ?? '');
    $nrc_no             = mysqli_real_escape_string($conn, $_POST['nrc_no'] ?? ''); 
    $gir_type           = mysqli_real_escape_string($conn, $_POST['gir_type'] ?? '');
    $gir_no             = mysqli_real_escape_string($conn, $_POST['gir_no'] ?? '');
    $address            = mysqli_real_escape_string($conn, $_POST['address'] ?? '');
    $business_type      = mysqli_real_escape_string($conn, $_POST['business_type'] ?? '');
    $plate_no       = mysqli_real_escape_string($conn, $_POST['plate_no'] ?? '');
    $manufacture               = mysqli_real_escape_string($conn, $_POST['manufacture'] ?? '');
    $brand_name        = mysqli_real_escape_string($conn, $_POST['brand_name'] ?? '');
    $build_type          = mysqli_real_escape_string($conn, $_POST['build_type'] ?? '');
    $chassi               = mysqli_real_escape_string($conn, $_POST['chassi'] ?? '');
    $make_year        = mysqli_real_escape_string($conn, $_POST['make_year'] ?? '');

    $chalan_no       = mysqli_real_escape_string($conn, $_POST['chalan_no'] ?? '');
    $it_demand_no       = mysqli_real_escape_string($conn, $_POST['it_demand_no'] ?? '');
    
    $investigation_value    = mysqli_real_escape_string($conn, $_POST['investigation_value'] ?? '');
    $source_of_income       = mysqli_real_escape_string($conn, $_POST['source_of_income'] ?? '');
    $investigation          = mysqli_real_escape_string($conn, $_POST['investigation'] ?? '');

    // 🎯 ရက်စွဲများအတွက် ပိုမိုစိတ်ချရသော Helper Function
    function formatDateForSQL($conn, $value) {
        $trimmed = trim($value);
        if (empty($trimmed) || $trimmed === '-/-/-' || $trimmed === '0000-00-00') {
            return "NULL";
        }
        return "'" . mysqli_real_escape_string($conn, $trimmed) . "'";
    }
    
    // 🎯 ပြင်ဆင်ချက် - ရက်စွဲများအားလုံးကို single quote အပြင်ကနေ မအုပ်တော့ဘဲ dynamic သတ်မှတ်ခြင်း
    $sale_date             = formatDateForSQL($conn, $_POST['sale_date'] ?? '');
    $notified_date          = formatDateForSQL($conn, $_POST['notified_date'] ?? '');
    $appointment_date       = formatDateForSQL($conn, $_POST['appointment_date'] ?? '');
    $appearance_date        = formatDateForSQL($conn, $_POST['appearance_date'] ?? '');
    $it_demand_date         = formatDateForSQL($conn, $_POST['it_demand_date'] ?? '');
    $chalan_date            = formatDateForSQL($conn, $_POST['chalan_date'] ?? '');

    // ကိန်းဂဏန်းများသန့်စင်ခြင်း
    function cleanNumber($val) {
        $clean = preg_replace('/[^\d.]/', '', $val);
        return (empty($clean)) ? 0 : floatval($clean);
    }

    $proposal_value     = cleanNumber($_POST['proposal_value'] ?? 0);
    $valuation_value    = cleanNumber($_POST['valuation_value'] ?? 0);
    $allowable_expenses = cleanNumber($_POST['allowable_expenses'] ?? 0);
    $taxable_income     = cleanNumber($_POST['taxable_income'] ?? 0);
    $income_tax         = cleanNumber($_POST['income_tax'] ?? 0);
    $advance_tax        = cleanNumber($_POST['advance_tax'] ?? 0);
    $tax_to_pay         = cleanNumber($_POST['tax_to_pay'] ?? 0);
    $penalty_tax        = cleanNumber($_POST['penalty_tax'] ?? 0);
    $total_tax          = cleanNumber($_POST['total_tax'] ?? 0);
    $paid_amount        = cleanNumber($_POST['paid_amount'] ?? 0);

    // ၅။ $edit_id ကိန်းဂဏန်းအခြေအနေအပေါ်မူတည်ပြီး ခွဲခြားခြင်း
    if ($edit_id === null || $edit_id <= 0) {
        // 🎯 INSERT MODE (Table: vehicledata)
        $sql = "INSERT INTO vehicledata (
            case_number, tax_year, officer_name, officer_rank, region, state_name, township_name, taxpayer_name, 
            nrc_no, gir_type, gir_no, address, business_type, plate_no, manufacture, brand_name, build_type, chassi, 
            make_year, sale_date, proposal_value, valuation_value, allowable_expenses, taxable_income, 
            income_tax, advance_tax, tax_to_pay, penalty_tax, total_tax, paid_amount, chalan_no, chalan_date, 
            notified_date, appointment_date, appearance_date, it_demand_no, it_demand_date, investigation_value, 
            source_of_income, investigation
        ) VALUES (
            '$case_number', '$tax_year', '$officer_name', '$officer_rank', '$region', '$state_name', '$township_name', '$taxpayer_name',
            '$nrc_no', '$gir_type', '$gir_no', '$address', '$business_type', '$plate_no', '$manufacture', '$brand_name', '$build_type', '$chassi',
            '$make_year', $sale_date, '$proposal_value', '$valuation_value', '$allowable_expenses', '$taxable_income', 
            '$income_tax', '$advance_tax', '$tax_to_pay', '$penalty_tax', '$total_tax', '$paid_amount', '$chalan_no', $chalan_date, 
            $notified_date, $appointment_date, $appearance_date, '$it_demand_no', $it_demand_date, '$investigation_value', 
            '$source_of_income', '$investigation'
        )";
        $msg = "အချက်အလက်အသစ်ကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ။";
    } else {
        // 🎯 UPDATE MODE (Table နာမည်ကို vehicledata သို့ ပြောင်းလဲပြင်ဆင်ပြီး)
        $sql = "UPDATE vehicledata SET 
                    case_number='$case_number', 
                    tax_year='$tax_year',  
                    officer_name='$officer_name',
                    officer_rank='$officer_rank', 
                    region='$region',  
                    state_name='$state_name',
                    township_name='$township_name', 
                    taxpayer_name='$taxpayer_name', 
                    nrc_no='$nrc_no',
                    gir_type='$gir_type',
                    gir_no='$gir_no', 
                    address='$address', 
                    business_type='$business_type', 
                    plate_no='$plate_no', 
                    manufacture='$manufacture', 
                    brand_name='$brand_name',
                    build_type='$build_type', 
                    chassi='$chassi', 
                    make_year='$make_year', 
                    sale_date=$sale_date,
                    proposal_value='$proposal_value', 
                    valuation_value='$valuation_value', 
                    allowable_expenses='$allowable_expenses',
                    taxable_income='$taxable_income',
                    income_tax='$income_tax',
                    advance_tax='$advance_tax', 
                    tax_to_pay='$tax_to_pay',
                    penalty_tax='$penalty_tax', 
                    total_tax='$total_tax', 
                    paid_amount='$paid_amount', 
                    chalan_no='$chalan_no', 
                    chalan_date=$chalan_date,
                    notified_date=$notified_date, 
                    appointment_date=$appointment_date,
                    appearance_date=$appearance_date, 
                    it_demand_no='$it_demand_no',
                    it_demand_date=$it_demand_date,
                    investigation_value='$investigation_value',
                    source_of_income='$source_of_income', 
                    investigation='$investigation'
                WHERE id = $edit_id"; 
        $msg = "အချက်အလက်များကို အောင်မြင်စွာ ပြင်ဆင်ပြီးပါပြီ။";
    }

    // Query ကို Run ခြင်း
    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('$msg');
                window.location.href = 'vehicle_demand_list.php'; 
              </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>