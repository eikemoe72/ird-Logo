<?php
session_start();
include 'db_config.php';

$id = $_GET['id'] ?? '';
$return_page = $_GET['return'] ?? '';
if ($return_page !== 'CT1_Demand_List.php') {
    $return_page = '';
}
$search_case = $_GET['search_case'] ?? ''; 
$data = []; 
$next_case_no = 1; 
$email = ''; // အသစ်အတွက် ကြိုတင်ကြေညာခြင်း

// =========================================================================
// ၁။ Login User ရဲ့ Data ကို ယူခြင်း
// =========================================================================
$login_user_data = [];
$state_name = "ပြည်နယ်/တိုင်း";
$township_name = "မြို့နယ်အခွန်ဦးစီးဌာနမှူးရုံး";
$officer_name = '';
$rank_ = '';
$region = '';

if (isset($_SESSION['user_name'])) {
    $current_user = $_SESSION['user_name'];
    $query = "SELECT `state_name`, `township_name`, `officer_name`, `rank_`, `region` FROM `user_register` WHERE `user_name` = '$current_user'"; 
    $result = $conn->query($query);
    if ($result && $row = $result->fetch_assoc()) {
        $state_name   = $row['state_name'];    
        $township_name = $row['township_name']; 
        $officer_name  = $row['officer_name']; // 💡 ဒီနေရာတွင် Session မှ အခွန်မှူးအမည်ကို တိုက်ရိုက်ယူပါ
        $rank_         = $row['rank_']; 
        $region        = $row['region'];
        $login_user_data = $row; 
    }
}

// 💡 မြို့နယ်အလိုက် Case Number ကို ခွဲခြားစစ်ထုတ်ရန် SQL Condition တည်ဆောက်ခြင်း
$loc_cond = "";
if (!empty($state_name) && $state_name !== "ပြည်နယ်/တိုင်း" && !empty($township_name) && $township_name !== "မြို့နယ်အခွန်ဦးစီးဌာနမှူးရုံး") {
    $loc_cond = " AND `state_name` = '$state_name' AND `township_name` = '$township_name'";
}

// =========================================================================
// ၂။ ပြင်ဆင်ရန် (Edit Mode) - ဤနေရာတွင် ဒေတာအားလုံးကို တစ်ကြိမ်တည်း ကွက်တိ ဆွဲထုတ်မည်
// =========================================================================
if (!empty($id)) {
    $query = "SELECT * FROM regular_data WHERE id = " . intval($id);
    $result = $conn->query($query);
    if ($result && $row = $result->fetch_assoc()) {
        $data = $row;
        $next_case_no = $row['case_number'];
        $case_number = $row['case_number'];
        
        // ရာထူးနှင့် အရာရှိအမည်ကို လက်ရှိ Login ဒေတာယူမည်
        $officer_name = !empty($login_user_data['officer_name']) ? $login_user_data['officer_name'] : $row['officer_name'];
        $rank_        = !empty($login_user_data['rank_']) ? $login_user_data['rank_'] : $row['rank_'];
        $region       = !empty($login_user_data['region']) ? $login_user_data['region'] : $row['region'];
        $email        = $row['email'] ?? ''; 
    }
}
// ၃။ Search Mode (အမှုတွဲဟောင်းကို ရှာဖွေလျှင်)
elseif (!empty($search_case)) {
    $stmt = $conn->prepare("SELECT * FROM regular_data WHERE case_number = ? $loc_cond LIMIT 1");
    $stmt->bind_param("s", $search_case);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $data = $row;
        $email = $row['email'] ?? '';
        if (!empty($row['taxYear'])) {
            $y = explode('-', $row['taxYear']);
            $data['rowYear1'] = ((int)$y[0] - 2) . "-" . ((int)$y[1] - 2);
            $data['rowYear2'] = ((int)$y[0] - 1) . "-" . ((int)$y[1] - 1);
            $data['rowYear3'] = $row['taxYear'];
            $data['taxYear'] = ((int)$y[0] + 1) . "-" . ((int)$y[1] + 1);
        }
        
        // 🛠 ပြင်ဆင်ချက် ၁ - ရှာဖွေမှုအပြီး Next Case No ကို မိမိမြို့နယ်အလိုက်သာ MAX ယူရေတွက်ခြင်း
        $res_max = $conn->query("SELECT MAX(CAST(case_number AS UNSIGNED)) as last_case FROM regular_data WHERE 1=1 $loc_cond");
        $next_case_no = (($res_max->fetch_assoc())['last_case'] ?? 0) + 1;
    }
}
// ၄။ New Case Mode
else {
    // 🛠 ပြင်ဆင်ချက် ၂ - အသစ်ဖွင့်လျှင် Next Case No ကို မိမိမြို့နယ်အလိုက်သာ MAX ယူရေတွက်ခြင်း
    $res = $conn->query("SELECT MAX(CAST(case_number AS UNSIGNED)) as last_case FROM regular_data WHERE 1=1 $loc_cond");
    $next_case_no = (($res->fetch_assoc())['last_case'] ?? 0) + 1;
}

if (empty($data['officer_name'])) {
    $data['officer_name'] = $login_user_data['officer_name'] ?? '';
    $data['rank_'] = $login_user_data['rank_'] ?? ''; 
    $data['region'] = $login_user_data['region'] ?? '';
}

// =========================================================================
// ၅။ Form Data များ ကန့်သတ်ချက်ဖြင့် ပြန်လည်စစ်ဆေးသတ်မှတ်ခြင်းအပိုင်း
// =========================================================================

// ၁။ Edit Mode (ID ပါလာလျှင် - အချက်အလက်အားလုံး ပြန်ပြမည်)
if (!empty($id)) {
    $result = $conn->query("SELECT * FROM regular_data WHERE id = " . intval($id));
    if ($result && $row = $result->fetch_assoc()) {
        $data = $row;
        $next_case_no = $row['case_number']; 
    }
} 
// ၂။ Search Mode (အမှုတွဲဟောင်းကို နံပါတ်ဖြင့် ရှာဖွေလျှင် - ကန့်သတ်ချက်ဖြင့်သာ ပြန်ခေါ်မည်)
elseif (!empty($search_case)) {
    $stmt = $conn->prepare("SELECT * FROM regular_data WHERE case_number = ? $loc_cond LIMIT 1");
    $stmt->bind_param("s", $search_case);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        // သင်အလိုရှိသော field (၁၁) ခုကိုသာ ရွေးထုတ်သိမ်းဆည်းမည်
        $data['taxpayer_name']   = $row['taxpayer_name'];
        $data['businessType1']   = $row['businessType1'];
        $data['businessType2']   = $row['businessType2'];
        $data['it_select']       = $row['it_select'];
        $data['it_no']           = $row['it_no'];
        $data['ct1_select_real'] = $row['ct1_select_real'];
        $data['ct1_no_real']     = $row['ct1_no_real'];
        $data['ct2_select_real'] = $row['ct2_select_real'];
        $data['ct2_no_real']     = $row['ct2_no_real'];
        $data['summary']         = $row['summary'];
        $data['appraisal']       = $row['appraisal'];

        $data['officer_name']   = $row['officer_name'];
        $data['rank_']          = $row['rank_'];
        $data['region']         = $row['region'];
        $data['declaredIncome1']= $row['declaredIncome1'];
        $data['declaredCT1']    = $row['declaredCT1'];
        $data['declaredCT2']    = $row['declaredCT2'];

        $data['address']        = $row['address'];
        $data['ph_no']          = $row['ph_no'];
        $data['email']          = $row['email'];

        if (!empty($row['taxYear'])) {
            $y = explode('-', $row['taxYear']);
            $data['rowYear1'] = ((int)$y[0] - 2) . "-" . ((int)$y[1] - 2);
        }
        $data['income1']        = $row['income2'];
        $data['income_tax1']    = $row['income_tax2'];
        $data['sale_income1']   = $row['sale_income2'];
        $data['ct1']            = $row['ct2'];

        if (!empty($row['taxYear'])) {
            $y = explode('-', $row['taxYear']);
            $data['rowYear2'] = ((int)$y[0] - 1) . "-" . ((int)$y[1] - 1);
        }
        $data['income2']        = $row['income3'];
        $data['income_tax2']    = $row['income_tax3'];
        $data['sale_income2']   = $row['sale_income3'];
        $data['ct2']            = $row['ct3'];

        $data['rowYear3']       = $row['taxYear'];
        $data['income3']        = $row['netProfit'];
        $data['income_tax3']    = $row['payableIncomeTax'];
        $data['sale_income3']   = $row['sale_income1'];
        $data['ct3']            = $row['totalSales'];

        // Tax Year ကို တစ်နှစ်တိုးခြင်း
        if (!empty($row['taxYear'])) {
            $years = explode('-', $row['taxYear']);
            if (count($years) == 2) {
                $new_start = (int)$years[0] + 1;
                $new_end = (int)$years[1] + 1;
                $data['taxYear'] = $new_start . "-" . $new_end;
            }
        }
        
        // 🛠 ပြင်ဆင်ချက် ၃ - ရှာဖွေပြီးနောက် ကိစ္စရပ်များအတွက် Next Case No အား မိမိမြို့နယ်အလိုက် ထပ်မံစစ်ဆေးခြင်း
        $res = $conn->query("SELECT MAX(CAST(case_number AS UNSIGNED)) as last_case FROM regular_data WHERE 1=1 $loc_cond");
        $row_max = $res->fetch_assoc();
        $next_case_no = ($row_max['last_case'] ?? 0) + 1;
    }
}
// ၃။ New Case Mode
else {
    // 🛠 ပြင်ဆင်ချက် ၄ - နံပါတ်စဉ်အသစ်တိုးခြင်းအား မိမိမြို့နယ်အလိုက်သာ MAX ယူရေတွက်ခြင်း
    $res = $conn->query("SELECT MAX(CAST(case_number AS UNSIGNED)) as last_case FROM regular_data WHERE 1=1 $loc_cond");
    if ($res && $row = $res->fetch_assoc()) {
        $next_case_no = ($row['last_case'] ?? 0) + 1;
    }
}

if (empty($data['officer_name'])) {
    $data['officer_name'] = $officer_name;
    $data['rank_']        = $rank_; 
    $data['region']       = $region;
}

// သိမ်းထားသော 1/မကန(နိုင်)015808 ကို အကွက် ၄ ခု ပြန်ခွဲခြင်း
if (!empty($data['nrc_no']) && preg_match('/^([^\/]+)\/([^\(]+)(\([^\)]+\))(.*)$/u', $data['nrc_no'], $nrc_matches)) {
    $data['state_code']    = trim($nrc_matches[1]);
    $data['letter_code']   = trim($nrc_matches[2]);
    $data['national_name'] = trim($nrc_matches[3]);
    $data['nrc_no']        = trim($nrc_matches[4]);
}
?>

<!DOCTYPE html>
<html lang="my">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tax Calculation System</title>
    <link rel="stylesheet" href="style.css">
    <style>
body {
    font-family: 'Pyidaungsu', sans-serif; background-color: #f0f0f0; margin: 0; padding: 5px;
}

.container { width: 100%; max-width: 1400px; margin: auto; background: white; border: 1px solid #000;  }

header {
    background: #0000FF; color: white; display: flex; justify-content: space-between; padding: 8px; font-weight: bold; font-size: 16px;
}

.main-content {
    display: flex; gap: 20px; padding: 5px 10px;
    max-width: 100%; box-sizing: border-box;
}

.section { flex: 1; min-width: 0; }

.section-title {
    background: yellow; text-align: center;
    padding:2px; margin: 0px 0px 10px 0px; font-size: 16px;
}

/* Grid များအား ကျစ်လျစ်အောင် စုစည်းခြင်း */
.left-grid, .calc-grid, .low-grid-table {
    display: grid;
    gap: 4px 8px; /* အပေါ်အောက် 4px သာ ကွာပါမည် */
    align-items: center;
}

.left-grid { grid-template-columns: 1.4fr 1fr 1.4fr 1fr; }

.calc-grid { grid-template-columns: 1.4fr 1fr 1fr 1fr; }

.low-grid-table { 
    grid-template-columns: 1fr 1fr 1fr 1fr 1fr; 
    margin-top: 10px;
    gap: 1px;

}
.search-btn{
    height: 26px;
}

/* Span Classes */
.span-2 {
    grid-column: span 2;
    background-color: #00FF00;
    font-weight: bold;
    text-align: center;
    height: 26px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 4px;
}

.span-3 { grid-column: span 3; text-align: left;}
/* Input & Label Control */
label {
    margin: 0; padding: 0; font-size: 15px;
    display: flex; align-items: center; height: 26px;
}

input, select {
    height: 26px; padding: 2px 5px;
    border: 1px solid #777; box-sizing: border-box;
    width: 100%; font-size: 14px;
    text-align: right;
}

.header-label {
    background-color: green; color: white;
    text-align: center; padding: 3px;
    font-size: 14px; border-radius: 3px;
}

/* label ထဲမှာ select မထည့်ဘဲ ဘေးချင်းယှဉ်စေရန် */
.flex-row {
    display: flex;
    gap: 4px;
    width: 100%;
}
.GIR_IT{ width: 60% !important; }
.GIR_CT1{ width: 60% !important; }
.GIR_CT2{ width: 60% !important; }
.Tin { width: 40% !important; }
.nrc { width: 40% !important; display: flex; gap: 4px; }
.nrc1 { width: 60% !important; display: flex; gap: 4px; }
.nrc2 { width: 35% !important; display: flex; gap: 4px; }
.nrc_no { width: 50% !important; display: flex; gap: 4px; }
/* Textarea Layout */
.note-container { margin-top: 8px; }
textarea {
    width: 98%; border: 1px solid #777;
    border-radius: 4px; padding: 5px;
    font-family: 'Pyidaungsu'; font-size: 14px;
    resize: vertical;
}
.left-section{
    flex: 1; border: 1px solid #ccc; padding: 10px;
}
.save{
    grid-column: span 2;
    background-color: #00FF00;
    font-weight: bold;
    text-align: center;
    height: 26px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 4px;
}
.clear{
    grid-column: span 2;
    background-color: gray;
    font-weight: bold;
    text-align: center;
    height: 26px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 4px;
}
.exit{
    grid-column: span 2;
    background-color: red;
    font-weight: bold;
    text-align: center;
    height: 26px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 4px;
}
.parcentage{
    background-color: rgb(195, 193, 193);
    font-weight: bold;
    text-align: center;
    height: 26px;
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 4px; 
    gap: 2px;

}
.next-btn {
    background-color: #5d46e2; /* ပုံထဲကအတိုင်း ခရမ်းရောင် သို့မဟုတ် အပြာရောင် */
    color: white;
    padding: 5px 22px;
    border: none;
    border-radius: 25px;
    cursor: pointer; /* လက်ညှိုးပုံစံပေါ်စေရန် */
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    font-weight: bold;
    white-space: nowrap;
    overflow-wrap: normal;
    word-break: keep-all;
    width: auto;
    max-width: 100%;
    flex: 0 0 auto;
}

.next-btn span {
    font-size: 18px; /* မြှားကို အနည်းငယ် ပိုကြီးစေရန် */
    font-weight: bold;
}

.next-btn:hover {
    background-color: #7b657b; /* Mouse တင်လိုက်ရင် အရောင်ပြောင်းရန် */
}
input:readonly { background-color: #ccc; }

.aling{text-align: center;}
.btn-clear{height: 32px; color:white; background-color:gray; border-radius:25px;cursor: pointer;font-weight: bold;}
.btn-exit{height: 32px; color:white; background-color:red; border-radius:25px;cursor: pointer;font-weight: bold;}
.your-style-class{width:70px;height:26px}
.your-style-class2{width:147px;height:26px}

.left-grid > *,
.calc-grid > *,
.low-grid-table > * {
    min-width: 0;
}

label,
.span-2,
.header-label {
    height: auto;
    min-height: 26px;
    white-space: normal;
    overflow-wrap: anywhere;
    line-height: 1.25;
}

.flex-row > select,
.flex-row > input {
    min-width: 0;
}

header > div {
    min-width: 0;
}

@media (max-width: 1180px) {
    header {
        flex-wrap: wrap;
        gap: 4px 12px;
    }
    .header-center {
        flex: 1 1 220px;
        text-align: center;
    }
    .main-content {
        flex-direction: column;
    }
}

@media (max-width: 720px) {
    .left-grid {
        grid-template-columns: minmax(0, 1fr) minmax(0, 1.15fr);
    }
    .span-2,
    .span-3,
    #email {
        grid-column: 1 / -1;
    }
    .calc-grid {
        grid-template-columns: minmax(0, 1.4fr) minmax(0, 1fr) minmax(0, 1fr) minmax(64px, 0.7fr);
    }
    .your-style-class {
        width: auto;
        min-width: 36px;
        padding: 0 4px;
    }
    .your-style-class2 {
        width: 100%;
    }
    .next-btn {
        padding: 5px 16px;
        white-space: nowrap;
    }
    .low-grid-table {
        grid-template-columns: repeat(5, minmax(68px, 1fr));
    }
}
</style>

</head>

<body>
<div class="container">
    <header>
        <div class="header-left"><span id="display_state"><?php echo $state_name; ?></span></div>
        <div class="header-center">Tax Calculation And Case Printing System</div>
        <div class="header-right"><span id="display_township"><?php echo $township_name; ?></span></div>
    </header>


    <!--<form id="taxForm" action="save_data.php" method="POST">-->
<form method="POST" action="Calculation_form2.php" method="POST">
    <input type="hidden" name="edit_id" value="<?php echo htmlspecialchars($_GET['id'] ?? $_POST['edit_id'] ?? ''); ?>">
    <input type="hidden" name="search_number" value="<?php echo htmlspecialchars($next_case_no); ?>">
    <input type="hidden" name="officer_name" value="<?php echo $user_name; ?>">
    <input type="hidden" name="rank_" value="<?php echo $user_rank; ?>">
    <input type="hidden" name="region" value="<?php echo $user_region; ?>">
    <input type="hidden" name="businessType1" value="<?php echo htmlspecialchars($businessType1); ?>">
    <input type="hidden" name="businessType2" value="<?php echo htmlspecialchars($businessType2); ?>">
    <input type="hidden" name="declaredCT2" value="<?php echo htmlspecialchars($declaredCT2); ?>">
    <input type="hidden" name="rank_" value="<?php echo htmlspecialchars($rank_); ?>">


        <div class="main-content">
            <div class="section left-section">
                <h3 class="section-title">အခွန်ထမ်းဆောင်မှုဆိုင်ရာအချက်အလက်များ</h3>
                <div class="left-grid">

                    
                <button type="button"class="search-btn"  onclick="const val = document.getElementById('caseSearchInput').value;
                     if(val) window.location.href='Calculation_Form1.php?search_case='+val;">Search</button>
                <input type="text" id="caseSearchInput" value="<?php echo htmlspecialchars($search_case); ?>" placeholder="အမှုတွဲအမှတ်ဖြင့် ရှာပါ">
                    <label style="" class="span-2">အခွန်ထမ်းမှတ်ပုံတင်အချက်အလက်များ</label>


                   
                    <label>အမှုတွဲအမှတ်</label>
                    <input type="text" name="case_number" value="<?php echo htmlspecialchars($next_case_no); ?>" >
                    <label>&ensp;&ensp;စည်းကြပ်နှစ်</label>
                        <div class="flex-row">
                            <select id="taxYear" name="taxYear" class="form-select" onchange="updateTableYears()">
                                <option value="">-- ရွေးချယ်ပါ --</option>
                                <?php 
                                $years = ["2022-2023", "2023-2024", "2024-2025", "2025-2026", "2026-2027"];
                                foreach($years as $y) {
                                    $selected = ($data['taxYear'] == $y) ? "selected" : "";
                                    echo "<option value='$y' $selected>$y</option>";
                                }
                                ?>
                            </select>
                        </div>

                    <label>အခွန်ထမ်းအမည်</label>
                    <input type="text" name="taxpayer_name" value="<?php echo htmlspecialchars($data['taxpayer_name'] ?? ''); ?>" placeholder="အမည်ရိုက်ပါ">
                    <label>&ensp;&ensp;ဝင်ငွေခွန်</label>
                        <div class="flex-row">
                            <select id="it_select" name="it_select" class="GIR_IT" onchange="checkGIRSelection()">
                                <option value="">ရွေးချယ်ရန်</option>
                                <option value="သက်မွေး" <?php if(($data['it_select'] ?? '') == 'သက်မွေး') echo 'selected'; ?>>သက်မွေး</option>
                                <option value="စီးပွား" <?php if(($data['it_select'] ?? '') == 'စီးပွား') echo 'selected'; ?>>စီးပွား</option>
                                <option value="ပစ္စည်း" <?php if(($data['it_select'] ?? '') == 'ပစ္စည်း') echo 'selected'; ?>>ပစ္စည်း</option>
                            </select>
                            
                            <input type="text" id="it_no" name="it_no" 
                                placeholder="IT No" class="Tin" 
                                value="<?php echo htmlspecialchars($data['it_no'] ?? ''); ?>" >
                        </div>
                        
                    <label>လုပ်ငန်းအမျိုးအစား-၁</label>
                    <input type="text" id="businessType1" name="businessType1" value="<?php echo htmlspecialchars($data['businessType1'] ?? ''); ?>">

                    <label>&ensp;&ensp;ကုန်သွယ်လုပ်ငန်းခွန်-၁</label>
                    <div class="flex-row">
                        <select id="ct1_select_real" name="ct1_select_real" class="GIR_CT1" onchange="checkGIRSelection()">
                            <option value="">ရွေးချယ်ပါ</option>
                            <option value="ထလ" <?php echo (($data['ct1_select_real'] ?? '') == 'ထလ') ? 'selected' : ''; ?>>ထလ</option>
                            <option value="ကသ" <?php echo (($data['ct1_select_real'] ?? '') == 'ကသ') ? 'selected' : ''; ?>>ကသ</option>
                            <option value="စသ" <?php echo (($data['ct1_select_real'] ?? '') == 'စသ') ? 'selected' : ''; ?>>စသ</option>
                            <option value="တခ" <?php echo (($data['ct1_select_real'] ?? '') == 'တခ') ? 'selected' : ''; ?>>တခ</option>
                            <option value="မဆ" <?php echo (($data['ct1_select_real'] ?? '') == 'မဆ') ? 'selected' : ''; ?>>မဆ</option>
                            <option value="ပန" <?php echo (($data['ct1_select_real'] ?? '') == 'ပန') ? 'selected' : ''; ?>>ပန</option>
                            <option value="ဖဖ" <?php echo (($data['ct1_select_real'] ?? '') == 'ဖဖ') ? 'selected' : ''; ?>>ဖဖ</option>
                            <option value="အလ" <?php echo (($data['ct1_select_real'] ?? '') == 'အလ') ? 'selected' : ''; ?>>အလ</option>
                            <option value="အခ" <?php echo (($data['ct1_select_real'] ?? '') == 'အခ') ? 'selected' : ''; ?>>အခ</option>
                            <option value="" <?php echo (($data['ct1_select_real'] ?? '') == '') ? 'selected' : ''; ?>></option>
                           
                        </select>
                        <input type="text" id="ct1_no_real" name="ct1_no_real" placeholder="CT-1 No" class="Tin" value="<?php echo htmlspecialchars($data['ct1_no_real'] ?? ''); ?>">
                    </div>

                    <label>လုပ်ငန်းအမျိုးအစား-၂</label>
                    <input type="text" id="businessType2" name="businessType2" value="<?php echo htmlspecialchars($data['businessType2'] ?? ''); ?>">

                    <label>&ensp;&ensp;ကုန်သွယ်လုပ်ငန်းခွန်-၂</label>
                    <div class="flex-row">
                        <select id="ct2_select_real" name="ct2_select_real" class="GIR_CT2" onchange="checkGIRSelection()">

                            <option value="">ရွေးချယ်ပါ</option>
                            <option value="ထလ" <?php echo (($data['ct2_select_real'] ?? '') == 'ထလ') ? 'selected' : ''; ?>>ထလ</option>
                            <option value="ကသ" <?php echo (($data['ct2_select_real'] ?? '') == 'ကသ') ? 'selected' : ''; ?>>ကသ</option>
                            <option value="စသ" <?php echo (($data['ct2_select_real'] ?? '') == 'စသ') ? 'selected' : ''; ?>>စသ</option>
                            <option value="တခ" <?php echo (($data['ct2_select_real'] ?? '') == 'တခ') ? 'selected' : ''; ?>>တခ</option>
                            <option value="မဆ" <?php echo (($data['ct2_select_real'] ?? '') == 'မဆ') ? 'selected' : ''; ?>>မဆ</option>
                            <option value="ပန" <?php echo (($data['ct2_select_real'] ?? '') == 'ပန') ? 'selected' : ''; ?>>ပန</option>
                            <option value="ဖဖ" <?php echo (($data['ct2_select_real'] ?? '') == 'ဖဖ') ? 'selected' : ''; ?>>ဖဖ</option>
                            <option value="အလ" <?php echo (($data['ct2_select_real'] ?? '') == 'အလ') ? 'selected' : ''; ?>>အလ</option>
                            <option value="အခ" <?php echo (($data['ct2_select_real'] ?? '') == 'အခ') ? 'selected' : ''; ?>>အခ</option>
                            <option value="" <?php echo (($data['ct2_select_real'] ?? '') == '') ? 'selected' : ''; ?>></option>
                            
                        </select>

                        <input type="text" id="ct2_no_real" name="ct2_no_real" placeholder="CT-2 No" class="Tin"  value="<?php echo htmlspecialchars($data['ct2_no_real'] ?? ''); ?>">
                    </div>

                    <label>နိုင်ငံသားမှတ်ပုံတင်အမှတ်</label>
                    <div class="flex-row">
                            <select id="state_code" name="state_code" class="nrc" onchange="checkNRCSelection()">
                                <option value="">ရွေး</option>
                                <?php
                                $saved_state_code = $data['state_code'] ?? '';
                                for ($i = 1; $i <= 14; $i++) {
                                    $code = str_pad((string) $i, 2, '0', STR_PAD_LEFT);
                                    $selected = ($saved_state_code === $code || intval($saved_state_code) === $i) ? 'selected' : '';
                                    echo "<option value=\"$code\" $selected>$i</option>";
                                }
                                ?>
                            </select>
                            <select id="letter_code" name="letter_code" class="nrc1" data-selected="<?php echo htmlspecialchars($data['letter_code'] ?? ''); ?>">
                                <option value="">ရွေး</option>
                                <?php if (!empty($data['letter_code'])): ?>
                                    <option value="<?php echo htmlspecialchars($data['letter_code']); ?>" selected><?php echo htmlspecialchars($data['letter_code']); ?></option>
                                <?php endif; ?>
                            </select>
                            
                    </div>     
                    <div class="flex-row">
                        <select id="national_name" name="national_name" class="nrc2" onchange="checkGIRSelection()">
                            <option value="">ရွေး</option>
                            <option value="(နိုင်)" <?php if(($data['national_name'] ?? '') == '(နိုင်)') echo 'selected'; ?>>(နိုင်)</option>
                            <option value="(ဧည့်)" <?php if(($data['national_name'] ?? '') == '(ဧည့်)') echo 'selected'; ?>>(ဧည့်)</option>
                            <option value="(ပြု)" <?php if(($data['national_name'] ?? '') == '(ပြု)') echo 'selected'; ?>>(ပြု)</option>
                            <option value="(သာ)" <?php if(($data['national_name'] ?? '') == '(သာ)') echo 'selected'; ?>>(သာ)</option>
                        </select>
                        <input type="text" id="nrc_no" name="nrc_no"
                                placeholder="NRC No" class="nrc_no"
                                inputmode="numeric" maxlength="6" pattern="[0-9]{0,6}"
                                oninput="limitNrcDigits(this)"
                                value="<?php echo htmlspecialchars($data['nrc_no'] ?? ''); ?>" >
                    </div>
                    <label>4</label>

                        

                    <label class="span-2">ကြေညာသည့်ဝင်ငွေ</label>
                    <label class="span-2">အခွန်မှူးအချက်အလက်</label>


                    <label>ဝင်ငွေခွန်</label>
                    <input type="text" id="declaredIncome1" name="declaredIncome1" value="<?php echo htmlspecialchars($data['declaredIncome1'] ?? ''); ?>">
                    <!--<input type="text" id="declaredIncome1" name="declaredIncome1" oninput="validateAndConvert(this)">-->
                    <label>&ensp;&ensp;အခွန်မှူးအမည်</label>
                    <input type="text" id="officer_name" name="officer_name" class="form-control" style="font-family:Pyidaungsu; text-align:center;" value="<?php echo htmlspecialchars($officer_name); ?>" readonly>
                 
                    <label>ကုန်သွယ်လုပ်ငန်းခွန်-၁</label>
                    <input type="text" id="declaredCT1" name="declaredCT1" value="<?php echo htmlspecialchars($data['declaredCT1'] ?? ''); ?>"  >
                    <label>&ensp;&ensp;ရာထူး</label>
                    <input type="text" id="rank_" name="rank_" class="form-control" style="font-family:Pyidaungsu; text-align:center;" value="<?php echo htmlspecialchars($rank_); ?>" readonly>
                    
                    <label>ကုန်သွယ်လုပ်ငန်းခွန်-၂</label>
                    <input type="text" id="declaredCT2" name="declaredCT2" value="<?php echo htmlspecialchars($data['declaredCT2'] ?? ''); ?>"  >
                        <label>&ensp;&ensp;နယ်မြေ</label>
                        <input type="text" name="region" value="<?php echo $_SESSION['region'] ?? ''; ?>" readonly style="text-align:center;">
                    
                    <label>အခွန်ထမ်းလိပ်စာ</label>
                    <input type="text" id="address" name="address" value="<?php echo htmlspecialchars($data['address'] ?? ''); ?>" class="span-3" >

                    <label>ဆက်သွယ်ရန်ဖုန်း/အီးမေလ်း</label>
                    <input type="text" id="ph_no" name="ph_no" value="<?php echo htmlspecialchars($data['ph_no'] ?? ''); ?>" placeholder="ဖုန်းနံပါတ်">
                    <input type="text" id="email" name="email" class="form-control" style="grid-column: span 2; font-family:Pyidaungsu; text-align: left;" placeholder="email ဖော်ပြပေးရန်" value="<?php echo htmlspecialchars($email); ?>">
                
                </div>

       
                <div class="low-grid-table">
                    <div class="header-label">စည်းကြပ်နှစ်</div>
                    <div class="header-label">သတ်မှတ်ဝင်ငွေ</div>
                    <div class="header-label">ဝင်ငွေခွန်</div>
                    <div class="header-label">သတ်မှတ်ရောင်းရငွေ</div>
                    <div class="header-label">ကုန်သွယ်လုပ်ငန်းခွန်</div>

                    <input type="text" id="rowYear1" name="rowYear1" value="<?php echo htmlspecialchars($data['rowYear1'] ?? ''); ?>" readOnly >
                    <input type="text" id="income1" name="income1" oninput="validateAndConvert(this)" placeholder="သတ်မှတ်ဝင်ငွေ" value="<?php echo htmlspecialchars($data['income1'] ?? ''); ?>">
                    <input type="text" id="income_tax1" name="income_tax1" oninput="validateAndConvert(this)" placeholder="ဝင်ငွေခွန်" value="<?php echo htmlspecialchars($data['income_tax1'] ?? ''); ?>">
                    <input type="text" id="sale_income1" name="sale_income1" oninput="validateAndConvert(this)" placeholder="သတ်မှတ်ရောင်းရငွေ" value="<?php echo htmlspecialchars($data['sale_income1'] ?? ''); ?>">
                    <input type="text" id="ct1" name="ct1" oninput="validateAndConvert(this)" placeholder="ကုန်သွယ်လုပ်ငန်းခွန်" value="<?php echo htmlspecialchars($data['ct1'] ?? ''); ?>">

                    <input type="text" id="rowYear2" name="rowYear2" value="<?php echo htmlspecialchars($data['rowYear2'] ?? ''); ?>" readOnly >
                    <input type="text" id="income2" name="income2" oninput="validateAndConvert(this)" placeholder="သတ်မှတ်ဝင်ငွေ" value="<?php echo htmlspecialchars($data['income2'] ?? ''); ?>">
                    <input type="text" id="income_tax2" name="income_tax2" oninput="validateAndConvert(this)" placeholder="ဝင်ငွေခွန်" value="<?php echo htmlspecialchars($data['income_tax2'] ?? ''); ?>">
                    <input type="text" id="sale_income2" name="sale_income2" oninput="validateAndConvert(this)" placeholder="သတ်မှတ်ရောင်းရငွေ" value="<?php echo htmlspecialchars($data['sale_income2'] ?? ''); ?>">
                    <input type="text" id="ct2" name="ct2" oninput="validateAndConvert(this)" placeholder="ကုန်သွယ်လုပ်ငန်းခွန်" value="<?php echo htmlspecialchars($data['ct2'] ?? ''); ?>">

                    <input type="text" id="rowYear3" name="rowYear3" value="<?php echo htmlspecialchars($data['rowYear3'] ?? ''); ?>" readOnly >
                    <input type="text" id="income3" name="income3" oninput="validateAndConvert(this)" placeholder="သတ်မှတ်ဝင်ငွေ" value="<?php echo htmlspecialchars($data['income3'] ?? ''); ?>">
                    <input type="text" id="income_tax3" name="income_tax3" oninput="validateAndConvert(this)" placeholder="ဝင်ငွေခွန်" value="<?php echo htmlspecialchars($data['income_tax3'] ?? ''); ?>">
                    <input type="text" id="sale_income3" name="sale_income3" oninput="validateAndConvert(this)" placeholder="သတ်မှတ်ရောင်းရငွေ" value="<?php echo htmlspecialchars($data['sale_income3'] ?? ''); ?>">
                    <input type="text" id="ct3" name="ct3" oninput="validateAndConvert(this)" placeholder="ကုန်သွယ်လုပ်ငန်းခွန်" value="<?php echo htmlspecialchars($data['ct3'] ?? ''); ?>">

                   
                </div>
                <div class="note-container">
                    <label for="remarks">လုပ်ငန်းအကျဉ်းချုပ်ဖော်ပြချက်</label>
                    <textarea id="summary" name="summary" rows="3" placeholder="ဤနေရာတွင် လုပ်ငန်းအကျဉ်းချုပ်ရေးသားပေးရန်။"><?php echo trim(htmlspecialchars($data['summary'] ?? '')); ?></textarea>
                </div>

                <div class="note-container">
                    <label for="remarks">အခွန်မှူးသုံးသပ်တင်ပြချက်</label>
                    <textarea id="appraisal" name="appraisal" rows="3" placeholder="အခွန်မှူးသုံးသပ်တင်ပြချက် ရေးသားပေးရန်။"><?php echo trim(htmlspecialchars($data['appraisal'] ?? '')); ?></textarea>
                </div>
            </div>
            
            <div class="section left-section">
                <h3 class="section-title">ကုန်သွယ်လုပ်ငန်းခွန်တွက်ချက်မှု</h3>
                     
                <div class="calc-grid">
              
                    <label>သတ်မှတ်ရောင်းရငွေ</label> 
                        <input type="text" id="salesAmount1" name="salesAmount1" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['salesAmount1'] ?? ''); ?>" placeholder="ရောင်းရငွေရိုက်ထည့်ပါ">
                        <input type="text" id="salesAmount2" name="salesAmount2" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['salesAmount2'] ?? ''); ?>" placeholder="ရောင်းရငွေရိုက်ထည့်ပါ">
                        <label></label> 

                        <label>၅% ဖြင့်ကျသင့်ကုန်သွယ်ခွန်</label>
                        <input type="text" id="ct1tax" name="ct1tax" readOnly oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['ct1tax'] ?? ''); ?>" >
                        <input type="text" id="ct2tax" name="ct2tax" readOnly oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['ct2tax'] ?? ''); ?>" class="secondary-input">
                        <label>
                            <button type="button" class="your-style-class" onclick="setCustomTax(1, 1/101)">1%</button>
                            &ensp;
                            <button type="button" class="your-style-class" onclick="setCustomTax(2, 3/103)">3%</button>
                        </label>
                       
                       

                        <label style="color: red;">စည်မျဉ် ၄၂ အရ ခုနှိမ်သောအခွန်</label>
                        <input type="text" id="rule42_1"  name="rule42_1" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['rule42_1'] ?? ''); ?>" style="color: red;"> 
                        <input type="text" id="rule42_2"  name="rule42_2" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['rule42_2'] ?? ''); ?>"  class="secondary-input" style="color: red;">
                        <label>
                            <button type="button" class="your-style-class" onclick="setCustomTax(1, 3/103)">3%</button>
                            &ensp;
                            <button type="button" class="your-style-class" onclick="setCustomTax(2, 1/101)">1%</button>
                        </label> 

                        <label>ခုနှိမ်ခွင့်နုတ်ပယ်ပြီးပေးရန်အခွန်</label>
                        <input type="text" id="afterRuler1" name="afterRuler1" readOnly value="<?php echo htmlspecialchars($data['afterRuler1'] ?? ''); ?>"> 
                        <input type="text" id="afterRuler2" name="afterRuler2" readOnly value="<?php echo htmlspecialchars($data['afterRuler2'] ?? ''); ?>" class="secondary-input">
                        <label>
                            <button type="button" class="your-style-class2" onclick="setCustomTax('both', 1/21)">5%</button>
                        </label> 

                        <label>ကြိုတင်ခွန်</label>
                        <input type="text" id="advanceTax1" name="advanceTax1" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['advanceTax1'] ?? ''); ?>" style="color:red"> 
                        <input type="text" id="advanceTax2" name="advanceTax2" oninput="validateAndConvert(this)"  value="<?php echo htmlspecialchars($data['advanceTax2'] ?? ''); ?>" style="color:red" class="secondary-input">
                        <label></label> 

                        <label>ထပ်မံပေးဆောင်ရမည့်အခွန်</label>
                        <input type="text" id="netTax1" name="netTax1" readOnly value="<?php echo htmlspecialchars($data['netTax1'] ?? ''); ?>"> 
                        <input type="text" id="netTax2" name="netTax2" readOnly value="<?php echo htmlspecialchars($data['netTax2'] ?? ''); ?>" class="secondary-input">
                        <label></label> 

                        <label style="color: red;">ဒဏ်ကြေး</label>
                        <input type="text" id="penalty1" name="penalty1" readOnly value="<?php echo htmlspecialchars($data['penalty1'] ?? ''); ?>" style="color: red;">
                        <input type="text" id="penalty2" name="penalty2" readOnly value="<?php echo htmlspecialchars($data['penalty2'] ?? ''); ?>" style="color: red;" class="secondary-input">
                        <label></label> 

                        <label>အခွန်+ဒဏ်ပေါင်း</label>
                        <input type="text" id="totalTax1" name="totalTax1"  readOnly value="<?php echo htmlspecialchars($data['totalTax1'] ?? ''); ?>"> 
                        <input type="text" id="totalTax2" name="totalTax2"  readOnly value="<?php echo htmlspecialchars($data['totalTax2'] ?? ''); ?>" class="secondary-input">
                        <label></label> 

                        <label class="red-text" style="color: red;">ပေးသွင်းသည့်အခွန်</label>
                        <input type="text" id="paidTax1" name="paidTax1"  oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['paidTax1'] ?? ''); ?>" style="color: red;"> 
                        <input type="text" id="paidTax2" name="paidTax2"  oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['paidTax2'] ?? ''); ?>" class="secondary-input" style="color: red;">
                        <label></label> 

                        <label>ချလန်နံပါတ်</label>
                        <input type="text" id="ct1_chalan_no" name="ct1_chalan_no" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['ct1_chalan_no'] ?? ''); ?>" >
                        <input type="text" id="ct2_chalan_no" name="ct2_chalan_no" oninput="validateAndConvert(this)" value="<?php echo htmlspecialchars($data['ct2_chalan_no'] ?? ''); ?>" class="secondary-input">
                        <label></label> 

                        <label>ရက်စွဲ</label>
                        <input type="date" id="date1" name="date1" value="<?php echo htmlspecialchars($data['date1'] ?? ''); ?>">
                        <input type="date" id="date2" name="date2" value="<?php echo htmlspecialchars($data['date2'] ?? ''); ?>"  class="secondary-input">
                        <label></label> 

                        <label></label>
                        <label></label>
                        <label></label>
                        <label></label>

                        
                        <label></label>
                        <button type="button" class="btn-clear" onclick="clearForm()">CLEAR</button>
                        <button type="button" class="btn-exit" onclick="exitToList()">EXIT</button>
                        <label><div style="display: flex; justify-content: flex-end; margin-top: 0px;">
                                    
                                    <button type="button" class="next-btn" onclick="goToNextPage()">
                                        Next <span>&raquo;</span>
                                    </button>
                                </div>
                               
                        </label>

                        <label></label>
                        <label></label>
                        <label></label>
                        <label></label>

                        <label></label>
                        <label></label>
                        <label></label>
                        <label></label>

                        <label></label>
                        <label></label>
                        <label></label>
                        <label></label>
                        
                   
                    <div class="button-group"></div>
                    
                    
                </div>
            </div>
        </div>
    </div>

</form>


<script>

function searchCase() {
    
    const caseNo = document.getElementById('caseSearchInput').value;
    if (caseNo) {
        // လက်ရှိ URL ကို search_case parameter နဲ့ ပြန်ခေါ်မယ်
        window.location.href = "Calculation_Form1.php?search_case=" + caseNo;
    }
}
// မှတ်ပုံတင်နံပါတ်ကို ဂဏန်း ၆ လုံးသာ ခွင့်ပြုသည်
function limitNrcDigits(el) {
    if (!el) return;
    const myanDigit = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
    let value = el.value;
    myanDigit.forEach(function (digit, index) {
        value = value.split(digit).join(String(index));
    });
    el.value = value.replace(/\D/g, '').slice(0, 6);
}

// နိုင်ငံသားမှတ်ပုံတင် ပြည်နယ်/တိုင်းကုဒ် ရွေးလျှင် locations ဇယားမှ letter_code များ ဆွဲထုတ်ခြင်း
function checkNRCSelection() {
    const stateEl = document.getElementById('state_code');
    const letterEl = document.getElementById('letter_code');
    if (!stateEl || !letterEl) return;

    const stateCode = stateEl.value;
    const keep = letterEl.getAttribute('data-selected') || letterEl.value;

    letterEl.innerHTML = '<option value="">ရွေး</option>';
    if (!stateCode) return;

    fetch('get_letters_by_state.php?state_code=' + encodeURIComponent(stateCode))
        .then(function (response) { return response.json(); })
        .then(function (res) {
            if (!res || res.status !== 'success' || !Array.isArray(res.data)) return;
            res.data.forEach(function (letter) {
                const opt = document.createElement('option');
                opt.value = letter;
                opt.textContent = letter;
                letterEl.appendChild(opt);
            });
            if (keep) {
                let matched = false;
                Array.from(letterEl.options).forEach(function (opt) {
                    if (opt.value === keep) {
                        opt.selected = true;
                        matched = true;
                    }
                });
                if (!matched) {
                    const opt = document.createElement('option');
                    opt.value = keep;
                    opt.textContent = keep;
                    opt.selected = true;
                    letterEl.appendChild(opt);
                }
            }
            letterEl.removeAttribute('data-selected');
        })
        .catch(function () {
            letterEl.innerHTML = '<option value="">ရွေး</option>';
            if (keep) {
                const opt = document.createElement('option');
                opt.value = keep;
                opt.textContent = keep;
                opt.selected = true;
                letterEl.appendChild(opt);
            }
        });
}

// ၁။ လက်ရှိ တွက်ချက်နေတဲ့ ရာခိုင်နှုန်းကို မှတ်ထားရန်
let currentRates = { rate1: 1/21, rate2: 1/21 };

// ၂။ Select Box (တခ) ရွေးချယ်မှု ရှိ/မရှိ စစ်ဆေးပြီး Rate ပြောင်းလဲခြင်း
function checkGIRSelection() {
    const el1 = document.getElementById('ct1_select_real');
    const el2 = document.getElementById('ct2_select_real');
    
    const gir1 = el1 ? el1.value.trim() : "";
    const gir2 = el2 ? el2.value.trim() : "";

    // "စသ" သို့မဟုတ် "တခ" သင်သုံးမည့် စာသားနှင့် ကိုက်ညီအောင် စစ်ပါ
    currentRates.rate1 = (gir1 === 'တခ') ? (3 / 103) : (1 / 21);
    currentRates.rate2 = (gir2 === 'တခ') ? (3 / 103) : (1 / 21);

    calculateTax(); 
}

// ၃။ ဂဏန်းပြောင်းလဲခြင်း
function parseVal(id) {
    let el = document.getElementById(id);
    if (!el) return 0;
    let val = el.value.replace(/,/g, '');
    return parseFloat(val) || 0;
}

// ၄။ ကော်မာ ပြန်ထည့်သွင်းခြင်း
function formatVal(id, num) {
    let el = document.getElementById(id);
    if (el) el.value = Math.round(num); //.toLocaleString();
}

// ၅။ ရိုက်ထည့်နေစဉ် ဂဏန်းပြောင်းလဲခြင်း
function validateAndConvert(el) {
    const myanDigit = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
    let value = el.value;
    myanDigit.forEach((digit, index) => { value = value.split(digit).join(index); });
    value = value.replace(/[^0-9.]/g, '');
    if (value !== "") {
        let parts = value.split('.');
        parts[0] = parseInt(parts[0]);//.toLocaleString();
        el.value = parts.join('.');
    }
    
    // ရောင်းရငွေ ရိုက်လိုက်တာနဲ့ Select Box အခြေအနေကိုပါ ပြန်စစ်ပြီး တွက်ရန်
    checkGIRSelection(); 
}


// ၆။ % ခလုတ်များအတွက် (Manual ပြောင်းချင်လျှင်)
function setCustomTax(side, rate) {
    if (side === 'both') {
        currentRates.rate1 = rate;
        currentRates.rate2 = rate;
    } else if (side === 1) {
        currentRates.rate1 = rate;
    } else if (side === 2) {
        currentRates.rate2 = rate;
    }
    
    // ခလုတ်နှိပ်လိုက်တဲ့နှုန်းနဲ့ အတင်းတွက်ခိုင်းမယ်
    calculateTax(true); 
}

// ၇။ အဓိက အခွန်တွက်ချက်ခြင်း Logic
function calculateTax(useCustomRate = false) {
    // pairs ထဲမှာ statusId နဲ့ rateKey ကိုပါ ထည့်ပေးရပါမယ်
    const pairs = [
        { 
            sales: "salesAmount1", tax: "ct1tax", rule42: "rule42_1", 
            after: "afterRuler1", advance: "advanceTax1", net: "netTax1", 
            penalty: "penalty1", total: "totalTax1",
            statusId: "ct1_select_real", rateKey: "rate1" 
        },
        { 
            sales: "salesAmount2", tax: "ct2tax", rule42: "rule42_2", 
            after: "afterRuler2", advance: "advanceTax2", net: "netTax2", 
            penalty: "penalty2", total: "totalTax2",
            statusId: "ct2_select_real", rateKey: "rate2" 
        }
    ];

    pairs.forEach(p => {
        let salesVal = parseVal(p.sales) || 0;
        let rule42Val = parseVal(p.rule42) || 0; // မေ့ကျန်ခဲ့သော variable
        let advanceVal = parseVal(p.advance) || 0; // မေ့ကျန်ခဲ့သော variable
        let rate;

        if (useCustomRate) {
            // ခလုတ်နှိပ်ထားရင် currentRates['rate1'] သို့မဟုတ် currentRates['rate2'] ကို ယူမယ်
            rate = currentRates[p.rateKey];
        } else {
            // ပုံမှန်ဆိုရင် Select Box ကိုကြည့်မယ်
            let statusEl = document.getElementById(p.statusId);
            let currentStatus = statusEl ? statusEl.value.trim() : "";
            
            // စသ သို့မဟုတ် တခ ဖြစ်လျှင် ၃% (၃/၁၀၃) ၊ ကျန်တာ ၅% (၁/၂၁)
            rate = (currentStatus === "တခ" || currentStatus === "စသ") ? (3 / 103) : (1 / 21);
            
            // လက်ရှိနှုန်းကို နောက်မှပြန်သုံးနိုင်အောင် currentRates ထဲ သိမ်းထားမယ်
            currentRates[p.rateKey] = rate;
        }

        // သိန်း ၅၀၀ စည်းကမ်းဖြင့် တွက်ချက်ခြင်း
        let calculatedTax = (salesVal >= 50000000) ? Math.round(salesVal * rate) : 0;
        
        // ၃။ အခွန်တွက်ချက်ခြင်း အဆင့်ဆင့် ပြသခြင်း
        formatVal(p.tax, calculatedTax);

        let afterRule42 = Math.max(0, calculatedTax - rule42Val);
        formatVal(p.after, afterRule42);
        
        let netTax = Math.max(0, afterRule42 - advanceVal);
        formatVal(p.net, netTax);
        
        let penalty = Math.round(netTax * 0.1);
        formatVal(p.penalty, penalty);
        
        formatVal(p.total, netTax + penalty);
    });

    const minusSum = (parseVal('ct1tax') || 0) + (parseVal('ct2tax') || 0);
    let minusEl = document.getElementById('minusCTInput');
    if (!minusEl) {
        minusEl = document.createElement('input');
        minusEl.type = 'hidden';
        minusEl.id = 'minusCTInput';
        minusEl.name = 'minusCTInput';
        const form = document.getElementById('calculationForm') || document.querySelector('form');
        if (form) form.appendChild(minusEl);
    }
    minusEl.value = Math.round(minusSum);
    
    if (typeof autoSave === "function") {
        autoSave(); 
    }
}
// --- ကျန်ရှိသော UI Helper functions (unlockNextBusiness, toggleRightSide, etc.) ကို မူလအတိုင်း ထားနိုင်ပါသည် ---

function unlockNextBusiness() {
    const input1 = document.getElementById('businessType1');
    const input2 = document.getElementById('businessType2');
    if (input1 && input1.value.trim().length > 0) {
        input2.readonly = false;
    } else if(input2) {
        input2.readonly = true;
        input2.value = "";
        toggleRightSide();
    }
}
//ညာခြမ်း အပိတ်ဖွင့်
// ညာခြမ်း အပိတ်ဖွင့်
function toggleRightSide() {
    const business2 = document.getElementById('businessType2');
    const targetBoxes = document.querySelectorAll('.secondary-input');
    
    // businessType2 မှာ တန်ဖိုးရှိမရှိ စစ်ခြင်း
    const hasValue = business2 && business2.value.trim().length > 0 && business2.value !== "Select Option";

    const ct2Select = document.getElementById('ct2_select_real');
    const ct2No = document.getElementById('ct2_no_real');
    const salesAmount2 = document.getElementById('salesAmount2');

    // Select Box ဖြစ်ပါက disabled သုံးရပါမည်
    if (ct2Select) {
        ct2Select.disabled = !hasValue;
        if (!hasValue) ct2Select.value = "";
    }

    if (ct2No) {
        ct2No.disabled = !hasValue; 
        if (!hasValue) ct2No.value = "";
    }

    if (salesAmount2) {
        salesAmount2.disabled = !hasValue; 
        if (!hasValue) salesAmount2.value = "";
    }

    // ညာဘက်ခြမ်း Input Box များကို ပိတ်/ဖွင့် လုပ်ခြင်း
    targetBoxes.forEach((box) => {
        box.disabled = !hasValue; 
        if (!hasValue) {
            box.value = "";
        }
    });

    // calculateTax function ရှိမှ ခေါ်ပေးရန်
    if (typeof calculateTax === 'function') {
        calculateTax();
    }
}

// Page စတင်ပွင့်ချိန် နှင့် businessType2 ပြောင်းလဲချိန်များတွင် အလုပ်လုပ်ရန်
document.addEventListener('DOMContentLoaded', function() {
    // 1. Page စတင် loading တက်ချိန်တွင် အရင် စစ်ဆေးရန်
    toggleRightSide();
    if (document.getElementById('state_code') && document.getElementById('state_code').value) {
        checkNRCSelection();
    }
    const nrcNoInput = document.getElementById('nrc_no');
    if (nrcNoInput) limitNrcDigits(nrcNoInput);

    // 2. businessType2 ကို ရွေးချယ်/စာရိုက်လိုက်တိုင်း toggleRightSide() ကို ပြန်ခေါ်ပေးရန် Event ထည့်ခြင်း
    const business2 = document.getElementById('businessType2');
    const date2 = document.getElementById('date2');
    if (business2) {
        business2.addEventListener('change', toggleRightSide);
        business2.addEventListener('input', toggleRightSide);
    }
    if (date2) {
        date2.enabled = !hasValue; 
        if (!hasValue) date2.value = "";
    }
});


function updateTableYears() {
    const selectedYear = document.getElementById('taxYear').value;

    if (selectedYear && selectedYear.includes('-')) {
        // ရှေ့နှစ်ကို ယူသည် (ဥပမာ- 2026-2027 ဆိုလျှင် 2026 ကို ယူမည်)
        let startYear = parseInt(selectedYear.split('-')[0]);

        // ( ) လက်သည်းကွင်းများကို အောက်ပါအတိုင်း သေချာပြန်ထည့်ပါ
        // Row 1: 2023-2024 (3 နှစ်အလို)
        document.getElementById('rowYear1').value = (startYear - 3) + "-" + (startYear - 2);
        
        // Row 2: 2024-2025 (2 နှစ်အလို)
        document.getElementById('rowYear2').value = (startYear - 2) + "-" + (startYear - 1);
        
        // Row 3: 2025-2026 (၁ နှစ်အလို)
        document.getElementById('rowYear3').value = (startYear - 1) + "-" + (startYear);
    }
}
function autoSave() {
    let formData = JSON.parse(localStorage.getItem('TaxSystem_Data_Share')) || {};
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach(input => { 
        if (input.id) { 
            formData[input.id] = input.value; 
        } 
    });
    // နှုန်းထား (Rate) များကိုပါ သိမ်းဆည်းထားရန် လိုအပ်သည်
    formData['current_rate1'] = currentRates.rate1;
    formData['current_rate2'] = currentRates.rate2;
    
    localStorage.setItem('TaxSystem_Data_Share', JSON.stringify(formData));
}

window.onload = function() {
    const urlParams = new URLSearchParams(window.location.search);
    const editId = urlParams.get('id') || urlParams.get('edit_id');
    // URL မှာ 'new=true' ပါလာရင် ဒေတာရှင်းဖို့အတွက် စစ်မယ်
    const isNew = urlParams.get('new'); 

    // ၁။ အမှုတွဲသစ် (New Case) ကို List Page ကနေ တိုက်ရိုက်လာရင် အကုန်ရှင်းမယ်
    if (isNew === "true") {
        console.log("New Entry: Clearing previous session data...");
        localStorage.removeItem('TaxSystem_Data_Share');
        // ဒေတာရှင်းပြီးရင် အောက်က savedData logic ဆီ ဆက်မသွားအောင် return ပြန်မယ်
        return; 
    }

    // ၂။ Edit Mode: ဒေတာဟောင်းတွေနဲ့ မရောအောင် ရှင်းပြီး DB ကဟာကိုပဲ သုံးမယ်
    if (editId) {
        console.log("Edit Mode: Loading from Database...");
        localStorage.removeItem('TaxSystem_Data_Share');
        
        if (typeof calculateTax === "function") calculateTax();
        if (typeof updateTableYears === "function") updateTableYears();
        return; 
    }

    // ၃။ ပုံမှန် အသစ်ထည့်နေရင်း Page Refresh ဖြစ်သွားရင်Saved Data တွေကို ပြန်ဖြည့်မယ် (မူလအတိုင်း)
    const savedData = localStorage.getItem('TaxSystem_Data_Share');
    if (savedData) {
        const formData = JSON.parse(savedData);
        Object.keys(formData).forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                element.value = formData[id];
            }
        });
        if (typeof calculateTax === "function") calculateTax();
    }
};

// =========================================================================
// 🎯 Calculation_Form1.php ရဲ့ အောက်ခြေမှ goToNextPage() ကုဒ်ကို ဤကဲ့သို့ လဲလှယ်ပါ
// =========================================================================
function goToNextPage() {
    if (typeof autoSave === "function") autoSave();
    const id = "<?php echo $id; ?>";
    const returnPage = "<?php echo htmlspecialchars($return_page, ENT_QUOTES); ?>";
    const formElement = document.getElementById('calculationForm') || document.querySelector('form');
    if (!formElement) return;

    const disabledElements = formElement.querySelectorAll('[disabled]');
    disabledElements.forEach(el => el.removeAttribute('disabled'));

    let nextAction = "Calculation_Form2.php" + (id ? ("?id=" + encodeURIComponent(id)) : "");
    if (returnPage) {
        nextAction += (nextAction.includes("?") ? "&" : "?") + "return=" + encodeURIComponent(returnPage);
    }

    formElement.method = "POST";
    formElement.action = nextAction;
    formElement.submit();
}

function exitToList() {
    // အတည်ပြုချက် မေးချင်ရင် ဒီလို သုံးနိုင်ပါတယ်
    if (confirm("ပင်မစာမျက်နာသို့ သွားရန်သေချာပါသလား?")) {
        window.location.href = "dashboard.php";
    }
}

function clearForm() {
    const protectedFields = ['case_number', 'officer_name', 'rank_', 'region'];
    const inputs = document.querySelectorAll('input, select, textarea');

    inputs.forEach(input => {
        if (!protectedFields.includes(input.name) && 
            input.type !== 'button' && 
            input.type !== 'submit' && 
            input.type !== 'hidden') {
            
            if (input.tagName === 'SELECT') {
                input.selectedIndex = 0;
            } else {
                input.value = ''; 
            }
        }
    });
}

// URL မှာ mode=new ပါမပါ စစ်မယ်
   const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('mode') === 'new') {
    const nextCaseNo = "<?php echo $next_case_no; ?>";
    
    document.querySelectorAll('input, textarea, select').forEach(el => {
        // ဒီအမည်တွေကို လုံးဝ မဖျက်ရ (Protected Fields)
        const protectedFields = ['case_number', 'officer_name', 'rank_', 'region'];

        if (el.name === 'case_number') {
            el.value = nextCaseNo;
        } else if (!protectedFields.includes(el.name) && el.type !== 'hidden' && el.type !== 'submit') {
            el.value = ''; // ကျန်တဲ့ အခွန်ထမ်း ဒေတာတွေကိုပဲ ရှင်းမယ်
        }
    });

    localStorage.clear();
}
//အခွန်မှူးအမည် အဆင့် နယ်မြေ ထည့်သါင်းခြင်း


</script>
</body>
</html>