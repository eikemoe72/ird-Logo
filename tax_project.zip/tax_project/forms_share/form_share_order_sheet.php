<?php
// ၁။ Session စတင်ခြင်း နှင့် Error ပိတ်ခြင်း
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', 0);
if (session_status() === PHP_SESSION_NONE) session_start();

// ၂။ ပင်မ Folder ထဲက db_config.php ကို လှမ်းချိတ်ခြင်း
if (file_exists('../db_config.php')) {
    include_once '../db_config.php';
} else {
    include_once 'db_config.php';
}
$conn->set_charset("utf8mb4");

// ၃။ URL ကလာတဲ့ id ကိုဖမ်းပြီး Database မှ ဒေတာ ရှာဖွေခြင်း
$row_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$db_data = [];

if ($row_id > 0) {
    // အစ်ကို့ရဲ့ ပင်မ Table နာမည် 'sharedata' ထဲမှ ဆွဲထုတ်ခြင်း
    $query = "SELECT * FROM sharedata WHERE id = $row_id";
    $result = $conn->query($query);
    if ($result && $result->num_rows > 0) {
        $db_data = $result->fetch_assoc();
    }
}

// ၄။ ရရှိလာသော ဒေတာများကို PHP Variable အဖြစ် ပြောင်းလဲသတ်မှတ်ခြင်း


$os_year      = htmlspecialchars($db_data['tax_year'] ?? '-');
$os_officer   = htmlspecialchars($db_data['officer_name'] ?? '-');
$os_rank      = htmlspecialchars($db_data['officer_rank'] ?? '-');
$os_region      = htmlspecialchars($db_data['region'] ?? '');
$os_state_name  = htmlspecialchars($db_data['state_name'] ?? '-');
$os_township  = htmlspecialchars($db_data['township_name'] ?? '-');

$os_name      = htmlspecialchars($db_data['taxpayer_name'] ?? '-');
$os_nrc_no  = htmlspecialchars($db_data['nrc_no'] ?? '-');
$os_gir       = htmlspecialchars($db_data['gir_no'] ?? '-');
$os_gir_type  = htmlspecialchars($db_data['gir_type'] ?? '-');
$os_address   = htmlspecialchars($db_data['address'] ?? '-');

$os_biz       = htmlspecialchars($db_data['business_type'] ?? '-');



   // (၄) မြေနှင့် အဆောက်အဦးဆိုင်ရာ အချက်အလက်များ
$os_company_name        = htmlspecialchars($db_data['company_name'] ?? '-');
$os_share_date          = htmlspecialchars($db_data['share_date'] ?? '-');
// 🎯 ဒသမကိန်း .00 မပါဘဲ ကော်မာခတ်ပြီး ကိန်းပြည့်ထုတ်ရန် အောက်ပါအတိုင်း ပြင်ပါသည်
$os_paid                = number_format(floatval($db_data['paid'] ?? 0), 0, '.', ',');
$os_share_value         = number_format(floatval($db_data['share_value'] ?? 0), 0, '.', ',');
$os_paid_share_value    = number_format(floatval($db_data['paid_share_value'] ?? 0), 0, '.', ',');
$os_valuation_value     = number_format(floatval($db_data['valuation_value'] ?? 0), 0, '.', ',');
$os_allowable_expenses  = number_format(floatval($db_data['allowable_expenses'] ?? 0), 0, '.', ',');
$os_taxable_income      = number_format(floatval($db_data['taxable_income'] ?? 0), 0, '.', ',');
$os_income_tax          = number_format(floatval($db_data['income_tax'] ?? 0), 0, '.', ',');
$os_advance_tax         = number_format(floatval($db_data['advance_tax'] ?? 0), 0, '.', ',');
$os_tax_to_pay          = number_format(floatval($db_data['tax_to_pay'] ?? 0), 0, '.', ',');
$os_penalty_tax         = number_format(floatval($db_data['penalty_tax'] ?? 0), 0, '.', ',');
$os_total_tax           = number_format(floatval($db_data['total_tax'] ?? 0), 0, '.', ',');
$os_paid_amount         = number_format(floatval($db_data['paid_amount'] ?? 0), 0, '.', ',');



$os_chalan_no  = htmlspecialchars($db_data['chalan_no'] ?? '......');
$os_chalan_date = (!empty($db_data['chalan_date']) && $db_data['chalan_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['chalan_date'])) 
    : '............';
$os_chalan_date = htmlspecialchars($os_chalan_date);
//$os_chalan_date  = htmlspecialchars($db_data['chalan_date'] ?? '............');

$os_notified_date = (!empty($db_data['notified_date']) && $db_data['notified_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['notified_date'])) 
    : '............';
$os_notified_date = htmlspecialchars($os_notified_date);

//$os_notified_date  = htmlspecialchars($db_data['notified_date'] ?? '............');

$os_appointment_date = (!empty($db_data['appointment_date']) && $db_data['appointment_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['appointment_date'])) 
    : '............';
$os_appointment_date = htmlspecialchars($os_appointment_date);
//$os_appointment_date  = htmlspecialchars($db_data['appointment_date'] ?? '............');

$os_appearance_date = (!empty($db_data['appearance_date']) && $db_data['appearance_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['appearance_date'])) 
    : '............';
$os_appearance_date = htmlspecialchars($os_appearance_date);
//$os_appearance_date  = htmlspecialchars($db_data['appearance_date'] ?? '............');


$os_itDemandNo  = htmlspecialchars($db_data['it_demand_no'] ?? '......');
$os_itDemandDate = (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') 
    ? date('d-m-Y', strtotime($db_data['it_demand_date'])) 
    : '............';
$os_itDemandDate = htmlspecialchars($os_itDemandDate);
//$os_itDemandDate  = htmlspecialchars($db_data['it_demand_date'] ?? '............');

$os_investigation_value  = htmlspecialchars($db_data['investigation_value'] ?? '......');
$os_source_of_income  = htmlspecialchars($db_data['source_of_income'] ?? '............');
$os_investigation  = htmlspecialchars($db_data['investigation'] ?? '............');

$row_remain_amount = $row_total_tax - $row_paid_amount; 
$os_terget_date = '............'; // Default စာသား
if (!empty($db_data['it_demand_date']) && $db_data['it_demand_date'] !== '0000-00-00') {
    try {
        $date = new DateTime($db_data['it_demand_date']);
        $date->modify('+14 days'); // ရက်ပေါင်း ၁၄ ရက် တိုးလိုက်ခြင်း
        $os_terget_date = $date->format('d-m-Y'); // dd-mm-yyyy ပုံစံဖြင့် ထုတ်ယူခြင်း
    } catch (Exception $e) {
        $os_terget_date = '............';
    }
}
?>


<style>
/* 🖥️ SCREEN မြင်ကွင်းအတွက် (ကွန်ပျူတာပေါ်တွင် စာရွက်အစစ်ကဲ့သို့ မြင်ရစေရန်) */
#orderSheetModal .modal-dialog {
    max-width: 210mm; 
    margin: 30px auto;
}

/* 🚨 ပြဿနာဖြစ်စေသော background စတိုင်ကို Modal ပွင့်မှသာ အလုပ်လုပ်အောင် dialog အောက်တွင် ထည့်ရပါမည် */
#orderSheetModal .modal-content {   
    background-color: #f8f9fa;
    border: 1px solid rgba(0,0,0,0.2);
    box-shadow: 0 5px 15px rgba(0,0,0,0.5);
    border-radius: 6px;
}

#orderSheetModal .modal-body {
    padding: 0px !important;
    overflow-x: hidden;
}

/* 📄 စာရွက် Background စတိုင် (Screen ပေါ်တွင်ကြည့်ပါက အရိပ်ပါမည်) */
.print-container { 
    background: #ffffff;
    width: 210mm;
    min-height: 297mm;
    margin: 0 auto;
    padding: 5mm 5mm 5mm 5mm !important; /* ရုံးသုံး အနားသတ် */
    box-sizing: border-box;
}

/* 📊 ဇယားကွက် ပုံစံများ */
.main-content-table2 {
    width: 100% !important;
    margin-bottom: 5px;
    border-collapse: collapse;
}

.main-content-table2 td {
    padding: 2px 4px !important;
    font-size: 15px;
    vertical-align: middle;
}

.main-content-table {
    width: 100% !important;
    table-layout: fixed; 
    border-collapse: collapse !important;
    margin-top: 10px;
}

.main-content-table th, 
.main-content-table td {
    border: 1px solid #000000 !important; /* မျဉ်းနက်အပြည့်ခတ်ရန် */
    padding: 8px 10px !important;
    font-size: 15px;
    word-wrap: break-word !important;
}
.main-content-table tr { border-bottom: none !important; }
.main-content-table thead th {
    background-color: #f5f5f5 !important;
    font-weight: bold;
    text-align: center;
    vertical-align: middle;
}

/* Order Sheet ဇယားအတွက် သီးသန့် Border သတ်မှတ်ခြင်း */
.order-table {
    border-collapse: collapse;
    width: 100%;
}

.order-table th, .order-table td {
    border: 1px solid black; /* ပုံမှန် ဘောင်လိုင်းအမည်း */
    padding: 10px;
}

/* အလယ်က အလျားလိုက်လိုင်း များကို ဖျောက်ရန် Class */
.no-middle-border td {
    border-top: none !important;
    border-bottom: none !important;
}

/* 🖨️ PRINT ထုတ်ယူသည့်အခါ စတိုင် (ပထမရော နောက်စာမျက်နှာပါ အတွင်းလိုင်း/အပြင်လိုင်း အပြည့်ထွက်စေရန်) */
@media print {
    /* ၁။ မလိုလားအပ်သော Element များကို ပိတ်ခြင်း */
    .modal-footer, .no-print, .btn, .btn-close, .modal-header, button { 
        display: none !important; 
    }
    
    /* ၂။ Print မြင်ကွင်း တည်ဆောက်ပုံ */
    body {
        visibility: hidden;
        background: #ffffff !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }
    
    #orderSheetModal, #orderSheetModal * { 
        visibility: visible !important; 
    }
    
    #orderSheetModal {
        position: absolute;
        left: 0;
        top: 0;
        width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .modal-dialog, .modal-content, .print-container { 
        margin: 0 !important;
        max-width: 100% !important; 
        width: 100% !important;
        border: none !important; 
        box-shadow: none !important;
        background: transparent !important;
        padding: 0mm !important;
    }

    .print-container {
        padding: 0 4mm !important;
        box-sizing: border-box !important;
    }

    table.order-table {
        border-collapse: separate !important;
        border-spacing: 0 !important;
        width: 100% !important;
        border: none !important; 
    }

    table.order-table thead {
        display: table-header-group;
    }

    table.order-table thead th {
        padding: 8px 6px !important;
        font-size: 13px !important;
        color: #000000 !important;
        font-weight: bold !important;
        border-top: 1.5px solid #000000 !important;
        border-bottom: 1.5px solid #000000 !important;
        border-left: 1.5px solid #000000 !important;
        border-right: none !important;
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        box-decoration-break: clone;
    }

    table.order-table tbody td {
        padding: 4px 6px !important;
        font-size: 14px !important;
        color: #000000 !important;
        border-top: none !important;
        border-bottom: none !important;
        border-left: 1.5px solid #000000 !important;
        border-right: none !important;
    }

    table.order-table > tbody > tr.no-middle-border > td {
        border-top: none !important;
        border-bottom: none !important;
    }

    table.order-table > thead > tr > th:first-child,
    table.order-table > tbody > tr > td:first-child {
        border-left: none !important;
    }
    table.order-table > thead > tr > th:last-child,
    table.order-table > tbody > tr > td:last-child {
        border-right: none !important;
    }

    @page {
        size: A4;
        margin: 8mm 10mm 8mm 10mm;
    }
}
</style>

<!--<div class="modal fade" id="orderSheetModal" tabindex="-1">-->

<div class="modal fade" id="orderSheetModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-body">
                <div class="modal-header no-print" style="background-color: #0b5ed7; color: white; display: flex; justify-content: space-between; align-items: center; padding: 12px 20px; border-bottom: none;">
                    <h5 class="modal-title" style="font-size: 16px; font-weight: bold; margin: 0; color: white;">
                        အမိန့်စာချပ် ထုတ်ယူရန် (Order Sheet)
                    </h5>
                    <button type="button" class="close-modal-btn" onclick="window.location.href='../share_demand_list.php';" style="background: none; border: none; color: #ff4d4d; font-size: 26px; cursor: pointer; opacity: 1; font-weight: bold; line-height: 1; padding: 0 5px;">
                        ×
                    </button>
                </div>

                <div class="modal-body" id="printableSheet">
                    <div class="print-container">
                        <div style="text-align: center; margin-bottom: 0px;">
                            <h6 style="font-weight: bold; font-size: 15px; margin-bottom: 0px;">အမိန့်စာချပ်</h6>
                            <p style="font-weight: bold; font-size: 14px;">(အထွေထွေအမှုတွဲဖိုင်အတွက်အသုံးပြုရန်)</p>
                        </div>

                        <table class="main-content-table2">
                            <tr>
                                <td style="width:18%; "><b>မြို့နယ်ရုံးအမည်</b></td>
                                <td style="width:47%; border-bottom: 1.5px dotted #000 !important;">၊ <span id="os_township"><?php echo $os_township; ?></span>အခွန်ဦးစီးဌာနမှူးရုံး</td>
                                <td style="width:13%; text-align:right; border: 1.5px dotted #000 !important;"><b>စည်းကြပ်နှစ်:</b></td>
                                <td style="width:22%; border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_year"><?php echo $os_year; ?></span></td>
                            </tr>
                            <tr>
                                <td><b>အခွန်ထမ်းအမည်</b></td>
                                <td style="border-bottom: 1.5px dotted #000 !important;">၊ <span id="os_name"><?php echo $os_name; ?></span>/( <span id="os_nrc_no"><?php echo $os_nrc_no; ?></span> )</td>
                                <td style="text-align:right; border: 1.5px dotted #000 !important;"><b>GIR-No:</b></td>
                                <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_gir"><?php echo $os_gir; ?></span>/<span id="os_gir_type"><?php echo $os_gir_type; ?></span></td>
                            </tr>
                            <tr>
                                <td><b>အခွန်ထမ်းလိပ်စာ</b></td>
                                <td style="border-bottom: 1.5px dotted #000 !important;">၊ <span id="os_address"><?php echo $os_address; ?></span></td>
                                <td style="text-align:right; border: 1.5px dotted #000 !important;"><b>အခွန်မှူး:</b></td>
                                <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_officer"><?php echo $os_officer; ?></span></td>
                            </tr>
                            <tr>
                                <td><b>လုပ်ငန်းအမျိုးအစား</b></td>
                                <td style="border-bottom: 1.5px dotted #000 !important;">၊ <span id="os_biz"><?php echo $os_biz; ?></span></td>
                                <td style="text-align:right; border: 1.5px dotted #000 !important;"><b>ရာထူး:</b></td>
                                <td style="border: 1.5px dotted #000 !important; text-align:center;"> <span id="os_rank"><?php echo $os_rank; ?></span></td>
                            </tr>
                        <?php 
                        if ($os_biz === 'အခြားရင်းနှီးမြုပ်နှံမှု') { 
                        ?>
                            <tr>
                                <td></td>
                                <td colspan='3' style="border-bottom: 1.5px dotted #000 !important; font-size:14px;">၊ (<span id="os_company_name"><?php echo $os_company_name; ?></span>)၊ 
                                    </td>
                            </tr>
                        <?php 
                        }else{ 
                        ?>
                            <tr>
                                <td></td>
                                <td colspan='3' style="border-bottom: 1.5px dotted #000 !important; font-size:14px;">၊ အစုတစ်စုတန်ဖိုး(<span id="os_share_value"><?php echo $os_share_value; ?></span>)၊ 
                                    ထည့်ဝင်သည့်အစုရှယ်ယာ(<span id="os_paid"><?php echo $os_paid; ?></span>)စု၊ </td>
                            </tr>
                        <?php 
                        }
                        ?>
                        </table>
                        <table class="order-table">
                            <thead>
                                <tr style="font-weight: bold; font-size: 12px; text-align:center;">
                                    <th style="width:12%; border-left:none !important;">ဆောင်ရွက်<br>သည့်နေ့စွဲ</th>
                                    <th style="width:76%">လုပ်ငန်းအကြောင်းအရာအကျဉ်းချုပ်</th>
                                    <th style="width:12%;border-right:none !important;">လိုက်နာဆောင်<br>ရွက်သည့်နေ့</th>
                                </tr>
                            </thead>
                        <?php 
                        // 🌟 🌟 🌟 [၁။ ပထမဆုံးအဆင့် - "အခြေ" ဖြစ်/မဖြစ် စစ်ဆေးခြင်း] 🌟 🌟 🌟
                        if ($os_biz === 'အစုရှယ်ယာရောင်းချခြင်း') { 
                        ?>
                        <tbody>
                            
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: justify; vertical-align:top;">............</td>
                                    <td >  
                                        <p style="text-align:justify !important;"> အခွန်ထမ်းသည် အစုတစ်စုတန်ဖိုး
                                        ( <span style="color:red;" id="os_share_value"><?php echo $os_share_value; ?></span> )ကျပ်တန်ဖိုးရှိ အစုရှယ်ယာပေါင်း(
                                        <span style="color:red;" id="os_paid"><?php echo $os_paid; ?></span> ) စု၊ အစုရယ်ယာတန်ဖိုးစုစုပေါင်း(  
                                        <span style="color:red;" id="os_paid_share_value"><?php echo $os_paid_share_value; ?></span> )
                                        ကျပ်ကို ရောင်းချခဲ့ကြောင်း သတင်းရရှိသဖြင့် အခြေပစ္စည်းမှမြတ်စွန်းငွေစိစစ်နိုင်ရန်အတွက် အမှုတွဲဖွင့်လှစ်သည်။</P>

                                        <br>
                                        <div style="text-align: right; padding-right: 60px; font-weight: bold;">စာရေးကြီး</div>
                                    </td>
                                    <td style=" border-left: 1.5px solid #000000 !important; border-right: none !important;"></td>
                                </tr>
                           
                                
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_notified_date"><?php echo $os_notified_date; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်းအား အစုရှယ်ယာရောင်းချခဲ့ခြင်းနှင့် ပတ်သက်၍ 
                                            မြတ်စွန်းငွေ စိစစ်နိုင်ရန်အတွက် အထောက်အထားများတင်ပြပေးရန် ပတခ(ဝင)-၅ ဖြင့် အကြောင်းကြားစာထုတ်ဆင့်ပါ။ </p>
                                        <br><br><br>
                                        
                                        <div style="text-align: right; padding-right: 60px; font-weight: bold;">အခွန်မှူး</div>
                                   
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top; font-weight: bold;"><span id="os_appointment_date"><?php echo $os_appointment_date; ?></span><br>ချိန်း</td>
                                </tr>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_appearance_date"><?php echo $os_appearance_date; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်း/ အခွန်ထမ်း၏ ကိုယ်စားလှယ်မှ လာရောက်ထွက်ဆိုသည်။  အစုရှယ်ယာရောင်းချခြင်းဆိုင်ရာ တင်ပြချက်အထောက်အထားများနှင့် ထွက်ဆိုချက်များအား ရယူသည်။</p>
                                        <br><br><br>
                                        <div style="text-align: right; padding-right: 60px; font-weight: bold;">အခွန်မှူး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                </tr>
                     
                                
                                
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_itDemandDate"><?php echo $os_itDemandDate; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်းတင်ပြသော အစုရှယ်ယာရောင်းချသည့်တန်ဖိုး၊ ကုမ္ပဏီမှတ်ပုံတင်၊ ကုမ္ပဏီ extract Form ပါ အထောက်အထားများနှင့် ရရှိထားသောသတင်းအချက်အလက်များအရ
                                            အစုရှယ်ယာရောင်းချခြင်းအတွက် မြတ်စွန်းငွေနှင့်ပတ်သက်၍ အောက်ပါအတိုင်း ဝင်ငွေခွန်စည်းကြပ်မှုအမိန့် ချမှတ်လိုက်သည်- </p>
                                        
                                        <table style="width:100%; border:none !important; line-height: 18px; ">
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right;">အစုရှယ်ယာအရောင်းသတ်မှတ်တန်ဖိုး</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px dashed #000 !important; 
                                                text-align:right; font-weight: bold;" id="os_taxable_income"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right; color:red;">(နုတ်)မူလတန်ဖိုးနှင့်စရိတ်</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px dashed #000 !important; 
                                                text-align:right; font-weight: bold; color:red;" id="os_taxable_income"><span id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right;">အခြေပစ္စည်းမှမြတ်စွန်းငွေ</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px solid #000 !important; 
                                                    text-align:right; font-weight: bold;" id="os_taxable_income"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; text-align:right;">ကျသင့်ဝင်ငွေခွန်</td>
                                                <td style="border:none !important; text-align:center;">=</td>
                                                <td style="border:none !important; border-bottom: 1.5px solid #000 !important;
                                                    text-align:right; font-weight: bold;" id="os_income_tax"><span id="os_income_tax"><?php echo $os_income_tax; ?></td>
                                                <td style="border:none !important;"></td>
                                            </tr>
                                            
                                        </table>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: left; vertical-align:top; font-weight: bold;">CDN-<span id="os_itDemandNo"><?php echo $os_itDemandNo; ?></span></td>
                                </tr>
                                <br><br>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_itDemandDate"><?php echo $os_itDemandDate; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important; ">ကျသင့်အခွန်( <span style="color:red;" id="os_itDeos_tax_to_paymandDate"><?php echo $os_tax_to_pay; ?></span></strong> ) 
                                        ကျပ်ကို ( <span style="color:red;" id="os_terget_date"><?php echo $os_terget_date; ?></span> )ရက်နေ့ မတိုင်မီ ပေးဆောင်စေရန် ချလန်ထုတ်ဆင့်ပါ။</p>
                                        <br><br><br><br>
                                        <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                </tr>
                                

                                <?php 
                                // 🎯 ၁။ Database ကလာတဲ့ တန်ဖိုးများကို ဖမ်းယူခြင်း
                                $total_tax_num   = floatval($db_data['total_tax'] ?? 0);
                                $paid_amount_num = floatval($db_data['paid_amount'] ?? 0);

                                // 🎯 ၂။ ကြွေးကျန်ငွေကို နှုတ်ပြီး Floating-point Error မတက်အောင် round လုပ်ခြင်း
                                $row_remain_amount = round($total_tax_num - $paid_amount_num); 

                                // 🎯 ၃။ ကြွေးကျန်ငွေ ၁ ကျပ် နှင့်အထက် ရှိနေလျှင် (မပြေကြေသေးလျှင်)
                                if ($row_remain_amount >= 1) { 
                                ?>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;">................</td>
                                        <td>
                                            <p style="text-align:justify !important;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေကို စည်းကြပ်သည့်နှစ်အတွင်း ပေးသွင်းခြင်း မရှိသည့်အတွက် 
                                                အခွန်ကြွေးကျန်ငွေအား အခွန်မပြေကျန်ငွေမှတ်ပုံတင်စာရင်းသို့ ကူးပြောင်းမှတ်တမ်းတင်သည်။</p>
                                            <br><br><br>
                                            <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr> 
                                <?php 
                                } else { 
                                // 🎯 ၄။ ကြွေးကျန် ၀ ဖြစ်သွားလျှင် (ပြေကျေစွာ ပေးသွင်းပြီးပါက == 0 အခြေအနေ)
                                ?>  
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"> 
                                            <span id="os_chalan_date"><?php echo $os_chalan_date; ?></span>
                                        </td>
                                        <td>
                                            <p style="text-align:justify !important;">ကျသင့်အခွန်ငွေ ( <span style="color:red;" id="os_total_tax"><?php echo $os_total_tax; ?></span> )
                                                ကျပ်ကို( <span style="color:red;" id="os_chalan_date"><?php echo $os_chalan_date; ?></span> )
                                                ရက်နေ့တွင် ချလန်အမှတ်( <span style="color:red;" id="os_chalan_no"><?php echo $os_chalan_no; ?></span> )ဖြင့် 
                                                ပြေကြေစွာပေးသွင်းပြီး ဖြစ်ပါသဖြင့် အမှုပိတ်သိမ်းသည်။ </p>
                                            <br><br>
                                            <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td></td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                <?php 
                                } // if-else အပိတ်
                                ?>
                        </table>
                        <?php 
                        } else if ($os_biz === 'အခြားရင်းနှီးမြုပ်နှံမှု'){ 
                        ?> 
                           
                        
                             <tbody>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: justify; vertical-align:top;">............</td>
                                    <td >  
                                        <p style="text-align:justify !important;"> အခွန်ထမ်းသည် 
                                        ( <span style="color:red;" id="os_company_name"><?php echo $os_company_name; ?></span> )စတင်ဆောင်ရွက်ကြောင်း 
                                        စုံစမ်းသိရှိရပါသဖြင့် လုပ်ငန်းအပေါ် ဝင်ငွေရလမ်းများကို စိစစ်နိုင်ရန် အမှုတွဲ ဖွင့်လှစ်ပါသည်။</P>

                                        <br> <br> <br>
                                        <div style="padding-left: 420px; font-weight: bold;">စာရေးကြီး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; "></td>
                                </tr>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_notified_date"><?php echo $os_notified_date; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်းအား လုပ်ငန်းတည်ထောင်ခြင်းနှင့် ပတ်သက်၍ 
                                            ဝင်ငွေရလမ်းအား စိစစ်နိုင်ရန်အတွက် အထောက်အထားများတင်ပြပေးရန် ပတခ(ဝင)-၅ ဖြင့် အကြောင်းကြားစာထုတ်ဆင့်ပါ။ </p>
                                        <br><br><br>
                                        <div style="text-align: right; padding-right: 60px; font-weight: bold;">အခွန်မှူး</div>
                                   
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top; font-weight: bold;"><span id="os_appointment_date"><?php echo $os_appointment_date; ?></span><br>ချိန်း</td>
                                </tr>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_appearance_date"><?php echo $os_appearance_date; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်း/ အခွန်ထမ်း၏ ကိုယ်စားလှယ်မှ လာရောက်ထွက်ဆိုသည်။  ဝင်ငွေရလမ်းဆိုင်ရာ တင်ပြချက်များနှင့် ထွက်ဆိုချက်များအား ရယူသည်။</p>
                                        <br><br>
                                        <div style="text-align: right; padding-right: 60px; font-weight: bold;">အခွန်မှူး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                </tr>
                     
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_itDemandDate"><?php echo $os_itDemandDate; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်းတင်ပြသော ကုမ္ပဏီမှတ်ပုံတင်၊ ကုမ္ပဏီ extract Form ပါ အထောက်အထားများနှင့် 
                                            အခွန်ထမ်းတင်ပြသည့် ဝင်ငွေရလမ်းများအရ အစုရှယ်ယာထည့်ဝင်ခြင်းအတွက် အောက်ပါအတိုင်း ဝင်ငွေခွန်စည်းကြပ်မှုအမိန့် ချမှတ်လိုက်သည်- </p>
                                        
                                        <table style="width:100%; border:none !important; line-height: 18px; ">
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right;">စိစစ်သည့်ရင်းနှီးမြုပ်နှံမှုတန်ဖိုး</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px dashed #000 !important; 
                                                text-align:right; font-weight: bold;" id="os_taxable_income"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right; color:red;">(နုတ်)ခွင့်ပြုဝင်ငွေရလမ်း</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px dashed #000 !important; 
                                                text-align:right; font-weight: bold; color:red;" id="os_taxable_income"><span id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right;">စည်းကြပ်မှုမှလွတ်ကင်းနေသောဝင်ငွေ</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px solid #000 !important; 
                                                    text-align:right; font-weight: bold;" id="os_taxable_income"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; text-align:right;">ကျသင့်ဝင်ငွေခွန်</td>
                                                <td style="border:none !important; text-align:center;">=</td>
                                                <td style="border:none !important; border-bottom: 1.5px solid #000 !important;
                                                    text-align:right; font-weight: bold;" id="os_income_tax"><span id="os_income_tax"><?php echo $os_income_tax; ?></td>
                                                <td style="border:none !important;"></td>
                                            </tr>  
                                            <tr>
                                                <td style="border:none !important; text-align:right;"></td>
                                                <td style="border:none !important; text-align:center;"></td>
                                                <td style="border:none !important; border-bottom: 0px solid #000 !important;
                                                    text-align:right; font-weight: bold;">&nbsp;<br><br><br><br></td>
                                                <td style="border:none !important;"></td>
                                            </tr>                   
                                        </table>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top; font-weight: bold;">CDN-<span id="os_itDemandNo"><?php echo $os_itDemandNo; ?></span></td>
                                </tr>
                                
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_itDemandDate"><?php echo $os_itDemandDate; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important; ">ကျသင့်အခွန်( <span style="color:red;" id="os_itDeos_tax_to_paymandDate"><?php echo $os_tax_to_pay; ?></span></strong> ) 
                                        ကျပ်ကို ( <span style="color:red;" id="os_terget_date"><?php echo $os_terget_date; ?></span> )ရက်နေ့ မတိုင်မီ ပေးဆောင်စေရန် ချလန်ထုတ်ဆင့်ပါ။</p>
                                        <br><br><br><br>
                                        <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                </tr>
                                

                                <?php 
                                // 🎯 ၁။ Database ကလာတဲ့ တန်ဖိုးများကို ဖမ်းယူခြင်း
                                $total_tax_num   = floatval($db_data['total_tax'] ?? 0);
                                $paid_amount_num = floatval($db_data['paid_amount'] ?? 0);

                                // 🎯 ၂။ ကြွေးကျန်ငွေကို နှုတ်ပြီး Floating-point Error မတက်အောင် round လုပ်ခြင်း
                                $row_remain_amount = round($total_tax_num - $paid_amount_num); 

                                // 🎯 ၃။ ကြွေးကျန်ငွေ ၁ ကျပ် နှင့်အထက် ရှိနေလျှင် (မပြေကြေသေးလျှင်)
                                if ($row_remain_amount >= 1) { 
                                ?>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;">................</td>
                                        <td>
                                            <p style="text-align:justify !important;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေကို စည်းကြပ်သည့်နှစ်အတွင်း ပေးသွင်းခြင်း မရှိသည့်အတွက် 
                                                အခွန်ကြွေးကျန်ငွေအား အခွန်မပြေကျန်ငွေမှတ်ပုံတင်စာရင်းသို့ ကူးပြောင်းမှတ်တမ်းတင်သည်။</p>
                                            <br><br><br>
                                            <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br>
                                            
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr> 
                                <?php 
                                } else { 
                                // 🎯 ၄။ ကြွေးကျန် ၀ ဖြစ်သွားလျှင် (ပြေကျေစွာ ပေးသွင်းပြီးပါက == 0 အခြေအနေ)
                                ?>   
                                <tbody>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"> 
                                            <span id="os_chalan_date"><?php echo $os_chalan_date; ?></span>
                                        </td>
                                        <td>
                                            <p style="text-align:justify !important;">ကျသင့်အခွန်ငွေ ( <span style="color:red;" id="os_total_tax"><?php echo $os_total_tax; ?></span> )
                                                ကျပ်ကို( <span style="color:red;" id="os_chalan_date"><?php echo $os_chalan_date; ?></span> )
                                                ရက်နေ့တွင် ချလန်အမှတ်( <span style="color:red;" id="os_chalan_no"><?php echo $os_chalan_no; ?></span> ) ဖြင့် 
                                                ပြေကြေစွာပေးသွင်းပြီး ဖြစ်ပါသဖြင့် အမှုပိတ်သိမ်းသည်။ </p>
                                            <br><br>
                                            <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td></td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <?php 
                                    } // if-else အပိတ်
                                    ?>
                        </table>
                        <?php 
                        //အစုရှယ်ယာထည့်ဝင်ခြင်းဆိုလျှင်
                        }else{ 
                        ?>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: justify; vertical-align:top;">............</td>
                                    <td >  
                                        <p style="text-align:justify !important;"> အခွန်ထမ်းသည် အစုတစ်စုတန်ဖိုး
                                        ( <span style="color:red;" id="os_share_value"><?php echo $os_share_value; ?></span> )၊ ထည့်ဝင်သည့်အစုရှယ်ယာပေါင်း(
                                        <span style="color:red;" id="os_paid"><?php echo $os_paid; ?></span> ) စု၊ အစုရယ်ယာတန်ဖိုးစုစုပေါင်း(  
                                        <span style="color:red;" id="os_paid_share_value"><?php echo $os_paid_share_value; ?></span> )
                                        ထည့်ဝင်ခြင်းအတွက် ဝင်ငွေရလမ်းစိစစ်ပေးပါရန် ကုမ္ပဏီမှတ်ပုံတင်လက်မှတ်၊ ကုမ္ပဏီ extract Form ၊ အိမ်ထောင်စုဇယား၊ မှတ်ပုံတင်မိတ္တူနှင့်တကွ တင်ပြလာပါသဖြင့် အမှုတွဲ ဖွင့်လှစ်ပါသည်။</P>

                                        <br>
                                        <div style="padding-right: 60px; font-weight: bold;">စာရေးကြီး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; "></td>
                                </tr>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_notified_date"><?php echo $os_notified_date; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်းအား အစုရှယ်ယာထည့်ဝင်ခြင်းနှင့် ပတ်သက်၍ 
                                            ဝင်ငွေရလမ်းအား စိစစ်နိုင်ရန်အတွက် အထောက်အထားများတင်ပြပေးရန် ပတခ(ဝင)-၅ ဖြင့် အကြောင်းကြားစာထုတ်ဆင့်ပါ။ </p>
                                        <br><br><br>
                                        <div style="text-align: right; padding-right: 60px; font-weight: bold;">အခွန်မှူး</div>
                                   
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top; font-weight: bold;"><span id="os_appointment_date"><?php echo $os_appointment_date; ?></span><br>ချိန်း</td>
                                </tr>
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_appearance_date"><?php echo $os_appearance_date; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်း/ အခွန်ထမ်း၏ ကိုယ်စားလှယ်မှ လာရောက်ထွက်ဆိုသည်။  ဝင်ငွေရလမ်းဆိုင်ရာ တင်ပြချက်များနှင့် ထွက်ဆိုချက်များအား ရယူသည်။</p>
                                        <br><br>
                                        <div style="text-align: right; padding-right: 60px; font-weight: bold;">အခွန်မှူး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                </tr>
                     
                                
                                
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_itDemandDate"><?php echo $os_itDemandDate; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important;">အခွန်ထမ်းတင်ပြသော ကုမ္ပဏီမှတ်ပုံတင်၊ ကုမ္ပဏီ extract Form ပါ အထောက်အထားများနှင့် 
                                            အခွန်ထမ်းတင်ပြသည့် ဝင်ငွေရလမ်းများအရ အစုရှယ်ယာထည့်ဝင်ခြင်းအတွက် အောက်ပါအတိုင်း ဝင်ငွေခွန်စည်းကြပ်မှုအမိန့် ချမှတ်လိုက်သည်- </p>
                                        
                                        <table style="width:100%; border:none !important; line-height: 18px; ">
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right;">အစုရှယ်ယာတန်ဖိုးစုစုပေါင်း</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px dashed #000 !important; 
                                                text-align:right; font-weight: bold;" id="os_taxable_income"><span id="os_valuation_value"><?php echo $os_valuation_value; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right; color:red;">(နုတ်)ခွင့်ပြုဝင်ငွေရလမ်း</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px dashed #000 !important; 
                                                text-align:right; font-weight: bold; color:red;" id="os_taxable_income"><span id="os_allowable_expenses"><?php echo $os_allowable_expenses; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; width:55%; text-align:right;">စည်းကြပ်မှုမှလွတ်ကင်းနေသောဝင်ငွေ</td>
                                                <td style="border:none !important; width:5%; text-align:center;">=</td>
                                                <td style="border:none !important; width:25%; border-bottom: 1.5px solid #000 !important; 
                                                    text-align:right; font-weight: bold;" id="os_taxable_income"><span id="os_taxable_income"><?php echo $os_taxable_income; ?></td>
                                                <td style="border:none !important; width:15%;"></td>
                                            </tr>
                                            <tr>
                                                <td style="border:none !important; text-align:right;">ကျသင့်ဝင်ငွေခွန်</td>
                                                <td style="border:none !important; text-align:center;">=</td>
                                                <td style="border:none !important; border-bottom: 1.5px solid #000 !important;
                                                    text-align:right; font-weight: bold;" id="os_income_tax"><span id="os_income_tax"><?php echo $os_income_tax; ?></td>
                                                <td style="border:none !important;"></td>
                                            </tr>                     
                                        </table>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top; font-weight: bold;">CDN-<span id="os_itDemandNo"><?php echo $os_itDemandNo; ?></span></td>
                                </tr>
                                
                                <tr class="no-middle-border">
                                    <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"><span id="os_itDemandDate"><?php echo $os_itDemandDate; ?></span></td>
                                    <td >
                                        <p style="text-align:justify !important; ">ကျသင့်အခွန်( <span style="color:red;" id="os_itDeos_tax_to_paymandDate"><?php echo $os_tax_to_pay; ?></span></strong> ) 
                                        ကျပ်ကို ( <span style="color:red;" id="os_terget_date"><?php echo $os_terget_date; ?></span> )ရက်နေ့ မတိုင်မီ ပေးဆောင်စေရန် ချလန်ထုတ်ဆင့်ပါ။</p>
                                        <br><br><br><br>
                                        <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                    </td>
                                    <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                </tr>
                                

                                <?php 
                                // 🎯 ၁။ Database ကလာတဲ့ တန်ဖိုးများကို ဖမ်းယူခြင်း
                                $total_tax_num   = floatval($db_data['total_tax'] ?? 0);
                                $paid_amount_num = floatval($db_data['paid_amount'] ?? 0);

                                // 🎯 ၂။ ကြွေးကျန်ငွေကို နှုတ်ပြီး Floating-point Error မတက်အောင် round လုပ်ခြင်း
                                $row_remain_amount = round($total_tax_num - $paid_amount_num); 

                                // 🎯 ၃။ ကြွေးကျန်ငွေ ၁ ကျပ် နှင့်အထက် ရှိနေလျှင် (မပြေကြေသေးလျှင်)
                                if ($row_remain_amount >= 1) { 
                                ?>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;">................</td>
                                        <td>
                                            <p style="text-align:justify !important;">ကျသင့်အခွန်နှင့်ဒဏ်ကြေးငွေကို စည်းကြပ်သည့်နှစ်အတွင်း ပေးသွင်းခြင်း မရှိသည့်အတွက် 
                                                အခွန်ကြွေးကျန်ငွေအား အခွန်မပြေကျန်ငွေမှတ်ပုံတင်စာရင်းသို့ ကူးပြောင်းမှတ်တမ်းတင်သည်။</p>
                                            <br><br><br>
                                            <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br>
                                            
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr> 
                                <?php 
                                } else { 
                                // 🎯 ၄။ ကြွေးကျန် ၀ ဖြစ်သွားလျှင် (ပြေကျေစွာ ပေးသွင်းပြီးပါက == 0 အခြေအနေ)
                                ?>  
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"> 
                                            <span id="os_chalan_date"><?php echo $os_chalan_date; ?></span>
                                        </td>
                                        <td>
                                            <p style="text-align:justify !important;">ကျသင့်အခွန်ငွေ ( <span style="color:red;" id="os_total_tax"><?php echo $os_total_tax; ?></span> )
                                                ကျပ်ကို( <span style="color:red;" id="os_chalan_date"><?php echo $os_chalan_date; ?></span> )
                                                ရက်နေ့တွင် ချလန်အမှတ်( <span style="color:red;" id="os_chalan_no"><?php echo $os_chalan_no; ?></span> ) ဖြင့် 
                                                ပြေကြေစွာပေးသွင်းပြီး ဖြစ်ပါသဖြင့် အမှုပိတ်သိမ်းသည်။ ကျသင့်တံဆိပ်ခေါင်းခွန်ကို တံဆိပ်ခေါင်းအက်ဥပဒေပါ သတ်မှတ်ချက်များနှင့်အညီ ဆက်လက်ရောင်းချပေးသွားရန်။</p>
                                            <br><br>
                                            <div style="text-align: right; padding-right: 80px; font-weight: bold;">အခွန်မှူး</div>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td></td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                    <tr class="no-middle-border">
                                        <td style="border-right: 1.5px solid #000000 !important; border-left: none !important; text-align: center; vertical-align:top;"></td>
                                        <td>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                            <br><br><br><br><br><br><br><br>
                                        </td>
                                        <td style="border-left: 1.5px solid #000000 !important; border-right: none !important; text-align: center; vertical-align:top;"></td>
                                    </tr>
                                <?php 
                                } // if-else အပိတ်
                                ?>
                        </table>                    
                        <?php 
                        } // if-else အပိတ်
                        ?>
                    </div>
                </div>
             
                <div style="background-color: #74a6f1; height:70px;" class="modal-footer no-print d-flex" style="width: 100%; border-top: 1px solid #dee2e6; padding: 15px; background-color: #ffffff;">
    
                   <div style="padding-left:540px; padding-top:15px" class="modal-footer no-print d-flex justify-content-end align-items-center gap-2" style="width: 100%; border-top: 1px solid #dee2e6; padding: 15px; ">

                        <button type="button" class="btn px-4" onclick="window.print()" 
                                style="background-color: #28a745 !important; color: #ffffff !important; border: 1px solid #191b1a !important; font-weight: bold; padding: 8px 20px; border-radius:8px;">
                            <i class="fa fa-print"></i> Print ထုတ်မည်
                        </button>
                        <button type="button" class="btn px-4" 
                                onclick="window.location.href='../share_demand_list.php?openModal=formsModal2';" 
                                style="background-color: #dc3545 !important; color: #ffffff !important; border: 1px solid #262424 !important; font-weight: bold; margin-left: 5px; padding: 8px 20px; border-radius:8px;">
                            ပိတ်မည်
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    var myModalEl = document.getElementById('orderSheetModal'); 
    var modal = bootstrap.Modal.getInstance(myModalEl) || new bootstrap.Modal(myModalEl);
    // modal.show(); //



// အကယ်၍ string ဖြစ်နေပြီး ကော်မာများ ပါဝင်နေပါက ဖယ်ရှား၍ ကိန်းပြည့်ပြောင်းရန် Helper
function parseToNumber(val) {
    if (!val) return 0;
    let cleanVal = String(val).replace(/,/g, ''); 
    return parseInt(cleanVal) || 0;
}
</script>