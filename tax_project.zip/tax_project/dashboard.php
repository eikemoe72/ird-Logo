<?php
session_start();
include 'db_config.php';

// Login user_name မရှိရင် login.php ကို ပြန်ပို့မယ်
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php"); 
    exit();
}

// ၂။ Default တန်ဖိုးပေးထားခြင်း
$state_name = "ပြည်နယ်/တိုင်း";
$township_name = "မြို့နယ်";
$officer_name = "";
$rank = "";
$current_user = $_SESSION['user_name'];

// ၃။ Query ကို ပြင်ဆင်ခြင်း (Single Quote ' ' သေချာထည့်ရန်)
$query = "SELECT state_name, township_name, officer_name,rank_ FROM user_register WHERE user_name = '$current_user' LIMIT 1";
$result = $conn->query($query);

// ၄။ Database ထဲမှ data ရှိလျှင် variable ထဲသို့ ထည့်မည်
if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $state_name = $row['state_name'];
    $township_name = $row['township_name'];
    $officer_name = $row['officer_name'];
    $rank = $row['rank_'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tax Calculation & Printing System</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <style>
        :root {
            --primary-gold: #c5a059;
            --dark-purple: #2e004f;
        }

        body {
            font-family: 'Inter', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0fdf4;
            min-height: 100vh;
            height: 100vh;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }

        header {
            background: var(--dark-purple);
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            padding: 0 12px;
            position: relative;
            width: 100%;
            z-index: 2000;
            box-sizing: border-box;
            flex: 0 0 auto;
        }

        .nav-bar {
            list-style: none;
            margin: 0;
            padding: 4px 8px;
            display: grid;
            grid-template-columns: minmax(150px, 1fr) auto minmax(150px, 1fr);
            align-items: center;
            gap: 8px;
        }

        .brand-container {
            display: flex;
            align-items: center;
            justify-self: start;
            min-width: 0;
            min-height: 48px;
        }

        .menu-group { list-style: none; min-width: 0; }
        .menu-group > ul {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 2px 4px;
            list-style: none;
            margin: 0;
            padding: 0;
        }
        .lg {
        width: 36px !important;
        height: auto !important;
        margin-right: 8px;
        flex: 0 0 auto;
        }

        .TCPS { font-size: clamp(0.72rem, 1.1vw, 0.9rem); font-weight: 800; color: #ffcc00; line-height: 1.25; }

        .nav-item {
            position: relative;
            display: flex;
            align-items: center;
            min-height: 44px;
            padding: 0 8px;
        }

        .nav-item > a {
            color: #f0f0f0;
            text-decoration: none;
            font-weight: 600;
            font-size: clamp(12px, 1.2vw, 14px);
            white-space: nowrap;
            display: flex;
            align-items: center;
            height: 100%; /* Area အပြည့်ယူထား၍ ထောက်ရလွယ်စေသည် */
        }

        .menu-icon { width: 18px; margin-right: 6px; }

        /* Dropdown Fix: Gap မရှိအောင် ပြင်ဆင်ခြင်း */
        .dropdown-content {
            display: none;
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            min-width: 220px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            border-radius: 0 0 5px 5px;
            z-index: 3000;
        }

        .nav-item:hover .dropdown-content {
            display: block;
        }

        .dropdown-content a {
            color: #333 !important;
            padding: 12px 20px;
            border-bottom: 1px solid #eee;
            display: block;
            text-decoration: none;
            font-size: 13.5px;
        }

        .dropdown-content a:hover {
            background-color: var(--primary-gold);
            color: white !important;
        }

        /* Main Container: Absolute Center */
        .info-bar {
            width: 100%;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 6px 16px;
            padding: 10px 16px;
            background-color: #ffffff;
            border-bottom: 1px solid #eee;
            box-sizing: border-box;
            position: relative;
            z-index: 1;
            flex: 0 0 auto;
        }
        .info-bar > div {
            color: #4b0082;
            font-weight: bold;
            font-size: clamp(0.85rem, 1.5vw, 1.1rem);
            flex: 1 1 180px;
            min-width: 0;
            text-align: center;
            line-height: 1.35;
            overflow-wrap: anywhere;
        }

        .main-container {
            position: relative;
            width: 100%;
            flex: 1 1 auto;
            min-height: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
        }

        .heading-box {
            background: white;
            padding: 10px 50px;
            border-radius: 15px;
            box-shadow: 0 15px 40px rgba(0,0,0,0.1);
            border: 2px solid var(--primary-gold);
            text-align: center;
            z-index: 100;
            width: 550px;
            max-width: 92%;
            position: relative;
            box-sizing: border-box;
        }

        .heading-box h1 { font-size: 32px; color: var(--dark-purple); margin: 15px 0 0; }
        .heading-box p { font-size: 22px; color: var(--primary-gold); font-weight: 700; margin: 25px 0 10px; }

        @media (max-width: 1300px) {
            .heading-box { width: min(550px, 42vw); padding: 8px 16px; }
            .heading-box h1 { font-size: clamp(16px, 2.2vw, 26px); margin-top: 8px; }
            .heading-box p { font-size: clamp(13px, 1.6vw, 18px); margin: 10px 0 8px; }
        }

        /* Image Frames: W:230px, H:150px */
        .image-frame {
            position: absolute;
            width: 230px; 
            height: 150px;
            background: white;
            border: 3px solid var(--primary-gold);
            box-shadow: 0 10px 20px rgba(0,0,0,0.15);
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 1s ease-in-out;
        }

        .image-frame img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        /* Footer Marquee */
        .footer-marquee {
            background: var(--dark-purple);
            color: #ffcc00;
            padding: 12px 0;
            position: relative;
            flex: 0 0 auto;
            width: 100%;
            box-sizing: border-box;
            font-weight: bold;
            z-index: 1000;
            overflow: hidden;
        }

        .marquee-text {
            display: inline-block;
            white-space: nowrap;
            animation: marquee 50s linear infinite;
        }

        @keyframes marquee {
            0% { transform: translateX(100vw); }
            100% { transform: translateX(-100%); }
        }


        /* Logout Button Styling */
.logout-item {
    margin-left: 0;
    justify-self: end;
    padding: 6px 4px;
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    justify-content: flex-end;
}

@media (max-width: 860px) {
    .nav-bar { display: flex; flex-wrap: wrap; }
    .menu-group { flex: 1 1 100%; }
}
.logout-item strong { font-size: clamp(12px, 1.3vw, 14px); }

.logout-btn {
    background: linear-gradient(135deg, #ff416c, #ff4b2b); /* အနီရောင် Gradient */
    color: white !important;
    padding: 8px 18px !important;
    border-radius: 20px;
    font-size: 14px !important;
    font-weight: bold !important;
    transition: 0.3s all;
    box-shadow: 0 4px 10px rgba(255, 75, 43, 0.3);
}

.logout-btn:hover {
    background: linear-gradient(135deg, #60ff2b, #5148f0);
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(255, 75, 43, 0.4);
}
    </style>
</head>
<body>

<header>
    <nav>
        <ul class="nav-bar">
            <li class="brand-container">
                <img src="Image/ird-logo.png" class="menu-icon lg" alt="IRD Logo">
                <div class="TCPS">TAX CALCULATION & CASE PRINTING SYSTEM</div>
            </li>
            <li class="menu-group">
            <ul>

            <li class="nav-item">
                <a href="#"><img src="Image/ird-logo.png" class="menu-icon" alt="IRD Logo"> Calculation Form</a>
                <div class="dropdown-content">
                    <a href="Calculation_form1.php?mode=new">Regular Calculation Form</a>
                    <!--<a href="Calculation_Form1.php">Regular Calculation Form</a>-->
                    <a href="housing_form.php">Housing Calculation Form</a>
                    <a href="vehicle_form.php">Vehicle Calculation Form</a>
                    <a href="share_form.php">Share Calculation Form</a>
                    <a href="Under48_Form.php">Under 48 Form</a>
                </div>
            </li>

            <li class="nav-item">
                <a href="#"><img src="Image/ird-logo.png" class="menu-icon" alt="IRD Logo"> Demand List</a>
                <div class="dropdown-content">
                    <a href="IT_Demand_List.php">IT Demand List</a>
                    <a href="CT1_Demand_List.php">CT1 Demand List</a>
                    <a href="capital_demand_list.php">Housing Demand List</a>
                    <a href="vehicle_demand_list.php">Vehicle Demand List</a>
                    <a href="share_demand_list.php">Share Demand List</a>
                    <a href="Under48_Demand_List.php">Under 48 Demand List</a>
                </div>
            </li>

            <li class="nav-item">
                <a href="#"><img src="Image/ird-logo.png" class="menu-icon" alt="IRD Logo"> Reports</a>
                <div class="dropdown-content">
                    <a href="tax_collection_report.php">Tax Collection</a>
                    <a href="#">TaxPayer Profile</a>
                </div>
            </li>

            <li class="nav-item">
                <a href="#"><img src="Image/ird-logo.png" class="menu-icon" alt="IRD Logo"> Setting</a>
                <div class="dropdown-content">
                    <a href="location.php">NRC Section</a>
                    <a href="#">Tax Rate Setting</a>
                    <?php if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin'): ?>
                    <a href="admin_setting.php">User Setting</a>
                    <?php endif; ?>
                    <a href="logout.php" style="color: #f35665 !important; font-weight: bold;">🚪 Logout</a>
                </div>
            </li>
            </ul>
            </li>
            <li class="logout-item">
                <strong style="color:white;">အသုံးပြုသူ - <?php echo isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'ဧည့်သည်'; ?></strong>
                <a href="logout.php" class="logout-btn">🚪 ထွက်မည် (Logout)</a>
            </li>
            
        </ul>
    </nav>
    
</header>
<div class="info-bar">
    <div><?php echo htmlspecialchars((string) $state_name); ?></div>
    <div>( <?php echo htmlspecialchars((string) $officer_name); ?> - <?php echo htmlspecialchars((string) $rank); ?> )</div>
    <div><?php echo htmlspecialchars((string) $township_name); ?>အခွန်ဦးစီးဌာနမှူးရုံး</div>
</div>


<div class="main-container">
    <div class="image-frame" id="f1"><img src="https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=400"></div>
    <div class="image-frame" id="f2"><img src="https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=400"></div>
    <div class="image-frame" id="f3"><img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400"></div>
    <div class="image-frame" id="f4"><img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400"></div>
    <div class="image-frame" id="f5"><img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400"></div>
    <div class="image-frame" id="f6"><img src="https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?w=400"></div>

    <div class="heading-box">
        <h1>Tax Calculation & Printing System</h1>
        <p>အခွန်ဆိုင်ရာတွက်ချက်မှုနှင့် အမှုတွဲထုတ်ယူခြင်းစနစ်</p>
    </div>
</div>

<div class="footer-marquee">
    <div class="marquee-text">
        *** Tax Calculation & Case Printing System သည် အခွန်တွက်ချက်မှုကို လွယ်ကူစွာတွက်ချက်နိုင်ရန်နှင့် အမူတွဲများကို လွယ်ကူစွာထုတ်ယူနိုင်ရန် ရေးဆွဲထားခြင်းဖြစ်သော်လည်း 
        အမှုတွဲများတည်ဆောက်ရာတွင် ပြည်တွင်းအခွန်များဦးစီးဌာနမှ ညွှန်ကြားချက်များနှင့်အညီ လိုအပ်သည့်သတ်မှတ်ပုံစံများကို အမှုတွဲတွင် ပြည့်စုံစွာတည်ဆောက်ထားရှိရန်လိုအပ်မည် ဖြစ်ပါသည်။
        ဤစနစ်ဖြင့်ထုတ်ယူသော အမှုတွဲပုံစံများသည် ပြည်တွင်းအခွန်များဦးစီးဌာနမှ သတ်မှတ်ထားသော အမှုတွဲတည်ဆောက်ပုံပါ သတ်မှတ်ချက် အပြည့်အစုံပါဝင်မည် မဟုတ်ကြောင်း အသိပေးအပ်ပါသည်။
        | Tax Calculation & Case Printing System v2.2026 ***
    </div>
</div>

<script>
    const frames = document.querySelectorAll('.image-frame');
    let angleOffset = 0;

 
function positionFrames() {
    const area = document.querySelector('.main-container');
    const width = area.clientWidth;
    const height = area.clientHeight;
    let frameW = 230;
    let frameH = 150;
    let radiusX = 400;
    let radiusY = 215;
    const fitX = width / 2 - 12;
    const fitY = height / 2 - 12;
    if (radiusX + frameW / 2 > fitX || radiusY + frameH / 2 > fitY) {
        const scale = Math.min(fitX / (radiusX + frameW / 2), fitY / (radiusY + frameH / 2));
        frameW = Math.max(72, Math.floor(230 * scale));
        frameH = Math.max(48, Math.floor(150 * scale));
        radiusX = Math.max(0, fitX - frameW / 2);
        radiusY = Math.max(0, fitY - frameH / 2);
    }

    frames.forEach((frame, index) => {
        frame.style.width = frameW + 'px';
        frame.style.height = frameH + 'px';
        const angle = (index * (360 / frames.length) + angleOffset) * (Math.PI / 180);
        const x = radiusX * Math.cos(angle);
        const y = radiusY * Math.sin(angle);
        frame.style.left = `calc(50% + ${x}px - ${frameW / 2}px)`;
        frame.style.top = `calc(50% + ${y}px - ${frameH / 2}px)`;
    });
}

window.addEventListener('resize', positionFrames);

    setInterval(() => {
        angleOffset += 60; 
        positionFrames();
    }, 10000);

    positionFrames();
</script>

</body>
</html>