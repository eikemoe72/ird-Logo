<?php
session_start(); 
include 'db_config.php';

/*if (!empty($_POST['edit_id'])) {
    echo "<pre>";
    print_r($_POST); // Form ကနေ ပါလာသမျှ ဒေတာအားလုံးကို ထုတ်ပြခိုင်းခြင်း
    echo "</pre>";
    die(); // ကုဒ်ကို ရှေ့ဆက်မသွားဘဲ ဒီမှာတင် ရပ်ခိုင်းလိုက်ခြင်း
}*/


// ၁။ ပို့လိုက်သော Data များကို လက်ခံခြင်း
$edit_id       = $_POST['edit_id'] ?? '';
$case_number   = $_POST['case_number'] ?? '';
$taxpayer_name = $_POST['taxpayer_name'] ?? '';
$taxYear       = $_POST['taxYear'] ?? ($_GET['taxYear'] ?? '');

// 💡 ဖြေရှင်းချက် - လက်ရှိ Login ဝင်ထားသူ၏ state_name နှင့် township_name ကို Database မှ တိုက်ရိုက်ယူခြင်း
$user_state = '';
$user_township = '';

if (isset($_SESSION['user_name'])) {
    $current_user = $_SESSION['user_name'];
    $loc_query = "SELECT state_name, township_name FROM user_register WHERE user_name = '$current_user'";
    $loc_result = $conn->query($loc_query);
    if ($loc_result && $loc_row = $loc_result->fetch_assoc()) {
        $user_state = $loc_row['state_name'];
        $user_township = $loc_row['township_name'];
    }
}

// ဂဏန်းများမှ ကော်မာဖြုတ်ရန် Function
function cleanNum($val) {
    if (empty($val)) return 0;
    
    // ၁။ မြန်မာဂဏန်းများကို အင်္ဂလိပ်ဂဏန်းသို့ ပြောင်းခြင်း
    $myan_num = array('၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉');
    $eng_num  = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    $val = str_replace($myan_num, $eng_num, (string)$val);
    
    // ၂။ ကော်မာ (,) များကို ဖြုတ်ခြင်း
    $clean = str_replace(',', '', $val); 
    
    // ၃။ ဂဏန်းအဖြစ် ပြောင်းလဲခြင်း
    return (float)$clean;
}

// မှတ်ပုံတင်အကွက် ၄ ခုကို 1/မကန(နိုင်)015808 ပုံစံ တစ်ကြောင်းတည်း စုခြင်း
function buildNrcNo($state, $letter, $type, $number) {
    $state  = trim((string)$state);
    $letter = trim((string)$letter);
    $type   = trim((string)$type);
    $number = trim((string)$number);

    if ($state === '' && $letter === '' && $type === '' && $number === '') {
        return '';
    }
    if ($state === '' && $letter === '' && $type === '' && strpos($number, '/') !== false) {
        return $number;
    }

    $state_display = ltrim($state, '0');
    if ($state !== '' && $state_display === '') {
        $state_display = '0';
    }

    return $state_display . '/' . $letter . $type . $number;
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $edit_id = $_POST['edit_id'] ?? '';
    $state_name   = $_POST['state_name'] ?? '';
    $township_name = $_POST['township_name'] ?? '';
    $case_number   = $_POST['case_number'] ?? '';
    $taxpayer_name = mysqli_real_escape_string($conn, $_POST['taxpayer_name'] ?? '');
    $businessType1 = $_POST['businessType1'] ?? '';
    $businessType2 = $_POST['businessType2'] ?? '';
    if (empty($taxYear)) { 
        $taxYear = $_POST['taxYear'] ?? ''; 
    }
    $it_select = mysqli_real_escape_string($conn, $_POST['it_select'] ?? '');

    $it_no         = $_POST['it_no'] ?? '';
    $ct1_select_real = mysqli_real_escape_string($conn, $_POST['ct1_select_real'] ?? '');

    $ct1_no_real = $_POST['ct1_no_real'] ?? '';
    $ct2_select_real = mysqli_real_escape_string($conn, $_POST['ct2_select_real'] ?? '');

    $ct2_no_real = $_POST['ct2_no_real'] ?? '';

    $nrc_no = mysqli_real_escape_string($conn, buildNrcNo(
        $_POST['state_code'] ?? '',
        $_POST['letter_code'] ?? '',
        $_POST['national_name'] ?? '',
        $_POST['nrc_no'] ?? ''
    ));


    $officer_name = mysqli_real_escape_string($conn, $_POST['officer_name'] ?? ''); 
    $rank_        = mysqli_real_escape_string($conn, $_POST['rank_'] ?? '');
    $region       = mysqli_real_escape_string($conn, $_POST['region'] ?? '');
    
    $declaredIncome1 = cleanNum($_POST['declaredIncome1'] ?? 0);
    $declaredCT1     = cleanNum($_POST['declaredCT1'] ?? 0);
    $declaredCT2     = cleanNum($_POST['declaredCT2'] ?? 0);
    $address       = mysqli_real_escape_string($conn, $_POST['address'] ?? '');

    $ph_no          = mysqli_real_escape_string($conn, $_POST['ph_no'] ?? '');
    $email          = mysqli_real_escape_string($conn, $_POST['email'] ?? $_POST['email2'] ?? '');

    // --- (၂) မှတ်တမ်းဟောင်းများ ---
    $rowYear1 = $_POST['rowYear1'] ?? ''; 
    $income1 = cleanNum($_POST['income'] ?? $_POST['income1'] ?? 0); // income ကို အရင်စစ်ပါ
    $income_tax1 = cleanNum($_POST['income_tax'] ?? $_POST['income_tax1'] ?? 0);
    $sale_income1 = cleanNum($_POST['sale_income'] ?? $_POST['sale_income1'] ?? 0);
    $ct1 = cleanNum($_POST['ct'] ?? $_POST['ct1'] ?? 0);

    $rowYear2 = $_POST['rowYear2'] ?? ''; 
    $income2 = cleanNum($_POST['income2'] ?? 0);
    $income_tax2 = cleanNum($_POST['income_tax2'] ?? 0); 
    $sale_income2 = cleanNum($_POST['sale_income2'] ?? 0); 
    $ct2 = cleanNum($_POST['ct2'] ?? 0);

    $rowYear3 = $_POST['rowYear3'] ?? ''; 
    $income3 = cleanNum($_POST['income3'] ?? 0);
    $income_tax3 = cleanNum($_POST['income_tax3'] ?? 0); 
    $sale_income3 = cleanNum($_POST['sale_income3'] ?? 0); 
    $ct3 = cleanNum($_POST['ct3'] ?? 0);

    // --- (၃) CT & Sales ---
    $salesAmount1 = cleanNum($_POST['salesAmount1'] ?? 0); 
    $ct1tax = cleanNum($_POST['taxAmount1'] ?? $_POST['ct1tax'] ?? 0);
    $rule42_1 = cleanNum($_POST['rule42_1'] ?? 0);
    $afterRuler1 = cleanNum($_POST['afterRuler1'] ?? 0);
    $advanceTax1 = cleanNum($_POST['advanceTax1'] ?? 0);
    $netTax1 = cleanNum($_POST['netTax1'] ?? 0);
    $penalty1 = cleanNum($_POST['penalty1'] ?? 0);
    $totalTax1 = cleanNum($_POST['totalTax1'] ?? 0); 
    $paidTax1 = cleanNum($_POST['paidTax1'] ?? 0);
    $ct1_chalan_no = cleanNum($_POST['ct1_chalan_no'] ?? 0);
    $date1 = !empty($_POST['date1']) ? "'" . $_POST['date1'] . "'" : "NULL";
    
    $salesAmount2 = cleanNum($_POST['salesAmount2'] ?? 0); 
    $ct2tax = cleanNum($_POST['taxAmount2'] ?? $_POST['ct2tax'] ?? 0);
    $rule42_2 = cleanNum($_POST['rule42_2'] ?? 0);
    $afterRuler2 = cleanNum($_POST['afterRuler2'] ?? 0); 
    $advanceTax2 = cleanNum($_POST['advanceTax2'] ?? 0); 
    $netTax2 = cleanNum($_POST['netTax2'] ?? 0);
    $penalty2 = cleanNum($_POST['penalty2'] ?? 0);
    $totalTax2 = cleanNum($_POST['totalTax2'] ?? 0); 
    $paidTax2 = cleanNum($_POST['paidTax2'] ?? 0);
    $ct2_chalan_no = cleanNum($_POST['ct2_chalan_no'] ?? 0);
    $date2 = !empty($_POST['date2']) ? "'" . $_POST['date2'] . "'" : "NULL";

    // --- (၄) Other Costs & Profits ---
    $totalSales = cleanNum($_POST['totalSales'] ?? 0);
    $minusCTInput = cleanNum($_POST['minusCTInput'] ?? 0);
    $netSales = cleanNum($_POST['netSales'] ?? 0);
    $otherIncomeTitle = mysqli_real_escape_string($conn, $_POST['otherIncomeTitle'] ?? '');
    $otherIncomeVal = cleanNum($_POST['otherIncomeVal'] ?? 0);
    $taxableSales = cleanNum($_POST['taxableSales'] ?? 0);
    $purchaseCost = cleanNum($_POST['purchaseCost'] ?? 0);
    $otherDirectCost = cleanNum($_POST['otherDirectCost'] ?? 0);
    $directGeneralCost = cleanNum($_POST['directGeneralCost'] ?? 0);
    $totalDirectCost = cleanNum($_POST['totalDirectCost'] ?? 0);
    $grossProfit = cleanNum($_POST['grossProfit'] ?? 0);
    $salaryCost = cleanNum($_POST['salaryCost'] ?? 0);
    $licence = cleanNum($_POST['licence'] ?? 0);
    $socialWelfare = cleanNum($_POST['socialWelfare'] ?? 0);
    $shopRent = cleanNum($_POST['shopRent'] ?? 0);
    $electricity = cleanNum($_POST['electricity'] ?? 0);
    $adminGeneralCost = cleanNum($_POST['adminGeneralCost'] ?? 0);
    $totalAdminCost = cleanNum($_POST['totalAdminCost'] ?? 0);
    $netProfit = cleanNum($_POST['netProfit'] ?? 0);

    // --- (၅) Reliefs & Final ---
    $basicRelief = cleanNum($_POST['basicRelief'] ?? 0);
    $spouse_relief = cleanNum($_POST['spouse_relief'] ?? 0);
    $parent_relief = cleanNum($_POST['parent_relief'] ?? 0);
    $child_relief = cleanNum($_POST['child_relief'] ?? 0);
    $totalRelief = cleanNum($_POST['totalRelief'] ?? 0);
    $finalTaxableIncome = cleanNum($_POST['finalTaxableIncome'] ?? 0);
    $payableIncomeTax = cleanNum($_POST['payableIncomeTax'] ?? 0);
    $advancePaidTax   = cleanNum($_POST['advancePaidTax'] ?? 0);
    $finalBalanceTax  = cleanNum($_POST['finalBalanceTax'] ?? 0);
    $itpanaty = cleanNum($_POST['itpanaty'] ?? $_POST['itpenalty'] ?? 0);
    $taxpanaty = cleanNum($_POST['taxpanaty'] ?? $_POST['taxpenalty'] ?? 0);
    $taxpanatyPaid = cleanNum($_POST['taxpanatyPaid'] ?? 0);
    $itchalanNo = $_POST['itchalanNo'] ?? '';

    // Dates
    $itchalanDate = !empty($_POST['itchalanDate']) ? "'" . $_POST['itchalanDate'] . "'" : "NULL";
    $orderDate = !empty($_POST['orderDate']) ? "'" . $_POST['orderDate'] . "'" : "NULL";
    $appointmentDate = !empty($_POST['appointmentDate']) ? "'" . $_POST['appointmentDate'] . "'" : "NULL";
    $visitedDate = !empty($_POST['visitedDate']) ? "'" . $_POST['visitedDate'] . "'" : "NULL";
    
    // စစ်ဆေးမှုပြုလုပ်ရန်အတွက် မူရင်း POST တန်ဖိုးများကို ယူထားပါသည်
    $raw_itDemandDate = $_POST['itDemandDate'] ?? '';
    $raw_ct1DemandDate = $_POST['ct1DemandDate'] ?? '';
    $raw_ct2DemandDate = $_POST['ct2DemandDate'] ?? '';

    // -------------------------------------------------------------------------
    // 🎯 တောင်းဆိုထားသော ဝါနင်း (Validation) စစ်ဆေးချက်အပိုင်း
    // -------------------------------------------------------------------------
    if (empty($raw_itDemandDate)) {
        echo "<script>alert('itDemandDate ထည့်သွင်းရန် လိုအပ်ပါသည်!'); history.back();</script>";
        exit();
    }

    if (!empty($ct1_select_real) && empty($raw_ct1DemandDate)) {
        echo "<script>alert('ct1_select_real ဒေတာရှိသဖြင့် ct1DemandDate ထည့်သွင်းရန် လိုအပ်ပါသည်!'); history.back();</script>";
        exit();
    }

    if (!empty($ct2_select_real) && empty($raw_ct2DemandDate)) {
        echo "<script>alert('ct2_select_real ဒေတာရှိသဖြင့် ct2DemandDate ထည့်သွင်းရန် လိုအပ်ပါသည်!'); history.back();</script>";
        exit();
    }
    // -------------------------------------------------------------------------

    $itDemandDate = !empty($raw_itDemandDate) ? "'" . $raw_itDemandDate . "'" : "NULL";
    $ct1DemandDate = !empty($raw_ct1DemandDate) ? "'" . $raw_ct1DemandDate . "'" : "NULL";
    $ct2DemandDate = !empty($raw_ct2DemandDate) ? "'" . $raw_ct2DemandDate . "'" : "NULL";

    $itDemandNo = $_POST['itDemandNo'] ?? '';
    $ct1DemandNo = $_POST['ct1DemandNo'] ?? '';
    $ct2DemandNo = $_POST['ct2DemandNo'] ?? '';
    $summary        = mysqli_real_escape_string($conn, $_POST['summary'] ?? $_POST['summary2'] ?? '');
    $appraisal      = mysqli_real_escape_string($conn, $_POST['appraisal'] ?? $_POST['appraisal2'] ?? '');


   if (!empty($edit_id)) {
    // ၂။ SQL Query တည်ဆောက်ခြင်း (ရက်စွဲများနှင့် စာသားများ အားလုံး ကွက်တိညှိပြီးသား)
    $sql = "UPDATE regular_data SET
        state_name = '$user_state', 
        township_name = '$user_township',   
        case_number = '$case_number',   
        taxpayer_name = '$taxpayer_name',   
        businessType1 = '$businessType1',   
        businessType2 = '$businessType2',   
        taxYear = '$taxYear', 
        it_select = '$it_select',   
        it_no = '$it_no',   
        ct1_select_real = '$ct1_select_real',   
        ct1_no_real = '$ct1_no_real',   
        ct2_select_real = '$ct2_select_real',   
        ct2_no_real = '$ct2_no_real',
        nrc_no = '$nrc_no',
        officer_name = '$officer_name', 
        rank_ = '$rank_',   
        region = '$region', 
        declaredIncome1 = $declaredIncome1, 
        declaredCT1 = $declaredCT1, 
        declaredCT2 = $declaredCT2, 
        address = '$address',   
        ph_no = '$ph_no',   
        email = '$email',  -- 🎯 အမှန်ကန်ဆုံး Variable နာမည် ညှိထားပါသည်
        rowYear1 = '$rowYear1',     
        income1 = $income1, 
        income_tax1 = $income_tax1, 
        sale_income1 = $sale_income1,   
        ct1 = $ct1, 
        rowYear2 = '$rowYear2',     
        income2 = $income2,     
        income_tax2 = $income_tax2,     
        sale_income2 = $sale_income2,   
        ct2 = $ct2,     
        rowYear3 = '$rowYear3', 
        income3 = $income3,     
        income_tax3 = $income_tax3,     
        sale_income3 = $sale_income3,   
        ct3 = $ct3, 
        salesAmount1 = $salesAmount1,   
        ct1tax = $ct1tax,   
        rule42_1 = $rule42_1,   
        afterRuler1 = $afterRuler1, 
        advanceTax1 = $advanceTax1, 
        netTax1 = $netTax1, 
        penalty1 = $penalty1,   
        totalTax1 = $totalTax1, 
        paidTax1 = $paidTax1,   
        ct1_chalan_no = $ct1_chalan_no,     
        date1 = $date1, 
        salesAmount2 = $salesAmount2,   
        ct2tax = $ct2tax,   
        rule42_2 = $rule42_2,   
        afterRuler2 = $afterRuler2,     
        advanceTax2 = $advanceTax2,     
        netTax2 = $netTax2,     
        penalty2 = $penalty2,   
        totalTax2 = $totalTax2,     
        paidTax2 = $paidTax2,   
        ct2_chalan_no = $ct2_chalan_no,     
        date2 = $date2,
        totalSales = $totalSales,   
        minusCTInput = $minusCTInput,   
        netSales = $netSales,
        otherIncomeTitle = '$otherIncomeTitle', 
        otherIncomeVal = $otherIncomeVal,   
        taxableSales = $taxableSales,   
        purchaseCost = $purchaseCost,   
        otherDirectCost = $otherDirectCost,     
        directGeneralCost = $directGeneralCost,     
        totalDirectCost = $totalDirectCost,     
        grossProfit = $grossProfit, 
        salaryCost = $salaryCost,   
        licence = $licence,     
        socialWelfare = $socialWelfare,     
        shopRent = '$shopRent',   -- 🎯 စာသားဖြစ်နိုင်သဖြင့် Quote အုပ်ပေးထားပါသည်
        electricity = $electricity,     
        adminGeneralCost = $adminGeneralCost,   
        totalAdminCost = $totalAdminCost,   
        netProfit = $netProfit, 
        basicRelief = $basicRelief,     
        spouse_relief = $spouse_relief,     
        parent_relief = $parent_relief,     
        child_relief = $child_relief,   
        totalRelief = $totalRelief,     
        finalTaxableIncome = $finalTaxableIncome,   
        payableIncomeTax = $payableIncomeTax,   
        advancePaidTax = $advancePaidTax,   
        finalBalanceTax = $finalBalanceTax, 
        itpanaty = $itpanaty,   
        taxpanaty = $taxpanaty, 
        taxpanatyPaid = $taxpanatyPaid, 
        itchalanNo = '$itchalanNo', 
        itchalanDate = $itchalanDate,   
        orderDate = $orderDate, 
        appointmentDate = $appointmentDate, 
        visitedDate = $visitedDate, 
        itDemandNo = '$itDemandNo',     
        itDemandDate = $itDemandDate,   
        ct1DemandNo = '$ct1DemandNo',   
        ct1DemandDate = $ct1DemandDate, 
        ct2DemandDate = $ct2DemandDate, 
        ct2DemandNo = '$ct2DemandNo',   
        summary = '$summary',
        appraisal = '$appraisal'
        WHERE id = " . intval($edit_id);
        

    if ($conn->query($sql) === TRUE) {
        $return_page = $_POST['return_page'] ?? '';
        if ($return_page !== 'CT1_Demand_List.php') {
            $return_page = 'IT_Demand_List.php';
        }
        echo "<script>alert('အောင်မြင်စွာ ပြင်ဆင်ပြီးပါပြီ'); window.location.href='" . $return_page . "';</script>";
    } else {
        echo "Update Error: " . $conn->error;
    }

} else {
    // --- (B) New Entry Mode: အသစ်သိမ်းမည့်အပိုင်း (ဒါလေးထည့်ပေးရပါမယ်) ---
    $sql = "INSERT INTO regular_data (
            state_name, township_name,
            case_number,taxpayer_name,businessType1,businessType2,taxYear,it_select,it_no,ct1_select_real, ct1_no_real,
            ct2_select_real,ct2_no_real, nrc_no, officer_name, rank_, region, address, ph_no, email,rowYear1,rowYear2,
            rowYear3, declaredIncome1, declaredCT1, declaredCT2,income1, income_tax1, sale_income1, ct1,
            income2,income_tax2, sale_income2, ct2, income3, income_tax3,sale_income3, ct3, 
            salesAmount1, ct1tax,rule42_1, afterRuler1, advanceTax1, netTax1, penalty1, totalTax1, paidTax1,
            ct1_chalan_no, date1,salesAmount2, ct2tax, rule42_2, afterRuler2,advanceTax2, netTax2,penalty2,
            totalTax2,paidTax2, ct2_chalan_no, date2, totalSales, minusCTInput, netSales,
            otherIncomeTitle, otherIncomeVal,taxableSales, purchaseCost, otherDirectCost, 
            directGeneralCost, totalDirectCost, grossProfit,salaryCost, licence, socialWelfare,shopRent,
            electricity, adminGeneralCost, totalAdminCost,netProfit, basicRelief, spouse_relief,
            parent_relief, child_relief, totalRelief, finalTaxableIncome, payableIncomeTax, advancePaidTax,
            finalBalanceTax,itpanaty, taxpanaty,taxpanatyPaid,itchalanDate,orderDate, appointmentDate, 
            visitedDate,itDemandDate,ct1DemandDate, ct2DemandDate, itchalanNo, itDemandNo, ct1DemandNo, ct2DemandNo,summary, appraisal
        ) VALUES (
            '$user_state', '$user_township',
            '$case_number','$taxpayer_name','$businessType1','$businessType2','$taxYear','$it_select','$it_no','$ct1_select_real', '$ct1_no_real',
            '$ct2_select_real','$ct2_no_real', '$nrc_no', '$officer_name', '$rank_', '$region', '$address', '$ph_no', '$email','$rowYear1','$rowYear2',
            '$rowYear3', '$declaredIncome1', '$declaredCT1', '$declaredCT2','$income1', '$income_tax1', '$sale_income1', '$ct1',
            '$income2','$income_tax2', '$sale_income2', '$ct2', '$income3', '$income_tax3','$sale_income3', '$ct3', 
            '$salesAmount1', '$ct1tax','$rule42_1', '$afterRuler1', '$advanceTax1', '$netTax1', '$penalty1', '$totalTax1', '$paidTax1',
            '$ct1_chalan_no', $date1,'$salesAmount2', '$ct2tax', '$rule42_2', '$afterRuler2','$advanceTax2', '$netTax2','$penalty2',
            '$totalTax2','$paidTax2', '$ct2_chalan_no', $date2, '$totalSales', '$minusCTInput', '$netSales',
            '$otherIncomeTitle', '$otherIncomeVal','$taxableSales', '$purchaseCost', '$otherDirectCost', 
            '$directGeneralCost', '$totalDirectCost', '$grossProfit','$salaryCost', '$licence', '$socialWelfare','$shopRent',
            '$electricity', '$adminGeneralCost', '$totalAdminCost','$netProfit', '$basicRelief', '$spouse_relief',
            '$parent_relief', '$child_relief', '$totalRelief', '$finalTaxableIncome', '$payableIncomeTax', '$advancePaidTax',
            '$finalBalanceTax','$itpanaty', '$taxpanaty','$taxpanatyPaid',$itchalanDate,$orderDate, $appointmentDate, 
            $visitedDate,$itDemandDate,$ct1DemandDate, $ct2DemandDate, '$itchalanNo', '$itDemandNo', '$ct1DemandNo', '$ct2DemandNo','$summary', '$appraisal'
        )";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('သိမ်းဆည်းပြီးပါပြီ'); window.location.href='IT_Demand_List.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
}

$conn->close();
?>