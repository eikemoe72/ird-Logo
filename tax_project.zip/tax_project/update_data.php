<?php
include 'db_config.php';

// ဂဏန်းများမှ ကော်မာဖယ်ထုတ်ရန် Function
function cleanNum($val) {
    if (empty($val)) return 0;
    $clean = str_replace(',', '', $val);
    return round((float)$clean);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Hidden field ကလာတဲ့ ID ကို အရင်ယူပါ
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    if ($id == 0) {
        echo "Error: ID မရှိပါသဖြင့် ပြင်ဆင်၍မရပါ။";
        exit;
    }

    // --- (၁) အခြေခံအချက်အလက်များ ---
    $case_number = $_POST['case_number'] ?? '';
    $taxpayer_name = $_POST['taxpayer_name'] ?? '';
    $businessType1 = $_POST['businessType1'] ?? '';
    $businessType2 = $_POST['businessType2'] ?? '';
    $taxYear = $_POST['taxYear'] ?? '';
    $rank_ = $_POST['rank_'] ?? '';
    
    // --- (၂) တွက်ချက်မှုဆိုင်ရာ ဂဏန်းများ ---
    $salesAmount1 = cleanNum($_POST['salesAmount1'] ?? 0);
    $salesAmount2 = cleanNum($_POST['salesAmount2'] ?? 0);
    $otherIncomeVal = cleanNum($_POST['otherIncomeVal'] ?? 0);
    $minusCTInput = cleanNum($_POST['minusCTInput'] ?? 0);
    $taxableSales = cleanNum($_POST['taxableSales'] ?? 0);
    $purchaseCost = cleanNum($_POST['purchaseCost'] ?? 0);
    $netProfit = cleanNum($_POST['netProfit'] ?? 0);
    
    $otherIncomeTitle = $_POST['otherIncomeTitle'] ?? '';

    // --- (၃) သက်သာခွင့်နှင့် အခွန်များ ---
    $basicRelief = cleanNum($_POST['basicRelief'] ?? 0);
    $spouse_relief = cleanNum($_POST['spouse_relief'] ?? 0);
    $parent_relief = cleanNum($_POST['parent_relief'] ?? 0);
    $child_relief = cleanNum($_POST['child_relief'] ?? 0);
    $finalTaxableIncome = cleanNum($_POST['finalTaxableIncome'] ?? 0);
    $payableIncomeTax = cleanNum($_POST['payableIncomeTax'] ?? 0);
    $itpanaty = cleanNum($_POST['itpanaty'] ?? 0);

    // --- (၄) Demand No. နှင့် Date များ ---
    $itDemandNo = $_POST['itDemandNo'] ?? '';
    $itDemandDate = !empty($_POST['itDemandDate']) ? $_POST['itDemandDate'] : NULL;

    // --- (၅) SQL UPDATE Query ---
    $sql = "UPDATE regular_data SET 
            -- (၁) အခြေခံ အချက်အလက်များ
            case_number = '$case_number',
            taxpayer_name = '$taxpayer_name',
            businessType1 = '$businessType1',
            businessType2 = '$businessType2',
            taxYear = '$taxYear',
            it_select = '$it_select',
            it_no = '$it_no',
            ct1_select_real = '$ct1_select_real',
            ct1_no_real = '$ct1_no_real',
            ct2_select_real = '$ct2_select_real',
            ct2_no_real = '$ct2_no_real',
            officer_name = '$officer_name',
            rank_ = '$rank_',
            region = '$region',
            address = '$address',
            ph_no = '$ph_no',
            email = '$email',

            rowYear1='$rowYear1', 
            rowYear2='$rowYear2', 
            rowYear3='$rowYear3',


            -- (၂) တွက်ချက်မှုဆိုင်ရာ ဂဏန်းများ (Single Quote မပါရပါ)
            declaredIncome1 = $declaredIncome1,
            declaredCT1 = $declaredCT1,
            declaredCT2 = $declaredCT2,
            income1 = $income1,
            income_tax1 = $income_tax1,
            sale_income1 = $sale_income1,
            ct1 = $ct1,
            income2 = $income2,
            income_tax2 = $income_tax2,
            sale_income2 = $sale_income2,
            ct2 = $ct2,
            income3 = $income3,
            income_tax3 = $income_tax3,
            sale_income3 = $sale_income3,
            ct3 = $ct3,

            -- (၃) CT & Sales ပိုင်း (အခုမှ ထည့်သွင်းမည့် Column များ)
            salesAmount1 = $salesAmount1,
            ct1tax = $ct1tax,
            rule42_1 = $rule42_1,
            afterRuler1 = $afterRuler1,
            advanceTax1 = $advanceTax1,
            netTax1 = $netTax1,
            penalty1 = $penalty1,
            totalTax1 = $totalTax1,
            paidTax1 = $paidTax1,
            balanceTax1 = $balanceTax1,
            
            salesAmount2 = $salesAmount2,
            ct2tax = $ct2tax,
            rule42_2 = $rule42_2,
            afterRuler2 = $afterRuler2,
            advanceTax2 = $advanceTax2,
            netTax2 = $netTax2,
            penalty2 = $penalty2,
            totalTax2 = $totalTax2,
            paidTax2 = $paidTax2,
            balanceTax2 = $balanceTax2,

            totalSales = $totalSales,
            minusCTInput = $minusCTInput,
            netSales = $netSales,
            otherIncomeVal = $otherIncomeVal,
            taxableSales = $taxableSales,
            purchaseCost = $purchaseCost,
            otherDirectCost = $otherDirectCost,
            directGeneralCost = $directGeneralCost,
            totalDirectCost = $totalDirectCost,
            grossProfit = $grossProfit,
            salaryCost = $salaryCost,
            licence = $licence,
            socialWelfare = $socialWelfare,
            shopRent = $shopRent,
            electricity = $electricity,
            adminGeneralCost = $adminGeneralCost,
            totalAdminCost = $totalAdminCost,
            netProfit = $netProfit,

            -- (၅) သက်သာခွင့်နှင့် အပြီးသတ် အခွန်များ
            basicRelief = $basicRelief,
            spouse_relief = $spouse_relief,
            parent_relief = $parent_relief,
            child_relief = $child_relief,
            totalRelief = $totalRelief,
            finalTaxableIncome = $finalTaxableIncome,
            payableIncomeTax = $payableIncomeTax,
            advancePaidTax = $advancePaidTax,
            finalBalanceTax = $finalBalanceTax,
            itpanaty = $itpanaty,
            taxpanaty = $taxpanaty,
            taxpanatyPaid = $taxpanatyPaid,

            -- (၆) ရက်စွဲများ (PHP ထဲတွင် Quote အုပ်ထားပြီးသားမို့ ဒီအတိုင်းသုံးပါ)
            date1 = $date1,
            date2 = $date2,
            itchalanDate = $itchalanDate,
            orderDate = $orderDate,
            appointmentDate = $appointmentDate,
            visitedDate = $visitedDate,
            itDemandDate = $itDemandDate,
            ct1DemandDate = $ct1DemandDate,
            ct2DemandDate = $ct2DemandDate,

            -- (၇) စာသားနှင့် မှတ်ချက်များ (Single Quote အုပ်ပေးပါ)
            itchalanNo = '$itchalanNo',
            itDemandNo = '$itDemandNo',
            ct1DemandNo = '$ct1DemandNo',
            ct2DemandNo = '$ct2DemandNo',
            otherIncomeTitle = '$otherIncomeTitle',
            summary = '$summary',
            appraisal = '$appraisal'

            WHERE id = $id";

    // --- (၆) Execute and Redirect ---
    if ($conn->query($sql) === TRUE) {
        echo "<script>
                alert('ပြင်ဆင်မှု အောင်မြင်ပါသည်။');
                window.location.href = 'IT_Demand_List.php';
              </script>";
    } else {
        echo "Error updating record: " . $conn->error;
        echo "<br><br>Query: " . $sql;
    }

    $conn->close();
} else {
    header("Location: IT_Demand_List.php");
    exit;
}

?>