<?php
include 'db_config.php';
header('Content-Type: application/json');

if (isset($_GET['state'])) {
    $state = $_GET['state'];
    
    // table structure အရ state_name ဟု ပြောင်းလဲအသုံးပြုထားပါသည်
    $stmt = $conn->prepare("SELECT township_name, town_name FROM locations WHERE state_name = ?");
    
    if (!$stmt) {
        echo json_encode(["error" => $conn->error]);
        exit();
    }

    $stmt->bind_param("s", $state);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $locations = [];
    while ($row = $result->fetch_assoc()) {
        $locations[] = [
            'township' => $row['township_name'],
            'city' => $row['town_name']
        ];
    }
    
    echo json_encode($locations);
    exit();
}
?>