<?php
header('Content-Type: application/json');
include 'db_config.php';

$min = intval($_GET['min_case'] ?? 0);
$max = intval($_GET['max_case'] ?? 0);

// 🎯 အမှုတွဲနံပါတ် '1/2026' ထဲမှ ရှေ့က '1' ကို စနစ်တကျ ဖြတ်ထုတ်၍ BETWEEN စစ်သော SQL စနစ်
$sql = "SELECT * FROM sharedata 
        WHERE CAST(SUBSTRING_INDEX(case_number, '/', 1) AS UNSIGNED) BETWEEN $min AND $max 
        ORDER BY CAST(SUBSTRING_INDEX(case_number, '/', 1) AS UNSIGNED) ASC";

$result = $conn->query($sql);
$data = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $data[] = [
            'case_number'   => $row['case_number'] ?? '',
            'tax_year'      => $row['tax_year'] ?? '',
            'officer_name'  => $row['officer_name'] ?? '',
            'region'        => $row['region'] ?? '',
            'state_name'    => $row['state_name'] ?? '',
            'township_name' => $row['township_name'] ?? '',
            'taxpayer_name' => $row['taxpayer_name'] ?? '',
            'nrc_no'        => $row['nrc_no'] ?? '',
            'gir_type'      => $row['gir_type'] ?? '',
            'gir_no'        => $row['gir_no'] ?? '',
            'address'       => str_replace(array("\r", "\n"), ' ', $row['address'] ?? ''),
            'business_type' => $row['business_type'] ?? '',
            'company_name'  => $row['company_name'] ?? '',
            'share_date'    => $row['share_date'] ?? '',
            'paid'          => $row['paid'] ?? '',
            'share_value'   => $row['share_value'] ?? 0,
            'paid_share_value' => $row['paid_share_value'] ?? 0,
            'valuation_value'  => $row['valuation_value'] ?? 0,
            'allowable_expenses' => $row['allowable_expenses'] ?? 0, 
            'taxable_income'     => $row['taxable_income'] ?? 0,
            'income_tax'         => $row['income_tax'] ?? 0,
            'advance_tax'        => $row['advance_tax'] ?? 0,
            'tax_to_pay'         => $row['tax_to_pay'] ?? 0,
            'penalty_tax'        => $row['penalty_tax'] ?? 0,
            'total_tax'          => $row['total_tax'] ?? 0,
            'paid_amount'        => $row['paid_amount'] ?? 0,
            'chalan_no'          => $row['chalan_no'] ?? '',
            'chalan_date'        => $row['chalan_date'] ?? ''
        ];
    }
}

// 🎯 ဒေတာမရှိလျှင်လည်း JSON Format အမှန် (Empty Array) ပြန်ပေးခြင်း
echo json_encode($data, JSON_UNESCAPED_UNICODE);
?>