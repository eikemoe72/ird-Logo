<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ၁။ အစ်ကို့ရဲ့ ဒေတာဘေ့စ် Config ဖိုင်ကို ဤနေရာတွင်လည်း လှမ်းပြီး Include လုပ်ပါသည်
include_once 'db_config.php'; 

// ချိတ်ဆက်မှု အဆင်မပြေပါက Error ပြရန်
if ($conn->connect_error) {
    die("Database ချိတ်ဆက်မှု ပျက်ပြားပါသည် - " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// ၂။ ရွေးထားသော အတန်းတစ်ခုကို ဖျက်ခြင်း
if (isset($_POST['btn_delete'])) {
    $id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
    $q = isset($_POST['q']) ? trim($_POST['q']) : '';
    $back = 'location.php' . ($q !== '' ? '?q=' . urlencode($q) : '');

    if ($id > 0 && $conn->query("DELETE FROM locations WHERE id = $id") === TRUE && $conn->affected_rows > 0) {
        $msg = "ရွေးထားသော အတန်းကို ဖျက်ပြီးပါပြီ။";
    } else {
        $msg = "ဖျက်၍ မရပါ။";
    }

    echo "<script>
            alert('$msg');
            window.location.href = '$back';
          </script>";
    $conn->close();
    exit;
}

// ၃။ Form တင်လာခြင်း ရှိမရှိ စစ်ဆေးခြင်း
if (isset($_POST['btn_save'])) {
    
    // Hidden Field မှ ID ကို လက်ခံခြင်း
    $id = isset($_POST['id']) ? trim($_POST['id']) : '';

    // Form မှ အချက်အလက်များကို လက်ခံပြီး SQL Injection ကာကွယ်ခြင်း
    $state_name    = mysqli_real_escape_string($conn, $_POST['state_name']);
    $state_code    = mysqli_real_escape_string($conn, $_POST['state_code']);
    $township_name = mysqli_real_escape_string($conn, $_POST['township_name']);
    $township_code = mysqli_real_escape_string($conn, $_POST['township_code']);
    $town_name     = mysqli_real_escape_string($conn, $_POST['town_name']);
    $town_code     = mysqli_real_escape_string($conn, $_POST['town_code']);
    
    // letter_code ကွက်လပ် အလွတ်ဖြစ်နေပါက Database ထဲတွင် NULL ဟု သိမ်းဆည်းရန်
    $letter_code   = isset($_POST['letter_code']) && trim($_POST['letter_code']) !== "" 
                     ? "'" . mysqli_real_escape_string($conn, $_POST['letter_code']) . "'" 
                     : "NULL";

    // ၃။ INSERT သို့မဟုတ် UPDATE လုပ်မည့် Logic ကို ခွဲခြားခြင်း
    if (!empty($id)) {
        // ID ပါလာသဖြင့် ပြင်ဆင်ခြင်းစနစ် (UPDATE) လုပ်ဆောင်မည်
        $sql = "UPDATE locations SET 
                    state_name    = '$state_name',
                    state_code    = '$state_code',
                    township_name = '$township_name',
                    township_code = '$township_code',
                    town_name     = '$town_name',
                    town_code     = '$town_code',
                    letter_code   = $letter_code
                WHERE id = '$id'";
                
        $msg = "တည်နေရာအချက်အလက်ကို အောင်မြင်စွာ ပြင်ဆင်ပြီးပါပြီ။";
    } else {
        // ID မပါလာသဖြင့် အသစ်ထည့်ခြင်းစနစ် (INSERT) လုပ်ဆောင်မည်
        $sql = "INSERT INTO locations (state_name, state_code, township_name, township_code, town_name, town_code, letter_code) 
                VALUES ('$state_name', '$state_code', '$township_name', '$township_code', '$town_name', '$town_code', $letter_code)";
                
        $msg = "တည်နေရာအချက်အလက်အသစ်ကို အောင်မြင်စွာ ထည့်သွင်းပြီးပါပြီ။";
    }

    // ၄။ Query ကို Run ပြီး ရလဒ်ပြသခြင်း
    if ($conn->query($sql) === TRUE) {
        $back = !empty($id)
            ? 'location.php?edit_id=' . urlencode($id)
            : 'location.php';
        echo "<script>
                alert('$msg');
                window.location.href = '$back'; 
              </script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>